# Banco externo de desarrollo — NO APRUEBA UNA ACTUALIZACIÓN

M1: 19/20 conversiones; 09 agota 480 s también en el reintento aislado.
M2 deduplica intentos rechazados y supera09 con el mismo límite: ver JSON reales.
El banco conserva20 geometrías de referencia, los STL, salidas actuales y registros.
Los resultados de coherencia CAD exacta del candidato se documentan en el informe
principal: Bancada, pinza y Lego 4×2 fallan. No se publica R8.

Las métricas independientes se enlazan sólo después de comparar todo DATA y
FILE_SCHEMA.17 tiene 1748 comprobaciones de material completas sin discrepancias;
19 tiene evaluación CAD completa con 1689 puntos sin discrepancias.11y16 conservan
su calibración de entrada insuficiente: no son ensayos globales plenamente aprobados.

Los tiempos de prueba están en los resultados. Los scripts históricos guardan
el protocolo original; no se presentan como instaladores ni como conversión
WebAssembly. Los límites geométricos no se han ampliado.
