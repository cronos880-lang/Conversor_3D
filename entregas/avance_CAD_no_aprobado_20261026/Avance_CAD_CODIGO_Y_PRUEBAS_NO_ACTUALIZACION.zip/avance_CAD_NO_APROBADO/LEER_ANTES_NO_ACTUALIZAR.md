# NO ES UNA ACTUALIZACIÓN DEL PROGRAMA

No se publica R8. Conserva tu instalación actual. Este paquete contiene código
de desarrollo y resultados de pruebas: no lo copies sobre el programa de uso.

El rótulo R8 dentro de las fuentes identifica el candidato interno que se estaba
ensayando. No significa que exista una versión R8 aprobada. Se mantienen las
fuentes completas para revisar y reproducir el trabajo, no para recomendar su uso.

La comprobación CAD exacta falla en Bancada, pinza y Lego 4×2. Pasar el arranque,
el flujo de navegador, las distancias muestreadas o el mallado cerrado no basta
para aprobar esos STEP. Lee INFORME_PROGRESO.md y ESTADO_ACEPTACION.json.

M1 es el código congelado sometido a 148 pruebas y a la regresión completa.
M2 añade la corrección de intentos repetidos: ver resultados y alcance en el informe.
Ninguno se presenta como actualización aprobada ni cambia R7 o main.
