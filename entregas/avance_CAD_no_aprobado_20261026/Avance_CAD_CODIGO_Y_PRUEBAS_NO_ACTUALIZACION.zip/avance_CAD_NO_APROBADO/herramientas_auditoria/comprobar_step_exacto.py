"""Auditar un STEP sin modificarlo. Salida2si no supera coherencia exacta."""
from pathlib import Path
import argparse,json,hashlib

def comprobar(path):
    import cadquery as cq
    from OCP.BRepCheck import BRepCheck_Analyzer,BRepCheck_NoError
    from OCP.BRepAlgoAPI import BRepAlgoAPI_Check
    from OCP.TopoDS import TopoDS_Iterator
    pending=list(cq.importers.importStep(str(path)).vals());solids=[]
    while pending:
        item=pending.pop();kind=item.ShapeType()
        if kind=='Solid':solids.append(item);continue
        if kind not in ('Compound','CompSolid'):
            return {'ok':False,'sha256_step':hashlib.sha256(path.read_bytes()).hexdigest(),
                    'error':'Objeto fuera del sólido: '+kind,'archivo_modificado':False}
        iterator=TopoDS_Iterator(item.wrapped)
        while iterator.More():pending.append(cq.Shape.cast(iterator.Value()));iterator.Next()
    if len(solids)!=1:
        return {'ok':False,'sha256_step':hashlib.sha256(path.read_bytes()).hexdigest(),
                'error':'Se esperaba exactamente un sólido','solidos':len(solids),'archivo_modificado':False}
    shape=solids[0]
    standard=BRepCheck_Analyzer(shape.wrapped);exact=BRepCheck_Analyzer(shape.wrapped,True,False,True)
    check=BRepAlgoAPI_Check(shape.wrapped,False,True);details=[];failures=0
    for fi,face in enumerate(shape.Faces()):
        for ei,edge in enumerate(face.Edges()):
            states=[str(v) for v in exact.Result(edge.wrapped).StatusOnShape(face.wrapped) if v!=BRepCheck_NoError]
            if states:
                failures+=1
                if len(details)<20:details.append({'cara':fi,'arista_local':ei,'estados':states})
    result={'sha256_step':hashlib.sha256(path.read_bytes()).hexdigest(),'solidos':len(shape.Solids()),
        'caras':len(shape.Faces()),'brep_estandar':bool(standard.IsValid()),'coherencia_exacta':bool(exact.IsValid()),
        'interferencias_occ':len(list(check.Result())),'contextos_arista_cara_con_error':failures,'detalle_acotado':details,
        'archivo_modificado':False,'nota':'Este control complementa distancias, volumen, topología y material; no los sustituye.'}
    result['ok']=result['brep_estandar'] and result['coherencia_exacta'] and result['interferencias_occ']==0 and result['solidos']==1
    return result

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('step',type=Path);parser.add_argument('--informe',type=Path);args=parser.parse_args()
    if args.informe and (args.informe.resolve()==args.step.resolve() or (args.informe.exists() and args.step.exists() and args.informe.samefile(args.step))):parser.error('El informe debe ser distinto del STEP')
    record=comprobar(args.step)
    if args.informe:args.informe.write_text(json.dumps(record,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps(record,ensure_ascii=False));return 0 if record['ok'] else 2
if __name__=='__main__':raise SystemExit(main())
