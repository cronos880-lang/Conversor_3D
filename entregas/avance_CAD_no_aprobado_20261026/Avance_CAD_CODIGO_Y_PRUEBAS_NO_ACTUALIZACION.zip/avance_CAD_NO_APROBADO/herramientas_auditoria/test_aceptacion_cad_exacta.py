"""Puerta de aceptación real. Los fallos se conservan, sin xfail ni omisiones."""
from pathlib import Path
import os
import cadquery as cq
import pytest
from OCP.BRepCheck import BRepCheck_Analyzer

ROOT=Path(os.environ['VISOR_EVIDENCIAS_R8'])
@pytest.mark.parametrize('relative',[
 'regresion_historica/resultados/Bancada_Motor.step',
 'regresion_historica/resultados/pinza.step',
 'nuevos_resultados/V_legoBrick4x2.step',
 'nuevos_resultados/Soporte_movil_2.step',
 'nuevos_resultados/Soportes_estante_bobinas_v0.step',
 'nuevos_resultados/Technic_PEGS_Cross_x6_A.step',
],ids=['bancada','pinza','lego4x2','soporte','estante','pegs'])
def test_step_reimportado_con_curvas_y_superficies_coherentes(relative):
    path=ROOT/relative
    assert path.is_file(),'Falta el STEP; no se omite la prueba'
    shape=cq.importers.importStep(str(path)).val()
    assert BRepCheck_Analyzer(shape.wrapped).IsValid(),'No supera ni el comprobador estándar'
    assert BRepCheck_Analyzer(shape.wrapped,True,False,True).IsValid(),(
        'Incoherencia de curvas 3D/curvas sobre superficie en la comprobación exacta; '
        'el candidato no se puede aprobar sólo con validez estándar y mallado cerrado')
