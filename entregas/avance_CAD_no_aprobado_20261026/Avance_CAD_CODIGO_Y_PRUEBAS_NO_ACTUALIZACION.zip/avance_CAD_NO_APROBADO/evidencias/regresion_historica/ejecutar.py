from pathlib import Path
import sys,json,time,hashlib
ROOT=Path(__file__).resolve().parent;MOTOR=ROOT.parent/'motor_congelado';sys.path.insert(0,str(MOTOR))
from bateria_reparacion import ejecutar
protocol=Path('/workspace/work/mejora_motor_post_r7_20261026/regresion_historica/protocolo.json')
rows=json.loads(protocol.read_text())['casos'];(ROOT/'protocolo.json').write_bytes(protocol.read_bytes());manifest=json.loads((ROOT.parent/'motor_congelado_sha256.json').read_text());report=[]
for spec in rows:
 if time.time()>1793044800:raise SystemExit('Fin de ventana de pruebas antes del empaquetado')
 assert all(hashlib.sha256((MOTOR/n).read_bytes()).hexdigest()==h for n,h in manifest.items())
 source=Path(spec['source']);assert hashlib.sha256(source.read_bytes()).hexdigest()==spec['sha256']
 print('HISTORICA',spec['id'],flush=True)
 output=ROOT/'resultados'/(spec['id']+'.step')
 result=ejecutar(MOTOR,source,output,limite=spec['limite_s'],memoria_mb=4096,extra_env={'VISOR_PERFIL':'precision'})
 result.update(id=spec['id'],grupo=spec['grupo'],referencia_step=spec['referencia_step'])
 if result['ok']:
  a=Path(spec['referencia_step']).read_bytes().split(b'DATA;',1)[1];b=output.read_bytes().split(b'DATA;',1)[1]
  result.update(data_step_identico_R7=a==b,sha256_data_nueva=hashlib.sha256(b).hexdigest(),sha256_data_R7=hashlib.sha256(a).hexdigest())
 assert hashlib.sha256(source.read_bytes()).hexdigest()==spec['sha256']
 report.append(result);(ROOT/'bateria.json').write_text(json.dumps({'resultados':report},indent=2,ensure_ascii=False))
 print(spec['id'],result['ok'],result['segundos'],result.get('data_step_identico_R7'),flush=True)
