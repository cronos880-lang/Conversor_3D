"""Ejecutar y verificar la ruta CAD experimental sin arrancar ni actualizar el Visor."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys,time
def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--paquete',type=Path,required=True)
 p.add_argument('--entrada',type=Path,required=True)
 p.add_argument('--salida',type=Path,required=True)
 p.add_argument('--limite',type=int,default=300)
 p.add_argument('--motor',type=Path,help='Copia experimental alternativa; requiere --manifiesto.')
 p.add_argument('--manifiesto',type=Path,help='SHA256 de la copia alternativa indicada en --motor.')
 a=p.parse_args();root=a.paquete.resolve();source=a.entrada.resolve();out=a.salida.resolve()
 if source==out:p.error('Entrada y salida deben ser distintas.')
 if source.suffix.lower() not in ('.stl','.off') or out.suffix.lower() not in ('.step','.stp'):p.error('Se requiere entrada STL/OFF y salida STEP.')
 targets=[out,*[out.with_suffix(s) for s in ('.json','.conversion.stdout','.contraste.json','.contraste.stdout','.aceptacion.json')],out.with_name(out.stem+'_NO_APROBADO.step')]
 if any(t.exists() for t in targets):p.error('Hay archivos de salida previos; usa una ruta nueva.')
 out.parent.mkdir(parents=True,exist_ok=True)
 if bool(a.motor)!=bool(a.manifiesto):p.error('--motor y --manifiesto deben indicarse juntos.')
 motor=a.motor.resolve() if a.motor else root/'fuentes_experimentales_NO_ACTUALIZAR'
 manifest=json.loads((a.manifiesto.resolve() if a.manifiesto else root/'FUENTES_SHA256.json').read_text())
 for name,digest in manifest.items():
  if hashlib.sha256((motor/name).read_bytes()).hexdigest()!=digest:p.error('Fuentes modificadas: '+name)
 before=hashlib.sha256(source.read_bytes()).hexdigest()
 env={**os.environ,'VISOR_MOTOR_ENSAYO':str(motor),'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1',
      'VISOR_EVALUADOR_R7':str(root/'herramientas/evaluador_R7_inmutable'),
      'VISOR_CONTROL_FRONTERA':str(root/'herramientas/control_frontera_M1_inmutable.py')}
 start=time.monotonic();report={'actualizacion_aprobada':False,'caso_verificado':False,'entrada_sha256':before}
 try:
  with out.with_suffix('.conversion.stdout').open('w') as log:
   result=subprocess.run([sys.executable,str(root/'herramientas/probar_api_integrada.py'),str(source),str(out)],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=a.limite)
  if result.returncode:raise ValueError('El trabajador de conversión no terminó correctamente.')
  cad=json.loads(out.with_suffix('.json').read_text());report['cad']=cad
  if not cad.get('puerta_cad_superada'):raise ValueError(cad.get('error','STEP rechazado por coherencia o interferencias.'))
  contrast=out.with_suffix('.contraste.json')
  with out.with_suffix('.contraste.stdout').open('w') as log:
   result=subprocess.run([sys.executable,str(root/'herramientas/contraste_geometrico_independiente.py'),str(source),str(out),str(contrast)],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=a.limite)
  if result.returncode:raise ValueError('La comprobación independiente no terminó correctamente.')
  proof=json.loads(contrast.read_text());report['contraste']=proof
  if proof.get('error') or proof.get('error_geometria_R7'):raise ValueError(proof.get('error') or proof['error_geometria_R7'])
  meshes=proof.get('frontera_tres_resoluciones',{}).get('resoluciones',[])
  if not proof.get('step_exacto') or 'geometria_R7' not in proof or len(meshes)!=3:raise ValueError('Faltan controles obligatorios.')
  if any(not x['cerrado'] or not x['orientado'] or x['intersecciones_cgal'] for x in meshes):raise ValueError('Mallado fino rechazado.')
  if hashlib.sha256(source.read_bytes()).hexdigest()!=before:raise ValueError('La entrada cambió.')
  report.update(caso_verificado=True,step_sha256=hashlib.sha256(out.read_bytes()).hexdigest())
 except Exception as exc:
  report['error']=str(exc)
  if out.exists():out.rename(out.with_name(out.stem+'_NO_APROBADO.step'))
 report['segundos']=time.monotonic()-start
 out.with_suffix('.aceptacion.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
 print(json.dumps({k:v for k,v in report.items() if k not in ('cad','contraste')},ensure_ascii=False))
 return 0 if report['caso_verificado'] else 2
if __name__=='__main__':raise SystemExit(main())
