"""Repetir las 21 conversiones históricas con la ruta habitual, sin omitir casos."""
from pathlib import Path
import argparse,hashlib,json,sys
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def body(path):return path.read_bytes().split(b'DATA;',1)[1]
def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--paquete',type=Path,required=True)
 parser.add_argument('--salida',type=Path,required=True)
 args=parser.parse_args();root=args.paquete.resolve();out=args.salida.resolve()
 if out.exists():parser.error('Usa una carpeta de salida nueva.')
 out.mkdir(parents=True);motor=root/'fuentes_experimentales_NO_ACTUALIZAR'
 manifest=json.loads((root/'FUENTES_SHA256.json').read_text())
 specs=json.loads((root/'PROTOCOLO_PORTABLE.json').read_text())['casos'];rows=[]
 references=json.loads((root/'REFERENCIAS_M1_SHA256.json').read_text())['referencias']
 sys.path.insert(0,str(motor));from bateria_reparacion import ejecutar
 for spec in specs:
  assert all(digest(motor/n)==h for n,h in manifest.items()),'Las fuentes han cambiado.'
  source=root/spec['source'];assert digest(source)==spec['sha256']
  destination=out/(spec['id']+'.step')
  row=ejecutar(motor,source,destination,limite=spec['limite_s'],memoria_mb=4096,extra_env={'VISOR_PERFIL':'precision'})
  row.update(id=spec['id'],grupo=spec['grupo'],ejecutado=True,ruta_nueva_activada=False)
  if row['ok']:
   row['data_step_identico_R7']=body(destination)==body(root/spec['referencia_step'])
   row['data_step_identico_M1']=hashlib.sha256(body(destination)).hexdigest()==references[spec['id']]['sha256_DATA']
  assert digest(source)==spec['sha256'],'Se ha alterado el STL original.'
  rows.append(row);(out/'bateria.json').write_text(json.dumps({'resultados':rows},indent=2,ensure_ascii=False))
  print(spec['id'],row['ok'],row['segundos'],flush=True)
 return 0 if len(rows)==len(specs) and all(row['ok'] for row in rows) else 2
if __name__=='__main__':raise SystemExit(main())
