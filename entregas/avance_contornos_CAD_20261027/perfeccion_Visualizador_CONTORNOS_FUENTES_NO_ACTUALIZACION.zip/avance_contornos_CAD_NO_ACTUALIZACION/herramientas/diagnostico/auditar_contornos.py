from pathlib import Path
import json,time,sys,collections
import cadquery as cq
from OCP.BRepCheck import BRepCheck_Analyzer,BRepCheck_NoError
from OCP.BRep import BRep_Tool
from OCP.BRepAdaptor import BRepAdaptor_Curve,BRepAdaptor_Curve2d,BRepAdaptor_Surface
from OCP.Adaptor3d import Adaptor3d_CurveOnSurface
from OCP.GeomLib import GeomLib_CheckCurveOnSurface

path=Path(sys.argv[1]);out=Path(sys.argv[2]);start=time.monotonic()
shape=cq.importers.importStep(str(path)).val()
check=BRepCheck_Analyzer(shape.wrapped,True,False,True)
rows=[]
for fi,face in enumerate(shape.Faces()):
    for ei,edge in enumerate(face.Edges()):
        states=[str(s).split('.')[-1] for s in check.Result(edge.wrapped).StatusOnShape(face.wrapped) if s!=BRepCheck_NoError]
        if not states:continue
        curve=BRepAdaptor_Curve(edge.wrapped);surf=BRepAdaptor_Surface(face.wrapped)
        measure=GeomLib_CheckCurveOnSurface(curve,1e-10);measure.SetParallel(False)
        measure.Perform(Adaptor3d_CurveOnSurface(BRepAdaptor_Curve2d(edge.wrapped,face.wrapped),surf))
        rows.append({'cara':fi,'arista':ei,'tipo_cara':str(surf.GetType()).split('.')[-1],
                     'tipo_arista':str(curve.GetType()).split('.')[-1],'estado':states,
                     'tolerancia_mm':BRep_Tool.Tolerance_s(edge.wrapped),
                     'separacion_mm':measure.MaxDistance() if measure.IsDone() else None})
record={'archivo':str(path),'exacto':check.IsValid(),'caras':len(shape.Faces()),'errores':rows,
        'por_tipo':dict(collections.Counter(r['tipo_cara'] for r in rows)),
        'segundos':time.monotonic()-start}
out.write_text(json.dumps(record,indent=2))
print({k:v for k,v in record.items() if k!='errores'},flush=True)
for r in sorted(rows,key=lambda r:r['separacion_mm'] or 0,reverse=True)[:8]:print(r,flush=True)
