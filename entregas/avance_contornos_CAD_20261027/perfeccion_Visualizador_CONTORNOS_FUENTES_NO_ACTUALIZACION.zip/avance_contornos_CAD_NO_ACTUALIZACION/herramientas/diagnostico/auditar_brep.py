import sys,json,collections
from pathlib import Path
import cadquery as cq
from OCP.BRepCheck import BRepCheck_Analyzer,BRepCheck_NoError
from OCP.TopAbs import TopAbs_SOLID,TopAbs_SHELL,TopAbs_FACE,TopAbs_WIRE,TopAbs_EDGE,TopAbs_VERTEX
from OCP.TopExp import TopExp_Explorer
path=Path(sys.argv[1]);shape=cq.Shape.importBrep(str(path));records=[]
for exact in [False,True]:
    checker=BRepCheck_Analyzer(shape.wrapped,True,False,exact);bad=[];summary=collections.Counter()
    for kind in [TopAbs_SOLID,TopAbs_SHELL,TopAbs_FACE,TopAbs_WIRE,TopAbs_EDGE,TopAbs_VERTEX]:
        explorer=TopExp_Explorer(shape.wrapped,kind);i=0
        while explorer.More():
            current=explorer.Current();result=checker.Result(current)
            statuses=[str(s).split('.')[-1] for s in result.Status() if s!=BRepCheck_NoError]
            if statuses:
                for s in statuses:summary[str(kind).split('.')[-1]+':'+s]+=1
                bad.append({'tipo':str(kind),'indice':i,'estado':statuses})
            explorer.Next();i+=1
    record={'exacto':exact,'valido':checker.IsValid(),'resumen':dict(summary),'fallos':bad};records.append(record)
    print({k:v for k,v in record.items() if k!='fallos'},flush=True)
Path(sys.argv[2]).write_text(json.dumps(records,indent=2))
