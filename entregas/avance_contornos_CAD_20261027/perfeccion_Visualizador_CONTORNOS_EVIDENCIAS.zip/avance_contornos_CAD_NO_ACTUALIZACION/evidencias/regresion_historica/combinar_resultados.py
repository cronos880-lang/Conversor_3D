"""Combinar ejecuciones reales de las colas, conservando su procedencia y huellas."""
from pathlib import Path
import hashlib,json,datetime
ROOT=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
specs=json.loads((ROOT/'protocolo.json').read_text())['casos'];records={}
for name,folder in [('bateria.json','resultados'),('segunda_cola.json','segunda_cola'),('cola_final_A.json','cola_final_A'),('cola_final_B.json','cola_final_B')]:
 path=ROOT/name
 if not path.exists():continue
 for row in json.loads(path.read_text())['resultados']:
  previous=records.get(row['id'])
  if previous and previous.get('ok') and not row.get('ok'):continue
  copy=dict(row);copy['procedencia_informe']=name;copy['procedencia_carpeta']=folder
  if copy.get('ok'):
   step=ROOT/folder/(copy['id']+'.step');assert sha(step)==copy['sha256_step']
   copy['ruta_resultado_en_paquete']=str(Path('evidencias/regresion_historica')/folder/step.name)
  records[row['id']]=copy
rows=[]
for spec in specs:
 assert sha(Path(spec['source']))==spec['sha256']
 row=records.get(spec['id'],{'id':spec['id'],'grupo':spec['grupo'],'ejecutado':False,'ok':False,'motivo':'Sin resultado final a este corte; no se cuenta como prueba superada.'})
 if row.get('ok'):assert row['sha256']==spec['sha256']
 rows.append(row)
report={'fuentes':'motor_congelado_validacion (M3)','ruta_nueva_activada':False,
 'fecha_corte_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'resultados':rows,'planificadas':len(specs),'ejecutadas':sum(bool(x.get('ejecutado')) for x in rows),'pasadas':sum(bool(x.get('ok')) for x in rows),
 'originales_y_step_verificados_por_huella':True,'conservar_informes_individuales':True}
(ROOT/'bateria_combinada.json').write_text(json.dumps(report,indent=2,ensure_ascii=False));print({k:v for k,v in report.items() if k!='resultados'})
