from pathlib import Path
import sys,json,time,hashlib,datetime
ROOT=Path(__file__).resolve().parent;MOTOR=ROOT.parent/'motor_congelado_validacion';sys.path.insert(0,str(MOTOR))
from bateria_reparacion import ejecutar
protocol=Path('/workspace/work/mejora_motor_post_r7_20261026/regresion_historica/protocolo.json')
rows=json.loads(protocol.read_text())['casos'];(ROOT/'protocolo.json').write_bytes(protocol.read_bytes())
manifest=json.loads((ROOT.parent/'motor_congelado_validacion_sha256.json').read_text());report=[]
deadline=datetime.datetime.fromisoformat('2026-10-27T01:00:00+00:00').timestamp()
for spec in rows:
 if time.time()>deadline-30:
  report.append({'id':spec['id'],'ejecutado':False,'motivo':'Fin de ventana reservada para pruebas; no se da por superado.'})
  (ROOT/'bateria.json').write_text(json.dumps({'resultados':report},indent=2));continue
 assert all(hashlib.sha256((MOTOR/n).read_bytes()).hexdigest()==h for n,h in manifest.items())
 source=Path(spec['source']);assert hashlib.sha256(source.read_bytes()).hexdigest()==spec['sha256']
 print('HISTORICA',spec['id'],flush=True);output=ROOT/'resultados'/(spec['id']+'.step')
 effective=min(spec['limite_s'],int(deadline-time.time()))
 result=ejecutar(MOTOR,source,output,limite=effective,memoria_mb=4096,extra_env={'VISOR_PERFIL':'precision'})
 result.update(id=spec['id'],grupo=spec['grupo'],referencia_step=spec['referencia_step'],ejecutado=True,
               limite_original_s=spec['limite_s'],limite_en_esta_ventana_s=effective,ruta_nueva_activada=False)
 if result['ok']:
  body=output.read_bytes().split(b'DATA;',1)[1]
  result['data_step_identico_R7']=Path(spec['referencia_step']).read_bytes().split(b'DATA;',1)[1]==body
  previous=Path('/workspace/work/mejora_cad_post_avance_20261026/regresion_historica/resultados')/(spec['id']+'.step')
  result['data_step_identico_M1']=previous.read_bytes().split(b'DATA;',1)[1]==body
 assert hashlib.sha256(source.read_bytes()).hexdigest()==spec['sha256']
 report.append(result);(ROOT/'bateria.json').write_text(json.dumps({'resultados':report},indent=2,ensure_ascii=False))
 print(spec['id'],result['ok'],result.get('segundos'),result.get('data_step_identico_M1'),flush=True)
