"""Completar casos pendientes tras replanificar dos colas, sin alterar el motor."""
from pathlib import Path
import sys,json,hashlib,time,datetime
ROOT=Path(__file__).resolve().parent;MOTOR=ROOT.parent/'motor_congelado_validacion';sys.path.insert(0,str(MOTOR))
from bateria_reparacion import ejecutar
lane=sys.argv[1];names={'A':['6558_fixed','Dimensiones'],'B':['Con fallos pero si step']}[lane]
manifest=json.loads((ROOT.parent/'motor_congelado_validacion_sha256.json').read_text())
specs=json.loads((ROOT/'protocolo.json').read_text())['casos'];rows=[]
limit=datetime.datetime.fromisoformat('2026-10-27T01:12:00+00:00').timestamp()
for name in names:
 spec=next(x for x in specs if x['id']==name)
 if time.time()>limit-30:
  rows.append({'id':name,'ejecutado':False,'motivo':'Fin de ventana final01:12UTC.'});continue
 assert all(hashlib.sha256((MOTOR/n).read_bytes()).hexdigest()==h for n,h in manifest.items())
 source=Path(spec['source']);assert hashlib.sha256(source.read_bytes()).hexdigest()==spec['sha256']
 destination=ROOT/('cola_final_'+lane)/(name+'.step');print('COLA_FINAL',lane,name,flush=True)
 effective=min(spec['limite_s'],int(limit-time.time()))
 result=ejecutar(MOTOR,source,destination,limite=effective,memoria_mb=4096,extra_env={'VISOR_PERFIL':'precision'})
 result.update(id=name,grupo=spec['grupo'],ejecutado=True,ruta_nueva_activada=False,cola='final_'+lane,limite_original_s=spec['limite_s'],limite_en_esta_ventana_s=effective)
 if result['ok']:
  body=destination.read_bytes().split(b'DATA;',1)[1]
  result['data_step_identico_R7']=Path(spec['referencia_step']).read_bytes().split(b'DATA;',1)[1]==body
  previous=Path('/workspace/work/mejora_cad_post_avance_20261026/regresion_historica/resultados')/(name+'.step')
  result['data_step_identico_M1']=previous.read_bytes().split(b'DATA;',1)[1]==body
 assert hashlib.sha256(source.read_bytes()).hexdigest()==spec['sha256']
 rows.append(result);(ROOT/('cola_final_'+lane+'.json')).write_text(json.dumps({'resultados':rows},indent=2,ensure_ascii=False))
 print(name,result['ok'],result['segundos'],result.get('data_step_identico_M1'),flush=True)
(ROOT/('cola_final_'+lane+'.json')).write_text(json.dumps({'resultados':rows},indent=2,ensure_ascii=False))
