"""Ensayo: corregir parametrización, conservando cada curva3D y superficie."""
from pathlib import Path
import sys,json,time
import cadquery as cq
from OCP.BRep import BRep_Tool,BRep_Builder
from OCP.BRepAdaptor import BRepAdaptor_Curve,BRepAdaptor_Curve2d,BRepAdaptor_Surface
from OCP.BRepCheck import BRepCheck_Analyzer,BRepCheck_NoError
from OCP.GeomAPI import GeomAPI_ProjectPointOnSurf
from OCP.GeomProjLib import GeomProjLib
from OCP.Geom2dAdaptor import Geom2dAdaptor_Curve
from OCP.Adaptor3d import Adaptor3d_CurveOnSurface
from OCP.GeomLib import GeomLib_CheckCurveOnSurface
from OCP.BRepAlgoAPI import BRepAlgoAPI_Check

source,dest=map(Path,sys.argv[1:]);shape=cq.importers.importStep(str(source)).val()
check=BRepCheck_Analyzer(shape.wrapped,True,False,True);builder=BRep_Builder();rows=[];start=time.monotonic()
for fi,face in enumerate(shape.Faces()):
 for ei,edge in enumerate(face.Edges()):
  if all(s==BRepCheck_NoError for s in check.Result(edge.wrapped).StatusOnShape(face.wrapped)):continue
  row={'cara':fi,'arista':ei};rows.append(row)
  try:
   curve=BRepAdaptor_Curve(edge.wrapped);surface=BRep_Tool.Surface_s(face.wrapped);adapt=BRepAdaptor_Surface(face.wrapped)
   original=GeomLib_CheckCurveOnSurface(curve,1e-10);original.SetParallel(False)
   original.Perform(Adaptor3d_CurveOnSurface(BRepAdaptor_Curve2d(edge.wrapped,face.wrapped),adapt))
   p=curve.Value(original.MaxParameter());row.update(param_antes_mm=original.MaxDistance(),distancia_fisica_mm=GeomAPI_ProjectPointOnSurf(p,surface).LowerDistance())
   if BRep_Tool.IsClosed_s(edge.wrapped,face.wrapped):raise ValueError('Costura con doble curvaUV; pendiente de tratar.')
   lo,hi=curve.FirstParameter(),curve.LastParameter();geometry=BRep_Tool.Curve_s(edge.wrapped,lo,hi)
   uv=GeomProjLib.Curve2d_s(geometry,lo,hi,surface,1e-10)
   if uv is None:raise ValueError('No converge la proyección2D.')
   result=GeomLib_CheckCurveOnSurface(curve,1e-10);result.SetParallel(False)
   result.Perform(Adaptor3d_CurveOnSurface(Geom2dAdaptor_Curve(uv,lo,hi),adapt))
   if not result.IsDone():raise ValueError('No se verifica la proyección.')
   row['param_despues_mm']=result.MaxDistance()
   if result.MaxDistance()>1e-7:raise ValueError('La parametrización no resuelve el desacuerdo.')
   tolerance=BRep_Tool.Tolerance_s(edge.wrapped)
   builder.UpdateEdge(edge.wrapped,uv,face.wrapped,tolerance);builder.Range(edge.wrapped,face.wrapped,lo,hi)
   row['corregida']=True
  except Exception as exc:row['error']=str(exc)
  print(row,flush=True)
before=bool(BRepCheck_Analyzer(shape.wrapped,True,False,True).IsValid());shape.exportStep(str(dest))
cold=cq.importers.importStep(str(dest)).val();bop=BRepAlgoAPI_Check(cold.wrapped,False,True)
record={'aristas':rows,'antes_exportacion_exacto':before,'en_frio_exacto':bool(BRepCheck_Analyzer(cold.wrapped,True,False,True).IsValid()),'bop':len(list(bop.Result())),'segundos':time.monotonic()-start}
dest.with_suffix('.json').write_text(json.dumps(record,indent=2));print('FINAL',{k:v for k,v in record.items() if k!='aristas'},flush=True)
