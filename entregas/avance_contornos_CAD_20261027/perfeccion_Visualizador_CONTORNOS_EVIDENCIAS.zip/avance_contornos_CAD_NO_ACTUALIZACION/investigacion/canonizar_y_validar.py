from pathlib import Path
import sys,time,json,traceback
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'motor_experimental/motor_superficies')]
import cadquery as cq
from planos_canonicos import canonizar_planos
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.BRepTools import BRepTools
from OCP.BRepAlgoAPI import BRepAlgoAPI_Check
source,dest=map(Path,sys.argv[1:]);start=time.monotonic();record={'ok':False}
try:
 shape=cq.Shape.importBrep(str(source));native,record['canonizacion']=canonizar_planos(shape.wrapped)
 BRepTools.Write_s(native,str(dest.with_suffix('.native.brep')))
 record.update(nativo_estandar=BRepCheck_Analyzer(native).IsValid(),nativo_exacto=BRepCheck_Analyzer(native,True,False,True).IsValid())
 print('CANONIZADO',record,'s',time.monotonic()-start,flush=True)
 if not record['nativo_estandar'] or not record['nativo_exacto']:raise ValueError('La representación canónica no supera la validez exacta.')
 cq.Shape.cast(native).exportStep(str(dest));print('STEP ESCRITO',time.monotonic()-start,flush=True)
 cold=cq.importers.importStep(str(dest)).val();record['lectura_fria_s']=time.monotonic()-start
 record.update(exacto=BRepCheck_Analyzer(cold.wrapped,True,False,True).IsValid(),estandar=cold.isValid())
 print('LECTURA',record,'s',time.monotonic()-start,flush=True)
 check=BRepAlgoAPI_Check(cold.wrapped,False,True)
 record['bop']=len(list(check.Result()));record['caras']=len(cold.Faces());record['solidos']=len(cold.Solids())
 record['ok']=record['exacto'] and record['estandar'] and record['bop']==0 and record['solidos']==1
except Exception as exc:record['error']=str(exc);traceback.print_exc()
record['segundos']=time.monotonic()-start;dest.with_suffix('.json').write_text(json.dumps(record,indent=2));print('FINAL',record,flush=True)
