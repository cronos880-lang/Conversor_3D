"""Medir geometría con el evaluador R7 inmutable. No sustituye la puerta BOP."""
import sys,json,time,traceback,os,importlib.util,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
FROZEN=Path(os.environ.get('VISOR_EVALUADOR_R7','/workspace/work/paquete_perfeccion_Visualizador_R7/Visor_experimental_fuentes'))
sys.path[:0]=[str(FROZEN),str(FROZEN/'motor_superficies')]
source,step,report=map(Path,sys.argv[1:]);start=time.monotonic();record={'actualizacion_aprobada':False,'evaluador':str(FROZEN),'alcance':'Geometría y frontera. Las interferencias BOP se evalúan por separado y siguen bloqueando la aceptación.'}
try:
 from preprocesador_stl import cargar_exacto
 from motor_v2 import _calidad
 original=cargar_exacto(source)
 try:record['geometria_R7']=_calidad(source,step,original,control_avanzado=False)
 except Exception as exc:
  record['error_geometria_R7']=str(exc);record['detalle_error_R7']={k:v for k,v in vars(exc).items() if isinstance(v,(dict,list,str,int,float,bool,type(None)))}
  traceback.print_exc()
 import cadquery as cq
 from OCP.BRepCheck import BRepCheck_Analyzer
 shape=cq.importers.importStep(str(step)).val();record['step_exacto']=BRepCheck_Analyzer(shape.wrapped,True,False,True).IsValid()
 sys.path.insert(0,str(FROZEN/'motor_superficies'))
 from meshfit_detect import detect
 result,working=detect(str(source),angle_tol_deg=32.,rms_tol_rel=.01,flat_tol_deg=8.,scan_mode=False)
 module_path=Path(os.environ.get('VISOR_CONTROL_FRONTERA','/workspace/work/mejora_cad_post_avance_20261026/motor_congelado/reconstruccion_curvas.py'))
 spec=importlib.util.spec_from_file_location('control_frontera_inmutable_M1',module_path);control=importlib.util.module_from_spec(spec);spec.loader.exec_module(control)
 required=control.cilindros_respaldados(result,working);record['cilindros_respaldados']=control.comprobar_cilindros(required,shape)
 from invariantes_material import InvariantesMaterial
 from validacion_reconstruccion import certificar_topologia_step
 record['topologia_material']=certificar_topologia_step(shape,original,InvariantesMaterial(original))
 quality=record.get('geometria_R7')
 if quality:
  with tempfile.TemporaryDirectory(prefix='visor_prueba_contorno_') as folder:
   record['frontera_tres_resoluciones']=control.certificar_mallado(shape,original,Path(folder)/'control.off',quality)
except Exception as exc:record['error']=str(exc);traceback.print_exc()
record['segundos']=time.monotonic()-start;report.write_text(json.dumps(record,indent=2,ensure_ascii=False,default=str));print('FINAL',{'geometria_R7_ok':'geometria_R7' in record,'error':record.get('error'),'segundos':record['segundos']},flush=True)
