"""Reproducir los puntos de contención usados por BRepCheck_Solid, sin alterar CAD."""
from pathlib import Path
import sys,json
import cadquery as cq
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeSolid
from OCP.BRepClass3d import BRepClass3d_SolidClassifier
from OCP.BRep import BRep_Tool
from OCP.BRepAdaptor import BRepAdaptor_Curve
from OCP.TopoDS import TopoDS
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_EDGE
source,output=map(Path,sys.argv[1:]);shape=cq.Shape.importBrep(str(source));items=[];points=[];records=[]
for i,shell in enumerate(shape.Shells()):
 solid=BRepBuilderAPI_MakeSolid(TopoDS.Shell_s(shell.wrapped)).Solid();classifier=BRepClass3d_SolidClassifier(solid)
 classifier.PerformInfinitePoint(1e-307);infinite=str(classifier.State())
 exp=TopExp_Explorer(solid,TopAbs_EDGE)
 while exp.More():
  edge=TopoDS.Edge_s(exp.Current())
  if not BRep_Tool.Degenerated_s(edge):break
  exp.Next()
 curve=BRepAdaptor_Curve(edge);t=(1-.43213918)*curve.FirstParameter()+.43213918*curve.LastParameter();point=curve.Value(t)
 items.append(classifier);points.append(point)
 records.append({'shell':i,'caras':len(shell.Faces()),'volumen':cq.Shape.cast(solid).Volume(),'infinito':infinite,
  'punto':point.Coord(),'tipo_arista':str(curve.GetType()),'rango':[curve.FirstParameter(),curve.LastParameter()],
  'tolerancia':BRep_Tool.Tolerance_s(edge)})
for i,classifier in enumerate(items):
 states=[]
 for j,point in enumerate(points):
  classifier.Perform(point,records[j]['tolerancia']);states.append(str(classifier.State()))
 records[i]['clasificacion_puntos_shells']=states
 print(records[i],flush=True)
output.write_text(json.dumps(records,indent=2))
