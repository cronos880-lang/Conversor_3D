"""Ensayo aislado: componer cavidades cerradas mediante booleanos sin tolerancia difusa."""
from pathlib import Path
import sys,json,time,traceback
import cadquery as cq
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeSolid
from OCP.BRepLib import BRepLib
from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut,BRepAlgoAPI_Check
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.BRepTools import BRepTools
from OCP.TopoDS import TopoDS
source,output=map(Path,sys.argv[1:]);start=time.monotonic()
record={'actualizacion_aprobada':False,'ensayo_aislado':True,'tolerancia_difusa_mm':0.,'etapas':[]}
try:
 shape=cq.Shape.importBrep(str(source));solids=[]
 for shell in shape.Shells():
  solid=BRepBuilderAPI_MakeSolid(TopoDS.Shell_s(shell.wrapped)).Solid()
  BRepLib.OrientClosedSolid_s(solid)
  wrapped=cq.Shape.cast(solid);solids.append(wrapped)
  print('ENVOLVENTE',len(wrapped.Faces()),wrapped.Volume(),wrapped.isValid(),flush=True)
 solids.sort(key=lambda s:abs(s.Volume()),reverse=True);result=solids[0].wrapped
 for tool in solids[1:]:
  operation=BRepAlgoAPI_Cut(result,tool.wrapped);operation.SetFuzzyValue(0.);operation.Build()
  if not operation.IsDone():raise ValueError('Booleano no terminado.')
  result=operation.Shape();wrapped=cq.Shape.cast(result)
  stage={'caras':len(wrapped.Faces()),'solidos':len(wrapped.Solids()),'valido':wrapped.isValid(),'volumen':wrapped.Volume()}
  record['etapas'].append(stage);print('CORTE',stage,flush=True)
 BRepTools.Write_s(result,str(output.with_suffix('.native.brep')))
 cq.exporters.export(cq.Shape.cast(result),str(output))
 cold=cq.importers.importStep(str(output)).val()
 record.update(exacto=BRepCheck_Analyzer(cold.wrapped,True,False,True).IsValid(),
               bop=len(list(BRepAlgoAPI_Check(cold.wrapped,False,True).Result())),
               caras=len(cold.Faces()),solidos=len(cold.Solids()),shells=len(cold.Shells()))
except Exception as exc:record['error']=str(exc);traceback.print_exc()
record['segundos']=time.monotonic()-start;output.with_suffix('.json').write_text(json.dumps(record,indent=2));print('FINAL',record,flush=True)
