from pathlib import Path
import sys,os,json,time,traceback
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'motor_experimental'),str(R/'motor_experimental/motor_superficies')]
from meshfit_detect import detect
import meshfit_brep
from contornos_compatibles import construir
from meshfit_step import export_step
import cadquery as cq
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.BRepAlgoAPI import BRepAlgoAPI_Check
from OCP.BRep import BRep_Tool
from preprocesador_stl import cargar_exacto
from invariantes_material import InvariantesMaterial
meshfit_brep._build=construir
from OCP.ShapeFix import ShapeFix_Shape,ShapeFix_Solid
class AjusteEstricto(ShapeFix_Shape):
 def __init__(self,shape):
  super().__init__(shape)
  self.FixSameParameterMode=0;self.FixVertexPositionMode=0;self.FixVertexTolMode=0
  face=self.FixFaceTool();face.FixWireMode=0;face.FixMissingSeamMode=1;face.FixOrientationMode=1
  face.FixSmallAreaWireMode=0;face.RemoveSmallAreaFaceMode=0;face.FixIntersectingWiresMode=0
  face.FixLoopWiresMode=0;face.AutoCorrectPrecisionMode=0
 def SetPrecision(self,value):super().SetPrecision(1e-7)
 def SetMaxTolerance(self,value):super().SetMaxTolerance(1e-5)
 def Perform(self,*args):
  t=time.monotonic();print('[ensayo] ShapeFix inicio',flush=True);r=super().Perform(*args)
  print('[ensayo] ShapeFix fin',round(time.monotonic()-t,3),flush=True);return r
meshfit_brep.ShapeFix_Shape=AjusteEstricto
class SolidoEstricto(ShapeFix_Solid):
 def __init__(self,solid):
  super().__init__(solid);self.FixShellMode=0;self.CreateOpenSolidMode=False
 def Perform(self,*args):
  t=time.monotonic();print('[ensayo] SolidFix inicio',flush=True);r=super().Perform(*args)
  print('[ensayo] SolidFix fin',round(time.monotonic()-t,3),flush=True);return r
meshfit_brep.ShapeFix_Solid=SolidoEstricto
from fijacion_contornos import AjusteContornos,OrientarSolido,completar_vertices_singulares
from planos_canonicos import canonizar_planos
meshfit_brep.ShapeFix_Shape=AjusteContornos
meshfit_brep.ShapeFix_Solid=OrientarSolido
fix_intersections=meshfit_brep._fix_wire_intersections
meshfit_brep._fix_wire_intersections=lambda shape,precision:fix_intersections(shape,1e-7)
source,dest=map(Path,sys.argv[1:]);t=time.monotonic();record={'ok':False}
def guardar_shell(*args,**kwargs):
 result,faces=construir(*args,**kwargs)
 result,proof=completar_vertices_singulares(result)
 print('[ensayo] cierre UV',proof,flush=True)
 updated=cq.Shape.cast(result).Faces()
 assert len(updated)==len(faces)
 faces={key:f.wrapped for key,f in zip(faces,updated)}
 from OCP.BRepTools import BRepTools
 BRepTools.Write_s(result,str(dest.with_suffix('.raw.brep')))
 return result,faces
meshfit_brep._build=guardar_shell
build_original=meshfit_brep.build_solid
def una_ronda(*args,**kwargs):
 kwargs['max_rounds']=1
 return build_original(*args,**kwargs)
meshfit_brep.build_solid=una_ronda
make_solid=meshfit_brep._make_solid
def guardar_solido(*args,**kwargs):
 result=make_solid(*args,**kwargs)
 if result is not None:
  from OCP.BRepLib import BRepLib
  for edge in cq.Shape.cast(result).Edges():
   if not BRep_Tool.SameRange_s(edge.wrapped) or not BRep_Tool.SameParameter_s(edge.wrapped):
    BRepLib.SameRange_s(edge.wrapped,1e-10);BRepLib.SameParameter_s(edge.wrapped,1e-9,True)
  result,proof=canonizar_planos(result);print('[ensayo] planos',proof,flush=True)
  from OCP.BRepTools import BRepTools
  BRepTools.Write_s(result,str(dest.with_suffix('.native.brep')))
 return result
meshfit_brep._make_solid=guardar_solido
try:
 original=cargar_exacto(source);invariants=InvariantesMaterial(original)
 result,mesh=detect(str(source),angle_tol_deg=32.,rms_tol_rel=.01,flat_tol_deg=8.,scan_mode=False)
 export_step(result,mesh,str(dest),organic=True,solid=True,organic_smooth=0.,ajuste_ia=False,require_solid=True,precision_reparacion=True,refinar_curvas=True,cavidades_verificadas=bool(invariants.negative))
 shape=cq.importers.importStep(str(dest)).val();bop=BRepAlgoAPI_Check(shape.wrapped,False,True)
 record.update(exacto=BRepCheck_Analyzer(shape.wrapped,True,False,True).IsValid(),estandar=shape.isValid(),
               caras=len(shape.Faces()),solidos=len(shape.Solids()),bop=len(list(bop.Result())),
               max_tol_aristas_mm=max(BRep_Tool.Tolerance_s(e.wrapped) for e in shape.Edges()))
 record['interferencias_detalle']=[]
 for issue in bop.Result():
  record['interferencias_detalle'].append({'estado':str(issue.GetCheckStatus()),
    'caras_ids':[i for i,f in enumerate(shape.Faces()) for bad in issue.GetFaultyShapes1() if f.wrapped.IsSame(bad)]})
 record['ok']=record['exacto'] and record['estandar'] and record['solidos']==1 and record['bop']==0
except Exception as exc:record['error']=str(exc);traceback.print_exc()
record['segundos']=time.monotonic()-t;dest.with_suffix('.json').write_text(json.dumps(record,indent=2));print('FINAL',record,flush=True)
