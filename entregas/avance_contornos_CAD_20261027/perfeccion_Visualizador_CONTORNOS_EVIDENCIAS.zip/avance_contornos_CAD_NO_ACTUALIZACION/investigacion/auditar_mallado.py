import sys,time,json
from pathlib import Path
import numpy as np,trimesh,cadquery as cq
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'motor_experimental'))
from topologia_vertices import inspeccionar_vertices
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.BRepTools import BRepTools
from OCP.BRep import BRep_Tool
from OCP.TopLoc import TopLoc_Location
from OCP.TopAbs import TopAbs_REVERSED
source,report=map(Path,sys.argv[1:3]);mode=sys.argv[3] if len(sys.argv)>3 else 'default';shape=cq.importers.importStep(str(source)).val();rows=[]
for resolution in (.00025,.0005,.001):
 start=time.monotonic();work=shape.copy();BRepTools.Clean_s(work.wrapped)
 if mode=='default':BRepMesh_IncrementalMesh(work.wrapped,resolution,False,.04,False).Perform()
 else:
  from OCP.IMeshTools import IMeshTools_Parameters,IMeshTools_MeshAlgoType
  params=IMeshTools_Parameters();params.Deflection=resolution;params.Angle=.04
  params.Relative=False;params.InParallel=False;params.MinSize=1e-9;params.AllowQualityDecrease=False
  if mode=='delabella':params.MeshAlgo=IMeshTools_MeshAlgoType.IMeshTools_MeshAlgoType_Delabella
  BRepMesh_IncrementalMesh(work.wrapped,params).Perform()
 V=[];F=[];owners=[]
 for i,face in enumerate(work.Faces()):
  loc=TopLoc_Location();tri=BRep_Tool.Triangulation_s(face.wrapped,loc)
  if tri is None:raise ValueError('Cara sin triangulación')
  offset=len(V);V.extend(tri.Node(j).Transformed(loc.Transformation()).Coord() for j in range(1,tri.NbNodes()+1))
  for triangle in tri.Triangles():
   a,b,c=triangle.Get();F.append((a+offset-1,c+offset-1,b+offset-1) if face.wrapped.Orientation()==TopAbs_REVERSED else (a+offset-1,b+offset-1,c+offset-1));owners.append(i)
 V=np.asarray(V);F=np.asarray(F);owners=np.asarray(owners)
 _,first,inverse=np.unique(np.round(V/1e-10).astype(np.int64),axis=0,return_index=True,return_inverse=True)
 mesh=trimesh.Trimesh(V[first],inverse[F],process=False);diag=inspeccionar_vertices(mesh)
 deg=np.any(np.diff(np.sort(mesh.faces,axis=1),axis=1)==0,axis=1)
 counts=np.bincount(mesh.edges_unique_inverse,minlength=len(mesh.edges_unique));bad_edges=mesh.edges_unique[counts!=2]
 bad_vertices=np.unique(bad_edges);bad_triangle=np.isin(mesh.faces,bad_vertices).any(axis=1)
 record={'deflexion_mm':resolution,'cerrado':bool(mesh.is_watertight),'orientado':bool(mesh.is_winding_consistent),
  'euler':int(mesh.euler_number),'vertices':diag,'caras':len(F),'degeneradas_indices':int(deg.sum()),
  'areas_exactamente_cero':int((mesh.area_faces==0).sum()),'aristas_no_dos_caras':len(bad_edges),
  'caras_cad_cercanas':np.unique(owners[bad_triangle]).tolist(),'caras_cad_degeneradas':np.unique(owners[deg]).tolist(),
  'vertices_problema_xyz':mesh.vertices[bad_vertices].tolist()[:30],'segundos':time.monotonic()-start}
 clean=trimesh.Trimesh(mesh.vertices.copy(),mesh.faces[mesh.area_faces!=0].copy(),process=False);clean.remove_unreferenced_vertices()
 record['normalizacion_cero']={'cerrado':bool(clean.is_watertight),'orientado':bool(clean.is_winding_consistent),
  'euler':int(clean.euler_number),'vertices':inspeccionar_vertices(clean),'triangulos_sin_area_retirados':int((mesh.area_faces==0).sum())}
 record['algoritmo']=mode
 rows.append(record);report.write_text(json.dumps(rows,indent=2));print(record,flush=True)
 np.savez_compressed(report.with_name(report.stem+str(resolution)+'.npz'),vertices=mesh.vertices,triangulos=mesh.faces,propietarios=owners)
