"""Ensayo aislado de división de caras periódicas, conservando sus superficies."""
from pathlib import Path
import sys,json,time,traceback
import cadquery as cq
from OCP.ShapeUpgrade import ShapeUpgrade_ShapeDivideClosed
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.BRepAlgoAPI import BRepAlgoAPI_Check
from OCP.BRepTools import BRepTools
source,output=map(Path,sys.argv[1:]);start=time.monotonic();record={'actualizacion_aprobada':False,'ensayo_aislado':True}
try:
 shape=cq.Shape.importBrep(str(source));operation=ShapeUpgrade_ShapeDivideClosed(shape.wrapped)
 operation.SetNbSplitPoints(1);operation.SetPrecision(1e-7);operation.SetMinTolerance(1e-9);operation.SetMaxTolerance(1e-7)
 record['realizado']=operation.Perform();result=operation.Result();wrapped=cq.Shape.cast(result)
 record.update(caras=len(wrapped.Faces()),valido=wrapped.isValid(),exacto=BRepCheck_Analyzer(result,True,False,True).IsValid(),volumen=wrapped.Volume(),volumen_antes=shape.Volume())
 print('DIVISION',record,flush=True);BRepTools.Write_s(result,str(output.with_suffix('.native.brep')))
 if record['exacto']:
  cq.exporters.export(wrapped,str(output));cold=cq.importers.importStep(str(output)).val()
  record['step_exacto']=BRepCheck_Analyzer(cold.wrapped,True,False,True).IsValid()
  record['bop']=len(list(BRepAlgoAPI_Check(cold.wrapped,False,True).Result()))
except Exception as exc:record['error']=str(exc);traceback.print_exc()
record['segundos']=time.monotonic()-start;output.with_suffix('.json').write_text(json.dumps(record,indent=2));print('FINAL',record,flush=True)
