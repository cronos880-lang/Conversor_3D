"""Sellar dos ZIP complementarios y verificar su extracción y todas sus huellas."""
from pathlib import Path
import hashlib,json,zipfile,shutil,time
ROOT=Path(__file__).resolve().parent;SOURCE=ROOT/'entrega/avance_contornos_CAD_NO_ACTUALIZACION';OUT=ROOT/'paquetes';EXTRACT=ROOT/'verificacion_zip'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
 OUT.mkdir(exist_ok=True)
 files=sorted(p for p in SOURCE.rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts and p.name!='MANIFIESTO_SHA256.json')
 manifest={str(p.relative_to(SOURCE)):sha(p) for p in files}
 (SOURCE/'MANIFIESTO_SHA256.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False));files.append(SOURCE/'MANIFIESTO_SHA256.json')
 code={'fuentes_experimentales_NO_ACTUALIZAR','archivos_modificados','herramientas','variante_prioridad_cilindros'}
 common=[p for p in files if len(p.relative_to(SOURCE).parts)==1]
 sourcefiles=[p for p in files if p.relative_to(SOURCE).parts[0] in code]
 evidence=[p for p in files if p not in common and p not in sourcefiles]
 packages=[]
 for name,selection in [('perfeccion_Visualizador_CONTORNOS_FUENTES_NO_ACTUALIZACION.zip',common+sourcefiles),('perfeccion_Visualizador_CONTORNOS_EVIDENCIAS.zip',common+evidence)]:
  target=OUT/name
  with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
   for path in sorted(selection):z.write(path,str(Path(SOURCE.name)/path.relative_to(SOURCE)))
  assert target.stat().st_size<95*1024**2,'ZIP demasiado grande para GitHub normal.'
  with zipfile.ZipFile(target) as z:assert z.testzip() is None
  packages.append({'archivo':name,'bytes':target.stat().st_size,'sha256':sha(target),'entradas':len(selection)})
 if EXTRACT.exists():shutil.rmtree(EXTRACT)
 EXTRACT.mkdir()
 for record in packages:
  with zipfile.ZipFile(OUT/record['archivo']) as z:z.extractall(EXTRACT)
 extracted=EXTRACT/SOURCE.name
 for name,digest in manifest.items():assert sha(extracted/name)==digest,name
 for folder,manifestname in [('fuentes_experimentales_NO_ACTUALIZAR','FUENTES_SHA256.json'),('variante_prioridad_cilindros/fuentes','variante_prioridad_cilindros/FUENTES_SHA256.json')]:
  subset=json.loads((extracted/manifestname).read_text())
  assert all(sha(extracted/folder/n)==digest for n,digest in subset.items())
 (OUT/'PAQUETES_SHA256.json').write_text(json.dumps(packages,indent=2))
 report={'crc_dos_zip':True,'extraccion_completa':True,'archivos_con_huella_verificada':len(manifest),
         'fuentes_M3_y_candidato_idénticas_a_congeladas':True,'paquetes':packages,'pruebas_extraidas':'Pendiente, se registran por separado antes de publicar.'}
 (OUT/'VERIFICACION_EXTRACCION.json').write_text(json.dumps(report,indent=2,ensure_ascii=False));print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':main()
