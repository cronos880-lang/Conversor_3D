"""Preparar una entrega reproducible de desarrollo; no genera un instalador."""
from pathlib import Path
import ast,difflib,hashlib,json,shutil,sys,importlib.metadata as metadata
ROOT=Path(__file__).resolve().parent
MOTOR=ROOT/'motor_congelado_validacion'
BASE=Path('/workspace/work/mejora_cad_post_avance_20261026/motor_progreso_M2')
R7=Path('/workspace/work/paquete_perfeccion_Visualizador_R7')
BANK=Path('/workspace/work/bateria_independiente_r7_20261026')
DEST=ROOT/'entrega/avance_contornos_CAD_NO_ACTUALIZACION'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(name,data):
 p=DEST/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,indent=2,ensure_ascii=False))
def copy(source,name):
 p=DEST/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,p)
def tree(source,dest):
 shutil.copytree(source,DEST/dest,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache','*.pyc','visor_step_*','visor_numerico_*','visor_curvas_*','visor_refinar_*'))
def main():
 manifest=json.loads((ROOT/'motor_congelado_validacion_sha256.json').read_text())
 assert all(sha(MOTOR/n)==h for n,h in manifest.items())
 if DEST.exists():shutil.rmtree(DEST)
 DEST.mkdir(parents=True,exist_ok=True);changes=[];patch=[]
 for name,digest in manifest.items():
  copy(MOTOR/name,Path('fuentes_experimentales_NO_ACTUALIZAR')/name)
  old=BASE/name;new=MOTOR/name
  if old.is_file() and sha(old)==digest:continue
  changes.append({'archivo':name,'nuevo_en_esta_fase':not old.is_file(),'sha256':digest})
  copy(new,Path('archivos_modificados')/name)
  before=old.read_text().splitlines(True) if old.is_file() else []
  patch.extend(difflib.unified_diff(before,new.read_text().splitlines(True),fromfile='a/'+name if old.is_file() else '/dev/null',tofile='b/'+name))
 save('FUENTES_SHA256.json',manifest);save('ARCHIVOS_CAMBIADOS.json',changes)
 (DEST/'CAMBIOS_RESPECTO_M2.patch').write_text(''.join(patch))
 tree(R7/'material_pruebas','material_pruebas')
 tree(R7/'Visor_experimental_fuentes','herramientas/evaluador_R7_inmutable')
 copy(Path('/workspace/work/mejora_cad_post_avance_20261026/motor_congelado/reconstruccion_curvas.py'),'herramientas/control_frontera_M1_inmutable.py')
 for folder in ['stl_sanos','resultados_sanos']:
  copy(BANK/folder/('17_barrido_spline.stl' if folder=='stl_sanos' else '17_barrido_spline.step'),Path('fixtures_banco_R7')/folder/('17_barrido_spline.stl' if folder=='stl_sanos' else '17_barrido_spline.step'))
 tools=Path('/workspace/work/mejora_cad_post_avance_20261026/entrega_progreso/avance_CAD_NO_APROBADO/herramientas_auditoria')
 copy(tools/'reproducir_pruebas.py','herramientas/reproducir_pruebas.py')
 for name in ['probar_api_integrada.py','contraste_geometrico_independiente.py']:
  copy(ROOT/'ensayos'/name,Path('herramientas')/name)
 for file in (ROOT/'herramientas').glob('*.py'):
  copy(file,(Path('herramientas') if file.name.startswith('reproducir_') else Path('herramientas/diagnostico'))/file.name)
 for file in (ROOT/'ensayos').glob('*.py'):copy(file,Path('investigacion')/file.name)
 for file in (ROOT/'ensayos').glob('*.stdout'):copy(file,Path('evidencias/intentos')/file.name)
 for file in (ROOT/'ensayos').glob('*.json'):copy(file,Path('evidencias/intentos')/file.name)
 for file in (ROOT/'ensayos').glob('*.npz'):copy(file,Path('evidencias/intentos')/file.name)
 for file in (ROOT/'ensayos').glob('*.off'):copy(file,Path('investigacion/entradas_intermedias')/file.name)
 for file in (ROOT/'resultados').glob('*.json'):copy(file,Path('evidencias/resultados')/file.name)
 # Sólo publicar STEP que tengan QA completa en esta fase; los demás permanecen negativos documentados.
 for name in ['pinza_api_integrada.step','pinza_parches_regulares.step']:
  copy(ROOT/'resultados'/name,Path('resultados_verificados')/name)
 for name in ['bancada_api_integrada.step','bancada_prioridad_cilindros.step','lego_compatibles_v24.native.brep']:
  if (ROOT/'resultados'/name).exists():copy(ROOT/'resultados'/name,Path('NO_APROBADOS')/name)
 for name in ['pinza.stl','Bancada_Motor.stl']:
  copy(R7/'material_pruebas/stl_regresion_14'/name,Path('entradas')/name)
 copy(Path('/workspace/work/mejora_cad_post_avance_20261026/entradas_nuevas/V_legoBrick4x2.stl'),'entradas/V_legoBrick4x2.stl')
 copy(Path('/workspace/work/mejora_motor_post_r7_20261026/preprocesados/V_legoBrick4x2.envolventes.off'),'entradas/V_legoBrick4x2.envolventes.off')
 for file in ROOT.glob('pruebas_*'):
  if file.suffix in ('.xml','.stdout'):copy(file,Path('evidencias/pytest')/file.name)
 for file in (ROOT/'regresion_historica').glob('*'):
  if file.is_file():copy(file,Path('evidencias/regresion_historica')/file.name)
 if (ROOT/'regresion_historica/resultados').exists():tree(ROOT/'regresion_historica/resultados','evidencias/regresion_historica/resultados')
 if (ROOT/'regresion_historica/segunda_cola').exists():tree(ROOT/'regresion_historica/segunda_cola','evidencias/regresion_historica/segunda_cola')
 for name in ['cola_final_A','cola_final_B','intentos_interrumpidos']:
  if (ROOT/'regresion_historica'/name).exists():tree(ROOT/'regresion_historica'/name,Path('evidencias/regresion_historica')/name)
 if (ROOT/'repeticion_paquete').exists():tree(ROOT/'repeticion_paquete','evidencias/repeticion_desde_paquete')
 copy(ROOT/'REPRODUCIR.md','REPRODUCIR.md')
 if (ROOT/'CONTINUAR_DESARROLLO.md').exists():copy(ROOT/'CONTINUAR_DESARROLLO.md','CONTINUAR_DESARROLLO.md')
 for file in (ROOT/'ensayos').glob('*.patch'):copy(file,Path('investigacion/variantes_no_adoptadas')/file.name)
 for name in ['preparar_entrega.py','generar_informe.py','agregar_variante_prioridad.py','empaquetar_verificar.py']:
  copy(ROOT/name,Path('investigacion/construccion_entrega')/name)
 rows=json.loads((ROOT/'regresion_historica/protocolo.json').read_text())['casos'];portable=[];m1_fingerprints={}
 for spec in rows:
  name=spec['id'];reference=Path(spec['referencia_step'])
  copy(reference,Path('referencias_R7')/(name+'.step'))
  previous=Path('/workspace/work/mejora_cad_post_avance_20261026/regresion_historica/resultados')/(name+'.step')
  if previous.exists():m1_fingerprints[name]={'sha256_step':sha(previous),'sha256_DATA':hashlib.sha256(previous.read_bytes().split(b'DATA;',1)[1]).hexdigest()}
  portable.append({**spec,'source':str(Path('material_pruebas')/Path(spec['source']).relative_to(R7/'material_pruebas')),
                   'referencia_step':str(Path('referencias_R7')/(name+'.step'))})
 save('PROTOCOLO_PORTABLE.json',{'casos':portable,'ruta_nueva_activada':False,'nota':'Conversión completa de regresión; no equivale a validar contornos_compartidos=True en estas piezas.'})
 save('REFERENCIAS_M1_SHA256.json',{'alcance':'Comparación exacta del bloque DATA, equivalente a comparar los bytes; evita duplicar 157 MB de STEP ya conservados en la entrega anterior. Se mantienen completos los STEP R7 y los 21 resultados nuevos M3.','referencias':m1_fingerprints})
 def constants(path):
  return {n.targets[0].id:ast.unparse(n.value) for n in ast.parse(path.read_text()).body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id.startswith('MAX_')}
 original=constants(R7/'Visor_experimental_fuentes/motor_v2.py');current=constants(MOTOR/'motor_v2.py')
 assert all(current[k]==v for k,v in original.items())
 controls=[]
 for name in ['perfiles_precision.py','holgura_geometrica.py','validacion_densa.py','politica_conversion.py']:
  a=R7/'Visor_experimental_fuentes'/name;b=MOTOR/name
  if a.exists() and b.exists():
   assert a.read_bytes()==b.read_bytes(),name
   controls.append({'archivo':name,'identico_R7':True,'sha256':sha(b)})
 save('TOLERANCIAS_VERIFICADAS.json',{'constantes_R7':original,'constantes_actuales':current,'constantes_R7_sin_relajar':True,'controles_identicos_R7':controls,'api_nueva_por_defecto':False})
 save('ENTORNO.json',{'python':sys.version,'sistema':sys.platform,'paquetes':{d.metadata['Name']:d.version for d in metadata.distributions() if d.metadata['Name']}})
 save('PROCEDENCIA.json',{'base_github':'2cd86999614a37518b460f674db5763b186d025d','fuentes_congeladas':len(manifest),
   'fuentes_y_ensayo_API_identicos':all((ROOT/'motor_experimental'/n).read_bytes()==(MOTOR/n).read_bytes() for n in manifest),
   'entrada_pinza_sha256':sha(R7/'material_pruebas/stl_regresion_14/pinza.stl'),
   'step_API_sha256':sha(ROOT/'resultados/pinza_api_integrada.step'),
   'evaluador_R7_sha256':{str(p.relative_to(R7/'Visor_experimental_fuentes')):sha(p) for p in (R7/'Visor_experimental_fuentes').rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts},
   'control_frontera_M1_sha256':sha(DEST/'herramientas/control_frontera_M1_inmutable.py')})
 print('Preparado:',DEST,';',len(manifest),'fuentes;',len(changes),'cambios respecto M2')
if __name__=='__main__':main()
