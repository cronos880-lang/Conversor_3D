"""Conservar separadamente el candidato posterior, sin atribuirle pruebas de M3."""
from pathlib import Path
import json,hashlib,shutil,difflib,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent;DEST=ROOT/'entrega/avance_contornos_CAD_NO_ACTUALIZACION'
def read(p):return json.loads(p.read_text()) if p.exists() else {}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 motor=ROOT/'motor_congelado_prioridad';manifest=read(ROOT/'motor_congelado_prioridad_sha256.json')
 assert manifest and all(sha(motor/n)==h for n,h in manifest.items())
 variant=DEST/'variante_prioridad_cilindros';variant.mkdir(exist_ok=True);patch=[]
 for name,digest in manifest.items():
  target=variant/'fuentes'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(motor/name,target)
  base=ROOT/'motor_congelado_validacion'/name
  if base.read_bytes()!=(motor/name).read_bytes():
   patch.extend(difflib.unified_diff(base.read_text().splitlines(True),(motor/name).read_text().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
 (variant/'CAMBIOS_RESPECTO_M3.patch').write_text(''.join(patch));(variant/'FUENTES_SHA256.json').write_text(json.dumps(manifest,indent=2))
 suite={}
 if (ROOT/'pruebas_prioridad_completas.xml').exists():
  data=ET.parse(ROOT/'pruebas_prioridad_completas.xml').getroot().find('testsuite');suite=dict(data.attrib)
 cad=read(ROOT/'resultados/bancada_prioridad_cilindros.json');qa=read(ROOT/'resultados/bancada_prioridad_contraste.json')
 pinza=read(ROOT/'repeticion_prioridad/pinza.aceptacion.json')
 complete=bool(cad.get('puerta_cad_superada') and qa.get('step_exacto') and qa.get('geometria_R7')
   and not qa.get('error') and len(qa.get('frontera_tres_resoluciones',{}).get('resoluciones',[]))==3)
 state={'actualizacion_aprobada':False,'api_solo_bajo_opcion_explicita':True,'bancada_caso_completo':complete,
        'bancada_API':cad,'bancada_contraste':qa,'pinza_completa':bool(pinza.get('caso_verificado')),
        'suite_candidato':suite,'regresion_21_en_esta_variante':'NO REPETIDA: corresponde a M3; no se transfiere automáticamente.',
        'fuentes_sha256':manifest}
 (variant/'ESTADO.json').write_text(json.dumps(state,indent=2,ensure_ascii=False))
 if complete:shutil.copy2(ROOT/'resultados/bancada_prioridad_cilindros.step',DEST/'resultados_verificados/bancada_variante_prioridad.step')
 if pinza.get('caso_verificado'):shutil.copy2(ROOT/'repeticion_prioridad/pinza.step',DEST/'resultados_verificados/pinza_variante_prioridad.step')
 if (ROOT/'repeticion_prioridad').exists():shutil.copytree(ROOT/'repeticion_prioridad',DEST/'evidencias/repeticion_variante_prioridad',dirs_exist_ok=True)
 for directory,label in [('motor_ensayo_parametros_locales','nucleos_no_adoptados'),('motor_ensayo_circulos_canonicos','circulos_no_adoptados')]:
  other=ROOT/directory;diff=[]
  for name in manifest:
   before=ROOT/'motor_congelado_validacion'/name;after=other/name
   if after.is_file() and before.read_bytes()!=after.read_bytes():diff.extend(difflib.unified_diff(before.read_text().splitlines(True),after.read_text().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
  target=DEST/'investigacion/variantes_no_adoptadas'/(label+'.patch');target.parent.mkdir(parents=True,exist_ok=True);target.write_text(''.join(diff))
 status=read(DEST/'ESTADO_ACEPTACION.json');status['variante_prioridad_cilindros']={k:v for k,v in state.items() if k!='fuentes_sha256'}
 (DEST/'ESTADO_ACEPTACION.json').write_text(json.dumps(status,indent=2,ensure_ascii=False))
 quality=qa.get('geometria_R7',{});cyl=qa.get('cilindros_respaldados',{})
 section=f'''

## Candidato posterior: prioridad de cilindros confirmados

Este candidato se conserva **separado de M3** en `variante_prioridad_cilindros/fuentes`, con su propia huella y parche. Primero asigna las superficies cilíndricas respaldadas por todos sus vértices y centroides (límite anterior de 0,008 mm); después segmenta las demás regiones. Las entidades manuales del usuario mantienen prioridad. El caso negativo de un hexágono impide tomar como cilindro un polígono sólo porque sus vértices estén sobre una circunferencia.

Estado de Bancada en este candidato: **{'PASA todas las puertas de ese caso' if complete else 'NO CONSTA aprobado en todas las puertas'}**. Estado de la repetición completa de pinza: **{'PASA' if pinza.get('caso_verificado') else 'NO CONSTA aprobada'}**. No se publica como actualización del Visor.

| Medida de Bancada en la variante | Resultado registrado |
|---|---|
| Caras / sólidos / BOP | {cad.get('caras','sin resultado')} / {cad.get('solidos','sin resultado')} / {cad.get('bop','sin resultado')} |
| Exactitud en lectura fría | {cad.get('step_exacto','sin resultado')} |
| Cilindros confirmados / preservados | {cyl.get('confirmados','sin resultado')} / {cyl.get('preservados','sin resultado')} |
| Caja / volumen | {quality.get('caja_error_mm','sin resultado')} mm / {quality.get('volumen_error_pct','sin resultado')} % |
| Desviación máxima densa observada | {quality.get('desviacion_max_verificada_mm','sin resultado')} mm |
| Resoluciones finas completadas | {len(qa.get('frontera_tres_resoluciones',{}).get('resoluciones',[]))} de 3 |
| Error de comprobación independiente | {qa.get('error') or qa.get('error_geometria_R7') or 'ninguno registrado' if qa else 'prueba no completada'} |
| Suite del candidato (total / fallos / errores / omitidas) | {suite.get('tests','sin resultado')} / {suite.get('failures','sin resultado')} / {suite.get('errors','sin resultado')} / {suite.get('skipped','sin resultado')} |

La batería de 21 conversiones de esta entrega corresponde a las fuentes M3. **No se afirma que haya sido repetida con este candidato posterior.** Sus verificaciones específicas se registran en `variante_prioridad_cilindros/ESTADO.json`. Tampoco resuelve el Lego ni activa la mejora en la interfaz.
'''
 with (DEST/'INFORME_RESULTADOS.md').open('a') as f:f.write(section)
 with (DEST/'REPRODUCIR.md').open('a') as f:f.write('''

## Candidato separado de prioridad cilíndrica

Para comprobar la variante posterior en el mismo entorno, usa la herramienta de la raíz e indica sus fuentes y su manifiesto explícitamente:

```bash
python herramientas/reproducir_ruta_nueva.py \
  --paquete . \
  --motor variante_prioridad_cilindros/fuentes \
  --manifiesto variante_prioridad_cilindros/FUENTES_SHA256.json \
  --entrada entradas/Bancada_Motor.stl \
  --salida prueba_variante/bancada.step \
  --limite 600
```

Es una comprobación de desarrollo, no una actualización de la aplicación. La regresión de 21 casos corresponde a M3; no se atribuye a esta variante. Los tiempos de ejecución dependen de la concurrencia y del equipo; cambiar el presupuesto no cambia tolerancias geométricas.
''')
 print('Variante conservada, Bancada completa:',complete,'pinza completa:',bool(pinza.get('caso_verificado')),'suite:',suite)
if __name__=='__main__':main()
