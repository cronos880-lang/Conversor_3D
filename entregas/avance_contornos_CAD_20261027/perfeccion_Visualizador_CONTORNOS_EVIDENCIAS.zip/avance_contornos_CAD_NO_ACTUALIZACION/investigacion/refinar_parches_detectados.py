"""Refinar sólo parches señalados por BOP y vinculados a sus triángulos fuente.

Diagnóstico experimental reutilizable: no se guardan nombres ni índices de
piezas en el algoritmo. La malla original permanece intacta.
"""
from pathlib import Path
import sys,json,hashlib
import numpy as np,trimesh,cadquery as cq
step,checks,mapping,destination=map(Path,sys.argv[1:]);data=np.load(mapping)
record=json.loads(checks.read_text());vertices=data['vertices'];faces=data['triangulos'];labels=data['etiquetas'];order=data['orden_caras']
shape=cq.importers.importStep(str(step)).val();cad_faces=shape.Faces()
if len(order)!=len(cad_faces):raise ValueError('La vinculación de caras no coincide con el STEP.')
targets=set();bound=[]
for error in record['interferencias_detalle']:
 if error['estado']!='BOPAlgo_CheckStatus.BOPAlgo_SelfIntersect':raise ValueError('No se repara este tipo de interferencia.')
 for index in error['caras_ids']:
  ids=np.flatnonzero(labels==order[index]);patch=np.unique(faces[ids])
  if len(ids)>2:raise ValueError('El parche no es pequeño; se requiere otra estrategia.')
  points=np.array([v.Center().toTuple() for v in cad_faces[index].Vertices()]);reference=vertices[patch]
  maximum=float(np.linalg.norm(points[:,None,:]-reference[None,:,:],axis=2).min(axis=1).max())
  if maximum>.012:raise ValueError('No se demuestra la correspondencia del parche con la fuente.')
  targets.update(map(int,ids));bound.append({'cara_step':index,'triangulos_fuente':ids.tolist(),'max_distancia_vertices_mm':maximum})
if not targets:raise ValueError('No hay parches vinculados para refinar.')
new_vertices=vertices.tolist();new_faces=[]
for i,(a,b,c) in enumerate(faces):
 if i not in targets:new_faces.append((a,b,c));continue
 center=np.mean(vertices[[a,b,c]].astype(np.longdouble),axis=0).astype(float)
 n=len(new_vertices);new_vertices.append(center.tolist());new_faces.extend([(a,b,n),(b,c,n),(c,a,n)])
old=trimesh.Trimesh(vertices,faces,process=False);new=trimesh.Trimesh(np.array(new_vertices),np.array(new_faces),process=False)
if not (old.is_watertight and new.is_watertight and new.is_winding_consistent and old.euler_number==new.euler_number):
 raise ValueError('La subdivisión cambia la topología; descartada.')
if abs(old.volume-new.volume)>1e-9 or abs(old.area-new.area)>1e-9:raise ValueError('La subdivisión no conserva las medidas.')
with destination.open('w') as stream:
 stream.write(f'OFF\n{len(new_vertices)} {len(new_faces)} 0\n')
 for p in new_vertices:stream.write(' '.join(format(float(v),'.17g') for v in p)+'\n')
 for f in new_faces:stream.write('3 '+' '.join(str(int(v)) for v in f)+'\n')
report={'etapa':'subdivision_local_experimental_no_aprobada','fuente_geometrica':str(mapping),
 'step_comprobado_sha256':hashlib.sha256(step.read_bytes()).hexdigest(),'parches':bound,'triangulos_refinados':len(targets),
 'caras_antes':len(old.faces),'caras_despues':len(new.faces),'cambio_volumen_mm3':float(new.volume-old.volume),
 'cambio_area_mm2':float(new.area-old.area),'euler_antes':int(old.euler_number),'euler_despues':int(new.euler_number),
 'stl_original_modificado':False,'salida':str(destination)}
destination.with_suffix('.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
