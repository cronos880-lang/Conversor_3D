"""Localizar el fallo del mallado bruto de 0,00025 mm, sin corregirlo ni aprobarlo."""
from pathlib import Path
import sys,json,time
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'motor_congelado_validacion'))
import numpy as np,trimesh,cadquery as cq
from topologia_vertices import inspeccionar_vertices
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.BRepTools import BRepTools
from OCP.BRep import BRep_Tool
from OCP.TopLoc import TopLoc_Location
from OCP.TopAbs import TopAbs_REVERSED
source,output=map(Path,sys.argv[1:]);start=time.monotonic();shape=cq.importers.importStep(str(source)).val()
BRepTools.Clean_s(shape.wrapped);BRepMesh_IncrementalMesh(shape.wrapped,.00025,False,.04,False).Perform()
vertices=[];faces=[];owners=[]
for i,face in enumerate(shape.Faces()):
 loc=TopLoc_Location();tri=BRep_Tool.Triangulation_s(face.wrapped,loc)
 if tri is None:raise ValueError('Cara sin malla.')
 offset=len(vertices);vertices.extend(tri.Node(j).Transformed(loc.Transformation()).Coord() for j in range(1,tri.NbNodes()+1))
 for item in tri.Triangles():
  a,b,c=item.Get();faces.append((a+offset-1,c+offset-1,b+offset-1) if face.wrapped.Orientation()==TopAbs_REVERSED else (a+offset-1,b+offset-1,c+offset-1));owners.append(i)
V=np.asarray(vertices);F=np.asarray(faces);owners=np.asarray(owners)
_,first,inverse=np.unique(np.round(V/1e-10).astype(np.int64),axis=0,return_index=True,return_inverse=True)
mesh=trimesh.Trimesh(V[first],inverse[F],process=False);counts=np.bincount(mesh.edges_unique_inverse,minlength=len(mesh.edges_unique))
bad=mesh.edges_unique[counts!=2];bad_vertices=np.unique(bad);near=np.isin(mesh.faces,bad_vertices).any(axis=1)
record={'actualizacion_aprobada':False,'solo_diagnostico':True,'deflexion_mm':.00025,'angulo_rad':.04,
 'cerrado':bool(mesh.is_watertight),'orientado':bool(mesh.is_winding_consistent),'euler':int(mesh.euler_number),
 'aristas_una_cara':int((counts==1).sum()),'aristas_mas_dos_caras':int((counts>2).sum()),
 'triangulos_area_cero':int((mesh.area_faces==0).sum()),'topologia_vertices':inspeccionar_vertices(mesh),
 'caras_cad_vecinas':np.unique(owners[near]).tolist(),'vertices_problema_xyz':mesh.vertices[bad_vertices].tolist()[:40],
 'segundos':time.monotonic()-start,'ningun_triangulo_retirado':True,'ningun_control_relajado':True}
output.write_text(json.dumps(record,indent=2));np.savez_compressed(output.with_suffix('.npz'),vertices=mesh.vertices,triangulos=mesh.faces,propietarios=owners)
print(record,flush=True)
