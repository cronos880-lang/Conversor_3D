"""Conversión experimental mediante la API real, sin sustituir funciones."""
from pathlib import Path
import sys,time,json,traceback,os
ROOT=Path(__file__).resolve().parents[1]
MOTOR=Path(os.environ.get('VISOR_MOTOR_ENSAYO',str(ROOT/'motor_congelado_validacion')))
sys.path[:0]=[str(MOTOR),str(MOTOR/'motor_superficies')]
from meshfit_detect import detect
from meshfit_step import export_step
from preprocesador_stl import cargar_exacto
from invariantes_material import InvariantesMaterial
from calidad_topologica import leer_solido_step_estricto
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.BRepAlgoAPI import BRepAlgoAPI_Check
source,output=map(Path,sys.argv[1:]);start=time.monotonic();record={'actualizacion_aprobada':False,'api_real':True}
try:
 original=cargar_exacto(source);invariants=InvariantesMaterial(original)
 if not original.is_watertight or not original.is_winding_consistent:raise ValueError('Se requiere entrada cerrada y orientada.')
 result,working=detect(str(source),angle_tol_deg=32.,rms_tol_rel=.01,flat_tol_deg=8.,scan_mode=False)
 export_step(result,working,str(output),solid=True,require_solid=True,ajuste_ia=False,
             precision_reparacion=True,refinar_curvas=True,contornos_compartidos=True,
             cavidades_verificadas=bool(invariants.negative))
 shape=leer_solido_step_estricto(output)
 record['step_exacto']=bool(BRepCheck_Analyzer(shape.wrapped,True,False,True).IsValid())
 print('LECTURA_FRIA',record['step_exacto'],time.monotonic()-start,flush=True)
 check=BRepAlgoAPI_Check(shape.wrapped,False,True)
 record.update(bop=len(list(check.Result())),caras=len(shape.Faces()),solidos=len(shape.Solids()))
 record['puerta_cad_superada']=record['step_exacto'] and record['bop']==0 and record['solidos']==1
except Exception as exc:record['error']=str(exc);traceback.print_exc()
record['segundos']=time.monotonic()-start;output.with_suffix('.json').write_text(json.dumps(record,indent=2));print('FINAL',record,flush=True)
