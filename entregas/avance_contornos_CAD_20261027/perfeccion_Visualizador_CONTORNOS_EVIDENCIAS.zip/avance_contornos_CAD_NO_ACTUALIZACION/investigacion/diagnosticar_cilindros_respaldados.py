"""Relacionar los cilindros confirmados del detector con los del STEP, sin relajar cotas."""
from pathlib import Path
import sys,json,importlib.util
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT/'motor_congelado_validacion'),str(ROOT/'motor_congelado_validacion/motor_superficies')]
import numpy as np,cadquery as cq
from meshfit_detect import detect
from reconstruccion_curvas import cilindros_respaldados
from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.GeomAbs import GeomAbs_Cylinder
source,step,report=map(Path,sys.argv[1:]);result,mesh=detect(str(source),angle_tol_deg=32.,rms_tol_rel=.01,flat_tol_deg=8.,scan_mode=False)
required=cilindros_respaldados(result,mesh);shape=cq.importers.importStep(str(step)).val();candidates=[]
for i,face in enumerate(shape.Faces()):
 adaptor=BRepAdaptor_Surface(face.wrapped)
 if adaptor.GetType()==GeomAbs_Cylinder:
  c=adaptor.Cylinder();candidates.append((i,c.Radius(),np.array(c.Axis().Direction().Coord()),np.array(c.Location().Coord())))
rows=[]
for r in required:
 axis=r['eje']/np.linalg.norm(r['eje']);distances=[]
 for i,radius,direction,center in candidates:
  distances.append({'cara':i,'radio':radius,'error_radio_mm':abs(radius-r['radio']),
   'alineacion':abs(direction@axis),'distancia_ejes_mm':float(np.linalg.norm(np.cross(center-r['centro'],axis)))})
 distances.sort(key=lambda x:x['error_radio_mm']+x['distancia_ejes_mm']+100*(1-x['alineacion']))
 row={'radio_fuente':r['radio'],'eje_fuente':axis.tolist(),'centro_fuente':r['centro'].tolist(),'max_ajuste_fuente':r['max_entrada_mm'],'mas_proximos':distances[:2]};rows.append(row);print(row,flush=True)
report.write_text(json.dumps(rows,indent=2))
