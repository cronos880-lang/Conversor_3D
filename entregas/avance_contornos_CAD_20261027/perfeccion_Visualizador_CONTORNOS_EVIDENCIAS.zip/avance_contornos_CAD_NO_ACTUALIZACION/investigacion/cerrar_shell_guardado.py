from pathlib import Path
import sys,time,json,traceback
R=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(R/'motor_experimental/motor_superficies')]
import cadquery as cq
from fijacion_contornos import AjusteContornos,OrientarSolido,completar_vertices_singulares
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeSolid
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.BRepAlgoAPI import BRepAlgoAPI_Check
from OCP.BRepTools import BRepTools
from OCP.BRep import BRep_Tool
from OCP.BRepLib import BRepLib
source,dest=map(Path,sys.argv[1:]);t=time.monotonic();record={'ok':False}
try:
 shape=cq.Shape.importBrep(str(source));raw,record['cierre_parametrico']=completar_vertices_singulares(shape.wrapped)
 fix=AjusteContornos(raw)
 print('ShapeFix inicio',flush=True);fix.Perform();print('ShapeFix fin',time.monotonic()-t,flush=True)
 result=cq.Shape.cast(fix.Shape());maker=BRepBuilderAPI_MakeSolid()
 for shell in result.Shells():maker.Add(shell.wrapped)
 orient=OrientarSolido(maker.Solid());orient.Perform();native=orient.Solid()
 for edge in cq.Shape.cast(native).Edges():
  if not BRep_Tool.SameRange_s(edge.wrapped) or not BRep_Tool.SameParameter_s(edge.wrapped):
   BRepLib.SameRange_s(edge.wrapped,1e-10);BRepLib.SameParameter_s(edge.wrapped,1e-9,True)
 BRepTools.Write_s(native,str(dest.with_suffix('.native.brep')))
 record['nativo_exacto']=bool(BRepCheck_Analyzer(native,True,False,True).IsValid())
 record['nativo_estandar']=bool(BRepCheck_Analyzer(native).IsValid())
 print('NATIVO',record,flush=True)
 if not record['nativo_estandar'] or not record['nativo_exacto']:
  raise ValueError('El B-Rep nativo no supera la aceptación; no se exporta para intentar ocultar el defecto.')
 cq.Shape.cast(native).exportStep(str(dest));cold=cq.importers.importStep(str(dest)).val()
 bop=BRepAlgoAPI_Check(cold.wrapped,False,True)
 record.update(exacto=bool(BRepCheck_Analyzer(cold.wrapped,True,False,True).IsValid()),estandar=cold.isValid(),
               bop=len(list(bop.Result())),caras=len(cold.Faces()),solidos=len(cold.Solids()),
               max_tolerancia_mm=max(BRep_Tool.Tolerance_s(e.wrapped) for e in cold.Edges()))
 record['ok']=record['exacto'] and record['estandar'] and record['bop']==0 and record['solidos']==1
except Exception as e:record['error']=str(e);traceback.print_exc()
record['segundos']=time.monotonic()-t;dest.with_suffix('.json').write_text(json.dumps(record,indent=2));print('FINAL',record,flush=True)
