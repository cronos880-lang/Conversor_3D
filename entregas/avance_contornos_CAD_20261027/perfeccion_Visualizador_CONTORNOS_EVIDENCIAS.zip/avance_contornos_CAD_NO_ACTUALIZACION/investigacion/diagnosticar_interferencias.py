import sys,json,time
from pathlib import Path
import cadquery as cq
from OCP.BRepAlgoAPI import BRepAlgoAPI_Check
from OCP.BRepTools import BRepTools
source,report=map(Path,sys.argv[1:]);start=time.monotonic();shape=cq.importers.importStep(str(source)).val()
print('LECTURA',time.monotonic()-start,flush=True);check=BRepAlgoAPI_Check(shape.wrapped,False,True);rows=[]
for i,result in enumerate(check.Result()):
 row={'estado':str(result.GetCheckStatus()),'formas':[]}
 for side,items in [(1,result.GetFaultyShapes1()),(2,result.GetFaultyShapes2())]:
  for j,item in enumerate(items):
   obj=cq.Shape.cast(item);box=obj.BoundingBox();r={'lado':side,'tipo':str(item.ShapeType()),'geom':obj.geomType(),
    'caja':[box.xmin,box.xmax,box.ymin,box.ymax,box.zmin,box.zmax],
    'caras_ids':[k for k,f in enumerate(shape.Faces()) if f.wrapped.IsSame(item)],
    'aristas_ids':[k for k,e in enumerate(shape.Edges()) if e.wrapped.IsSame(item)]}
   path=report.with_name(report.stem+f'_{i}_{side}_{j}.brep');BRepTools.Write_s(item,str(path));r['geometria_archivo']=path.name
   row['formas'].append(r)
 rows.append(row);print(row,flush=True)
record={'archivo':str(source),'fallos':rows,'segundos':time.monotonic()-start};report.write_text(json.dumps(record,indent=2))
