"""Ensayo geométrico: curvas comunes de la intersección de las superficies."""
import sys,json,time,math,collections
from pathlib import Path
import numpy as np
import cadquery as cq
from OCP.BRep import BRep_Tool,BRep_Builder
from OCP.BRepCheck import BRepCheck_Analyzer,BRepCheck_NoError
from OCP.GeomAPI import GeomAPI_IntSS,GeomAPI_ProjectPointOnCurve
from OCP.gp import gp_Pnt
from OCP.TopExp import TopExp
from OCP.TopAbs import TopAbs_EDGE,TopAbs_FACE,TopAbs_FORWARD,TopAbs_REVERSED
from OCP.TopTools import TopTools_IndexedDataMapOfShapeListOfShape
from OCP.TopoDS import TopoDS,TopoDS_Edge
from OCP.ShapeBuild import ShapeBuild_ReShape
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeEdge
from OCP.ShapeFix import ShapeFix_Shape
from OCP.BRepAdaptor import BRepAdaptor_Curve

source,dest,report=map(Path,sys.argv[1:]);shape=cq.importers.importStep(str(source)).val()
check=BRepCheck_Analyzer(shape.wrapped,True,False,True)
failed=set()
for f in shape.Faces():
    for e in f.Edges():
        if any(s!=BRepCheck_NoError for s in check.Result(e.wrapped).StatusOnShape(f.wrapped)):
            failed.add(hash(e))
mapping=TopTools_IndexedDataMapOfShapeListOfShape();TopExp.MapShapesAndAncestors_s(shape.wrapped,TopAbs_EDGE,TopAbs_FACE,mapping)
context=ShapeBuild_ReShape();rows=[];start=time.monotonic()
for edge in shape.Edges():
    faces=[TopoDS.Face_s(f) for f in mapping.FindFromKey(edge.wrapped)]
    if len(faces)!=2:continue
    if hash(edge) not in failed:continue
    row={'arista':len(rows),'caras':[cq.Face(f).geomType() for f in faces]};rows.append(row)
    try:
        t=time.monotonic();inter=GeomAPI_IntSS(*[BRep_Tool.Surface_s(f) for f in faces],1e-8)
        row['intersecciones']=inter.NbLines() if inter.IsDone() else 0
        if not row['intersecciones']:raise ValueError('sin intersección')
        old=BRepAdaptor_Curve(edge.wrapped);samples=[old.Value(t) for t in np.linspace(old.FirstParameter(),old.LastParameter(),9)]
        candidates=[]
        for i in range(1,inter.NbLines()+1):
            curve=inter.Line(i);projs=[GeomAPI_ProjectPointOnCurve(p,curve) for p in samples]
            if any(p.NbPoints()==0 for p in projs):continue
            errors=[p.LowerDistance() for p in projs];params=np.array([p.LowerDistanceParameter() for p in projs])
            if curve.IsPeriodic():params=np.unwrap(params,period=curve.Period())
            if np.any(np.diff(params)>1e-6) and np.any(np.diff(params)<-1e-6):continue
            candidates.append((max(errors),curve,float(params[0]),float(params[-1])))
        if not candidates:raise ValueError('sin rama continua')
        err,curve,lo,hi=min(candidates,key=lambda v:v[0]);row['movimiento_curva_mm']=err
        if err>.012:raise ValueError('intersección alejada')
        if abs(hi-lo)<1e-8:raise ValueError('intervalo degenerado')
        if hi<lo:
            lo,hi=curve.ReversedParameter(lo),curve.ReversedParameter(hi);curve=curve.Reversed()
        builder=BRep_Builder();new=TopoDS_Edge();builder.MakeEdge(new,curve,1e-7)
        v0=TopExp.FirstVertex_s(edge.wrapped);v1=TopExp.LastVertex_s(edge.wrapped)
        for vertex,point in [(v0,curve.Value(lo)),(v1,curve.Value(hi))]:
            distance=BRep_Tool.Pnt_s(vertex).Distance(point)
            if distance>.012:raise ValueError('extremo alejado')
            builder.UpdateVertex(vertex,max(BRep_Tool.Tolerance_s(vertex),distance*1.01+1e-7))
        builder.Add(new,v0.Oriented(TopAbs_FORWARD));builder.Add(new,v1.Oriented(TopAbs_REVERSED));builder.Range(new,lo,hi)
        context.Replace(edge.wrapped,new.Oriented(edge.wrapped.Orientation()))
        row['ok']=True;row['segundos']=time.monotonic()-t
    except Exception as e:row['error']=str(e)
    print(row,flush=True)
    report.write_text(json.dumps({'parcial':rows},indent=2))
work=context.Apply(shape.wrapped)
fix=ShapeFix_Shape(work);fix.SetPrecision(1e-7);fix.SetMaxTolerance(1e-5);fix.Perform()
cq.Shape.cast(fix.Shape()).exportStep(str(dest));cold=cq.importers.importStep(str(dest)).val()
r={'aristas':rows,'caras':len(cold.Faces()),'solidos':len(cold.Solids()),'estandar':cold.isValid(),
   'exacto':BRepCheck_Analyzer(cold.wrapped,True,False,True).IsValid(),'segundos':time.monotonic()-start}
report.write_text(json.dumps(r,indent=2));print('FINAL', {k:v for k,v in r.items() if k!='aristas'},flush=True)
