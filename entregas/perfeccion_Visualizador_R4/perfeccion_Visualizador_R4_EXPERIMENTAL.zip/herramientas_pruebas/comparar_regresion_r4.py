from pathlib import Path
import json,hashlib,sys
sys.path.insert(0,str(Path.cwd()))
from revolucion_verificada import conviene
old=Path('/workspace/work/perfeccion_Visualizador_r3/evidencias/regresion_precision');new=Path('evidencias/regresion_precision')
a=json.loads((old/'bateria.json').read_text())['resultados'];b=json.loads((new/'bateria.json').read_text())['resultados'];out=[]
assert len(a)==len(b)==12
for row in b:
 previous=next(r for r in a if r['archivo']==row['archivo']);assert row['sha256']==previous['sha256'];assert row['ok']==previous['ok'];report={'archivo':row['archivo'],'ok_R3':previous['ok'],'ok_R4':row['ok'],'sin_nueva_regresion':True}
 if row['ok']:
  paths=[root/(Path(row['archivo']).stem+'.step') for root in (old,new)];data=[p.read_bytes().split(b'DATA;',1)[1] for p in paths];assert data[0]==data[1],row['archivo']
  q=row['informe_motor']['resultado']['calidad'];oq=previous['informe_motor']['resultado']['calidad']
  keys=['caras_step','tipos_caras','volumen_error_pct','caja_error_mm','integridad_cad','distancia_stl_step_mm','distancia_step_stl_mm','inspeccion_densa']
  differing=[k for k in keys if q[k]!=oq[k]]
  report.update(geometria_data_step_identica=True,sha256_data=hashlib.sha256(data[1]).hexdigest(),metricas_con_diferencias=differing,refinamiento_fragmentacion_elegible=conviene(q,row['informe_motor']['resultado']['caras_stl']))
 out.append(report)
result={'aceptadas_R3':sum(r['ok'] for r in a),'aceptadas_R4':sum(r['ok'] for r in b),'total':len(b),'nuevas_regresiones':0,'geometrias_aceptadas_identicas':all(r.get('geometria_data_step_identica',True) for r in out),'casos':out}
Path('evidencias/comparacion_regresion_r3_r4.json').write_text(json.dumps(result,indent=2,ensure_ascii=False));print(json.dumps(result,ensure_ascii=False))
# El ensayo de navegador posterior a las últimas salvaguardas produce el mismo
# DATA que el archivo nativo contrastado de forma independiente.
for name in ('navegador_30383_impresion.step','navegador_30383_automatico.step'):
 expected=Path('evidencias/30383_final/30383_alternate_fixed.step').read_bytes().split(b'DATA;',1)[1];actual=Path('evidencias')/name
 assert actual.read_bytes().split(b'DATA;',1)[1]==expected
