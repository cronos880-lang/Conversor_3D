const {chromium}=require('playwright');
const fs=require('fs');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 const page=await browser.newPage({viewport:{width:1440,height:900},acceptDownloads:true});const errors=[];let id;
 page.on('pageerror',e=>errors.push(String(e)));
 try{
 await page.goto('http://127.0.0.1:8768');
 await page.waitForFunction(()=>!document.getElementById('openBtn').disabled);
 if(await page.locator('#conversionProfile').inputValue()!=='precision')throw Error('El perfil por defecto no es precisión');
 await page.locator('#fileInput').setInputFiles('/workspace/work/rar_usuario_20261024/30383_alternate_fixed.stl');
 await page.waitForFunction(()=>!document.getElementById('convertBtn').disabled);
 await page.locator('#conversionProfile').selectOption('impresion');
 page.on('response',async r=>{if(r.url().endsWith('/iniciar-conversion'))try{id=(await r.json()).id}catch{}});
 await page.locator('#convertBtn').click();
 await page.waitForFunction(()=>document.getElementById('conversionPercent').textContent==='100 %'||document.getElementById('conversionPercent').classList.contains('failed'),{},{timeout:240000});
 if(await page.locator('#conversionPercent').evaluate(el=>el.classList.contains('failed')))throw Error(await page.locator('#error').innerText());
 if(await page.locator('#exportBtn').isDisabled())throw Error('Exportación deshabilitada');
 const state=await(await page.request.get('http://127.0.0.1:8768/estado-conversion/'+id)).json();
 const diagnostic=JSON.parse(fs.readFileSync('Registros_Conversion/'+id+'.json','utf8'));
 if(!state.precision_alcanzada||state.desviacion_max_mm===undefined)throw Error('Falta precisión alcanzada');
 if(!await page.locator('#details').innerText().then(t=>t.includes('Precisión alcanzada')))throw Error('No muestra precisión real');
 if(diagnostic.perfil!=='impresion'||diagnostic.calidad.perfil_validacion.id!=='impresion')throw Error('No se aplicó el perfil al motor');
 page.once('dialog',d=>d.accept('30383_impresion'));
 const downloaded=page.waitForEvent('download');await page.locator('#exportBtn').click();const download=await downloaded;
 await download.saveAs('evidencias/navegador_30383_impresion.step');
 if(!fs.readFileSync('evidencias/navegador_30383_impresion.step','utf8').startsWith('ISO-10303-21;'))throw Error('Descarga STEP incorrecta');
 await page.screenshot({path:'evidencias/navegador_r4.png',fullPage:true});
 await page.locator('#conversionProfile').selectOption('precision');
 if(!await page.locator('#exportBtn').isDisabled())throw Error('Cambiar perfil conserva indebidamente el STEP anterior');
 await page.locator('#newBtn').click();
 await page.waitForFunction(()=>document.getElementById('fileName').textContent==='Sin archivo');
 fs.writeFileSync('evidencias/navegador_r4.json',JSON.stringify({ok:true,id,estado:state,detalle_visible:await page.locator('#details').innerText(),perfil:diagnostic.calidad.perfil_validacion,errores_js:errors,flujo:['importar','elegir impresión','convertir','100%','descargar STEP','cambiar perfil invalida STEP','Nuevo']},null,2));
 if(errors.length)throw Error(errors.join('\n'));
 console.log('Navegador Chromium: flujo completo de impresión y descarga aprobado');
 }finally{
  if(id)try{const state=await(await page.request.get('http://127.0.0.1:8768/estado-conversion/'+id)).json();if(state.estado==='ejecutando')await page.request.post('http://127.0.0.1:8768/cancelar-conversion/'+id)}catch{}
  await browser.close();
 }
})().catch(e=>{console.error(e);process.exitCode=1});
