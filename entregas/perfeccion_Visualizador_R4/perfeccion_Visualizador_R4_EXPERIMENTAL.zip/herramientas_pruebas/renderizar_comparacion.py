from pathlib import Path
import cadquery as cq,vtk
window=vtk.vtkRenderWindow();window.SetOffScreenRendering(1);window.SetSize(1600,750)
paths=['evidencias/r4_rar_precision/30383_alternate_fixed.step','evidencias/30383_final/30383_alternate_fixed.step']
for i,path in enumerate(paths):
 solid=cq.importers.importStep(path).solids().val();r=vtk.vtkRenderer();r.SetViewport(i/2,0,(i+1)/2,1);r.SetBackground(.96,.97,.985);window.AddRenderer(r)
 verts,tris=solid.copy().tessellate(.015,angularTolerance=.08);points=vtk.vtkPoints();polys=vtk.vtkCellArray()
 for p in verts:points.InsertNextPoint(*p.toTuple())
 for tri in tris:polys.InsertNextCell(3);[polys.InsertCellPoint(int(k)) for k in tri]
 data=vtk.vtkPolyData();data.SetPoints(points);data.SetPolys(polys);mapper=vtk.vtkPolyDataMapper();mapper.SetInputData(data);actor=vtk.vtkActor();actor.SetMapper(mapper);actor.GetProperty().SetColor(.40,.67,.86);r.AddActor(actor)
 lp=vtk.vtkPoints();lines=vtk.vtkCellArray();index=0
 for edge in solid.Edges():
  pp=[edge.positionAt(k/32) for k in range(33)];lines.InsertNextCell(len(pp))
  for p in pp:lp.InsertNextPoint(*p.toTuple());lines.InsertCellPoint(index);index+=1
 ld=vtk.vtkPolyData();ld.SetPoints(lp);ld.SetLines(lines);lm=vtk.vtkPolyDataMapper();lm.SetInputData(ld);la=vtk.vtkActor();la.SetMapper(lm);la.GetProperty().SetColor(.1,.17,.23);la.GetProperty().SetLineWidth(1.2);r.AddActor(la)
 text=vtk.vtkTextActor();text.SetInput(f'{"R3" if i==0 else "R4"}: {len(solid.Faces())} caras / {len(solid.Edges())} aristas');text.GetTextProperty().SetColor(.1,.17,.23);text.GetTextProperty().SetFontSize(24);text.SetPosition(30,700);r.AddActor2D(text)
 r.GetActiveCamera().SetPosition(25,-38,25);r.GetActiveCamera().SetFocalPoint(0,0,4);r.GetActiveCamera().SetViewUp(0,0,1);r.ResetCamera();r.GetActiveCamera().Zoom(1.15)
window.Render();capture=vtk.vtkWindowToImageFilter();capture.SetInput(window);capture.Update();writer=vtk.vtkPNGWriter();writer.SetFileName('evidencias/30383_R3_R4_caras.png');writer.SetInputConnection(capture.GetOutputPort());writer.Write();print('Imagen comparativa R3/R4 guardada')
