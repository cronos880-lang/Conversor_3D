import sys,json,math
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
import cadquery as cq
from OCP.BRepClass3d import BRepClass3d_SolidClassifier
from OCP.TopAbs import TopAbs_IN,TopAbs_OUT
from OCP.gp import gp_Pnt
from preprocesador_stl import cargar_exacto,componentes
from verificacion_reparacion import union_independiente
source=Path('/workspace/work/rar_usuario_20261024/30383_alternate_fixed.stl');mesh=cargar_exacto(source)
ref=union_independiente(componentes(mesh)).Solids()[0];cad=cq.importers.importStep('evidencias/30383_final/30383_alternate_fixed.step').solids().val();checks=[]
for y in [-1.5,-1.1,-.6,0,.6,1.1,1.5]:checks.append(('tabique central' if y==0 else 'cavidad lateral',[-4.,y,5.58],TopAbs_IN if y==0 else TopAbs_OUT))
for y in [-.3,0,.3]:
 for angle in range(0,360,45):
  a=math.radians(angle);checks.append(('pared',[-4+1.3*math.cos(a),y,5.58+1.3*math.sin(a)],TopAbs_IN))
rows=[]
for zone,point,desired in checks:
 expected=BRepClass3d_SolidClassifier(ref.wrapped,gp_Pnt(*point),1e-7).State();actual=BRepClass3d_SolidClassifier(cad.wrapped,gp_Pnt(*point),1e-7).State()
 rows.append({'zona':zone,'xyz_mm':point,'referencia':str(expected),'step':str(actual),'ok':expected==actual==desired})
Path('evidencias/30383_cavidades_paredes.json').write_text(json.dumps({'ok':all(r['ok'] for r in rows),'puntos':rows},indent=2));assert all(r['ok'] for r in rows),[r for r in rows if not r['ok']];print('31 puntos específicos: cavidades laterales, tabique central y paredes conservados')
