"""Vigilar el proceso CAD ya aislado; sin crear otro motor ni relajar límites.

Ideas de meshfit_guard adaptadas al árbol del servidor y a cancelación existente.
"""
from __future__ import annotations
import os
import subprocess
import time
import psutil


class LimiteRecursos(RuntimeError):
    def __init__(self, message, stdout='', stderr='', pico_mb=0):
        super().__init__(message)
        self.stdout, self.stderr, self.pico_mb = stdout, stderr, pico_mb


def limite_memoria_bytes():
    # Límite absoluto conservador y mitad de RAM disponible al iniciar.
    # En Linux respetar además cgroup v2 del entorno de referencia.
    total = psutil.virtual_memory().total
    try:
        from pathlib import Path
        value = Path('/sys/fs/cgroup/memory.max').read_text().strip()
        if value != 'max':
            total = min(total, int(value))
    except (OSError, ValueError):
        pass
    return min(6*1024**3, int(total*.5))


def comunicar_vigilado(proc, timeout, detener, *, memoria_bytes=None):
    cap = limite_memoria_bytes() if memoria_bytes is None else memoria_bytes
    if timeout <= 0 or cap <= 0:
        raise ValueError('Límites de recursos inválidos.')
    start, peak = time.monotonic(), 0
    process = psutil.Process(proc.pid)
    while True:
        try:
            ram = sum(p.memory_info().rss for p in [process, *process.children(recursive=True)]
                      if p.is_running())
            peak = max(peak, ram)
        except psutil.NoSuchProcess:
            pass
        except psutil.AccessDenied as exc:
            detener(proc)
            out, err = proc.communicate()
            raise LimiteRecursos('No se puede supervisar la memoria del motor; detenido.', out, err, peak/1024**2) from exc
        why = (f'La conversión se detuvo al superar {timeout} segundos.' if time.monotonic()-start > timeout else
               f'La conversión se detuvo por memoria: {peak/1024**2:.0f} MB > {cap/1024**2:.0f} MB.' if peak > cap else None)
        if why:
            detener(proc)
            out, err = proc.communicate()
            raise LimiteRecursos(why, out, err, peak/1024**2)
        try:
            out, err = proc.communicate(timeout=min(.5, max(.01, timeout-(time.monotonic()-start))))
            return out, err, round(peak/1024**2, 2)
        except subprocess.TimeoutExpired:
            continue
