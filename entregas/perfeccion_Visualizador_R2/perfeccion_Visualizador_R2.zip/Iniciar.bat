@echo off
call "%~dp0Visor_experimental_fuentes\Iniciar.bat"
