"""Propuestas geométricas para reconstrucción CAD de entradas reparadas.

No aceptan un STEP: todo candidato requiere la validación original, relectura
CAD y controles de material. No se seleccionan piezas por nombre.
"""
from __future__ import annotations
import numpy as np


def _circulo(points):
    (x,y,b),*_ = np.linalg.lstsq(np.c_[2*points,np.ones(len(points))],
                                (points*points).sum(1),rcond=None)
    return np.array([x,y]),float(np.sqrt(max(0.,b+x*x+y*y)))


def _error_radial(triangles,center,radius):
    """Cota radial de TODO el triángulo frente al cilindro infinito."""
    p=triangles-center
    high=np.linalg.norm(p,axis=2).max(1)
    low=np.full(len(p),np.inf)
    crosses=[]
    for a,b in ((0,1),(1,2),(2,0)):
        start=p[:,a];edge=p[:,b]-start;den=(edge*edge).sum(1)
        t=np.clip(-(start*edge).sum(1)/np.maximum(den,1e-300),0.,1.)
        low=np.minimum(low,np.linalg.norm(start+t[:,None]*edge,axis=1))
        crosses.append(start[:,0]*p[:,b,1]-start[:,1]*p[:,b,0])
    cross=np.array(crosses).T
    area=np.abs((p[:,1,0]-p[:,0,0])*(p[:,2,1]-p[:,0,1])-
                (p[:,1,1]-p[:,0,1])*(p[:,2,0]-p[:,0,0]))
    inside=((cross>=0).all(1)|(cross<=0).all(1))&(area>1e-18)
    low[inside]=0.
    return np.maximum(np.abs(high-radius),np.abs(low-radius))


def detectar_cilindros(mesh,*,tolerancia=.012,limite=48):
    """Circunferencias con soporte angular y cota sobre triángulos completos."""
    from axial_recognition import candidates
    V,F,N,C,A=mesh.vertices,mesh.faces,mesh.face_normals,mesh.triangles_center,mesh.area_faces
    adjacency=mesh.face_adjacency
    neighbors=[[] for _ in F]
    for a,b in adjacency:neighbors[a].append(int(b));neighbors[b].append(int(a))
    known=candidates(mesh,min_faces=12,tol=tolerancia,max_trials=4000)
    proposals=[]
    for axis in range(3):
        ij=[k for k in range(3) if k!=axis]
        eligible=np.where(abs(N[:,axis])<.03)[0]
        if len(eligible)<12:continue
        projected=V[F[eligible]][:,:,ij]
        centers=C[eligible][:,ij]
        normals=N[eligible][:,ij]
        seeds={}
        def add(center,r):
            if r<.1 or r>2*np.linalg.norm(mesh.extents):return
            key=tuple(np.round(np.r_[center,r]/.02).astype(int))
            seeds.setdefault(key,(center,r))
        for k in known:
            if k['axis']==axis:add(np.asarray(k['center']),k['radius'])
        pairs=adjacency[(abs(N[adjacency[:,0],axis])<.03)&
                        (abs(N[adjacency[:,1],axis])<.03)]
        angles=mesh.face_adjacency_angles
        pairs=pairs if len(pairs)==0 else adjacency[(angles>np.radians(.5))&(angles<np.radians(45))&
                        (abs(N[adjacency[:,0],axis])<.03)&(abs(N[adjacency[:,1],axis])<.03)]
        eligible_set=set(eligible.tolist())
        for pair in pairs:
            pts=V[np.unique(F[pair])][:,ij]
            if len(np.unique(pts,axis=0))>=3:add(*_circulo(pts))
            near=set(map(int,pair));front=near.copy();origin=C[pair].mean(0)
            for _ in range(4):
                new={j for i in front for j in neighbors[i] if j in eligible_set and
                     np.linalg.norm((C[j]-origin)[ij])<np.linalg.norm(mesh.extents)*.02 and
                     abs(N[j]@N[pair[0]])>.6}
                front=new-near;near|=new
            pts=V[np.unique(F[list(near)])][:,ij]
            if len(np.unique(pts,axis=0))>=3:add(*_circulo(pts))
        for center,r in seeds.values():
            ids=None
            for iteration in range(4):
                radial=centers-center;length=np.linalg.norm(radial,axis=1)
                mask=(abs(length-r)<tolerancia+.003)&(
                      abs((radial*normals).sum(1))/np.maximum(length,1e-15)>.95)
                local=np.where(mask)[0]
                if len(local)<12:break
                errors=_error_radial(projected[local],center,r)
                local=local[errors<tolerancia]
                if len(local)<12:break
                ids=eligible[local]
                center,r=_circulo(V[np.unique(F[ids])][:,ij])
            if ids is None or len(ids)<12:continue
            errors=_error_radial(V[F[ids]][:,:,ij],center,r)
            ids=ids[errors<=tolerancia]
            if len(ids)<12:continue
            samples=V[np.unique(F[ids])]
            height=float(np.ptp(samples[:,axis]));area=float(A[ids].sum())
            phi=np.sort(np.arctan2(C[ids][:,ij[1]]-center[1],C[ids][:,ij[0]]-center[0])%(2*np.pi))
            arc=float(360*(1-np.diff(np.r_[phi,phi[0]+2*np.pi]).max()/(2*np.pi)))
            if height<.15 or area<.1 or arc<60:continue
            proposals.append({'axis':axis,'center':center.tolist(),'radius':r,'area':area,
                'faces':ids.tolist(),'height':height,'arc':arc,
                'max_triangulo_mm':float(_error_radial(V[F[ids]][:,:,ij],center,r).max())})
    accepted=[];covered=set()
    for p in sorted(proposals,key=lambda x:-x['area']):
        if p['radius']<.1:continue
        if len(set(p['faces'])-covered)<.6*len(p['faces']):continue
        if any(p['axis']==q['axis'] and abs(p['radius']-q['radius'])<.025 and
               np.linalg.norm(np.array(p['center'])-q['center'])<.025 for q in accepted):continue
        # El soporte no puede sumar pequeños parches inconexos de curvas
        # distintas para fingir una circunferencia completa.
        import trimesh
        ids=np.asarray(p['faces'],dtype=int);active=np.zeros(len(F),bool);active[ids]=True
        links=adjacency[active[adjacency].all(1)]
        groups=trimesh.graph.connected_components(links,nodes=ids,min_len=1)
        ij=[k for k in range(3) if k!=p['axis']];arcs=[]
        for group in groups:
            phi=np.sort(np.arctan2(C[group][:,ij[1]]-p['center'][1],
                                  C[group][:,ij[0]]-p['center'][0])%(2*np.pi))
            arcs.append(float(360*(1-np.diff(np.r_[phi,phi[0]+2*np.pi]).max()/(2*np.pi))))
        p['arco_conexo_max']=max(arcs)
        if p['arco_conexo_max']<60:continue
        accepted.append(p);covered.update(p['faces'])
        if len(accepted)>=limite:break
    return accepted


def _recortar_z(points,axis,lo,hi):
    """Recorte convexo de un triángulo al intervalo axial cerrado."""
    polygon=[np.asarray(p) for p in points]
    for value,sign in ((lo,1),(hi,-1)):
        new=[]
        for a,b in zip(polygon,polygon[1:]+polygon[:1]):
            da=sign*(a[axis]-value);db=sign*(b[axis]-value)
            if da>=0:new.append(a)
            if (da>=0)!=(db>=0):new.append(a+(b-a)*(da/(da-db)))
        polygon=new
        if not polygon:break
    return polygon


def _radio_minimo_polygon(points):
    p=np.asarray(points);best=float(np.linalg.norm(p,axis=1).min())
    signs=[]
    for a,b in zip(p,np.roll(p,-1,axis=0)):
        edge=b-a;t=float(np.clip(-a@edge/max(float(edge@edge),1e-300),0.,1.))
        best=min(best,float(np.linalg.norm(a+t*edge)));signs.append(float(np.cross(a,b)))
    # Un polígono proyectado no degenerado que contiene el origen tiene radio 0.
    area=abs(sum(signs))/2
    if area>1e-18 and (min(signs)>=0 or max(signs)<=0):best=0.
    return best


def envolvente_coaxial(mesh,cylinders,*,margen=.025):
    """Dominio conservador: certificado sobre todos los triángulos originales.

    Los cilindros solo proponen la envolvente. Ninguna pieza se dibuja por su
    nombre. Si la cobertura falla, la estrategia se rechaza. Los vacíos se
    sustraen solo si no cortan ninguna cara original y el número de giro es 0.
    """
    import cadquery as cq,trimesh,igl
    principal=max(cylinders,key=lambda p:p['area']);axis=principal['axis']
    ij=[k for k in range(3) if k!=axis];center=np.asarray(principal['center'])
    N,C,F,V=mesh.face_normals,mesh.triangles_center,mesh.faces,mesh.vertices
    envelopes=[];holes=[]
    for p in cylinders:
        if p['axis']!=axis or np.linalg.norm(np.asarray(p['center'])-center)>.03:continue
        ids=np.asarray(p['faces'],dtype=int);rad=C[ids][:,ij]-np.asarray(p['center'])
        sign=float(np.median((rad*N[ids][:,ij]).sum(1)))
        if sign<0:
            holes.append(p);continue
        active=np.zeros(len(F),bool);active[ids]=True;links=mesh.face_adjacency
        groups=trimesh.graph.connected_components(links[active[links].all(1)],nodes=ids,min_len=1)
        for group in groups:
            if len(group)<2 or mesh.area_faces[group].sum()<.01:continue
            points=V[np.unique(F[group])];lo=float(points[:,axis].min())-margen
            hi=float(points[:,axis].max())+margen
            if hi-lo<.05:continue
            radius=float(np.linalg.norm(points[:,ij]-center,axis=1).max())+margen
            envelopes.append((lo,hi,radius))
    if not envelopes:raise ValueError('No se ha propuesto una envolvente axial')
    proposed=sorted(set([float(mesh.bounds[0,axis])-margen,float(mesh.bounds[1,axis])+margen]+
                        [x for lo,hi,_ in envelopes for x in (lo,hi)]))
    cuts=[proposed[0]]
    for value in proposed[1:-1]:
        if value-cuts[-1]>=2*margen:cuts.append(value)
    cuts.append(proposed[-1])
    triangles=V[F];zmin=triangles[:,:,axis].min(1);zmax=triangles[:,:,axis].max(1)
    # Una cara puede atravesar varios niveles: comprobar su polígono recortado,
    # no únicamente los vértices del STL ni una muestra puntual.
    certified=[]
    for lo,hi in zip(cuts[:-1],cuts[1:]):
        ids=np.where((zmax>lo)&(zmin<hi))[0]
        if not len(ids):continue
        radius=0.
        for fi in ids:
            points=_recortar_z(triangles[fi],axis,lo,hi)
            if points:radius=max(radius,float(np.linalg.norm(np.asarray(points)[:,ij]-center,axis=1).max()))
        # Esta es solo una envolvente de trabajo. Ampliarla nunca modifica
        # una tolerancia de aceptación ni decide el material final.
        certified.append((lo,hi,radius+margen))
    envelopes=certified
    def cylinder(lo,hi,radius,ctr):
        origin=np.zeros(3);origin[axis]=lo;origin[ij]=ctr
        return cq.Solid.makeCylinder(radius,hi-lo,cq.Vector(*origin),cq.Vector(*np.eye(3)[axis]))
    parts=[cylinder(lo,hi,r,center) for lo,hi,r in envelopes]
    shape=parts[0].fuse(*parts[1:]).clean() if len(parts)>1 else parts[0]
    details=[]
    for p in holes:
        points=V[np.unique(F[p['faces']])];lo=float(points[:,axis].min())+margen
        hi=float(points[:,axis].max())-margen;radius=p['radius']-margen;ctr=np.asarray(p['center'])
        if hi<=lo or radius<=0:continue
        intersects=False
        for fi in np.where((zmax>lo)&(zmin<hi))[0]:
            polygon=_recortar_z(triangles[fi],axis,lo,hi)
            if polygon and _radio_minimo_polygon(np.asarray(polygon)[:,ij]-ctr)<radius:
                intersects=True;break
        if intersects:continue
        point=np.zeros(3);point[axis]=(lo+hi)/2;point[ij]=ctr
        if float(igl.winding_number(V,F,point))>.5:continue
        shape=shape.cut(cylinder(lo,hi,radius,ctr));details.append({'radio':radius,'min':lo,'max':hi})
    if not shape.isValid() or len(shape.Solids())!=1:
        raise ValueError('La envolvente no forma un sólido válido')
    return shape,{'axis':axis,'envolventes':len(envelopes),'vacios_certificados':details,
                  'cobertura':'Todos los triángulos recortados por intervalos axiales.',
                  'margen_envolvente_mm':margen,'volumen_dominio':shape.Volume()}


def detectar_planos(mesh,cylinders,*,min_area=.15,min_area_oblicua=1.,tolerancia=.00005):
    V,F,N,A,C=mesh.vertices,mesh.faces,mesh.face_normals,mesh.area_faces,mesh.triangles_center
    used=np.zeros(len(F),bool)
    for cylinder in cylinders:used[cylinder['faces']]=True
    planes=[]
    for fi in np.argsort(-A):
        if used[fi] or A[fi]<1e-8:continue
        n=N[fi].copy();j=np.argmax(abs(n))
        if n[j]<0:n=-n
        offset=float(n@C[fi]);rough=np.where((~used)&(abs(N@n)>.9999))[0]
        ids=rough[np.max(abs(V[F[rough]]@n-offset),axis=1)<tolerancia]
        if not len(ids):used[fi]=True;continue
        used[ids]=True;area=float(A[ids].sum())
        if area<min_area:continue
        points=V[np.unique(F[ids])];mean=np.average(C[ids],axis=0,weights=A[ids])
        _,_,vt=np.linalg.svd(points-mean,full_matrices=False);n=vt[-1]
        if n[np.argmax(abs(n))]<0:n=-n
        n[abs(n)<1e-5]=0;n/=np.linalg.norm(n);offset=float(n@mean)
        error=float(abs(points@n-offset).max())
        if error>max(.0001,tolerancia):
            # La hipótesis inicial sí acotaba estos triángulos; no sustituirla
            # por un ajuste RMS que empeore su error máximo.
            n=N[fi].copy()
            if n[np.argmax(abs(n))]<0:n=-n
            offset=float(n@C[fi]);error=float(abs(points@n-offset).max())
        if error>max(.0001,tolerancia) or (max(abs(n))<.9999 and area<min_area_oblicua):continue
        if any(abs(n@np.asarray(p['normal']))>1-1e-10 and abs(offset-p['offset'])<.00005 for p in planes):continue
        planes.append({'normal':n.tolist(),'offset':offset,'area':area,
                       'faces':ids.tolist(),'max_triangulo_mm':error})
    return planes


def envolvente_capas(mesh,axis,*,capas=8,margen=.025):
    """Prismas convexos que cubren todas las caras cortadas por cada capa."""
    import cadquery as cq,shapely
    ij=[k for k in range(3) if k!=axis];V=mesh.vertices
    edges=V[mesh.edges_unique];cuts=np.linspace(mesh.bounds[0,axis]-margen,
                                               mesh.bounds[1,axis]+margen,capas+1)
    shapes=[];profiles=[]
    for lo,hi in zip(cuts[:-1],cuts[1:]):
        points=[V[(V[:,axis]>=lo)&(V[:,axis]<=hi)][:,ij]]
        for z in (lo,hi):
            a,b=edges[:,0],edges[:,1];mask=(a[:,axis]<z)&(b[:,axis]>z)|(a[:,axis]>z)&(b[:,axis]<z)
            aa,bb=a[mask],b[mask]
            t=(z-aa[:,axis])/(bb[:,axis]-aa[:,axis]);points.append((aa+(bb-aa)*t[:,None])[:,ij])
        cloud=np.vstack(points)
        if not len(cloud):continue
        polygon=shapely.MultiPoint(cloud).convex_hull.buffer(margen,join_style=2)
        if polygon.geom_type!='Polygon':raise ValueError('No se ha obtenido una envolvente convexa')
        coords=np.asarray(polygon.exterior.coords)[:-1];world=np.zeros((len(coords),3));world[:,ij]=coords;world[:,axis]=lo-1e-6
        wire=cq.Wire.makePolygon([cq.Vector(*p) for p in world],close=True)
        shape=cq.Solid.extrudeLinear(wire,[],cq.Vector(*(np.eye(3)[axis]*(hi-lo+2e-6))))
        shapes.append(shape);profiles.append({'min':float(lo),'max':float(hi),'vertices':coords.tolist()})
    if not shapes:raise ValueError('Envolvente sin volumen')
    result=shapes[0].fuse(*shapes[1:]).clean() if len(shapes)>1 else shapes[0]
    if not result.isValid() or len(result.Solids())!=1:raise ValueError('La envolvente no forma un sólido válido')
    return result,{'axis':axis,'capas':profiles,'margen_envolvente_mm':margen,
                   'volumen_dominio':result.Volume(),
                   'cobertura':'Envolvente convexa de vértices y cortes de todas las aristas por capa.'}
