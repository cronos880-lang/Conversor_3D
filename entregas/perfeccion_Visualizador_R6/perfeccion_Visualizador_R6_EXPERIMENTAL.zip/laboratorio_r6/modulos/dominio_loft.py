"""Dominio poliédrico por secciones convexas, certificado sobre el STL.

Es una envolvente para particionar y clasificar material, no una conversión
aceptada. Los vacíos y la concavidad deben recuperarse y validarse por separado.
"""
import numpy as np


def construir(mesh,axis,*,direcciones=72,margen=.005,error_perfil=.0005):
    import cadquery as cq
    from OCP.BRepBuilderAPI import BRepBuilderAPI_Sewing,BRepBuilderAPI_MakeSolid
    from OCP.TopoDS import TopoDS
    ij=[k for k in range(3) if k!=axis];V=mesh.vertices;edges=V[mesh.edges_unique]
    phi=np.arange(direcciones)*2*np.pi/direcciones;normals=np.c_[np.cos(phi),np.sin(phi)]
    values=np.unique(np.round(V[:,axis]/.0001)*.0001)
    values=np.unique(np.r_[mesh.bounds[0,axis],values[(values>mesh.bounds[0,axis])&(values<mesh.bounds[1,axis])],mesh.bounds[1,axis]])
    rows=[]
    a,b=edges[:,0],edges[:,1]
    for z in values:
        nearby=V[abs(V[:,axis]-z)<.00011][:,ij]
        mask=((a[:,axis]<=z)&(b[:,axis]>=z)|(a[:,axis]>=z)&(b[:,axis]<=z))&(abs(a[:,axis]-b[:,axis])>1e-12)
        aa,bb=a[mask],b[mask];t=(z-aa[:,axis])/(bb[:,axis]-aa[:,axis]);points=np.vstack([nearby,(aa+(bb-aa)*t[:,None])[:,ij]])
        if not len(points):raise ValueError('Sección sin puntos de referencia')
        rows.append((points@normals.T).max(0)+margen)
    H=np.asarray(rows);keep={0,len(values)-1};stack=[(0,len(values)-1)]
    while stack:
        lo,hi=stack.pop()
        if hi-lo<2:continue
        ts=(values[lo+1:hi]-values[lo])/(values[hi]-values[lo]);pred=H[lo]+ts[:,None]*(H[hi]-H[lo]);errors=abs(H[lo+1:hi]-pred).max(1);i=int(np.argmax(errors))+lo+1
        if errors[i-lo-1]>error_perfil:keep.add(i);stack.extend([(lo,i),(i,hi)])
    selected=np.array(sorted(keep));levels=values[selected];profiles=H[selected]
    levels=np.r_[levels[0]-margen,levels,levels[-1]+margen];profiles=np.vstack([profiles[0],profiles,profiles[-1]])
    # Certificado de cobertura: las desigualdades son afines dentro de cada
    # intervalo axial. Basta comprobar vértices y cruces de aristas con niveles.
    maximum=-np.inf;count=0
    def check(points):
        nonlocal maximum,count
        if not len(points):return
        for block in np.array_split(points,max(1,(len(points)+4095)//4096)):
            ids=np.clip(np.searchsorted(levels,block[:,axis],side='right')-1,0,len(levels)-2);t=(block[:,axis]-levels[ids])/(levels[ids+1]-levels[ids]);h=profiles[ids]+t[:,None]*(profiles[ids+1]-profiles[ids]);maximum=max(maximum,float((block[:,ij]@normals.T-h).max()));count+=len(block)
    check(V)
    for z in levels[1:-1]:
        mask=((a[:,axis]<z)&(b[:,axis]>z)|(a[:,axis]>z)&(b[:,axis]<z));aa,bb=a[mask],b[mask];t=(z-aa[:,axis])/(bb[:,axis]-aa[:,axis]);check(aa+(bb-aa)*t[:,None])
    extra=max(0.,maximum+1e-8);profiles+=extra
    inv=[np.linalg.inv(normals[[i,(i+1)%direcciones]]) for i in range(direcciones)]
    rings=[]
    for z,h in zip(levels,profiles):
        xy=np.array([inv[i]@h[[i,(i+1)%direcciones]] for i in range(direcciones)]);points=np.zeros((direcciones,3));points[:,ij]=xy;points[:,axis]=z;rings.append(points)
    sew=BRepBuilderAPI_Sewing(1e-7)
    def face(points):return cq.Face.makeFromWires(cq.Wire.makePolygon([cq.Vector(*p) for p in points],close=True))
    sew.Add(face(rings[0][::-1]).wrapped);sew.Add(face(rings[-1]).wrapped)
    for lower,upper in zip(rings[:-1],rings[1:]):
        for i in range(direcciones):
            j=(i+1)%direcciones;sew.Add(face([lower[i],lower[j],upper[j],upper[i]]).wrapped)
    sew.Perform();shape=cq.Shape.cast(BRepBuilderAPI_MakeSolid(TopoDS.Shell_s(sew.SewedShape())).Solid())
    if not shape.isValid():raise ValueError('La envolvente por secciones no es válida')
    return shape,{'axis':axis,'niveles':levels.tolist(),'direcciones':direcciones,'caras':len(shape.Faces()),
        'perfiles_iniciales':len(values),'margen_mm':margen,'error_reduccion_perfil_mm':error_perfil,
        'ampliacion_certificado_mm':extra,'comprobaciones_cobertura':count,
        'max_desigualdad_antes_de_ampliar_mm':maximum,'volumen':shape.Volume()}
