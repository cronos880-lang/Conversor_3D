"""Retriangulación conservadora para fronteras ya verificadas por CGAL.

Preserva enlaces y Euler y vuelve a comprobar cada cambio con predicados
exactos. No elimina regiones por tamaño ni cambia el presupuesto geométrico.
"""
import time
from pathlib import Path
import numpy as np
import trimesh


def acondicionar(mesh,control_path,*,deadline=None):
    from reparacion_contactos_locales import compactar_aristas_cortas
    from reparador_exacto_aislado import ControlExacto,medidas_superficie
    deadline=deadline or time.monotonic()+180
    checks=0
    def valid(candidate):
        nonlocal checks
        if time.monotonic()>deadline:raise TimeoutError('Acondicionamiento CAD agotado')
        checks+=1
        try:return not ControlExacto(candidate,control_path).pares()
        except ValueError:return False
    if not valid(mesh):raise ValueError('Se requiere una frontera CGAL válida')
    candidate,compact=compactar_aristas_cortas(mesh,limite_mm=1e-7,validar=valid,max_colapsos=500,
                                             probar_punto_medio=True)
    flips=[]
    for iteration in range(200):
        V,F=candidate.vertices,candidate.faces
        tris=V[F];cross=np.cross(tris[:,1]-tris[:,0],tris[:,2]-tris[:,0]);area=np.linalg.norm(cross,axis=1)
        lengths=np.linalg.norm(tris-np.roll(tris,-1,axis=1),axis=2);altitude=area/np.maximum(lengths.max(1),1e-300)
        bad=np.where(altitude<1e-7)[0]
        if not len(bad):break
        existing={tuple(sorted(map(int,e))) for e in candidate.edges_unique}
        adjacency={}
        for faces,edge in zip(candidate.face_adjacency,candidate.face_adjacency_edges):
            adjacency[tuple(sorted(map(int,edge)))]=list(map(int,faces))
        changed=False
        for fi in bad[np.argsort(altitude[bad])]:
            tri=F[fi]
            for k in np.argsort(-lengths[fi]):
                a,b=int(tri[k]),int(tri[(k+1)%3]);key=tuple(sorted((a,b)));pair=adjacency.get(key,[])
                if len(pair)!=2:continue
                other=pair[0] if pair[1]==fi else pair[1]
                c=int(next(v for v in tri if v not in (a,b)))
                d=int(next(v for v in F[other] if v not in (a,b)))
                if c==d or tuple(sorted((c,d))) in existing:continue
                stable=fi if area[fi]>area[other] else other
                normal=cross[stable]/max(area[stable],1e-300)
                if np.max(np.abs((V[[a,b,c,d]]-V[F[stable,0]])@normal))>1e-9:continue
                newfaces=np.array([[c,d,b],[d,c,a]])
                pts=V[newfaces];newcross=np.cross(pts[:,1]-pts[:,0],pts[:,2]-pts[:,0])
                if np.any(newcross@normal<=0):continue
                newlen=np.linalg.norm(pts-np.roll(pts,-1,axis=1),axis=2).max(1)
                quality=float((np.linalg.norm(newcross,axis=1)/np.maximum(newlen,1e-300)).min())
                old=float(min(altitude[fi],altitude[other]))
                if quality<=max(old*2,1e-12):continue
                faces=F.copy();faces[fi]=newfaces[0];faces[other]=newfaces[1]
                proposal=trimesh.Trimesh(V.copy(),faces,process=False)
                if not proposal.is_watertight or not proposal.is_winding_consistent:continue
                if not valid(proposal):continue
                flips.append({'caras':[int(fi),int(other)],'altitud_antes_mm':old,'altitud_despues_mm':quality})
                candidate=proposal;changed=True;break
            if changed:break
        if not changed:break
    candidate,compact_final=compactar_aristas_cortas(candidate,limite_mm=1e-7,validar=valid,
        max_colapsos=500,probar_punto_medio=True)
    compact['colapsos']+=compact_final['colapsos']
    proof=medidas_superficie(mesh,candidate)
    if proof['max_mm']>.002:raise ValueError('Acondicionamiento fuera del límite superficial de 0.002 mm')
    if candidate.euler_number!=mesh.euler_number:raise ValueError('El acondicionamiento cambia Euler')
    triangles=candidate.triangles;area=np.linalg.norm(np.cross(triangles[:,1]-triangles[:,0],triangles[:,2]-triangles[:,0]),axis=1)
    lengths=np.linalg.norm(triangles-np.roll(triangles,-1,axis=1),axis=2).max(1)
    return candidate,{'compactacion':compact,'volteos':flips,'controles_exactos':checks,
        'superficie':proof,'caras_altitud_subresolucion':int((area/lengths<1e-7).sum()),
        'arista_min_mm':float(candidate.edges_unique_length.min()),
        'euler_antes':int(mesh.euler_number),'euler_despues':int(candidate.euler_number)}
