"""Reconstrucción verificada de cavidades de la malla regularizada."""
import numpy as np


def reconstruir(mesh,log=lambda *args:None):
    import trimesh,cadquery as cq,shapely,manifold3d as mf
    from shapely.geometry import Polygon
    from reparador_exacto_aislado import ControlExacto,medidas_superficie
    from verificacion_reparacion import solido_poliedrico
    from saneamiento_cad import comprobar_interferencias
    from pathlib import Path
    import tempfile
    parts=[p for p in mesh.split(only_watertight=False) if p.volume<0];result=[]
    for i,part in enumerate(parts):
        center=part.vertices.mean(0);_,_,vt=np.linalg.svd(part.vertices-center,full_matrices=False);u,v=vt[:2];n=np.cross(u,v);coords=(part.vertices-center)@np.array([u,v,n]).T;thickness=float(np.ptp(coords[:,2]));boss=None;details={'indice':i,'espesor_pca_mm':thickness}
        if thickness<1e-5:
            triangles=coords[part.faces,:2];polygons=[Polygon(t) for t in triangles if Polygon(t).area>1e-24]
            footprint=shapely.union_all(shapely.set_precision(polygons,1e-9)).simplify(1e-6,preserve_topology=True)
            if footprint.geom_type!='Polygon':raise ValueError('La cavidad laminar no tiene una única huella')
            middle=float((coords[:,2].min()+coords[:,2].max())/2)
            def prism(poly,height):
                def wire(ring):return cq.Wire.makePolygon([cq.Vector(*(center+u*x+v*y+n*(middle-height/2))) for x,y in list(ring.coords)[:-1]],close=True)
                return cq.Solid.extrudeLinear(wire(poly.exterior),[wire(r) for r in poly.interiors],cq.Vector(*(n*height)))
            shape=prism(footprint,max(thickness,.00002));boss=prism(footprint.buffer(.008),max(thickness,.00002)+.016)
            details['refuerzo_local_mm']=.008;details['metodo']='prisma_laminar';details['espesor_salida_mm']=max(thickness,.00002)
        else:
            positive=part.copy();positive.invert()
            try:shape=solido_poliedrico(positive);details['metodo']='facetas_exactas'
            except Exception:
                shape=None
                for eps in (.00001,.00005):
                    solid=mf.Manifold(mf.Mesh64(np.array(positive.vertices,dtype=np.float64,order='C',copy=True),np.array(positive.faces,dtype=np.uint64,order='C',copy=True)))
                    dilated=solid.minkowski_sum(mf.Manifold.cube([2*eps]*3,True)).simplify(1e-7);data=dilated.to_mesh64();candidate=trimesh.Trimesh(data.vert_properties[:,:3],data.tri_verts,process=False);vertices,idx=np.unique(candidate.vertices,axis=0,return_inverse=True);candidate=trimesh.Trimesh(vertices,idx[candidate.faces],process=False)
                    try:
                        with tempfile.TemporaryDirectory(prefix='visor_cavidad_') as tmp:
                            if ControlExacto(candidate,Path(tmp)/'control.off').pares():continue
                        trial=solido_poliedrico(candidate)
                        if comprobar_interferencias(trial)!=(True,0):continue
                        shape=trial;details.update(metodo='dilatacion_local',semiancho_mm=eps);break
                    except Exception:continue
                if shape is None:raise ValueError('No se pudo reconstruir una cavidad sin interferencias')
        if not shape.isValid() or comprobar_interferencias(shape)!=(True,0):raise ValueError('Cavidad CAD no válida')
        vertices,faces=shape.copy().tessellate(.0001);candidate=trimesh.Trimesh([p.toTuple() for p in vertices],faces,process=False);proof=medidas_superficie(part,candidate)
        if proof['max_mm']>.002:raise ValueError('La cavidad cambia más de 0.002 mm')
        details.update(superficie=proof,caras=len(shape.Faces()),volumen_antes=abs(float(part.volume)),volumen_despues=shape.Volume())
        result.append((shape,boss,details));log('Cavidad verificada',i,details['metodo'],proof['max_mm'])
    return result
