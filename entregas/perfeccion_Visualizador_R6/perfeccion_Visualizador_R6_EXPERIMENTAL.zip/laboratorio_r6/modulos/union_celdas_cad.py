"""Unión de celdas ya intersecadas, conservando todos los cuerpos."""


def unir(cells):
    import cadquery as cq
    from OCP.BRepAlgoAPI import BRepAlgoAPI_Fuse
    from OCP.BOPAlgo import BOPAlgo_GlueFull
    from OCP.TopTools import TopTools_ListOfShape
    if not cells:raise ValueError('No hay celdas de material')
    if len(cells)==1:return cells[0]
    args=TopTools_ListOfShape();tools=TopTools_ListOfShape();args.Append(cells[0].wrapped)
    for shape in cells[1:]:tools.Append(shape.wrapped)
    operation=BRepAlgoAPI_Fuse();operation.SetArguments(args);operation.SetTools(tools)
    operation.SetRunParallel(False);operation.SetNonDestructive(True)
    operation.SetFuzzyValue(0.);operation.SetGlue(BOPAlgo_GlueFull);operation.Build()
    if not operation.IsDone():raise ValueError('No se pudo unir las celdas')
    shape=cq.Shape.cast(operation.Shape())
    expected=sum(p.Volume() for p in cells)
    if abs(shape.Volume()-expected)>max(1e-6,abs(expected)*1e-7):
        raise ValueError('La unión de celdas cambia el volumen')
    return shape
