"""Puntos interiores de celdas limitadas por planos y cilindros.

Optimiza la distancia a las superficies activas. El punto obtenido se contrasta
con el clasificador exacto del B-Rep; nunca se acepta únicamente por el optimizador.
"""
import numpy as np


def punto_interior(part):
    from scipy.optimize import minimize
    from OCP.BRepAdaptor import BRepAdaptor_Surface
    from OCP.GeomAbs import GeomAbs_Plane,GeomAbs_Cylinder
    from OCP.TopAbs import TopAbs_REVERSED,TopAbs_IN
    from OCP.BRepClass3d import BRepClass3d_SolidClassifier
    from OCP.gp import gp_Pnt
    planes=[];cylinders=[]
    for face in part.Faces():
        surface=BRepAdaptor_Surface(face.wrapped,True)
        orientation=-1. if face.wrapped.Orientation()==TopAbs_REVERSED else 1.
        if surface.GetType()==GeomAbs_Plane:
            p=surface.Plane();n=np.asarray(p.Axis().Direction().Coord())*orientation
            planes.append((n,float(n@np.asarray(p.Location().Coord()))))
        elif surface.GetType()==GeomAbs_Cylinder:
            c=surface.Cylinder();axis=np.asarray(c.Axis().Direction().Coord())
            cylinders.append((np.asarray(c.Location().Coord()),axis,c.Radius(),orientation))
        else:raise ValueError('La celda incluye una superficie no admitida para el punto interior.')
    center=np.asarray(part.Center().toTuple());bb=part.BoundingBox()
    lo=np.array([bb.xmin,bb.ymin,bb.zmin]);hi=np.array([bb.xmax,bb.ymax,bb.zmax])
    support=np.asarray([v.Center().toTuple() for v in part.Vertices()]+
        [e.positionAt(t).toTuple() for e in part.Edges() for t in (.25,.5,.75)])
    # Una envolvente escalonada puede tener caras que solo limitan una parte
    # de la celda. No convertirlas en semiespacios globales incompatibles.
    planes=[(n,b) for n,b in planes if np.min(b-support@n)>=-1e-6]
    cylinders=[(o,a,r,s) for o,a,r,s in cylinders if np.min(s*(r-
        np.linalg.norm((support-o)-((support-o)@a)[:,None]*a,axis=1)))>=-1e-6]
    for j in range(3):
        n=np.eye(3)[j];planes.extend([(n,float(hi[j])),(-n,float(-lo[j]))])
    if any(np.linalg.norm((center-o)-a*((center-o)@a))<1e-8 for o,a,_,_ in cylinders):
        center=np.asarray(part.Vertices()[0].Center().toTuple())*.99+center*.01
    def distances(x):
        ds=[];jac=[]
        for n,b in planes:ds.append(b-n@x[:3]);jac.append(np.r_[-n,-1.])
        for o,a,r,sign in cylinders:
            d=x[:3]-o;d-=a*(d@a);length=float(np.linalg.norm(d))
            ds.append(sign*(r-length));jac.append(np.r_[-sign*d/max(length,1e-30),-1.])
        return np.asarray(ds)-x[3],np.asarray(jac)
    d,_=distances(np.r_[center,0.]);initial=np.r_[np.clip(center,lo,hi),max(0.,float(d.min(initial=0.)))]
    result=minimize(lambda x:-x[3],initial,jac=lambda x:np.array([0.,0.,0.,-1.]),
        method='SLSQP',bounds=list(zip(lo,hi))+[(0.,float(np.linalg.norm(hi-lo)))],
        constraints={'type':'ineq','fun':lambda x:distances(x)[0],
                     'jac':lambda x:distances(x)[1]},
        options={'ftol':1e-12,'maxiter':100})
    point=result.x[:3];values,_=distances(np.r_[point,0.]);margin=float(values.min())
    checker=BRepClass3d_SolidClassifier(part.wrapped)
    checker.Perform(gp_Pnt(*map(float,point)),1e-9)
    verified=checker.State()==TopAbs_IN and margin>=-1e-8
    return point,{'verificado':bool(verified),'margen_mm':margin,'optimizador':bool(result.success),
                  'min_restriccion_mm':float(values.min(initial=0.)),'iteraciones':int(result.nit)}
