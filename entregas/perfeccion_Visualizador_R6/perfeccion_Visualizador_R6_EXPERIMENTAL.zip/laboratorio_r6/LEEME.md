# Investigación separada del motor de uso

Ningún STEP de estos ensayos ha sido aprobado. No sustituir archivos del Visor por estos módulos. Los scripts conservan rutas del entorno Linux de investigación y algunas dependencias entre artefactos intermedios; requieren adaptarlas y regenerar esos artefactos. Los BREP y STEP rechazados no se distribuyen como conversiones. Los parámetros, errores y controles están en evidencias/ensayos_r6. Esta carpeta documenta el progreso para continuar el desarrollo; no es un reparador listo para el usuario.

Los módulos usan las dependencias declaradas del proyecto. Los ensayos antiguos que importan MeshLib/PyMeshLab son exclusivamente de laboratorio; esas bibliotecas no se incorporan a producción.
