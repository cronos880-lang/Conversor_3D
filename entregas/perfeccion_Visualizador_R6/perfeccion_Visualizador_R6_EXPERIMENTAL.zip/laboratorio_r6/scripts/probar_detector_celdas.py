from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
from preprocesador_stl import cargar_exacto
from reconstruccion_celdas import detectar_cilindros
for name in ['6558_fixed','Pieza_Nueva_Detenida']:
 start=time.monotonic();m=cargar_exacto(Path('/workspace/work/casos_usuario_r5')/(name+'.stl'));c=detectar_cilindros(m);Path('evidencias/'+name+'_cilindros_r6.json').write_text(json.dumps(c,indent=2));print(name,'cilindros',len(c),'s',time.monotonic()-start,flush=True)
 for p in c:print({k:v for k,v in p.items() if k!='faces'},flush=True)
