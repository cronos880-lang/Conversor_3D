from pathlib import Path
import sys,json,time,traceback
sys.path.insert(0,str(Path.cwd()))
import numpy as np,trimesh,manifold3d as mf
from preprocesador_stl import cargar_exacto
from reparador_exacto_aislado import ControlExacto,desenredar
from reparacion_contactos_locales import descomponer_contactos
from verificacion_reparacion import solido_poliedrico
from saneamiento_cad import comprobar_interferencias
out=[]
for name in ['6558_fixed','Pieza_Nueva_Detenida']:
 start=time.monotonic();row={'archivo':name}
 try:
  source=cargar_exacto(Path('/workspace/work/perfeccion_Visualizador_r5/evidencias/casos_finales')/(name+'.reparado.stl'));body=mf.Manifold(mf.Mesh64(np.array(source.vertices,dtype=np.float64,order='C',copy=True),np.array(source.faces,dtype=np.uint64,order='C',copy=True)));cube=mf.Manifold.cube([.00002]*3,True);print('START',name,len(source.faces),flush=True);closed=body.minkowski_sum(cube).minkowski_difference(cube).set_tolerance(.000002).simplify(.000002);data=closed.to_mesh64();m=trimesh.Trimesh(data.vert_properties[:,:3],data.tri_verts,process=False);v,i=np.unique(m.vertices,axis=0,return_inverse=True);m=trimesh.Trimesh(v,i[m.faces],process=False);print('MORPH',name,len(m.faces),closed.status(),time.monotonic()-start,flush=True)
  if len(m.faces)>60000:raise ValueError('Complejidad de malla excesiva')
  m,dc=descomponer_contactos(m);m,sep=desenredar(m,Path('work/morph.off'),time.monotonic()+90,solo_contactos=False);row['desenredo']=sep;row['SI']=len(ControlExacto(m,Path('work/morph.off')).pares());row['caras']=len(m.faces);row['microcaras']=int((m.area_faces<1e-14).sum());Path('work/'+name+'_morfologico.stl').write_text(trimesh.exchange.stl.export_stl_ascii(m));print('MESH',name,row,flush=True)
  shape=solido_poliedrico(m);row.update(valido=shape.isValid(),caras_cad=len(shape.Faces()),interferencias=comprobar_interferencias(shape));shape.exportBrep('work/'+name+'_morfologico.brep');row['ok']=True
 except Exception as exc:row.update(ok=False,error=str(exc));traceback.print_exc()
 row['segundos']=time.monotonic()-start;out.append(row);Path('evidencias/cierre_morfologico.json').write_text(json.dumps(out,indent=2));print(row,flush=True)
