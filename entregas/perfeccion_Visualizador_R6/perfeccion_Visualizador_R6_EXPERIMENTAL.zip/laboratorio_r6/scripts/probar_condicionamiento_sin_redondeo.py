from pathlib import Path
import sys,json,time,traceback
sys.path.insert(0,str(Path.cwd()))
import numpy as np,trimesh,manifold3d as mf
def _manifold(mesh):
 return mf.Manifold(mf.Mesh64(np.array(mesh.vertices,dtype=np.float64,order="C",copy=True),np.array(mesh.faces,dtype=np.uint64,order="C",copy=True)))
from reparador_exacto_aislado import cargar,ControlExacto,medidas_superficie
from topologia_vertices import inspeccionar_vertices
root=Path('/workspace/work/perfeccion_Visualizador_r5/evidencias/casos_finales');out=[]
for name in ['6558_fixed','Pieza_Nueva_Detenida']:
 source=cargar(root/(name+'.reparado.stl'));report=json.loads((root/(name+'.reparado.reparacion.json')).read_text());ops=report['regularizacion_material']['operaciones']
 for eps in [.0003]:
  start=time.monotonic();row={'archivo':name,'contacto_eps':eps}
  try:
   result=_manifold(source)
   for kind,op in [('micro_union_material',mf.OpType.Add),('micro_apertura_vacio',mf.OpType.Subtract)]:
    pts=[x['xyz_mm'] for x in ops if x['tipo']==kind]
    if pts:result=mf.Manifold.batch_boolean([result,mf.Manifold.batch_boolean([mf.Manifold.cube([2*eps]*3,True).translate(p) for p in pts],mf.OpType.Add)],op)
   result=result.set_tolerance(.000002).simplify(.000002)
   data=result.to_mesh64();mesh=trimesh.Trimesh(data.vert_properties[:,:3],data.tri_verts,process=False)
   result=_manifold(mesh).set_tolerance(.000002).simplify(.000002)
   data=result.to_mesh64();mesh=trimesh.Trimesh(data.vert_properties[:,:3],data.tri_verts,process=False)
   v,i=np.unique(mesh.vertices,axis=0,return_inverse=True);mesh=trimesh.Trimesh(v,i[mesh.faces],process=False)
   topology=inspeccionar_vertices(mesh);row.update(status=str(result.status()),closed=bool(mesh.is_watertight),bad=topology['vertices_no_manifold'],faces=len(mesh.faces),microfaces=int((mesh.area_faces<1e-14).sum()))
   control=ControlExacto(mesh,Path('work/condicionamiento_sin_redondeo.off'));row['SI']=len(control.pares());row['superficie_vs_R5']=medidas_superficie(source,mesh)
   if row['SI']==0 and row['bad']==0 and row['closed']:
    Path('work/'+name+'_condicionado.stl').write_text(trimesh.exchange.stl.export_stl_ascii(mesh))
  except Exception as e:row['error']=str(e);traceback.print_exc()
  row['segundos']=time.monotonic()-start;out.append(row);Path('evidencias/condicionamiento_sin_redondeo.json').write_text(json.dumps(out,indent=2));print(row,flush=True)
