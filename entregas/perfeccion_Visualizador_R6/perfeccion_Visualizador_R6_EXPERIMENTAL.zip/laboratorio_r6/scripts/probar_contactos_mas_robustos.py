from pathlib import Path
import sys,json,time,traceback
sys.path.insert(0,str(Path.cwd()))
import numpy as np,trimesh,cadquery as cq,manifold3d as mf
from preprocesador_stl import cargar_exacto,_manifold
from reparador_exacto_aislado import ControlExacto,medidas_superficie,desenredar,validar_material
from motor_v2 import convertir,_calidad
from cavidades_cad import reconstruir
name=sys.argv[1] if len(sys.argv)>1 else '6558_fixed';start=time.monotonic();row={'archivo':name};eps=.0005
try:
 original_path=Path('/workspace/work/casos_usuario_r5')/(name+'.stl');original=cargar_exacto(original_path);prepared=cargar_exacto(Path('/workspace/work/perfeccion_Visualizador_r5/evidencias/casos_finales')/(name+'.reparado.stl'));report=json.loads((Path('/workspace/work/perfeccion_Visualizador_r5/evidencias/casos_finales')/(name+'.reparado.reparacion.json')).read_text());ops=report['regularizacion_material']['operaciones'];shape=_manifold(prepared)
 adds=[mf.Manifold.cube([2*eps]*3,True).translate(o['xyz_mm']) for o in ops if o['tipo']=='micro_union_material'];cuts=[mf.Manifold.cube([2*eps]*3,True).translate(o['xyz_mm']) for o in ops if o['tipo']=='micro_apertura_vacio']
 if adds:shape=shape+mf.Manifold.batch_boolean(adds,mf.OpType.Add)
 if cuts:shape=shape-mf.Manifold.batch_boolean(cuts,mf.OpType.Add)
 shape=shape.simplify(1e-9);data=shape.to_mesh64();m=trimesh.Trimesh(data.vert_properties[:,:3],data.tri_verts,process=False);v,ix=np.unique(m.vertices,axis=0,return_inverse=True);m=trimesh.Trimesh(v,ix[m.faces],process=False);m=__import__('reparacion_contactos_locales').descomponer_contactos(m)[0];checker=ControlExacto(m,Path('work/'+name+'_robusto.off'));pairs=checker.pares();print('MESH',len(m.faces),'SI',len(pairs),flush=True)
 if pairs:m,proof=desenredar(m,Path('work/'+name+'_robusto.off'),start+180,solo_contactos=False);row['desenredo']=proof
 q=medidas_superficie(prepared,m);print('SUPERFICIE',q,flush=True)
 if q['max_mm']>.002:raise ValueError('Exceso de modificación local')
 row['material']=validar_material(original,m,ops);row['superficie']=q;parts=list(m.split(only_watertight=False));bodies=[p for p in parts if p.volume>0]
 if len(bodies)!=1:raise ValueError('Cambio de cuerpos')
 body=bodies[0];bodypath=Path('work/'+name+'_robusto_cuerpo.stl');bodypath.write_text(trimesh.exchange.stl.export_stl_ascii(body));target=Path('work/'+name+'_robusto_cuerpo.step')
 print('CONVIRTIENDO_CUERPO',len(body.faces),'CAVIDADES',len(parts)-1,flush=True)
 with Path('evidencias/'+name+'_robusto_motor.log').open('w',buffering=1) as log:
  result=convertir(bodypath,target,log,flat_tol_deg=1.3,digital=True,analitico=True,sin_simplificar=True,precision_reparacion=True,control_avanzado=True,conservar_vertices=True)
 shape=cq.importers.importStep(str(target)).val();print('BODY_CAD_OK',len(shape.Faces()),flush=True)
 for void,boss,detail in reconstruir(prepared,log=lambda *a:print(*a,flush=True)):
  if boss is not None:shape=shape.fuse(boss)
  shape=shape.cut(void)
 target=Path('work/'+name+'_robusto.step');shape.exportStep(str(target));row['calidad']=_calidad(original_path,target,original,control_avanzado=True);row['ok']=True
except Exception as exc:row.update(ok=False,error=str(exc));traceback.print_exc()
row['segundos']=time.monotonic()-start;Path('evidencias/'+name+'_contactos_robustos.json').write_text(json.dumps(row,indent=2));print('RESULT',json.dumps(row),flush=True)
