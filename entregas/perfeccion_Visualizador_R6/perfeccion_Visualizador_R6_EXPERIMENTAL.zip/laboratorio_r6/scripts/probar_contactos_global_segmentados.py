from pathlib import Path
import sys,json,traceback,time
sys.path.insert(0,str(Path.cwd()))
import cadquery as cq,numpy as np,igl
from OCP.TopTools import TopTools_IndexedDataMapOfShapeListOfShape
from OCP.TopExp import TopExp
from OCP.TopAbs import TopAbs_EDGE,TopAbs_FACE
from preprocesador_stl import cargar_exacto
from motor_v2 import _calidad
from saneamiento_cad import comprobar_interferencias
name=sys.argv[1] if len(sys.argv)>1 else '6558_fixed';source=Path('/workspace/work/casos_usuario_r5')/(name+'.stl');mesh=cargar_exacto(source);shape=cq.importers.importBrep('work/'+name+'_global_fino_material.brep').val();mapping=TopTools_IndexedDataMapOfShapeListOfShape();TopExp.MapShapesAndAncestors_s(shape.wrapped,TopAbs_EDGE,TopAbs_FACE,mapping);joins=[];cuts=[];records=[]
for i in range(1,mapping.Extent()+1):
 fs=[]
 for f in mapping.FindFromIndex(i):
  if not any(f.IsSame(old) for old in fs):fs.append(f)
 if len(fs)<=2:continue
 edge=cq.Edge(mapping.FindKey(i));print('EDGE',len(fs),edge.geomType(),edge.Length(),flush=True)
 if edge.geomType()!='LINE':raise ValueError('Contacto no recto')
 a=np.array(edge.startPoint().toTuple());b=np.array(edge.endPoint().toTuple());length=np.linalg.norm(b-a);direction=(b-a)/length;ts=np.linspace(0,1,max(9,min(1025,int(np.ceil(length/.005))+1)));winds=igl.winding_number(mesh.vertices,mesh.faces,a+ts[:,None]*(b-a))
 if np.any((winds>.25)&(winds<.75)):raise ValueError('Campo cercano a la frontera en el contacto')
 labels=winds>.5;breaks=[0.];kinds=[bool(labels[0])]
 for j in range(len(ts)-1):
  if labels[j]==labels[j+1]:continue
  lo,hi=ts[j:j+2]
  for _ in range(18):
   mid=(lo+hi)/2;w=float(igl.winding_number(mesh.vertices,mesh.faces,a+mid*(b-a)))
   if (w>.5)==labels[j]:lo=mid
   else:hi=mid
  breaks.append(float((lo+hi)/2));kinds.append(bool(labels[j+1]))
 breaks.append(1.)
 for lo,hi,material in zip(breaks[:-1],breaks[1:],kinds):
  if (hi-lo)*length<1e-7:raise ValueError('Segmento de contacto no resoluble')
  kind='union' if material else 'vacio';radius=.00005;start=a+lo*(b-a);end=a+hi*(b-a);tube=cq.Solid.makeCylinder(radius,(hi-lo)*length+2*radius,cq.Vector(*(start-radius*direction)),cq.Vector(*direction));(joins if material else cuts).append(tube);records.append({'tipo':kind,'a':start.tolist(),'b':end.tolist(),'radio_mm':radius,'muestras_campo':len(winds)})
 print('SEGMENTOS',len(kinds),flush=True)
print('LOCAL',len(joins),len(cuts),flush=True)
if joins:shape=shape.fuse(*joins)
if cuts:shape=shape.cut(*cuts)
print('FINAL',shape.isValid(),len(shape.Solids()),len(shape.Shells()),shape.Volume(),len(shape.Faces()),flush=True)
Path('evidencias/contactos_global_fino.json').write_text(json.dumps(records,indent=2));shape.exportBrep('work/6558_contactos_global_fino.brep');target=Path('work/6558_contactos_global_fino.step');shape.exportStep(str(target))
try:
 q=_calidad(source,target,mesh,control_avanzado=True);Path('evidencias/6558_contactos_global_fino_calidad.json').write_text(json.dumps(q,indent=2));print('QUALITY_OK',json.dumps(q),flush=True)
except Exception as exc:print('QUALITY_FAIL',str(exc),flush=True);traceback.print_exc()
