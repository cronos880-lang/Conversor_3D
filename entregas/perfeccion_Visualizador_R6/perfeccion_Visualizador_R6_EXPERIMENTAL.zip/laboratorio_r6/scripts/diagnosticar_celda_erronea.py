from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
import cadquery as cq,numpy as np,igl
from OCP.BRepClass3d import BRepClass3d_SolidClassifier
from OCP.gp import gp_Pnt
from OCP.TopAbs import TopAbs_IN
from preprocesador_stl import cargar_exacto
name='6558_fixed';mesh=cargar_exacto(Path('/workspace/work/casos_usuario_r5')/(name+'.stl'));parts=cq.importers.importBrep('work/6558_fixed_splitter_finito_partes.brep').val().Solids();rows=json.loads(Path('evidencias/splitter_finito_clasificacion.json').read_text());targets=np.array([[2.5,0,16.2],[-2.3,1.0,16.2],[2.405,0,16.2],[2.45,0,16.2]])
print('SOURCE',igl.winding_number(mesh.vertices,mesh.faces,targets),flush=True)
for p in targets:
 for i,part in enumerate(parts):
  bb=part.BoundingBox()
  if not(bb.xmin<=p[0]<=bb.xmax and bb.ymin<=p[1]<=bb.ymax and bb.zmin<=p[2]<=bb.zmax):continue
  c=BRepClass3d_SolidClassifier(part.wrapped);c.Perform(gp_Pnt(*map(float,p)),1e-8)
  if c.State()!=TopAbs_IN:continue
  row=rows[i];print('CELL',p.tolist(),i,'volume',row['volumen'],'material',row['material'],'proof',row.get('punto_interior'),flush=True);print('POINTS',list(zip(row['puntos'],row['winding'])),flush=True);print('SURFACES',[(f.geomType(),f.Center().toTuple()) for f in part.Faces()],flush=True)
