from pathlib import Path
import sys,json,time,traceback
sys.path.insert(0,str(Path.cwd()))
import numpy as np,trimesh,manifold3d as mf
from preprocesador_stl import cargar_exacto
from verificacion_reparacion import solido_poliedrico
from reparador_exacto_aislado import ControlExacto,medidas_superficie
from saneamiento_cad import comprobar_interferencias
mesh=cargar_exacto(Path('/workspace/work/perfeccion_Visualizador_r5/evidencias/casos_finales/Pieza_Nueva_Detenida.reparado.stl'));part=[p for p in mesh.split(only_watertight=False) if p.volume<0][1];positive=part.copy();positive.invert();out=[]
for eps in [.00001,.00005,.0001]:
 start=time.monotonic();row={'eps':eps}
 try:
  s=mf.Manifold(mf.Mesh64(np.array(positive.vertices,dtype=np.float64,order='C',copy=True),np.array(positive.faces,dtype=np.uint64,order='C',copy=True)));r=s.minkowski_sum(mf.Manifold.cube([2*eps]*3,True)).simplify(1e-7);d=r.to_mesh64();m=trimesh.Trimesh(d.vert_properties[:,:3],d.tri_verts,process=False);v,ix=np.unique(m.vertices,axis=0,return_inverse=True);m=trimesh.Trimesh(v,ix[m.faces],process=False);row.update(caras=len(m.faces),max_superficie=medidas_superficie(part,m)['max_mm'],SI=len(ControlExacto(m,Path('work/cavidad_dilatada.off')).pares()));cad=solido_poliedrico(m);row.update(valido=cad.isValid(),interferencias=comprobar_interferencias(cad));cad.exportBrep('work/Pieza_Nueva_Detenida_cavidad_1.brep');row['ok']=True
 except Exception as exc:row.update(ok=False,error=str(exc));traceback.print_exc()
 row['segundos']=time.monotonic()-start;out.append(row);Path('evidencias/cavidad_dilatada.json').write_text(json.dumps(out,indent=2));print(row,flush=True)
 if row.get('ok'):break
