"""Ensayo de calidad numérica con cero intersecciones exactas por movimiento."""
import time,numpy as np
from reparador_exacto_aislado import ControlExacto,medidas_superficie

def mejorar(mesh,path,*,deadline=None,objetivo=1e-6):
 deadline=deadline or time.monotonic()+240;m=mesh.copy();base=m.vertices.copy();F=m.faces;inc=[[] for _ in m.vertices]
 for i,f in enumerate(F):
  for v in f:inc[v].append(i)
 check=ControlExacto(m,path)
 if check.pares():raise ValueError('La entrada tiene intersecciones')
 def heights(T):return np.linalg.norm(np.cross(T[:,1]-T[:,0],T[:,2]-T[:,0]),axis=1)/np.maximum(np.linalg.norm(T-np.roll(T,-1,axis=1),axis=2).max(1),1e-300)
 rng=np.random.default_rng(20261024);moves=[];trials=0
 for iteration in range(80):
  T=m.vertices[F];hs=heights(T);bad=np.where(hs<objetivo)[0]
  print('CALIDAD',iteration,len(bad),float(hs.min()),flush=True)
  if not len(bad):break
  changed=False
  for fi in bad[np.argsort(hs[bad])]:
   for v in F[fi]:
    ids=np.array(inc[v]);old=m.vertices[v].copy();previous=hs[ids];oldbad=int((previous<objetivo).sum());previousmin=float(previous.min());tri=T[ids];cross=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);area=np.linalg.norm(cross,axis=1);normals=cross/np.maximum(area[:,None],1e-300);average=cross.sum(0);center=m.vertices[np.unique(F[ids])].mean(0)-old;directions=list(np.eye(3))+list(-np.eye(3))
    for d in [average,center,*normals[np.argsort(-area)[:6]]]:
     if np.linalg.norm(d)>1e-20:directions.extend([d/np.linalg.norm(d),-d/np.linalg.norm(d)])
    directions.extend(d/np.linalg.norm(d) for d in rng.normal(size=(12,3)))
    accepted=False
    for eps in (2e-6,2e-5,1e-4):
     for direction in directions:
      if time.monotonic()>deadline:raise TimeoutError('Acondicionamiento numérico agotado')
      p=old+eps*direction
      if np.linalg.norm(p-base[v])>.0003:continue
      newtri=tri.copy();newtri[F[ids]==v]=p;nh=heights(newtri);nbad=int((nh<objetivo).sum());nmin=float(nh.min())
      if nbad>oldbad or (nbad==oldbad and nmin<max(previousmin*2,previousmin+1e-12)):continue
      if nmin<min(previousmin,objetivo):continue
      check.mover(int(v),p);trials+=1
      if check.pares():check.mover(int(v),old);continue
      m.vertices[v]=p;moves.append({'v':int(v),'eps':eps,'antes':previousmin,'despues':nmin,'malas_antes':oldbad,'malas_despues':nbad});accepted=True;changed=True;print('MOVER',moves[-1],flush=True);break
     if accepted:break
    if accepted:break
   if changed:break
  if not changed:break
 hs=heights(m.vertices[F]);q=medidas_superficie(mesh,m)
 if q['max_mm']>.002 or check.pares():raise ValueError('Acondicionamiento inválido')
 return m,{'movimientos':moves,'ensayos_cgal':trials,'objetivo_mm':objetivo,'min_altitud_mm':float(hs.min()),'caras_bajo_objetivo':int((hs<objetivo).sum()),'superficie':q}
