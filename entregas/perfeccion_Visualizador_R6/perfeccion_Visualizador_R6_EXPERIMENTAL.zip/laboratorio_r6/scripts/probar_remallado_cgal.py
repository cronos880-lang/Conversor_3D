from pathlib import Path
import sys,time,json,traceback
sys.path.insert(0,str(Path.cwd()))
import numpy as np,trimesh,cadquery as cq
from CGAL import CGAL_Polygon_mesh_processing as pmp
from preprocesador_stl import cargar_exacto
from reparador_exacto_aislado import ControlExacto,medidas_superficie,escribir_off
from verificacion_reparacion import solido_poliedrico
from cavidades_cad import reconstruir
from motor_v2 import _calidad
name=sys.argv[1] if len(sys.argv)>1 else '6558_fixed';start=time.monotonic();prepared=cargar_exacto(Path('/workspace/work/perfeccion_Visualizador_r5/evidencias/casos_finales')/(name+'.reparado.stl'));body=next(p for p in prepared.split(only_watertight=False) if p.volume>0);row={'archivo':name};target_length=.15
try:
 checker=ControlExacto(body,Path('work/'+name+'_remesh_control.off'));poly=checker.poly
 def constraints(mesh,poly):
  normals=mesh.face_normals;hs=[]
  for h in poly.halfedges():
   a,b=h.facet().id(),h.opposite().facet().id()
   if a>=b:continue
   pa,pb=h.vertex().point(),h.opposite().vertex().point();length=np.linalg.norm(np.array([pa.x(),pa.y(),pa.z()])-np.array([pb.x(),pb.y(),pb.z()]))
   if length>1e-5 and normals[a]@normals[b]<np.cos(np.deg2rad(30)):hs.append(h)
  return hs
 hs=constraints(body,poly);print('CONSTRAINTS',len(hs),flush=True);pmp.split_long_edges(hs,target_length*1.30,poly);poly.write_to_file('work/'+name+'_remesh_dividido.off');m=trimesh.load('work/'+name+'_remesh_dividido.off',process=False);checker=ControlExacto(m,Path('work/'+name+'_remesh_control.off'));poly=checker.poly;hs=constraints(m,poly);print('DIVIDIDO',len(m.faces),'CONSTRAINTS',len(hs),flush=True)
 pmp.isotropic_remeshing(list(poly.facets()),target_length,poly,3,hs,True);poly.write_to_file('work/'+name+'_remesh.off');candidate=trimesh.load('work/'+name+'_remesh.off',process=False);print('REMESH',len(candidate.faces),time.monotonic()-start,flush=True)
 check=ControlExacto(candidate,Path('work/'+name+'_remesh_control.off'));pairs=check.pares();print('CGAL',len(pairs),flush=True)
 if pairs:raise ValueError('Remallado con autointersecciones')
 proof=medidas_superficie(body,candidate);row['superficie']=proof;print('SURFACE',proof,flush=True)
 if proof['max_mm']>.020:raise ValueError('Remallado se aparta más de 0.020 mm')
 Path('work/'+name+'_remesh.stl').write_text(trimesh.exchange.stl.export_stl_ascii(candidate));shape=solido_poliedrico(candidate);print('CAD',shape.isValid(),len(shape.Faces()),flush=True)
 for void,boss,detail in reconstruir(prepared,log=lambda *a:print(*a,flush=True)):
  if boss is not None:shape=shape.fuse(boss)
  shape=shape.cut(void)
 target=Path('work/'+name+'_remesh.step');shape.exportStep(str(target));original=Path('/workspace/work/casos_usuario_r5')/(name+'.stl');row['calidad']=_calidad(original,target,cargar_exacto(original),control_avanzado=True);row['ok']=True
except Exception as exc:row.update(ok=False,error=str(exc));traceback.print_exc()
row['segundos']=time.monotonic()-start;Path('evidencias/'+name+'_remesh_cgal.json').write_text(json.dumps(row,indent=2));print('RESULT',json.dumps(row),flush=True)
