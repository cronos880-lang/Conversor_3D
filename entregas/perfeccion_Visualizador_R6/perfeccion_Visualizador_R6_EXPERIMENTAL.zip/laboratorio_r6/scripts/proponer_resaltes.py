from pathlib import Path
import sys,json,numpy as np,trimesh
sys.path.insert(0,str(Path.cwd()))
from preprocesador_stl import cargar_exacto
from reconstruccion_celdas import _circulo
name='6558_fixed';m=cargar_exacto(Path('/workspace/work/casos_usuario_r5')/(name+'.stl'));cs=json.loads(Path('evidencias/'+name+'_cilindros_r6.json').read_text());base=max(cs,key=lambda p:p['area']);axis=base['axis'];ij=[k for k in range(3) if k!=axis];center=np.array(base['center']);rho=np.linalg.norm(m.triangles_center[:,ij]-center,axis=1);radial=m.triangles_center[:,ij]-center;radial/=np.linalg.norm(radial,axis=1)[:,None];dot=(radial*m.face_normals[:,ij]).sum(1);mask=(rho>base['radius']+.015)&(dot>.1)&(abs(m.face_normals[:,axis])>.03)
for p in cs:mask[p['faces']]=False
links=m.face_adjacency;groups=trimesh.graph.connected_components(links[mask[links].all(1)],nodes=np.where(mask)[0],min_len=1);props=[]
for i,ids in enumerate(groups):
 area=float(m.area_faces[ids].sum())
 if len(ids)<6 or area<.03:continue
 pts=np.vstack([m.vertices[np.unique(m.faces[ids])],m.triangles_center[ids]]);profile=np.c_[np.linalg.norm(pts[:,ij]-center,axis=1),pts[:,axis]];ctr,r=_circulo(profile);err=float(abs(np.linalg.norm(profile-ctr,axis=1)-r).max());xyz=pts.mean(0);mat=np.c_[2*pts,np.ones(len(pts))];b=(pts*pts).sum(1);cx,cy,cz,off=np.linalg.lstsq(mat,b,rcond=None)[0];spherecenter=np.array([cx,cy,cz]);sr=float(np.sqrt(max(0,off+spherecenter@spherecenter)));se=float(abs(np.linalg.norm(pts-spherecenter,axis=1)-sr).max());phi=np.sort(np.arctan2(profile[:,1]-ctr[1],profile[:,0]-ctr[0])%(2*np.pi));arc=float(360*(1-np.diff(np.r_[phi,phi[0]+2*np.pi]).max()/(2*np.pi)));row={'grupo':i,'faces':ids.tolist(),'area':area,'bounds':np.array([pts.min(0),pts.max(0)]).tolist(),'torus':{'axis':axis,'center_xy':center.tolist(),'major_radius':float(ctr[0]),'z_center':float(ctr[1]),'minor_radius':r,'max_mm':err,'arc':arc},'sphere':{'center':spherecenter.tolist(),'radius':sr,'max_mm':se}};props.append(row);print({k:v for k,v in row.items() if k!='faces'},flush=True)
Path('evidencias/resaltes_candidatos.json').write_text(json.dumps(props,indent=2))
