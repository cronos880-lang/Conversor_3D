from pathlib import Path
import sys,json,time,traceback
sys.path.insert(0,str(Path.cwd()))
import cadquery as cq,numpy as np,igl
from OCP.BOPAlgo import BOPAlgo_Splitter
from OCP.BRep import BRep_Builder
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeSolid
from OCP.TopTools import TopTools_IndexedMapOfShape
from OCP.TopoDS import TopoDS,TopoDS_Shell
from OCP.TopAbs import TopAbs_FACE,TopAbs_EDGE
from OCP.TopExp import TopExp_Explorer
from OCP.BRepClass3d import BRepClass3d_SolidClassifier
from OCP.gp import gp_Pnt
from OCP.TopAbs import TopAbs_IN
from OCP.ShapeUpgrade import ShapeUpgrade_UnifySameDomain
from preprocesador_stl import cargar_exacto
from motor_v2 import _calidad
from verificacion_reparacion import distancia_malla
name='6558_fixed';source=Path('/workspace/work/casos_usuario_r5')/(name+'.stl');mesh=cargar_exacto(source);bounds=mesh.bounds.copy();bounds[0]-=.025;bounds[1]+=.025;dims=bounds[1]-bounds[0];box=cq.Solid.makeBox(*map(float,dims),cq.Vector(*bounds[0]));L=float(np.linalg.norm(dims)*3);start=time.monotonic()
planes=[]
for p in json.loads(Path('evidencias/inventario_celdas.json').read_text())[0]['planes']:
 n=np.eye(3)[p['axis']];planes.append({'normal':n.tolist(),'offset':p['value']})
for p in json.loads(Path('evidencias/planos_completos.json').read_text()):
 n=np.array(p['normal']);offset=p['offset']
 if p['area']<1 or max(abs(n))>.9999:continue
 n[abs(n)<1e-5]=0;n/=np.linalg.norm(n);v=mesh.vertices[np.unique(mesh.faces[p['faces']])];offset=float((v@n).mean())
 if abs(v@n-offset).max()>.0001:continue
 planes.append({'normal':n.tolist(),'offset':offset})
cylinders=json.loads(Path('evidencias/6558_cilindros_completos.json').read_text());mainaxis=max(cylinders,key=lambda x:x['area'])['axis']
for p in cylinders:
 if p['axis']==mainaxis:continue
 ij=[k for k in range(3) if k!=p['axis']];n=np.eye(3)[mainaxis];planes.append({'normal':n.tolist(),'offset':p['center'][ij.index(mainaxis)]})
from reconstruccion_celdas import envolvente_coaxial
box,envelope_report=envolvente_coaxial(mesh,cylinders);print('DOMAIN',envelope_report,flush=True)
cache=Path('work/'+name+'_splitter_extendido_partes.brep')
if not cache.exists():
 builder=BOPAlgo_Splitter();builder.SetRunParallel(False);builder.SetNonDestructive(True);builder.SetFuzzyValue(0.);builder.AddArgument(box.wrapped)
 for p in planes:
  n=np.array(p['normal']);plane=cq.Plane(origin=cq.Vector(*(n*p['offset'])),normal=cq.Vector(*n));face=cq.Face.makeFromWires(cq.Workplane(plane).rect(L,L).val());builder.AddTool(face.wrapped)
 for p in cylinders:
  axis=p['axis'];center=np.zeros(3);center[axis]=(bounds[0,axis]+bounds[1,axis])/2-L;center[[k for k in range(3) if k!=axis]]=p['center'];cylinder=cq.Solid.makeCylinder(p['radius'],2*L,cq.Vector(*center),cq.Vector(*np.eye(3)[axis]));face=next(f for f in cylinder.Faces() if f.geomType()=='CYLINDER');builder.AddTool(face.wrapped)
 print('TOOLS',len(planes)+len(cylinders),flush=True);builder.Perform()
 if builder.HasErrors():raise ValueError('Splitter no ha completado la partición')
 whole=cq.Shape.cast(builder.Shape());whole.exportBrep(str(cache));print('SPLIT',len(whole.Solids()),time.monotonic()-start,flush=True)
else:whole=cq.importers.importBrep(str(cache)).val()
from puntos_celdas import punto_interior
parts=whole.Solids();selected=[];records=[]
for index,part in enumerate(parts):
 classifier=BRepClass3d_SolidClassifier(part.wrapped)
 def inside(point):classifier.Perform(gp_Pnt(*map(float,point)),1e-8);return classifier.State()==TopAbs_IN
 center,point_proof=punto_interior(part)
 samples=[];boundary_samples=False
 if point_proof['verificado']:
  samples.append(center)
  if point_proof['margen_mm']<.018:
   radius=max(0.,point_proof['margen_mm']*.7)
   for direction in np.r_[np.eye(3),-np.eye(3)]:
    p=center+radius*direction
    if inside(p):samples.append(p)
 else:
  bb=part.BoundingBox();lo=np.array([bb.xmin,bb.ymin,bb.zmin]);hi=np.array([bb.xmax,bb.ymax,bb.zmax]);rng=np.random.default_rng(1717)
  for p in rng.uniform(lo,hi,size=(64,3)):
   if inside(p):samples.append(p)
   if len(samples)>=7:break
 if not samples:
  samples=[np.asarray(e.positionAt(.5).toTuple()) for e in part.Edges()[:12]];boundary_samples=True
  if not samples:raise ValueError('Celda sin puntos de frontera medibles')
 winds=igl.winding_number(mesh.vertices,mesh.faces,np.array(samples));material=bool(np.median(winds)>.5)
 if material:selected.append(part)
 records.append({'id':index,'material':material,'volumen':part.Volume(),'puntos':[p.tolist() for p in samples],'winding':np.asarray(winds).tolist(),'muestras_en_frontera':boundary_samples,'punto_interior':point_proof})
 if index%200==0:
  Path('evidencias/splitter_extendido_parcial.json').write_text(json.dumps(records,indent=2))
  print('CLASS',index,len(parts),len(selected),flush=True)
Path('evidencias/splitter_extendido_clasificacion.json').write_text(json.dumps(records,indent=2));print('UNION',len(selected),sum(p.Volume() for p in selected),flush=True)
# Cancelación exacta de caras compartidas entre celdas seleccionadas.
face_map=TopTools_IndexedMapOfShape();uses={}
for part in selected:
 for face in part.Faces():
  i=face_map.Add(face.wrapped);uses.setdefault(i,[]).append(face.wrapped)
if any(len(x)>2 for x in uses.values()):raise ValueError('Incidencia no manifold en una cara')
faces=[x[0] for x in uses.values() if len(x)==1];edge_map=TopTools_IndexedMapOfShape();edge_faces={};parent=list(range(len(faces)))
def root(i):
 while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
 return i
for i,face in enumerate(faces):
 ex=TopExp_Explorer(face,TopAbs_EDGE)
 while ex.More():edge_faces.setdefault(edge_map.Add(ex.Current()),set()).add(i);ex.Next()
for ids in edge_faces.values():
 ids=list(ids)
 for i in ids[1:]:parent[root(i)]=root(ids[0])
groups={}
for i,face in enumerate(faces):groups.setdefault(root(i),[]).append(face)
b=BRep_Builder();maker=BRepBuilderAPI_MakeSolid()
for group in groups.values():
 shell=TopoDS_Shell();b.MakeShell(shell)
 for face in group:b.Add(shell,face)
 shell.Closed(True);maker.Add(shell)
shape=cq.Shape.cast(maker.Solid());shape.exportBrep('work/6558_raw_extendido.brep');print('RAW',len(faces),shape.isValid(),shape.Volume(),len(groups),flush=True)
unify=ShapeUpgrade_UnifySameDomain(shape.wrapped,True,True,False);unify.Build();shape=cq.Shape.cast(unify.Shape());print('CLEAN',len(shape.Faces()),shape.isValid(),shape.Volume(),flush=True);shape.exportStep('work/'+name+'_splitter_extendido.step')
try:q=_calidad(source,Path('work/'+name+'_splitter_extendido.step'),mesh,control_avanzado=True);print('QUALITY_OK',json.dumps(q),flush=True)
except Exception as e:print('QUALITY_FAIL',str(e),flush=True);traceback.print_exc()
