from pathlib import Path
import sys,time,json,traceback
sys.path.insert(0,str(Path.cwd()))
import cadquery as cq,trimesh
from preprocesador_stl import cargar_exacto
from regularizar_resolucion_cad import mejorar
from verificacion_reparacion import solido_poliedrico
from cavidades_cad import reconstruir
from motor_v2 import _calidad
name='6558_fixed';start=time.monotonic();row={}
try:
 m=cargar_exacto(Path('work/'+name+'_acondicionado_b.stl'));m,proof=mejorar(m,Path('work/resolucion.off'),deadline=start+240);row['acondicionamiento']=proof;print('MESH',proof['min_altitud_mm'],proof['caras_bajo_objetivo'],flush=True);Path('work/'+name+'_resolucion.stl').write_text(trimesh.exchange.stl.export_stl_ascii(m));shape=solido_poliedrico(m);print('CAD_OK',len(shape.Faces()),flush=True);prepared=cargar_exacto(Path('/workspace/work/perfeccion_Visualizador_r5/evidencias/casos_finales')/(name+'.reparado.stl'))
 for void,boss,detail in reconstruir(prepared,log=lambda *a:print(*a,flush=True)):
  if boss is not None:shape=shape.fuse(boss)
  shape=shape.cut(void)
 path=Path('work/'+name+'_resolucion.step');shape.exportStep(str(path));src=Path('/workspace/work/casos_usuario_r5')/(name+'.stl');row['calidad']=_calidad(src,path,cargar_exacto(src),control_avanzado=True);row['ok']=True
except Exception as exc:row.update(ok=False,error=str(exc));traceback.print_exc()
row['segundos']=time.monotonic()-start;Path('evidencias/resolucion_cad.json').write_text(json.dumps(row,indent=2));print('RESULT',row.get('ok'),row.get('error'),flush=True)
