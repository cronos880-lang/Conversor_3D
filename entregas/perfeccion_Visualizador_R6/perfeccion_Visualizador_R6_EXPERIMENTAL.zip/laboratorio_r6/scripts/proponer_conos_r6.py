from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
import numpy as np
from preprocesador_stl import cargar_exacto
name='6558_fixed';m=cargar_exacto(Path('/workspace/work/casos_usuario_r5')/(name+'.stl'));cs=json.loads(Path('evidencias/'+name+'_cilindros_r6.json').read_text());main=max(cs,key=lambda p:p['area']);axis=main['axis'];ij=[k for k in range(3) if k!=axis];ctr=np.array(main['center']);C,N,A=m.triangles_center,m.face_normals,m.area_faces;rho=np.linalg.norm(C[:,ij]-ctr,axis=1);rad=C[:,ij]-ctr;dot=(rad*N[:,ij]).sum(1)/np.maximum(rho,1e-15);ids=np.where((abs(N[:,axis])>.025)&(abs(N[:,axis])<.95)&(dot>.3))[0];rng=np.random.default_rng(44);pairs=rng.choice(ids,size=(6000,2),replace=True,p=np.sqrt(A[ids])/np.sqrt(A[ids]).sum());seeds={}
for i,j in pairs:
 if abs(C[i,axis]-C[j,axis])<.05:continue
 slope=(rho[i]-rho[j])/(C[i,axis]-C[j,axis]);b=rho[i]-slope*C[i,axis]
 if .02<abs(slope)<3:seeds.setdefault((round(slope/.01),round(b/.03)),(slope,b))
tri=m.triangles[ids];sample=np.concatenate([tri,tri.mean(1)[:,None,:],(tri+np.roll(tri,-1,axis=1))/2],axis=1);rr=np.linalg.norm(sample[:,:,ij]-ctr,axis=2);zz=sample[:,:,axis];props=[];start=time.monotonic()
for slope,b in seeds.values():
 active=None
 for _ in range(4):
  errors=np.max(abs(rr-slope*zz-b),axis=1)/np.sqrt(1+slope*slope);alignment=(dot[ids]-slope*N[ids,axis])/np.sqrt(1+slope*slope);local=np.where((errors<.012)&(alignment>.9)&(-N[ids,axis]*slope>0))[0]
  if len(local)<8:break
  active=ids[local];p=m.vertices[np.unique(m.faces[active])];slope,b=np.polyfit(p[:,axis],np.linalg.norm(p[:,ij]-ctr,axis=1),1)
 if active is None or len(active)<8 or not(.02<abs(slope)<3):continue
 errs=np.max(abs(rr-slope*zz-b),axis=1)/np.sqrt(1+slope*slope);local=np.where((errs<.012)&(-N[ids,axis]*slope>0))[0];active=ids[local]
 if len(active)<8:continue
 phi=np.sort(np.arctan2(C[active][:,ij[1]]-ctr[1],C[active][:,ij[0]]-ctr[0])%(2*np.pi));arc=float(360*(1-np.diff(np.r_[phi,phi[0]+2*np.pi]).max()/(2*np.pi)));area=float(A[active].sum());pts=m.vertices[np.unique(m.faces[active])]
 if arc<60 or area<.1 or np.ptp(pts[:,axis])<.1:continue
 props.append({'axis':axis,'center':ctr.tolist(),'slope':float(slope),'intercept':float(b),'min':float(pts[:,axis].min()),'max':float(pts[:,axis].max()),'arc':arc,'area':area,'faces':active.tolist(),'max_mm':float(errs[local].max())})
accepted=[];used=set()
for p in sorted(props,key=lambda x:-x['area']):
 if len(set(p['faces'])-used)<.5*len(p['faces']):continue
 if any(abs(p['slope']-q['slope'])<.015 and abs(p['intercept']-q['intercept'])<.03 for q in accepted):continue
 accepted.append(p);used.update(p['faces']);print({k:v for k,v in p.items() if k!='faces'},flush=True)
 if len(accepted)>=12:break
Path('evidencias/conos_r6.json').write_text(json.dumps(accepted,indent=2));print('TOTAL',len(accepted),'SEEDS',len(seeds),'SEC',time.monotonic()-start,flush=True)
