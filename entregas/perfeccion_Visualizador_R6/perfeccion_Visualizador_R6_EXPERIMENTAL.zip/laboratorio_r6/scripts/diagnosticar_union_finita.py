from pathlib import Path
import sys,collections,json,time
sys.path.insert(0,str(Path.cwd()))
import cadquery as cq
from OCP.BRepCheck import BRepCheck_Analyzer,BRepCheck_NoError
from OCP.TopTools import TopTools_IndexedDataMapOfShapeListOfShape
from OCP.TopExp import TopExp
from OCP.TopAbs import TopAbs_EDGE,TopAbs_FACE
shape=cq.importers.importBrep('work/6558_raw_finito.brep').val();an=BRepCheck_Analyzer(shape.wrapped);counter=collections.Counter();bad=[]
for typ,items in [('v',shape.Vertices()),('e',shape.Edges()),('f',shape.Faces()),('s',shape.Shells()),('S',shape.Solids())]:
 for i,x in enumerate(items):
  status=list(an.Result(x.wrapped).Status())
  if status !=[BRepCheck_NoError]:counter[(typ,str(status))]+=1;bad.append((typ,i,str(status)))
m=TopTools_IndexedDataMapOfShapeListOfShape();TopExp.MapShapesAndAncestors_s(shape.wrapped,TopAbs_EDGE,TopAbs_FACE,m);valences=collections.Counter(len(list(m.FindFromIndex(i))) for i in range(1,m.Extent()+1));print('STATUS',counter,'VALENCIAS',valences,flush=True);Path('evidencias/union_finito_errores.json').write_text(json.dumps({'status':str(counter),'valencias':dict(valences),'bad':bad},indent=2))
