from pathlib import Path
import sys,json,time,traceback
sys.path.insert(0,str(Path.cwd()))
import numpy as np,trimesh,manifold3d as mf
from preprocesador_stl import cargar_exacto,_manifold
from reparador_exacto_aislado import ControlExacto,medidas_superficie,desenredar,validar_material
from reparacion_contactos_locales import descomponer_contactos
name='6558_fixed';start=time.monotonic();row={'archivo':name,'semiancho_mm':.0005}
try:
 body=cargar_exacto(Path('work/'+name+'_robusto_cuerpo.stl'));solid=_manifold(body);kernel=mf.Manifold.cube([.001]*3,True);print('DILATANDO',len(body.faces),flush=True);closed=solid.minkowski_sum(kernel);print('DILATADO',closed.num_tri(),time.monotonic()-start,flush=True);closed=closed.minkowski_difference(kernel).simplify(1e-6);print('EROSIONADO',closed.num_tri(),time.monotonic()-start,flush=True);data=closed.to_mesh64();mesh=trimesh.Trimesh(data.vert_properties[:,:3],data.tri_verts,process=False);mesh.remove_unreferenced_vertices();mesh,proof=descomponer_contactos(mesh);row['descomposicion']=proof
 control=ControlExacto(mesh,Path('work/'+name+'_cerrado_controlado.off'));pairs=control.pares();print('CGAL',len(pairs),flush=True)
 if pairs:mesh,proof=desenredar(mesh,Path('work/'+name+'_cerrado_controlado.off'),start+420,solo_contactos=False);row['desenredo']=proof
 prepared=cargar_exacto(Path('/workspace/work/perfeccion_Visualizador_r5/evidencias/casos_finales')/(name+'.reparado.stl'));body_ref=next(p for p in prepared.split(only_watertight=False) if p.volume>0);q=medidas_superficie(body_ref,mesh);row['superficie']=q;print('SUPERFICIE',q,flush=True)
 if q['max_mm']>.002:raise ValueError('Cierre fuera del presupuesto superficial local')
 original=cargar_exacto(Path('/workspace/work/casos_usuario_r5')/(name+'.stl'));row['material']=validar_material(original,mesh,[]);Path('work/'+name+'_cerrado_controlado.stl').write_text(trimesh.exchange.stl.export_stl_ascii(mesh));row['ok']=True;row['caras']=len(mesh.faces);row['euler_antes']=body.euler_number;row['euler_despues']=mesh.euler_number
except Exception as exc:row.update(ok=False,error=str(exc));traceback.print_exc()
row['segundos']=time.monotonic()-start;Path('evidencias/'+name+'_cierre_controlado.json').write_text(json.dumps(row,indent=2));print('RESULT',json.dumps(row),flush=True)
