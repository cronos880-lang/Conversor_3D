from pathlib import Path
import sys,json,time,traceback
sys.path.insert(0,str(Path.cwd()))
import trimesh
from preprocesador_stl import cargar_exacto
from reparacion_contactos_locales import contraer_microaristas_generadas
from reparador_exacto_aislado import ControlExacto,medidas_superficie
out=[]
for name in ['6558_fixed','Pieza_Nueva_Detenida']:
 start=time.monotonic();m=cargar_exacto(Path('work')/(name+'_acondicionado.stl'));row={'archivo':name};checks=0;deadline=start+180
 def valid(p):
  global checks
  checks+=1
  if time.monotonic()>deadline:raise TimeoutError('Acondicionamiento agotado')
  try:return not ControlExacto(p,Path('work/'+name+'_contraccion.off')).pares()
  except ValueError:return False
 try:
  candidate,proof=contraer_microaristas_generadas(m,limite_mm=1e-7,validar=valid);q=medidas_superficie(m,candidate)
  if q['max_mm']>.002:raise ValueError('La contracción no conserva la superficie')
  Path('work/'+name+'_contraido_cad.stl').write_text(trimesh.exchange.stl.export_stl_ascii(candidate));row.update(ok=True,proof=proof,superficie=q,checks=checks,min_arista=float(candidate.edges_unique_length.min()));print('RESULT',name,len(candidate.faces),q,checks,row['min_arista'],flush=True)
 except Exception as exc:row.update(ok=False,error=str(exc));traceback.print_exc()
 row['segundos']=time.monotonic()-start;out.append(row);Path('evidencias/contraccion_validada.json').write_text(json.dumps(out,indent=2))
