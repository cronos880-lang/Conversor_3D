import argparse,subprocess,time,psutil,os,signal,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--rss',type=float,default=3000);p.add_argument('--segundos',type=float,default=480);p.add_argument('--informe',type=Path,required=True);p.add_argument('cmd',nargs=argparse.REMAINDER);a=p.parse_args();cmd=a.cmd[1:] if a.cmd and a.cmd[0]=='--' else a.cmd;start=time.monotonic();child=subprocess.Popen(cmd,start_new_session=True);peak=0.;reason=None
while child.poll() is None:
 try:
  root=psutil.Process(child.pid);rss=sum(p.memory_info().rss for p in [root]+root.children(recursive=True) if p.is_running())/1024**2;peak=max(peak,rss)
 except psutil.Error:rss=0
 if rss>a.rss:reason='limite_memoria'
 if time.monotonic()-start>a.segundos:reason='limite_tiempo'
 if reason:
  os.killpg(child.pid,signal.SIGTERM)
  try:child.wait(timeout=2)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
  break
 time.sleep(.25)
a.informe.write_text(json.dumps({'codigo':child.wait(),'interrupcion':reason,'rss_pico_mb':peak,'segundos':time.monotonic()-start,'limite_mb':a.rss,'limite_segundos':a.segundos},indent=2));raise SystemExit(child.returncode if child.returncode>=0 else 2)
