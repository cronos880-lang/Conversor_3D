from pathlib import Path
import sys,json,time,traceback
sys.path.insert(0,str(Path.cwd()))
import cadquery as cq,trimesh
from preprocesador_stl import cargar_exacto
from acondicionamiento_b import acondicionar
from verificacion_reparacion import solido_poliedrico
from motor_v2 import _calidad
from cavidades_cad import reconstruir
name='6558_fixed';start=time.monotonic();row={'archivo':name}
try:
 source=cargar_exacto(Path('work/'+name+'_robusto_cuerpo.stl'));mesh,proof=acondicionar(source,Path('work/'+name+'_acondicionado_b.off'),deadline=start+240);row['acondicionamiento']=proof;print('MESH_OK',proof,flush=True);Path('work/'+name+'_acondicionado_b.stl').write_text(trimesh.exchange.stl.export_stl_ascii(mesh));shape=solido_poliedrico(mesh);print('CAD_OK',len(shape.Faces()),flush=True);prepared=cargar_exacto(Path('/workspace/work/perfeccion_Visualizador_r5/evidencias/casos_finales')/(name+'.reparado.stl'))
 for void,boss,d in reconstruir(prepared,log=lambda *a:print(*a,flush=True)):
  if boss is not None:shape=shape.fuse(boss)
  shape=shape.cut(void)
 path=Path('work/'+name+'_acondicionado_b.step');shape.exportStep(str(path));original=Path('/workspace/work/casos_usuario_r5')/(name+'.stl');row['calidad']=_calidad(original,path,cargar_exacto(original),control_avanzado=True);row['ok']=True
except Exception as exc:row.update(ok=False,error=str(exc));traceback.print_exc()
row['segundos']=time.monotonic()-start;Path('evidencias/'+name+'_acondicionado_b.json').write_text(json.dumps(row,indent=2));print('RESULT',json.dumps(row),flush=True)
