from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
import numpy as np,trimesh
from preprocesador_stl import cargar_exacto
m=cargar_exacto(Path('/workspace/work/casos_usuario_r5/6558_fixed.stl'));cs=json.loads(Path('evidencias/6558_fixed_cilindros_r6.json').read_text());base=max(cs,key=lambda p:p['area']);axis=base['axis'];ij=[k for k in range(3) if k!=axis];centerxy=np.array(base['center']);C,N,A=m.triangles_center,m.face_normals,m.area_faces;rad=C[:,ij]-centerxy;rho=np.linalg.norm(rad,axis=1);dot=(rad*N[:,ij]).sum(1)/np.maximum(rho,1e-15);mask=(dot>.1)&(abs(N[:,axis])>.03);mask[np.unique([x for p in cs for x in p['faces']])]=False;ids=np.where(mask)[0];rng=np.random.default_rng(42);pairs=rng.choice(ids,size=(3000,2),replace=True,p=np.sqrt(A[ids])/np.sqrt(A[ids]).sum());seeds={}
for i,j in pairs:
 zi,zj=C[i,axis],C[j,axis]
 if abs(zi-zj)<.1:continue
 z0=((rho[i]**2+zi**2)-(rho[j]**2+zj**2))/(2*(zi-zj));r=float(np.sqrt(rho[i]**2+(zi-z0)**2))
 if r<.2 or r>np.linalg.norm(m.extents)*2:continue
 seeds.setdefault((round(z0/.03),round(r/.03)),(z0,r))
triangles=m.triangles[ids];proposals=[];start=time.monotonic()
def error(center,r):
 high=np.linalg.norm(triangles-center,axis=2).max(1);near=trimesh.triangles.closest_point(triangles,np.tile(center,(len(triangles),1)));low=np.linalg.norm(near-center,axis=1);return np.maximum(abs(high-r),abs(low-r))
for z0,r in seeds.values():
 center=np.zeros(3);center[ij]=centerxy;center[axis]=z0;active=None
 for _ in range(4):
  d=C[ids]-center;alignment=(d*N[ids]).sum(1)/np.linalg.norm(d,axis=1);local=np.where((error(center,r)<.012)&(alignment>.9))[0]
  if len(local)<12:break
  active=ids[local];points=m.vertices[np.unique(m.faces[active])];rr=np.linalg.norm(points[:,ij]-centerxy,axis=1);z=points[:,axis];z0,b=np.linalg.lstsq(np.c_[2*z,np.ones(len(z))],rr*rr+z*z,rcond=None)[0];r=float(np.sqrt(max(0,b+z0*z0)));center[axis]=z0
 if active is None or len(active)<12:continue
 errs=error(center,r);local=np.where(errs<.012)[0];active=ids[local]
 if len(active)<12 or np.ptp(m.vertices[np.unique(m.faces[active])][:,axis])<.2:continue
 area=float(A[active].sum())
 if area<.2:continue
 proposals.append({'center':center.tolist(),'radius':r,'faces':active.tolist(),'area':area,'max_mm':float(errs[local].max())})
accepted=[]
for p in sorted(proposals,key=lambda p:-p['area']):
 if any(np.linalg.norm(np.array(p['center'])-q['center'])<.03 and abs(p['radius']-q['radius'])<.03 for q in accepted):continue
 accepted.append(p);print({k:v for k,v in p.items() if k!='faces'},flush=True)
 if len(accepted)>=12:break
Path('evidencias/esferas_axiales.json').write_text(json.dumps(accepted,indent=2));print('SEEDS',len(seeds),'ACCEPT',len(accepted),'SEC',time.monotonic()-start,flush=True)
