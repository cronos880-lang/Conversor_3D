from pathlib import Path
import sys
sys.path.insert(0,str(Path.cwd()))
from preprocesador_stl import cargar_exacto
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
m=cargar_exacto(Path('/workspace/work/casos_usuario_r5/6558_fixed.stl'));sec=m.section(plane_origin=[0,0,0],plane_normal=[0,1,0]);fig,ax=plt.subplots(figsize=(10,6))
for line in sec.discrete:ax.plot(line[:,2],line[:,0],'-',lw=1)
ax.set(xlim=(14.8,17.2),ylim=(2.25,2.6),xlabel='Z (mm)',ylabel='X (mm)',title='6558: perfil original del resalte, sección Y=0');ax.grid();fig.savefig('evidencias/perfil_resalte.png',dpi=130)
