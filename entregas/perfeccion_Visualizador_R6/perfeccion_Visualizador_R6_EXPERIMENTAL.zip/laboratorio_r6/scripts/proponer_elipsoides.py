from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
import numpy as np,trimesh
from preprocesador_stl import cargar_exacto
m=cargar_exacto(Path('/workspace/work/casos_usuario_r5/6558_fixed.stl'));cs=json.loads(Path('evidencias/6558_fixed_cilindros_r6.json').read_text());base=max(cs,key=lambda p:p['area']);axis=base['axis'];ij=[k for k in range(3) if k!=axis];centerxy=np.array(base['center']);C,N,A=m.triangles_center,m.face_normals,m.area_faces;rad=C[:,ij]-centerxy;rho=np.linalg.norm(rad,axis=1);dot=(rad*N[:,ij]).sum(1)/np.maximum(rho,1e-15);mask=(dot>.1)&(abs(N[:,axis])>.025);mask[np.unique([x for p in cs for x in p['faces']])]=False;ids=np.where(mask)[0];tris=m.triangles[ids];rng=np.random.default_rng(45);sets=rng.choice(ids,size=(4500,5),replace=True,p=np.sqrt(A[ids])/np.sqrt(A[ids]).sum());seeds={};start=time.monotonic()
def fit(points):
 zref=float(points[:,axis].mean());d=points[:,ij]-centerxy;z=points[:,axis]-zref
 mat=np.c_[d[:,0]**2,d[:,1]**2,z*z,z,np.ones(len(z))];coef=np.linalg.svd(mat,full_matrices=False if len(points)>=5 else True)[2][-1];a,b,c,d,e=coef
 if a<0:a,b,c,d,e=-a,-b,-c,-d,-e
 if min(a,b,c)<=1e-14:return None
 val=d*d/(4*c)-e
 if val<=0:return None
 radii2=val/np.array([a,b,c]);r=np.sqrt(radii2)
 if r.min()<.1 or r.max()>np.linalg.norm(m.extents)*2:return None
 center=np.zeros(3);center[ij]=centerxy;center[axis]=zref-d/(2*c);rr=np.zeros(3);rr[ij]=r[:2];rr[axis]=r[2]
 if center[axis]<m.bounds[0,axis]-r[2] or center[axis]>m.bounds[1,axis]+r[2]:return None
 return center,rr
def bound(center,radii):
 normalized=(tris-center)/radii;high=np.linalg.norm(normalized,axis=2).max(1);near=trimesh.triangles.closest_point(normalized,np.zeros((len(tris),3)));low=np.linalg.norm(near,axis=1);return radii.max()*np.maximum(abs(high-1),abs(low-1))
for subset in sets:
 hypothesis=fit(C[subset])
 if hypothesis is None:continue
 center,radii=hypothesis;key=tuple(np.round(np.r_[center[axis],radii]/.05).astype(int));seeds.setdefault(key,(center,radii))
print('SEEDS',len(seeds),flush=True);props=[]
for center,radii in seeds.values():
 active=None
 for _ in range(3):
  errors=bound(center,radii);g=(C[ids]-center)/(radii*radii);alignment=(g*N[ids]).sum(1)/np.linalg.norm(g,axis=1);local=np.where((errors<.018)&(alignment>.9))[0]
  if len(local)<12:break
  active=ids[local];p=m.vertices[np.unique(m.faces[active])];refined=fit(p)
  if refined is None:break
  center,radii=refined
 if active is None:continue
 errors=bound(center,radii);local=np.where(errors<.018)[0];active=ids[local];area=float(A[active].sum())
 if len(active)<12 or area<.2:continue
 props.append({'center':center.tolist(),'radii':radii.tolist(),'faces':active.tolist(),'area':area,'max_triangulo_mm':float(errors[local].max())})
accepted=[];covered=set()
for p in sorted(props,key=lambda p:-p['area']):
 if len(set(p['faces'])-covered)<.6*len(p['faces']):continue
 if any(np.linalg.norm(np.array(p['center'])-q['center'])<.05 and np.linalg.norm(np.array(p['radii'])-q['radii'])<.05 for q in accepted):continue
 accepted.append(p);covered.update(p['faces']);print({k:v for k,v in p.items() if k!='faces'},flush=True)
 if len(accepted)>=8:break
Path('evidencias/elipsoides_r6.json').write_text(json.dumps(accepted,indent=2));print('TOTAL',len(accepted),'SEC',time.monotonic()-start,flush=True)
