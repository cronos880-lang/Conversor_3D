from pathlib import Path
import sys,json,time,traceback
sys.path.insert(0,str(Path.cwd()));sys.path.insert(0,'/workspace/work/herramientas_r5')
import numpy as np,cadquery as cq,igl
from OCP.BOPAlgo import BOPAlgo_CellsBuilder
from OCP.TopTools import TopTools_ListOfShape
from OCP.BRepClass3d import BRepClass3d_SolidClassifier
from OCP.gp import gp_Pnt
from OCP.TopAbs import TopAbs_IN
from preprocesador_stl import cargar_exacto
from motor_v2 import _calidad
from saneamiento_cad import comprobar_interferencias
name='6558_fixed';source=Path('/workspace/work/casos_usuario_r5')/(name+'.stl');mesh=cargar_exacto(source);inventory=json.loads(Path('evidencias/inventario_celdas.json').read_text())[0];bounds=mesh.bounds.copy();bounds[0]-=.000001;bounds[1]+=.000001;dims=bounds[1]-bounds[0];box=cq.Solid.makeBox(*map(float,dims),cq.Vector(*bounds[0]));tools=[box];types=[{'type':'box'}]
for p in inventory['planes']:
 ai=p['axis'];value=p['value']
 if value<bounds[0,ai]+1e-5 or value>bounds[1,ai]-1e-5:continue
 d=dims.copy();d[ai]=value-bounds[0,ai];tool=cq.Solid.makeBox(*map(float,d),cq.Vector(*bounds[0]));tools.append(tool);types.append({'type':'plane','axis':ai,'value':value})
cylinders=json.loads(Path('evidencias/6558_fixed_cilindros_locales.json').read_text())
for p in cylinders:
 axis=p['axis'];direction=np.eye(3)[axis];center=np.zeros(3);center[axis]=bounds[0,axis];center[[k for k in range(3) if k!=axis]]=p['center'];tool=cq.Solid.makeCylinder(p['radius'],dims[axis],cq.Vector(*center),cq.Vector(*direction));tools.append(tool);types.append(dict(p,type='cylinder'))
print('TOOLS',len(tools),flush=True);builder=BOPAlgo_CellsBuilder();builder.SetRunParallel(False);builder.SetNonDestructive(True);builder.SetFuzzyValue(0.)
for tool in tools:builder.AddArgument(tool.wrapped)
start=time.monotonic();builder.Perform();parts=cq.Shape.cast(builder.GetAllParts()).Solids();print('CELLS',len(parts),'sec',time.monotonic()-start,'errors',builder.HasErrors(),flush=True);records=[];selected=0;builder.RemoveAllFromResult();masks={}

classifier=None
def inside(s,p):
 classifier.Perform(gp_Pnt(*map(float,p)),1e-7)
 return classifier.State()==TopAbs_IN

def interior(s):
 global classifier
 classifier=BRepClass3d_SolidClassifier(s.wrapped)
 p=np.asarray(s.Center().toTuple())
 if inside(s,p):return p
 bb=s.BoundingBox();lo=np.array([bb.xmin,bb.ymin,bb.zmin]);hi=np.array([bb.xmax,bb.ymax,bb.zmax]);rng=np.random.default_rng(1717)
 for p in rng.uniform(lo,hi,size=(30,3)):
  if inside(s,p):return p
 v,f=s.copy().tessellate(.03,angularTolerance=.1);v=np.array([p.toTuple() for p in v]);f=np.array(f);centers=v[f].mean(axis=1)
 for q in centers[np.linspace(0,len(centers)-1,min(80,len(centers))).astype(int)]:
  for eps in [1e-5,1e-6]:
   for axis in np.eye(3):
    for sign in [-1,1]:
     p=q+sign*eps*axis
     if inside(s,p):return p
 raise ValueError('No se ha localizado un punto interior de una celda')
for index,part in enumerate(parts):
 volume=part.Volume()
 if volume<1e-15:raise ValueError('Celda material degenerada; no se descarta por tamaño')
 point=interior(part);w=float(igl.winding_number(mesh.vertices,mesh.faces,point));material=w>.5
 mask=[bool(np.all(point>bounds[0]) and np.all(point<bounds[1]))]
 for t in types[1:]:
  if t['type']=='plane':mask.append(point[t['axis']]<t['value'])
  else:
   ij=[k for k in range(3) if k!=t['axis']];mask.append(np.linalg.norm(point[ij]-t['center'])<t['radius'])
 key=tuple(mask)
 if key in masks and masks[key]!=material:
  print('CONFLICT',index,volume,point.tolist(),w,'insidebox',mask[0],flush=True)
  raise ValueError('Las superficies no separan dos regiones con material distinto')
 masks[key]=material
 if material:
  selected+=1;take=TopTools_ListOfShape();avoid=TopTools_ListOfShape()
  for yes,tool in zip(mask,tools):(take if yes else avoid).Append(tool.wrapped)
  builder.AddToResult(take,avoid,1,False)
 records.append({'celda':index,'volumen':volume,'material':material,'punto':point.tolist(),'winding':w})
 if index%100==0:print('CLASS',index,len(parts),selected,flush=True)
print('MERGE',selected,flush=True);builder.RemoveInternalBoundaries();shape=cq.Shape.cast(builder.Shape());print('RESULT',shape.isValid(),len(shape.Solids()),len(shape.Faces()),shape.Volume(),flush=True);Path('evidencias/celdas_6558_capsulas.json').write_text(json.dumps({'herramientas':types,'celdas':records,'caras':len(shape.Faces()),'solidos':len(shape.Solids()),'valido':shape.isValid(),'volumen':shape.Volume(),'segundos':time.monotonic()-start},indent=2));shape.exportStep('work/6558_celdas_capsulas.step')
try:print('QUALITY',_calidad(source,Path('work/6558_celdas_capsulas.step'),mesh,control_avanzado=True),flush=True)
except Exception as e:print('QUALITY_REJECTED',str(e),flush=True);traceback.print_exc()
