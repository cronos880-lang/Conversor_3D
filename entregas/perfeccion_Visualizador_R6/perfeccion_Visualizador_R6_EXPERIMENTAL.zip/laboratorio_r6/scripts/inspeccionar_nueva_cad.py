from pathlib import Path
import sys,json
sys.path.insert(0,str(Path.cwd()))
import cadquery as cq
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
shape=cq.importers.importBrep('work/Pieza_Nueva_Detenida_global_20_sin_cavidades.brep').val();parts=shape.Solids();print('PARTS',[(s.Volume(),len(s.Faces()),s.Center().toTuple()) for s in parts],flush=True);d=BRepExtrema_DistShapeShape(parts[0].wrapped,parts[1].wrapped);d.Perform();print('GAP',d.Value(),d.PointOnShape1(1).Coord(),d.PointOnShape2(1).Coord(),flush=True)
