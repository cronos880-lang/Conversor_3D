from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
import cadquery as cq,numpy as np
from puntos_celdas import punto_interior
parts=cq.importers.importBrep('work/6558_fixed_splitter_axial_partes.brep').val().Solids();out=[];start=time.monotonic()
indices=sorted(set([1385]+np.linspace(0,len(parts)-1,120,dtype=int).tolist()))
for i in indices:
 p,r=punto_interior(parts[i]);r['id']=i;r['volumen']=parts[i].Volume();out.append(r)
 if not r['verificado']:print('NO_VERIFICADO',r,p.tolist(),flush=True)
print('RESULTADO',len(out),'verificados',sum(x['verificado'] for x in out),'segundos',time.monotonic()-start,flush=True);Path('evidencias/puntos_celdas.json').write_text(json.dumps(out,indent=2))
