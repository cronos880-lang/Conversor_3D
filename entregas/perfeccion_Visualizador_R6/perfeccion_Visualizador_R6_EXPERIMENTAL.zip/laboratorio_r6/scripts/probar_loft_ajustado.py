from pathlib import Path
import sys,json,time,traceback
sys.path.insert(0,str(Path.cwd()))
from preprocesador_stl import cargar_exacto
from dominio_loft import construir
from OCP.ShapeUpgrade import ShapeUpgrade_UnifySameDomain
import cadquery as cq
name='6558_fixed';start=time.monotonic();m=cargar_exacto(Path('/workspace/work/casos_usuario_r5')/(name+'.stl'));shape,proof=construir(m,2,direcciones=48,margen=.001,error_perfil=.0005);u=ShapeUpgrade_UnifySameDomain(shape.wrapped,True,True,False);u.SetLinearTolerance(1e-7);u.SetAngularTolerance(1e-9);u.Build();clean=cq.Shape.cast(u.Shape())
if clean.isValid() and abs(clean.Volume()-shape.Volume())<1e-6:shape=clean
shape.exportBrep('work/'+name+'_loft_fino.brep');Path('evidencias/loft_fino.json').write_text(json.dumps({'proof':proof,'caras':len(shape.Faces()),'segundos':time.monotonic()-start},indent=2));print('DOMAIN_FINE',len(proof['niveles']),len(shape.Faces()),proof['ampliacion_certificado_mm'],shape.Volume(),flush=True)
