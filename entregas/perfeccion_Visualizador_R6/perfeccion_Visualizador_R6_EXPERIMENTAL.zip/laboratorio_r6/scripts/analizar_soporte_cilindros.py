from pathlib import Path
import json,sys
sys.path.insert(0,str(Path.cwd()))
import numpy as np,trimesh
from preprocesador_stl import cargar_exacto
for name in ['6558_fixed','Pieza_Nueva_Detenida']:
 m=cargar_exacto(Path('/workspace/work/casos_usuario_r5')/(name+'.stl'));ps=json.loads(Path('evidencias/'+name+'_cilindros_r6.json').read_text());accepted=[]
 for p in ps:
  ids=np.array(p['faces']);active=np.zeros(len(m.faces),bool);active[ids]=True;links=m.face_adjacency;links=links[active[links].all(1)];groups=trimesh.graph.connected_components(links,nodes=ids,min_len=1);ij=[k for k in range(3) if k!=p['axis']];arcs=[]
  for g in groups:
   phi=np.sort(np.arctan2(m.triangles_center[g][:,ij[1]]-p['center'][1],m.triangles_center[g][:,ij[0]]-p['center'][0])%(2*np.pi));arc=float(360*(1-np.diff(np.r_[phi,phi[0]+2*np.pi]).max()/(2*np.pi)));arcs.append((arc,float(m.area_faces[g].sum())))
  maximum=max(x[0] for x in arcs);p['arco_conexo_max']=maximum
  if maximum>=90:accepted.append(p)
  print(name,'axis',p['axis'],'r',round(p['radius'],4),'center',np.round(p['center'],3),'arc',round(p['arc'],1),'conexo',round(maximum,1),'grupos',len(groups),flush=True)
 Path('evidencias/'+name+'_cilindros_conexos.json').write_text(json.dumps(accepted,indent=2))
