from pathlib import Path
import sys,json,time,traceback
sys.path.insert(0,str(Path.cwd()))
import cadquery as cq,trimesh
from preprocesador_stl import cargar_exacto
from motor_v2 import convertir,_calidad
from cavidades_cad import reconstruir
name=sys.argv[1] if len(sys.argv)>1 else '6558_fixed';start=time.monotonic();row={'archivo':name}
try:
 original=Path('/workspace/work/casos_usuario_r5')/(name+'.stl');prepared=cargar_exacto(Path('/workspace/work/perfeccion_Visualizador_r5/evidencias/casos_finales')/(name+'.reparado.stl'));parts=prepared.split(only_watertight=False);body=next(p for p in parts if p.volume>0);bodypath=Path('work/'+name+'_cuerpo_separado.stl');bodypath.write_text(trimesh.exchange.stl.export_stl_ascii(body));target=Path('work/'+name+'_cuerpo_separado.step')
 with Path('evidencias/'+name+'_cuerpo_separado_motor.log').open('w',buffering=1) as log:
  result=convertir(bodypath,target,log,flat_tol_deg=1.3,digital=True,analitico=True,sin_simplificar=True,precision_reparacion=True,control_avanzado=True,conservar_vertices=True)
 print('BODY_OK',flush=True);shape=cq.importers.importStep(str(target)).val()
 for void,boss,proof in reconstruir(prepared,log=lambda *a:print(*a,flush=True)):
  if boss is not None:shape=shape.fuse(boss)
  shape=shape.cut(void)
 target=Path('work/'+name+'_cuerpo_cavidades.step');shape.exportStep(str(target));row['calidad']=_calidad(original,target,cargar_exacto(original),control_avanzado=True);row['ok']=True
except Exception as exc:row.update(ok=False,error=str(exc));traceback.print_exc()
row['segundos']=time.monotonic()-start;Path('evidencias/'+name+'_cuerpo_separado.json').write_text(json.dumps(row,indent=2));print('RESULT',json.dumps(row),flush=True)
