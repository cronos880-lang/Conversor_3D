from pathlib import Path
import sys,json,time,traceback
sys.path.insert(0,str(Path.cwd()))
import cadquery as cq,numpy as np,igl
from OCP.BOPAlgo import BOPAlgo_Splitter
from OCP.BRep import BRep_Builder
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeSolid
from OCP.TopTools import TopTools_IndexedMapOfShape
from OCP.TopoDS import TopoDS,TopoDS_Shell
from OCP.TopAbs import TopAbs_FACE,TopAbs_EDGE
from OCP.TopExp import TopExp_Explorer
from OCP.BRepClass3d import BRepClass3d_SolidClassifier
from OCP.gp import gp_Pnt
from OCP.TopAbs import TopAbs_IN
from OCP.ShapeUpgrade import ShapeUpgrade_UnifySameDomain
from preprocesador_stl import cargar_exacto
from motor_v2 import _calidad
from verificacion_reparacion import distancia_malla
name=sys.argv[1] if len(sys.argv)>1 else 'Pieza_Nueva_Detenida';source=Path('/workspace/work/casos_usuario_r5')/(name+'.stl');mesh=cargar_exacto(source);bounds=mesh.bounds.copy();bounds[0]-=.025;bounds[1]+=.025;dims=bounds[1]-bounds[0];box=cq.Solid.makeBox(*map(float,dims),cq.Vector(*bounds[0]));L=float(np.linalg.norm(dims)*3);start=time.monotonic()
from reconstruccion_celdas import detectar_planos
cylinders=json.loads((Path('evidencias')/(name+'_cilindros_r6.json')).read_text())
planes=detectar_planos(mesh,cylinders,min_area_oblicua=1.,tolerancia=.004)
Path('evidencias/'+name+'_planos_locales.json').write_text(json.dumps(planes,indent=2))
mainaxis=max(cylinders,key=lambda x:x['area'])['axis']
for p in cylinders:
 if p['axis']==mainaxis:continue
 ij=[k for k in range(3) if k!=p['axis']];n=np.eye(3)[mainaxis];planes.append({'normal':n.tolist(),'offset':p['center'][ij.index(mainaxis)]})
box=cq.importers.importBrep('work/'+name+'_loft_fino.brep').val();print('DOMAIN',box.Volume(),len(box.Faces()),flush=True)
cache=Path('work/'+name+'_splitter_loft_fino_partes.brep')
if not cache.exists():
 builder=BOPAlgo_Splitter();builder.SetRunParallel(False);builder.SetNonDestructive(True);builder.SetFuzzyValue(0.);builder.AddArgument(box.wrapped)
 for p in planes:
  n=np.array(p['normal'])
  if 'faces' not in p:
   plane=cq.Plane(origin=cq.Vector(*(n*p['offset'])),normal=cq.Vector(*n));face=cq.Face.makeFromWires(cq.Workplane(plane).rect(L,L).val())
  else:
   points=mesh.vertices[np.unique(mesh.faces[p['faces']])];center=points.mean(0);_,_,vt=np.linalg.svd(points-center,full_matrices=False);u=vt[0]-n*(vt[0]@n);u/=np.linalg.norm(u);v=np.cross(n,u);origin=n*p['offset'];q=(points-origin)@np.array([u,v]).T;lo=q.min(0)-.035;hi=q.max(0)+.035;corners=[origin+u*x+v*y for x,y in [(lo[0],lo[1]),(hi[0],lo[1]),(hi[0],hi[1]),(lo[0],hi[1])]];face=cq.Face.makeFromWires(cq.Wire.makePolygon([cq.Vector(*x) for x in corners],close=True))
  builder.AddTool(face.wrapped)
 for p in cylinders:
  axis=p['axis'];center=np.zeros(3);center[axis]=(bounds[0,axis]+bounds[1,axis])/2-L;center[[k for k in range(3) if k!=axis]]=p['center'];cylinder=cq.Solid.makeCylinder(p['radius'],2*L,cq.Vector(*center),cq.Vector(*np.eye(3)[axis]));face=next(f for f in cylinder.Faces() if f.geomType()=='CYLINDER');builder.AddTool(face.wrapped)
 print('TOOLS',len(planes)+len(cylinders),flush=True);builder.Perform()
 if builder.HasErrors():raise ValueError('Splitter no ha completado la partición')
 whole=cq.Shape.cast(builder.Shape());whole.exportBrep(str(cache));print('SPLIT',len(whole.Solids()),time.monotonic()-start,flush=True)
else:whole=cq.importers.importBrep(str(cache)).val()
from puntos_celdas import punto_interior
parts=whole.Solids();selected=[];records=[]
cached=len(records)
for index,part in enumerate(parts):
 if index<cached:continue
 classifier=BRepClass3d_SolidClassifier(part.wrapped)
 def inside(point):classifier.Perform(gp_Pnt(*map(float,point)),1e-8);return classifier.State()==TopAbs_IN
 try:center,point_proof=punto_interior(part)
 except ValueError:center=np.array(part.Center().toTuple());point_proof={'verificado':False,'margen_mm':0.}
 samples=[];boundary_samples=False
 if point_proof['verificado']:
  samples.append(center)
  if point_proof['margen_mm']<.018:
   radius=max(0.,point_proof['margen_mm']*.7)
   for direction in np.r_[np.eye(3),-np.eye(3)]:
    p=center+radius*direction
    if inside(p):samples.append(p)
 else:
  bb=part.BoundingBox();lo=np.array([bb.xmin,bb.ymin,bb.zmin]);hi=np.array([bb.xmax,bb.ymax,bb.zmax]);rng=np.random.default_rng(1717)
  for p in rng.uniform(lo,hi,size=(64,3)):
   if inside(p):samples.append(p)
   if len(samples)>=7:break
 if not samples:
  samples=[np.asarray(e.positionAt(.5).toTuple()) for e in part.Edges()[:12]];boundary_samples=True
  if not samples:raise ValueError('Celda sin puntos de frontera medibles')
 records.append({'id':index,'volumen':part.Volume(),'puntos':[p.tolist() for p in samples],
  'muestras_en_frontera':boundary_samples,'punto_interior':point_proof})
 if index%200==0:print('POINTS',index,len(parts),flush=True)
print('CALCULANDO_CAMPO',len(records),time.monotonic()-start,flush=True)
counts=[len(r['puntos']) for r in records];allpoints=np.vstack([r['puntos'] for r in records]);allwinds=igl.winding_number(mesh.vertices,mesh.faces,allpoints);offset=0
for row,part,count in zip(records,parts,counts):
 winds=allwinds[offset:offset+count];offset+=count;material=bool(np.median(winds)>.5);row.update(material=material,winding=winds.tolist())
 if material:selected.append(part)
Path('evidencias/'+name+'_loft_fino_clasificacion.json').write_text(json.dumps(records,indent=2));print('UNION',len(selected),sum(r['volumen'] for r in records if r['material']),time.monotonic()-start,flush=True)
from union_celdas_cad import unir
shape=unir(selected);print('UNIDO',shape.isValid(),len(shape.Solids()),len(shape.Faces()),shape.Volume(),flush=True)
from cavidades_cad import reconstruir
prepared=cargar_exacto(Path('/workspace/work/perfeccion_Visualizador_r5/evidencias/casos_finales')/(name+'.reparado.stl'))
cavities=reconstruir(prepared,log=lambda *a:print(*a,flush=True))
for void,boss,details in cavities:
 if boss is not None:shape=shape.fuse(boss)
 shape=shape.cut(void)
print('CAVIDADES',len(cavities),shape.isValid(),len(shape.Solids()),len(shape.Shells()),shape.Volume(),flush=True)
Path('evidencias/'+name+'_cavidades_fino.json').write_text(json.dumps([d for _,_,d in cavities],indent=2))
shape.exportBrep('work/'+name+'_loft_fino_material.brep');shape.exportStep('work/'+name+'_splitter_loft_fino.step')
try:q=_calidad(source,Path('work/'+name+'_splitter_loft_fino.step'),mesh,control_avanzado=True);print('QUALITY_OK',json.dumps(q),flush=True)
except Exception as e:print('QUALITY_FAIL',str(e),flush=True);traceback.print_exc()
