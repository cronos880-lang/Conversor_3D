from pathlib import Path
import sys,json,time,traceback
sys.path.insert(0,str(Path.cwd()))
import trimesh
from preprocesador_stl import cargar_exacto
from acondicionamiento_cad import acondicionar
out=[]
for name in ['6558_fixed','Pieza_Nueva_Detenida']:
 start=time.monotonic();row={'archivo':name}
 try:
  source=cargar_exacto(Path('/workspace/work/perfeccion_Visualizador_r5/evidencias/casos_finales')/(name+'.reparado.stl'));body=[p for p in source.split(only_watertight=False) if p.volume>0][0];m,proof=acondicionar(body,Path('work/'+name+'_acondicionado.off'));Path('work/'+name+'_acondicionado.stl').write_text(trimesh.exchange.stl.export_stl_ascii(m));row.update(ok=True,proof=proof,caras=len(m.faces));print('RESULT',name,len(proof['compactacion']['colapsos']),len(proof['volteos']),proof['caras_altitud_subresolucion'],proof['arista_min_mm'],proof['superficie'],flush=True)
 except Exception as exc:row.update(ok=False,error=str(exc));traceback.print_exc()
 row['segundos']=time.monotonic()-start;out.append(row);Path('evidencias/acondicionamiento_cad.json').write_text(json.dumps(out,indent=2))
