from pathlib import Path
import sys,json,time,traceback,collections
sys.path.insert(0,str(Path.cwd()))
import numpy as np,cadquery as cq,trimesh
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakePolygon,BRepBuilderAPI_MakeFace,BRepBuilderAPI_Sewing,BRepBuilderAPI_MakeSolid
from OCP.ShapeUpgrade import ShapeUpgrade_UnifySameDomain
from OCP.ShapeFix import ShapeFix_Shape
from OCP.TopoDS import TopoDS
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_SHELL
from OCP.gp import gp_Pnt
from preprocesador_stl import cargar_exacto
from saneamiento_cad import comprobar_interferencias
out=[]
for name in ['6558_fixed','Pieza_Nueva_Detenida']:
 source=cargar_exacto(Path('/workspace/work/perfeccion_Visualizador_r5/evidencias/casos_finales')/(name+'.reparado.stl'));body=[p for p in source.split(only_watertight=False) if p.volume>0][0]
 for grid in [1e-9,1e-8]:
  start=time.monotonic();row={'archivo':name,'grid_mm':grid,'altitud_minima_mm':1e-7}
  try:
   triangles=np.round(body.triangles/grid)*grid;cross=np.linalg.norm(np.cross(triangles[:,1]-triangles[:,0],triangles[:,2]-triangles[:,0]),axis=1);length=np.max(np.linalg.norm(triangles-np.roll(triangles,-1,axis=1),axis=2),axis=1);altitude=cross/np.maximum(length,1e-300);ids=np.where(altitude>1e-7)[0];row['omitidos_por_degeneracion']=np.where(altitude<=1e-7)[0].tolist();sew=BRepBuilderAPI_Sewing(1e-7)
   for fi in ids:
    polygon=BRepBuilderAPI_MakePolygon()
    for p in triangles[fi]:polygon.Add(gp_Pnt(*map(float,p)))
    polygon.Close()
    if not polygon.IsDone():raise ValueError('Contorno no representable fuera del filtro explícito')
    maker=BRepBuilderAPI_MakeFace(polygon.Wire())
    if not maker.IsDone():raise ValueError('Cara no representable fuera del filtro explícito')
    sew.Add(maker.Face())
   sew.Perform();fixed=sew.SewedShape();sf=ShapeFix_Shape(fixed);sf.SetPrecision(1e-7);sf.SetMaxTolerance(1e-6);sf.Perform();fixed=sf.Shape();exp=TopExp_Explorer(fixed,TopAbs_SHELL);solidmaker=BRepBuilderAPI_MakeSolid();shellcount=0
   while exp.More():solidmaker.Add(TopoDS.Shell_s(exp.Current()));shellcount+=1;exp.Next()
   shape=cq.Shape.cast(solidmaker.Solid());row.update(shells=shellcount,raw_valido=shape.isValid(),caras_raw=len(shape.Faces()),volumen_raw=shape.Volume());print('RAW',row,flush=True)
   unify=ShapeUpgrade_UnifySameDomain(shape.wrapped,True,True,False);unify.SetLinearTolerance(1e-7);unify.SetAngularTolerance(1e-5);unify.Build();shape=cq.Shape.cast(unify.Shape());row.update(valido=shape.isValid(),caras=len(shape.Faces()),volumen=shape.Volume());print('CLEAN',row,flush=True)
   shape.exportBrep('work/'+name+'_condicionado_cad_'+str(grid)+'.brep')
   if shape.isValid():row['interferencias']=comprobar_interferencias(shape)
   row['ok']=bool(row['valido'] and row.get('interferencias')==(True,0));print('CHECK',row,flush=True)
  except Exception as exc:row.update(ok=False,error=str(exc));traceback.print_exc()
  row['segundos']=time.monotonic()-start;out.append(row);Path('evidencias/brep_condicionado.json').write_text(json.dumps(out,indent=2));print('END',row,flush=True)
  if row.get('ok'):break
