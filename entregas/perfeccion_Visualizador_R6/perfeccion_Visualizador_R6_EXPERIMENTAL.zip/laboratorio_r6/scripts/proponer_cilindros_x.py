from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
import numpy as np
from preprocesador_stl import cargar_exacto
name=sys.argv[1] if len(sys.argv)>1 else '6558_fixed';m=cargar_exacto(Path('/workspace/work/casos_usuario_r5')/(name+'.stl'));V,F,C,N,A=m.vertices,m.faces,m.triangles_center,m.face_normals,m.area_faces;adj=m.face_adjacency;angles=m.face_adjacency_angles;tol=.018;allp=[];start=time.monotonic()
for axis in range(1):
 ij=[k for k in range(3) if k!=axis];eligible=np.where(abs(N[:,axis])<.03)[0];pairs=adj[(angles>np.radians(.5))&(angles<np.radians(45))&(abs(N[adj[:,0],axis])<.03)&(abs(N[adj[:,1],axis])<.03)];seeds={}
 def fit(points):
  mat=np.c_[2*points,np.ones(len(points))];cx,cy,b=np.linalg.lstsq(mat,(points*points).sum(1),rcond=None)[0];return np.array([cx,cy]),np.sqrt(max(0,b+cx*cx+cy*cy))
 for pair in pairs:
  pts=V[np.unique(F[pair])][:,ij]
  if len(np.unique(pts,axis=0))<3:continue
  center,r=fit(pts)
  if r<.1 or r>2*np.linalg.norm(m.extents):continue
  key=tuple(np.round(np.r_[center,r]/.025).astype(int));seeds.setdefault(key,(center,r))
 print('axis',axis,'seeds',len(seeds),flush=True)
 for center,r in seeds.values():
  current=None
  for iteration in range(3):
   radial=C[eligible][:,ij]-center;rr=np.linalg.norm(radial,axis=1);dot=np.abs((radial*N[eligible][:,ij]).sum(1))/np.maximum(rr,1e-15);rough=(abs(rr-r)<tol)&(dot>.95);ids=eligible[rough]
   if len(ids)<12:break
   pts=V[F[ids]][:,:,ij];dv=np.abs(np.linalg.norm(pts-center,axis=2)-r).max(1);ids=ids[dv<tol]
   if len(ids)<12:break
   center,r=fit(V[np.unique(F[ids])][:,ij]);current=ids
  if current is None or len(current)<12:continue
  samples=np.vstack([V[np.unique(F[current])],C[current]]);err=float(np.abs(np.linalg.norm(samples[:,ij]-center,axis=1)-r).max());height=float(np.ptp(samples[:,axis]));area=float(A[current].sum());phi=np.sort(np.arctan2(C[current][:,ij[1]]-center[1],C[current][:,ij[0]]-center[0])%(2*np.pi));arc=360*(1-np.diff(np.r_[phi,phi[0]+2*np.pi]).max()/(2*np.pi))
  if err>tol or height<.15 or arc<90 or area<.1:continue
  allp.append({'axis':axis,'center':center.tolist(),'radius':float(r),'area':area,'faces':current.tolist(),'height':height,'arc':arc,'max_original_mm':err})
Path('evidencias/cilindros_propuestas_x.json').write_text(json.dumps(allp,indent=2))
accepted=[]
for p in sorted(allp,key=lambda p:-p['area']):
 if any(p['axis']==q['axis'] and abs(p['radius']-q['radius'])<.025 and np.linalg.norm(np.array(p['center'])-q['center'])<.025 for q in accepted):continue
 accepted.append(p);print({k:v for k,v in p.items() if k!='faces'},flush=True)
 if len(accepted)>=48:break
Path('evidencias/'+name+'_cilindros_x.json').write_text(json.dumps(accepted,indent=2));print('TOTAL',len(accepted),'SEC',time.monotonic()-start,flush=True)
