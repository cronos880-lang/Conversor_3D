from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
import cadquery as cq,numpy as np
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeVertex
from OCP.gp import gp_Pnt
from preprocesador_stl import cargar_exacto
from verificacion_reparacion import distancia_malla
s=cq.importers.importStep('work/6558_fixed_splitter_finito.step').solids().val();m=cargar_exacto(Path('/workspace/work/casos_usuario_r5/6558_fixed.stl'));print('SHELLS',len(s.Shells()),[(len(x.Faces()),x.Area()) for x in s.Shells()],flush=True)
shell=cq.Compound.makeCompound(s.Shells());dist=BRepExtrema_DistShapeShape();dist.LoadS2(shell.wrapped);points=m.vertices[np.linspace(0,len(m.vertices)-1,800,dtype=int)];records=[]
for p in points:
 dist.LoadS1(BRepBuilderAPI_MakeVertex(gp_Pnt(*map(float,p))).Vertex());dist.Perform();q=dist.PointOnShape2(1);records.append({'xyz':p.tolist(),'dist':dist.Value(),'closest':[q.X(),q.Y(),q.Z()]})
print('SRC',sorted(records,key=lambda r:-r['dist'])[:12],flush=True)
v,f=s.copy().tessellate(.005);v=np.array([p.toTuple() for p in v]);d=distancia_malla(m,v);ids=np.argsort(-d)[:12];print('CAD',[(v[i].tolist(),float(d[i])) for i in ids],flush=True);print('P95ALL',np.percentile([r['dist'] for r in records],95),np.percentile(d,95),flush=True)
Path('evidencias/errores_finito.json').write_text(json.dumps({'source':records,'cad_peores':[{'xyz':v[i].tolist(),'dist':float(d[i])} for i in ids]},indent=2))
