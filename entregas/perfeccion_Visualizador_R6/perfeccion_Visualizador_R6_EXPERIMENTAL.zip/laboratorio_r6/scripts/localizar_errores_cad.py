import sys,json
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
import cadquery as cq,numpy as np
from preprocesador_stl import cargar_exacto
from validacion_local import _distancias_cad
from verificacion_reparacion import distancia_malla
name='6558_fixed';m=cargar_exacto(Path('/workspace/work/casos_usuario_r5')/(name+'.stl'));shape=cq.importers.importStep('work/6558_contactos_global_fino.step').val();pts=m.vertices[np.linspace(0,len(m.vertices)-1,1200,dtype=int)];d=_distancias_cad(shape,pts);v,f=shape.copy().tessellate(.01);p=np.array([x.toTuple() for x in v]);dd=distancia_malla(m,p);out={}
for key,points,dist in [('stl_cad',pts,d),('cad_stl',p,dd)]:
 ix=np.argsort(-dist)[:50];out[key]=[{'p':points[i].tolist(),'d':float(dist[i])} for i in ix];print(key,'p95',np.percentile(dist,95),'max',max(dist),flush=True);print(json.dumps(out[key][:20]),flush=True)
Path('evidencias/errores_global_fino.json').write_text(json.dumps(out,indent=2))
