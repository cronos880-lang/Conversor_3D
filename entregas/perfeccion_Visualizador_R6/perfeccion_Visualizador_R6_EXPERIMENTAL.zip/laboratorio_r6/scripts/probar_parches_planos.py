from pathlib import Path
import sys,json,time,traceback
sys.path.insert(0,str(Path.cwd()))
from preprocesador_stl import cargar_exacto
from brep_parches_planos import construir
from saneamiento_cad import comprobar_interferencias
out=[]
for name in ['6558_fixed','Pieza_Nueva_Detenida']:
 start=time.monotonic();row={'archivo':name}
 try:
  m=cargar_exacto(Path('work')/(name+'_acondicionado.stl'));s,proof=construir(m);row.update(proof=proof,volumen=s.Volume());s.exportBrep('work/'+name+'_parches_planos.brep');print('BREP',name,proof,flush=True)
  if s.isValid():row['interferencias']=comprobar_interferencias(s)
  row['ok']=bool(s.isValid() and row.get('interferencias')==(True,0));print('CHECK',name,row.get('interferencias'),flush=True)
 except Exception as e:row.update(ok=False,error=str(e));traceback.print_exc()
 row['segundos']=time.monotonic()-start;out.append(row);Path('evidencias/parches_planos.json').write_text(json.dumps(out,indent=2))
