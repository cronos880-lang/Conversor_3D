from pathlib import Path
import sys,json,traceback
sys.path.insert(0,str(Path.cwd()))
import numpy as np,cadquery as cq,trimesh,shapely
from shapely.geometry import Polygon
from shapely.ops import unary_union
from preprocesador_stl import cargar_exacto
from verificacion_reparacion import solido_poliedrico
from reparador_exacto_aislado import medidas_superficie
from saneamiento_cad import comprobar_interferencias
root=Path('/workspace/work/perfeccion_Visualizador_r5/evidencias/casos_finales');reports=[]
for name in ['6558_fixed','Pieza_Nueva_Detenida']:
 mesh=cargar_exacto(root/(name+'.reparado.stl'));pieces=[p for p in mesh.split(only_watertight=False) if p.volume<0]
 for i,part in enumerate(pieces):
  row={'archivo':name,'indice':i,'caras':len(part.faces)}
  try:
   center=part.vertices.mean(0);_,_,vt=np.linalg.svd(part.vertices-center,full_matrices=False);u,v=vt[:2];n=np.cross(u,v);coords=(part.vertices-center)@np.array([u,v,n]).T;thickness=float(np.ptp(coords[:,2]));row['espesor_pca_mm']=thickness
   if thickness<.00001:
    polys=[Polygon(x) for x in coords[part.faces,:2] if Polygon(x).area>1e-24];footprint=unary_union(shapely.set_precision(polys,1e-9)).simplify(.000001,preserve_topology=True);row['huella']=footprint.geom_type
    polygons=[footprint] if footprint.geom_type=='Polygon' else list(footprint.geoms);shapes=[];lo=float(coords[:,2].min());hi=float(coords[:,2].max());height=max(thickness,.00002);z=(lo+hi)/2-height/2
    for polygon in polygons:
     def wire(ring):return cq.Wire.makePolygon([cq.Vector(*(center+u*x+v*y+n*z)) for x,y in list(ring.coords)[:-1]],close=True)
     shapes.append(cq.Solid.extrudeLinear(wire(polygon.exterior),[wire(r) for r in polygon.interiors],cq.Vector(*(n*height))))
    if len(shapes)!=1:raise ValueError('La huella no forma una única cavidad')
    shape=shapes[0];row['metodo']='prisma_laminar'
   else:
    positive=part.copy();positive.invert();shape=solido_poliedrico(positive);row['metodo']='facetas_exactas'
   row.update(valido=shape.isValid(),interferencias=comprobar_interferencias(shape),volumen=shape.Volume(),caras_step=len(shape.Faces()))
   vertices,faces=shape.copy().tessellate(.0001);m=trimesh.Trimesh([p.toTuple() for p in vertices],faces,process=False);row['superficie']=medidas_superficie(part,m)
   if not row['valido'] or row['interferencias']!= (True,0) or row['superficie']['max_mm']>.002:raise ValueError('La cavidad no supera la validación')
   shape.exportBrep('work/'+name+f'_cavidad_{i}.brep');row['ok']=True
  except Exception as exc:row.update(ok=False,error=str(exc));traceback.print_exc()
  print(row,flush=True);reports.append(row);Path('evidencias/cavidades_cad_simplificadas.json').write_text(json.dumps(reports,indent=2))
