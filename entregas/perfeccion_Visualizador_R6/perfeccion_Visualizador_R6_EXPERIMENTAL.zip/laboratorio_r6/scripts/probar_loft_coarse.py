from pathlib import Path
import sys,json,time,traceback
sys.path.insert(0,str(Path.cwd()))
from preprocesador_stl import cargar_exacto
from dominio_loft import construir
from OCP.ShapeUpgrade import ShapeUpgrade_UnifySameDomain
import cadquery as cq
out=[]
for name in ['6558_fixed','Pieza_Nueva_Detenida']:
 start=time.monotonic();row={'archivo':name}
 try:
  m=cargar_exacto(Path('/workspace/work/casos_usuario_r5')/(name+'.stl'));shape,proof=construir(m,2,direcciones=48,margen=.004,error_perfil=.004);u=ShapeUpgrade_UnifySameDomain(shape.wrapped,True,True,False);u.SetLinearTolerance(1e-7);u.SetAngularTolerance(1e-9);u.Build();clean=cq.Shape.cast(u.Shape())
  if clean.isValid() and abs(clean.Volume()-shape.Volume())<1e-6:shape=clean
  shape.exportBrep('work/'+name+'_loft_coarse.brep');row.update(ok=True,proof=proof,caras_limpias=len(shape.Faces()));print('RESULT',name,len(proof['niveles']),len(shape.Faces()),proof['ampliacion_certificado_mm'],shape.Volume(),flush=True)
 except Exception as e:row.update(ok=False,error=str(e));traceback.print_exc()
 row['segundos']=time.monotonic()-start;out.append(row);Path('evidencias/loft_coarse.json').write_text(json.dumps(out,indent=2))
