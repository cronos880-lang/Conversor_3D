"""Construcción poliédrica con uniones 2D antes de crear caras CAD.

Evita pedir al kernel caras de triángulos numéricamente degenerados. La unión
no constituye aceptación: se deben verificar el STEP reimportado y la malla
original con los umbrales del programa.
"""
import numpy as np


def construir(mesh,*,tolerancia_plano=1e-9,tolerancia_contorno=1e-7):
    import cadquery as cq,shapely
    from shapely.geometry import Polygon
    from OCP.BRepBuilderAPI import BRepBuilderAPI_Sewing,BRepBuilderAPI_MakeSolid
    from OCP.TopExp import TopExp_Explorer
    from OCP.TopAbs import TopAbs_SHELL
    from OCP.TopoDS import TopoDS
    V,F=mesh.vertices,mesh.faces;T=V[F]
    cross=np.cross(T[:,1]-T[:,0],T[:,2]-T[:,0]);area=np.linalg.norm(cross,axis=1)
    if np.any(area==0):raise ValueError('Hay triángulos colapsados')
    normals=cross/area[:,None];neighbors=[[] for _ in F]
    for a,b in mesh.face_adjacency:neighbors[a].append(int(b));neighbors[b].append(int(a))
    used=np.zeros(len(F),bool);groups=[]
    for seed in np.argsort(-area):
        if used[seed]:continue
        n=normals[seed];origin=T[seed,0];ids=[];queue=[int(seed)];seen={int(seed)}
        while queue:
            i=queue.pop()
            if used[i]:continue
            if normals[i]@n<=0:continue
            if max(abs((T[i]-origin)@n))>tolerancia_plano:continue
            used[i]=True;ids.append(i)
            for j in neighbors[i]:
                if not used[j] and j not in seen:seen.add(j);queue.append(j)
        groups.append((ids,n,origin))
    sew=BRepBuilderAPI_Sewing(2e-5);polygons_count=0;triangulated=0;collapsed=[];faces=[]
    for ids,n,origin in groups:
        edges=T[ids[0]]-np.roll(T[ids[0]],-1,axis=0);u=edges[np.argmax(np.linalg.norm(edges,axis=1))];u=u-n*(u@n);u/=np.linalg.norm(u);v=np.cross(n,u);basis=np.array([u,v]);triangles=(T[ids]-origin)@basis.T
        polys=[Polygon(t) for t in triangles if Polygon(t).area>0]
        region=shapely.union_all(shapely.set_precision(polys,1e-7))
        region=region.buffer(tolerancia_contorno,join_style=2,mitre_limit=2).buffer(
            -tolerancia_contorno,join_style=2,mitre_limit=2)
        region=region.simplify(2*tolerancia_contorno,preserve_topology=True)
        polygons=[region] if region.geom_type=='Polygon' else list(region.geoms)
        if not polygons:collapsed.append(ids);continue
        for poly in polygons:
            if poly.geom_type!='Polygon' or poly.is_empty:continue
            poly=shapely.orient_polygons(poly,exterior_cw=False)
            def make(polygon):
                def wire(ring):
                    points=[cq.Vector(*(origin+u*x+v*y)) for x,y in list(ring.coords)[:-1]]
                    kept=[]
                    for point in points:
                        if not kept or (point-kept[-1]).Length>1.5*tolerancia_contorno:kept.append(point)
                    if len(kept)>1 and (kept[0]-kept[-1]).Length<=1.5*tolerancia_contorno:kept.pop()
                    return cq.Wire.makePolygon(kept,close=True) if len(kept)>=3 else None
                outer=wire(polygon.exterior)
                if outer is None:return None
                holes=[w for r in polygon.interiors if (w:=wire(r)) is not None]
                return cq.Face.makeFromWires(outer,holes)
            face=make(poly)
            if face is None:collapsed.append(ids);continue
            if face.isValid():sew.Add(face.wrapped);faces.append(face);polygons_count+=1;continue
            for tri in shapely.constrained_delaunay_triangles(poly).geoms:
                face=make(tri)
                if not face.isValid():
                    face=face.fix()
                    if not face.isValid():
                        xy=np.asarray(tri.exterior.coords)[:3];area2=2*tri.area;longest=np.linalg.norm(xy-np.roll(xy,-1,axis=0),axis=1).max()
                        if area2/max(longest,1e-300)<2e-5:
                            collapsed.append(ids);continue
                        raise ValueError('Un parche planar no se puede construir sin deformarlo')
                sew.Add(face.wrapped);faces.append(face);triangulated+=1
    sew.Perform();result=sew.SewedShape();exp=TopExp_Explorer(result,TopAbs_SHELL);maker=BRepBuilderAPI_MakeSolid();shells=0
    while exp.More():maker.Add(TopoDS.Shell_s(exp.Current()));shells+=1;exp.Next()
    from OCP.ShapeFix import ShapeFix_Shape
    fixer=ShapeFix_Shape(maker.Solid());fixer.SetPrecision(2e-5);fixer.SetMaxTolerance(4e-5);fixer.Perform()
    shape=cq.Shape.cast(fixer.Shape())
    return shape,{'grupos':len(groups),'caras_poligonales':polygons_count,'triangulos_residuales':triangulated,
        'grupos_colapsados':collapsed,'shells':shells,'valido':shape.isValid(),'caras_cad':len(shape.Faces()),
        'tolerancia_plano_mm':tolerancia_plano,'tolerancia_contorno_mm':tolerancia_contorno}
