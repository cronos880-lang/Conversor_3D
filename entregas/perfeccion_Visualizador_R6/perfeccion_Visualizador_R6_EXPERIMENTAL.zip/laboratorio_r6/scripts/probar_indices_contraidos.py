from pathlib import Path
import sys,json,time,traceback,hashlib
sys.path.insert(0,str(Path.cwd()))
import numpy as np,cadquery as cq
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeFace,BRepBuilderAPI_MakeSolid
from OCP.BRep import BRep_Builder
from OCP.TopoDS import TopoDS,TopoDS_Shell,TopoDS_Vertex,TopoDS_Edge,TopoDS_Wire
from OCP.gp import gp_Pnt,gp_Dir,gp_Pln
from OCP.Geom import Geom_Line
from OCP.TopAbs import TopAbs_FORWARD,TopAbs_REVERSED
from OCP.ShapeUpgrade import ShapeUpgrade_UnifySameDomain
from preprocesador_stl import cargar_exacto
from saneamiento_cad import comprobar_interferencias
out=[]
for name in ['6558_fixed','Pieza_Nueva_Detenida']:
 start=time.monotonic();path=Path('work')/(name+'_contraido_cad.stl');m=cargar_exacto(path);row={'archivo':name,'stl_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
 try:
  tris=m.triangles;cross=np.cross(tris[:,1]-tris[:,0],tris[:,2]-tris[:,0]);areas=np.linalg.norm(cross,axis=1);normals=cross/areas[:,None];length=np.linalg.norm(tris-np.roll(tris,-1,axis=1),axis=2).max(1);alt=areas/length;neighbors=[[] for _ in m.faces]
  for a,b in m.face_adjacency:neighbors[a].append(int(b));neighbors[b].append(int(a))
  stable=normals.copy();borrowed=0
  for fi in np.where(alt<1e-6)[0]:
   near=set(neighbors[fi]);near.update(j for i in list(near) for j in neighbors[i])
   for j in sorted(near,key=lambda j:-areas[j]):
    normal=normals[j]
    if max(abs((tris[fi]-tris[fi,0])@normal))>1e-10:continue
    stable[fi]=normal if normal@normals[fi]>0 else -normal;borrowed+=1;break
  builder=BRep_Builder();vertices=[];tol=1e-10
  for p in m.vertices:
   v=TopoDS_Vertex();builder.MakeVertex(v,gp_Pnt(*map(float,p)),tol);vertices.append(v)
  edges={};shell=TopoDS_Shell();builder.MakeShell(shell)
  for fi,face in enumerate(m.faces):
   wire=TopoDS_Wire();builder.MakeWire(wire)
   for a,b in zip(face,np.roll(face,-1)):
    key=tuple(sorted((int(a),int(b))))
    if key not in edges:
     p0,p1=m.vertices[list(key)];distance=float(np.linalg.norm(p1-p0));edge=TopoDS_Edge();curve=Geom_Line(gp_Pnt(*map(float,p0)),gp_Dir(*map(float,p1-p0)));builder.MakeEdge(edge,curve,tol);builder.Range(edge,0.,distance);va=TopoDS.Vertex_s(vertices[key[0]].Oriented(TopAbs_FORWARD));vb=TopoDS.Vertex_s(vertices[key[1]].Oriented(TopAbs_REVERSED));builder.Add(edge,va);builder.Add(edge,vb);builder.UpdateVertex(va,0.,edge,tol);builder.UpdateVertex(vb,distance,edge,tol);builder.SameParameter(edge,True);builder.SameRange(edge,True);edges[key]=edge
    builder.Add(wire,edges[key] if a<b else TopoDS.Edge_s(edges[key].Reversed()))
   wire.Closed(True);plane=gp_Pln(gp_Pnt(*map(float,m.vertices[face[0]])),gp_Dir(*map(float,stable[fi])));builder.Add(shell,BRepBuilderAPI_MakeFace(plane,wire,True).Face())
  shell.Closed(True);shape=cq.Shape.cast(BRepBuilderAPI_MakeSolid(shell).Solid());row.update(raw_valido=shape.isValid(),raw_caras=len(shape.Faces()),planos_estabilizados=borrowed,volumen=shape.Volume());shape.exportBrep('work/'+name+'_contraido_indices_raw.brep');print('RAW',row,flush=True)
  unify=ShapeUpgrade_UnifySameDomain(shape.wrapped,True,True,False);unify.SetLinearTolerance(1e-9);unify.SetAngularTolerance(1e-8);unify.Build();shape=cq.Shape.cast(unify.Shape());row.update(valido=shape.isValid(),caras=len(shape.Faces()),volumen_unificado=shape.Volume());shape.exportBrep('work/'+name+'_contraido_indices_cad.brep');print('CLEAN',row,flush=True)
  if row['valido']:row['interferencias']=comprobar_interferencias(shape)
  row['ok']=bool(row['valido'] and row.get('interferencias')==(True,0));print('CHECK',row,flush=True)
 except Exception as exc:row.update(ok=False,error=str(exc));traceback.print_exc()
 row['segundos']=time.monotonic()-start;out.append(row);Path('evidencias/indices_contraidos.json').write_text(json.dumps(out,indent=2))
