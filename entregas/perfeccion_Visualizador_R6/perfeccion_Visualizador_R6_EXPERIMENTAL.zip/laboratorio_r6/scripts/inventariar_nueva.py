from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
import numpy as np
from preprocesador_stl import cargar_exacto
from axial_recognition import candidates
name='Pieza_Nueva_Detenida';m=cargar_exacto(Path('/workspace/work/casos_usuario_r5')/(name+'.stl'));start=time.monotonic();props=candidates(m,min_faces=12,tol=.012,max_trials=4000);out=[]
for p in props:
 row={k:(v.tolist() if isinstance(v,np.ndarray) else v) for k,v in p.items()};out.append(row)
print('CANDIDATES',len(out),'SECONDS',time.monotonic()-start,flush=True)
for x in out:print({k:v for k,v in x.items() if k!='faces'},flush=True)
Path('evidencias/nueva_cilindros_candidatos.json').write_text(json.dumps(out,indent=2))
