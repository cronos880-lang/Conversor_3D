from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
from preprocesador_stl import cargar_exacto
from reconstruccion_celdas import detectar_planos,envolvente_capas
for name in ['6558_fixed','Pieza_Nueva_Detenida']:
 m=cargar_exacto(Path('/workspace/work/casos_usuario_r5')/(name+'.stl'));c=json.loads(Path('evidencias/'+name+'_cilindros_r6.json').read_text());start=time.monotonic();p=detectar_planos(m,c);Path('evidencias/'+name+'_planos_r6.json').write_text(json.dumps(p,indent=2));print(name,'planos',len(p),'s',time.monotonic()-start,'volume_src',m.volume,flush=True)
 if name=='Pieza_Nueva_Detenida':
  envelope,proof=envolvente_capas(m,2);envelope.exportBrep('work/'+name+'_dominio.brep');Path('evidencias/'+name+'_dominio.json').write_text(json.dumps(proof,indent=2));print('ENV',envelope.Volume(),time.monotonic()-start,flush=True)
