from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
import numpy as np
from preprocesador_stl import cargar_exacto
m=cargar_exacto(Path('/workspace/work/casos_usuario_r5/6558_fixed.stl'));V,F,N,A,C=m.vertices,m.faces,m.face_normals,m.area_faces,m.triangles_center
used=np.zeros(len(F),dtype=bool)
for p in json.loads(Path('evidencias/6558_fixed_cilindros_locales.json').read_text()):used[p['faces']]=True
planes=[];start=time.monotonic()
for fi in np.argsort(-A):
 if used[fi] or A[fi]<1e-7:continue
 n=N[fi].copy();j=np.argmax(abs(n))
 if n[j]<0:n=-n
 offset=float(n@C[fi]);rough=np.where((~used)&(abs(N@n)>.9999))[0]
 dist=np.max(abs(V[F[rough]]@n-offset),axis=1);ids=rough[dist<.00005]
 if len(ids)==0:used[fi]=True;continue
 used[ids]=True;area=float(A[ids].sum())
 if area<.02:continue
 pts=V[np.unique(F[ids])];mean=np.average(C[ids],axis=0,weights=A[ids]);_,_,vt=np.linalg.svd(pts-mean,full_matrices=False);n=vt[-1];j=np.argmax(abs(n))
 if n[j]<0:n=-n
 offset=float(n@mean);error=float(abs(pts@n-offset).max());span=np.ptp(pts,axis=0)
 planes.append({'normal':n.tolist(),'offset':offset,'area':area,'error':error,'faces':ids.tolist(),'span':span.tolist()})
print('TOTAL',len(planes),'SEC',time.monotonic()-start,'AREA',sum(p['area'] for p in planes),flush=True)
for p in sorted(planes,key=lambda p:-p['area']):print({k:v for k,v in p.items() if k!='faces'},flush=True)
Path('evidencias/planos_completos.json').write_text(json.dumps(planes,indent=2))
