from pathlib import Path
import sys,json
sys.path.insert(0,str(Path.cwd()))
import numpy as np
from preprocesador_stl import cargar_exacto
m=cargar_exacto(Path('/workspace/work/casos_usuario_r5/6558_fixed.stl'))
section=m.section(plane_origin=[2.,0.,0.],plane_normal=[1.,0.,0.]);lines=section.discrete
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,ax=plt.subplots(figsize=(12,5))
for l in lines:ax.plot(l[:,2],l[:,1],'-',lw=1)
ax.set(xlim=(-.2,4.5),ylim=(-2.7,2.7),xlabel='Z (mm)',ylabel='Y (mm)',title='6558: sección del STL original en X=2 mm');ax.set_aspect('equal');ax.grid(True);fig.savefig('evidencias/capsulas_x.png',dpi=140)
ids=np.where((abs(m.face_normals[:,0])<.01)&(m.triangles_center[:,2]<4)&(abs(m.triangles_center[:,0])>1.6)&(abs(m.triangles_center[:,1])<.5))[0];pts=m.vertices[np.unique(m.faces[ids])];print('CARAS',len(ids),'DATOS YZ',np.unique(np.round(pts[:,[1,2]],5),axis=0).tolist(),flush=True)
