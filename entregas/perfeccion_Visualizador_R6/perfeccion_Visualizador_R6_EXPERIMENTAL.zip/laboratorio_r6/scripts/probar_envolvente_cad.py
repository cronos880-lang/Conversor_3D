from pathlib import Path
import sys,json,time,traceback
sys.path.insert(0,str(Path.cwd()))
import numpy as np,trimesh,manifold3d as mf
from preprocesador_stl import cargar_exacto
from reparador_exacto_aislado import ControlExacto,medidas_superficie,desenredar
from reparacion_contactos_locales import descomponer_contactos
from verificacion_reparacion import solido_poliedrico
from saneamiento_cad import comprobar_interferencias
root=Path('/workspace/work/perfeccion_Visualizador_r5/evidencias/casos_finales');out=[]
def manifold(m):return mf.Manifold(mf.Mesh64(np.array(m.vertices,dtype=np.float64,order='C',copy=True),np.array(m.faces,dtype=np.uint64,order='C',copy=True)))
for name in ['6558_fixed','Pieza_Nueva_Detenida']:
 full=cargar_exacto(root/(name+'.reparado.stl'));source=[p for p in full.split(only_watertight=False) if p.volume>0][0];proof=json.loads((root/(name+'.reparado.reparacion.json')).read_text());ops=proof['regularizacion_material']['operaciones']
 for eps in [0.,.0003]:
  start=time.monotonic();row={'archivo':name,'contacto_eps':eps}
  try:
   result=manifold(source)
   if eps:
    for kind,op in [('micro_union_material',mf.OpType.Add),('micro_apertura_vacio',mf.OpType.Subtract)]:
     pts=[x['xyz_mm'] for x in ops if x['tipo']==kind]
     if pts:result=mf.Manifold.batch_boolean([result,mf.Manifold.batch_boolean([mf.Manifold.cube([2*eps]*3,True).translate(p) for p in pts],mf.OpType.Add)],op)
   result=result.set_tolerance(.000002).simplify(.000002);d=result.to_mesh64();m=trimesh.Trimesh(d.vert_properties[:,:3],d.tri_verts,process=False);v,ix=np.unique(m.vertices,axis=0,return_inverse=True);m=trimesh.Trimesh(v,ix[m.faces],process=False);m,dc=descomponer_contactos(m);m,separacion=desenredar(m,Path('work/envolvente.off'),time.monotonic()+120,solo_contactos=False);row['separacion']=separacion
   row['superficie']=medidas_superficie(source,m);row['SI']=len(ControlExacto(m,Path('work/envolvente.off')).pares());row['caras']=len(m.faces)
   if row['superficie']['max_mm']>.002:raise ValueError('La envolvente cambia más de 0.002 mm')
   Path('work/'+name+'_envolvente.stl').write_text(trimesh.exchange.stl.export_stl_ascii(m));solid=solido_poliedrico(m);row.update(valido=solid.isValid(),caras_step=len(solid.Faces()),interferencias=comprobar_interferencias(solid));solid.exportBrep('work/'+name+'_envolvente.brep');row['ok']=True
  except Exception as e:row.update(ok=False,error=str(e));traceback.print_exc()
  row['segundos']=time.monotonic()-start;out.append(row);Path('evidencias/envolvente_cad.json').write_text(json.dumps(out,indent=2));print(row,flush=True)
  if row.get('ok'):break
