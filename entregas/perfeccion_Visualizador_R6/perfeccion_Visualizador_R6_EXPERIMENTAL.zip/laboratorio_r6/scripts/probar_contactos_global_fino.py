from pathlib import Path
import sys,json,traceback,time
sys.path.insert(0,str(Path.cwd()))
import cadquery as cq,numpy as np,igl
from OCP.TopTools import TopTools_IndexedDataMapOfShapeListOfShape
from OCP.TopExp import TopExp
from OCP.TopAbs import TopAbs_EDGE,TopAbs_FACE
from preprocesador_stl import cargar_exacto
from motor_v2 import _calidad
from saneamiento_cad import comprobar_interferencias
name='6558_fixed';source=Path('/workspace/work/casos_usuario_r5')/(name+'.stl');mesh=cargar_exacto(source);shape=cq.importers.importBrep('work/'+name+'_global_fino_material.brep').val();mapping=TopTools_IndexedDataMapOfShapeListOfShape();TopExp.MapShapesAndAncestors_s(shape.wrapped,TopAbs_EDGE,TopAbs_FACE,mapping);joins=[];cuts=[];records=[]
for i in range(1,mapping.Extent()+1):
 fs=[]
 for f in mapping.FindFromIndex(i):
  if not any(f.IsSame(old) for old in fs):fs.append(f)
 if len(fs)<=2:continue
 edge=cq.Edge(mapping.FindKey(i));print('EDGE',len(fs),edge.geomType(),edge.Length(),flush=True)
 if edge.geomType()!='LINE':raise ValueError('Contacto no recto')
 a=np.array(edge.startPoint().toTuple());b=np.array(edge.endPoint().toTuple());direction=(b-a)/np.linalg.norm(b-a);points=a+np.array([.25,.5,.75])[:,None]*(b-a);winds=igl.winding_number(mesh.vertices,mesh.faces,points);print('WINDS',winds,flush=True)
 if min(winds)>.5:kind='union'
 elif max(winds)<.5:kind='vacio'
 else:raise ValueError('Campo de material ambiguo en el contacto')
 radius=.00005;tube=cq.Solid.makeCylinder(radius,np.linalg.norm(b-a)+2*radius,cq.Vector(*(a-radius*direction)),cq.Vector(*direction));(joins if kind=='union' else cuts).append(tube);records.append({'tipo':kind,'a':a.tolist(),'b':b.tolist(),'winding':winds.tolist(),'radio_mm':radius})
print('LOCAL',len(joins),len(cuts),flush=True)
if joins:shape=shape.fuse(*joins)
if cuts:shape=shape.cut(*cuts)
print('FINAL',shape.isValid(),len(shape.Solids()),len(shape.Shells()),shape.Volume(),len(shape.Faces()),flush=True)
Path('evidencias/contactos_global_fino.json').write_text(json.dumps(records,indent=2));shape.exportBrep('work/6558_contactos_global_fino.brep');target=Path('work/6558_contactos_global_fino.step');shape.exportStep(str(target))
try:
 q=_calidad(source,target,mesh,control_avanzado=True);Path('evidencias/6558_contactos_global_fino_calidad.json').write_text(json.dumps(q,indent=2));print('QUALITY_OK',json.dumps(q),flush=True)
except Exception as exc:print('QUALITY_FAIL',str(exc),flush=True);traceback.print_exc()
