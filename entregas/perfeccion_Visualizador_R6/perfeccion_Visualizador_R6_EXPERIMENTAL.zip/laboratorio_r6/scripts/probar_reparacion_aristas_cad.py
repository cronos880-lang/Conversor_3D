from pathlib import Path
import sys,json,time,traceback
sys.path.insert(0,str(Path.cwd()))
import cadquery as cq,numpy as np,igl
from OCP.TopTools import TopTools_IndexedDataMapOfShapeListOfShape,TopTools_ListOfShape
from OCP.TopExp import TopExp
from OCP.TopAbs import TopAbs_EDGE,TopAbs_FACE
from OCP.BRepAlgoAPI import BRepAlgoAPI_Fuse
from OCP.BOPAlgo import BOPAlgo_GlueShift
from preprocesador_stl import cargar_exacto
from saneamiento_cad import comprobar_interferencias
raw=cq.importers.importBrep('work/6558_raw_lote.brep').val();m=cargar_exacto(Path('/workspace/work/casos_usuario_r5/6558_fixed.stl'));map=TopTools_IndexedDataMapOfShapeListOfShape();TopExp.MapShapesAndAncestors_s(raw.wrapped,TopAbs_EDGE,TopAbs_FACE,map);edges=[cq.Edge(map.FindKey(i)) for i in range(1,map.Extent()+1) if len(list(map.FindFromIndex(i)))>2]
for edge in edges:print('EDGE',edge.geomType(),edge.Length(),edge.startPoint().toTuple(),edge.endPoint().toTuple(),flush=True)
parts=cq.importers.importBrep('work/6558_fixed_splitter_extendido_partes.brep').val().Solids();records=json.loads(Path('evidencias/splitter_lote_clasificacion.json').read_text());selected=[p for p,r in zip(parts,records) if r['material']];out=[]
for radius in [.00005,.0005]:
 start=time.monotonic();row={'radio':radius}
 try:
  tubes=[]
  for edge in edges:
   if edge.geomType()!='LINE':raise ValueError('Este ensayo requiere aristas rectas')
   a=np.array(edge.startPoint().toTuple());b=np.array(edge.endPoint().toTuple());direction=(b-a)/np.linalg.norm(b-a);center=(a+b)/2;w=float(igl.winding_number(m.vertices,m.faces,center));print('FIELD',center.tolist(),w,flush=True)
   if w<.5:print('CONTACTO DE VACÍO: ensayo unión no autorizado por campo',flush=True)
   tube=cq.Solid.makeCylinder(radius,np.linalg.norm(b-a)+2*radius,cq.Vector(*(a-radius*direction)),cq.Vector(*direction));tubes.append(tube)
  args=TopTools_ListOfShape();tools=TopTools_ListOfShape();args.Append(selected[0].wrapped)
  for p in selected[1:]+tubes:tools.Append(p.wrapped)
  op=BRepAlgoAPI_Fuse();op.SetArguments(args);op.SetTools(tools);op.SetRunParallel(False);op.SetNonDestructive(True);op.SetGlue(BOPAlgo_GlueShift);op.SetFuzzyValue(0.);op.Build()
  if not op.IsDone():raise ValueError('La unión local no se ha completado')
  shape=cq.Shape.cast(op.Shape());row.update(valido=shape.isValid(),solidos=len(shape.Solids()),caras=len(shape.Faces()),volumen=shape.Volume());print('FUSE',row,flush=True)
  if row['valido'] and row['solidos']==1:
   row['interferencias']=comprobar_interferencias(shape);shape.exportBrep('work/6558_union_tubos.brep')
 except Exception as exc:row['error']=str(exc);traceback.print_exc()
 row['segundos']=time.monotonic()-start;out.append(row);Path('evidencias/reparacion_aristas_cad.json').write_text(json.dumps(out,indent=2));print(row,flush=True)
