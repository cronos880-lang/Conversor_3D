from pathlib import Path
import sys,json,traceback,time
sys.path.insert(0,str(Path.cwd()))
import cadquery as cq,numpy as np
from preprocesador_stl import cargar_exacto
from motor_v2 import _calidad
from brep_parches_r6b import construir
from cavidades_cad import reconstruir
from saneamiento_cad import comprobar_interferencias
name=sys.argv[1] if len(sys.argv)>1 else '6558_fixed';source=Path('/workspace/work/casos_usuario_r5')/(name+'.stl');mesh=cargar_exacto(source);prepared=cargar_exacto(Path('/workspace/work/perfeccion_Visualizador_r5/evidencias/casos_finales')/(name+'.reparado.stl'));parts=prepared.split(only_watertight=False);positive=[p for p in parts if p.volume>0]
if len(positive)!=1:raise ValueError('Cuerpos no esperados')
body=positive[0];out=[]
for tol,contour in [(1e-5,1e-6),(2e-5,2e-6)]:
 start=time.monotonic();row={'tol':tol,'contorno':contour}
 try:
  shape,proof=construir(body,tolerancia_plano=tol,tolerancia_contorno=contour);row['construccion']=proof;print('BODY',proof,flush=True);shape.exportBrep('work/'+name+'_parches_r6b.brep')
  if not shape.isValid():raise ValueError('Cuerpo de parches no válido')
  for void,boss,detail in reconstruir(prepared,log=lambda *a:print(*a,flush=True)):
   if boss is not None:shape=shape.fuse(boss)
   shape=shape.cut(void)
  print('FINAL',shape.isValid(),len(shape.Solids()),len(shape.Shells()),flush=True);target=Path('work/'+name+'_parches_r6b.step');shape.exportStep(str(target));q=_calidad(source,target,mesh,control_avanzado=True);row.update(ok=True,calidad=q);print('QUALITY_OK',flush=True)
 except Exception as exc:row.update(ok=False,error=str(exc));print('FAIL',str(exc),flush=True);traceback.print_exc()
 row['segundos']=time.monotonic()-start;out.append(row);Path('evidencias/'+name+'_parches_r6b.json').write_text(json.dumps(out,indent=2))
 if row['ok']:break
