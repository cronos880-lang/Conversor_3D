from pathlib import Path
import sys,json,time,traceback
sys.path.insert(0,str(Path.cwd()))
from preprocesador_stl import cargar_exacto
from dominio_loft import construir
out=[]
for name in ['6558_fixed','Pieza_Nueva_Detenida']:
 start=time.monotonic();row={'archivo':name}
 try:
  m=cargar_exacto(Path('/workspace/work/casos_usuario_r5')/(name+'.stl'));shape,proof=construir(m,2);shape.exportBrep('work/'+name+'_loft_dominio.brep');row.update(ok=True,proof=proof);print(name,proof,flush=True)
 except Exception as exc:row.update(ok=False,error=str(exc));traceback.print_exc()
 row['segundos']=time.monotonic()-start;out.append(row);Path('evidencias/dominio_loft.json').write_text(json.dumps(out,indent=2))
