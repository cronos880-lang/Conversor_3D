from pathlib import Path
import sys,json,collections
sys.path.insert(0,str(Path.cwd()))
import cadquery as cq
from OCP.BRepAlgoAPI import BRepAlgoAPI_Check
shape=cq.importers.importBrep('work/6558_fixed_resolucion_indices_cad.brep').val();check=BRepAlgoAPI_Check(shape.wrapped,False,True);records=[]
for item in check.Result():
 row={'tipo':str(item.GetCheckStatus())}
 for key,getter in [('forma1',item.GetShape1),('forma2',item.GetShape2)]:
  try:
   part=cq.Shape.cast(getter());bb=part.BoundingBox();row[key]={'tipo':str(part.ShapeType()),'caja':[[bb.xmin,bb.ymin,bb.zmin],[bb.xmax,bb.ymax,bb.zmax]]}
  except Exception as e:row[key]=str(e)
 records.append(row)
r={'valido_brep':shape.isValid(),'interferencias':len(records),'tipos':dict(collections.Counter(x['tipo'] for x in records)),'ejemplos':records[:20],'step_aprobado':False};Path('evidencias/diagnostico_interferencias_resolucion.json').write_text(json.dumps(r,indent=2));print({k:v for k,v in r.items() if k!='ejemplos'})
