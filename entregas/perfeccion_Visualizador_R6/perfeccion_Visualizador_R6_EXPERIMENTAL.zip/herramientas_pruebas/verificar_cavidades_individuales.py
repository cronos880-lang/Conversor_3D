from pathlib import Path
import sys,json
sys.path.insert(0,str(Path.cwd()))
from preprocesador_stl import cargar_exacto
from cavidades_cad import reconstruir
from saneamiento_cad import comprobar_interferencias
out=[]
for name in ['6558_fixed','Pieza_Nueva_Detenida']:
 m=cargar_exacto(Path('/workspace/work/perfeccion_Visualizador_r5/evidencias/casos_finales')/(name+'.reparado.stl'));items=reconstruir(m)
 for void,boss,proof in items:
  assert void.isValid() and comprobar_interferencias(void)==(True,0)
  out.append({'archivo':name,**proof,'valido':True,'interferencias':0,'ensamblaje_completo_validado':False})
assert len(out)==5
Path('evidencias/cavidades_individuales_final.json').write_text(json.dumps(out,indent=2));print('Cinco cavidades individuales válidas, cero interferencias. Ensamblaje completo sin aprobar.')
