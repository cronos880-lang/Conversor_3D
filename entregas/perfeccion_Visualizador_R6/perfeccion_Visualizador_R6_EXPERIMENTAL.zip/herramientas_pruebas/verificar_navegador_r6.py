from pathlib import Path
import sys,json,hashlib
sys.path.insert(0,str(Path.cwd()))
import cadquery as cq
from saneamiento_cad import comprobar_interferencias
p=Path('evidencias/navegador_30383_r6.step');shape=cq.importers.importStep(str(p)).val();old=Path('/workspace/work/perfeccion_Visualizador_r5/evidencias/navegador_30383_r5.step');data=lambda p:p.read_bytes().split(b'DATA;',1)[1];valid,count=comprobar_interferencias(shape);assert len(shape.Solids())==1 and shape.isValid() and valid and count==0 and data(p)==data(old)
r={'ok':True,'solidos':1,'brep_valido':True,'interferencias':0,'caras':len(shape.Faces()),'data_step_identico_R5':True,'sha256_data':hashlib.sha256(data(p)).hexdigest(),'referencia_independiente':'Mismo DATA que R5/R4, previamente comprobado. No se reejecuta Onshape.'};Path('evidencias/navegador_step_reimportado.json').write_text(json.dumps(r,indent=2));print(r)
