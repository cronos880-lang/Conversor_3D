from pathlib import Path
import sys,json,hashlib
sys.path.insert(0,str(Path.cwd()))
from reparador_exacto_aislado import ControlExacto,cargar
from topologia_vertices import inspeccionar_vertices
n=json.loads(Path('evidencias/navegador_r5_reparacion.json').read_text());r=json.loads((Path('Registros_Conversion')/(n['id']+'.json')).read_text());p=Path('evidencias/navegador_6558_reparado.stl');proof=r['preprocesamiento']['verificacion_independiente'];mesh=cargar(p);pairs=ControlExacto(mesh,Path('work/navegador_control.off')).pares();topology=inspeccionar_vertices(mesh)
result={'ok':not pairs and topology['vertices_no_manifold']==0 and hashlib.sha256(p.read_bytes()).hexdigest()==proof['reparado_sha256'],'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'autointersecciones_exactas':len(pairs),'topologia_vertices':topology,'job_id':n['id'],'version_programa':r['version_programa'],'sin_STEP':n['error_sin_STEP']}
assert result['ok'] and result['sin_STEP'];Path('evidencias/verificacion_stl_navegador.json').write_text(json.dumps(result,indent=2));Path('work/navegador_control.off').unlink();print(json.dumps(result))
