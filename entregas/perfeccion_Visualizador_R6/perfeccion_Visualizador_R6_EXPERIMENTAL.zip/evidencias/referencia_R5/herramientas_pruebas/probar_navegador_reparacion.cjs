const {chromium}=require('playwright'),fs=require('fs');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 const page=await browser.newPage({viewport:{width:1440,height:900},acceptDownloads:true});const errors=[];let id;
 page.on('pageerror',e=>errors.push(String(e)));
 try{
 await page.goto('http://127.0.0.1:8769');await page.waitForFunction(()=>!document.getElementById('openBtn').disabled);
 if(!await page.title().then(t=>t.includes('R5')))throw Error('Encabezado incorrecto');
 await page.locator('#fileInput').setInputFiles('/workspace/work/casos_usuario_r5/6558_fixed.stl');await page.waitForFunction(()=>!document.getElementById('convertBtn').disabled);
 page.on('response',async r=>{if(r.url().endsWith('/iniciar-conversion'))try{id=(await r.json()).id}catch{}});
 await page.locator('#convertBtn').click();await page.waitForFunction(()=>document.getElementById('conversionPercent').textContent==='100 %'||document.getElementById('conversionPercent').classList.contains('failed'),{},{timeout:1200000});
 const state=await(await page.request.get('http://127.0.0.1:8769/estado-conversion/'+id)).json();
 const diagnostic=await(await page.request.get('http://127.0.0.1:8769/reparacion/'+id+'/informe')).json();
 if(!diagnostic.reparado)throw Error('No se ha verificado la reparación');
 const url=state.archivos_reparacion.reparado;if(!url)throw Error('Falta STL reparado');
 if(state.estado==='error'){
  if(!await page.locator('#exportBtn').isDisabled())throw Error('Ofrece STEP pese al fallo');
  const link=page.getByRole('link',{name:'Descargar malla regularizada (STL)'});if(!await link.isVisible())throw Error('No muestra descarga del STL');
  const wait=page.waitForEvent('download');await link.click();const download=await wait;await download.saveAs('evidencias/navegador_6558_reparado.stl');
  const rejected=await page.request.get('http://127.0.0.1:8769/descargar-conversion/'+id);if(rejected.status()===200)throw Error('Publica STEP rechazado');
 }else if(state.estado!=='terminado')throw Error('Estado final inesperado');
 await page.screenshot({path:'evidencias/navegador_r5_reparacion.png',fullPage:true});
 fs.writeFileSync('evidencias/navegador_r5_reparacion.json',JSON.stringify({ok:true,id,estado:state,detalle_visible:await page.locator('#error').innerText(),error_sin_STEP:state.estado==='error',STL_reparado_disponible:true,errores_js:errors},null,2));
 if(errors.length)throw Error(errors.join('\n'));
 await page.locator('#newBtn').click();await page.waitForFunction(()=>document.getElementById('fileName').textContent==='Sin archivo');console.log('Flujo de reparación y descarga comprobado');
 }finally{
 if(id)try{const state=await(await page.request.get('http://127.0.0.1:8769/estado-conversion/'+id)).json();if(state.estado==='ejecutando')await page.request.post('http://127.0.0.1:8769/cancelar-conversion/'+id)}catch{}
 await browser.close();
 }
})().catch(e=>{console.error(e);process.exitCode=1});
