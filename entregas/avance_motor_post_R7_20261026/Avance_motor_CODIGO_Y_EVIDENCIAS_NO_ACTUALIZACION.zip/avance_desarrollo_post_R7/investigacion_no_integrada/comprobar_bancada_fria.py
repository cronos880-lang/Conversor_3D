from pathlib import Path
import json,time
import cadquery as cq
from OCP.BRepAlgoAPI import BRepAlgoAPI_Check
root=Path(__file__).resolve().parent
old=Path('/workspace/work/paquete_perfeccion_Visualizador_R7/evidencias/regresion_precision/Bancada_Motor.step')
report=[]
for label,path in [('R7',old),('candidato',root/'regresion_historica/resultados/Bancada_Motor.step')]:
    start=time.monotonic();shape=cq.importers.importStep(str(path)).val()
    check=BRepAlgoAPI_Check(shape.wrapped,False,True)
    report.append({'version':label,'valido':bool(shape.isValid()),'interferencias_en_frio':not check.IsValid(),'caras':len(shape.Faces()),'segundos':time.monotonic()-start})
    (root/'bancada_lectura_fria.json').write_text(json.dumps(report,indent=2));print(report[-1],flush=True)
