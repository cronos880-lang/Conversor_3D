"""Investigación aislada; ningún resultado de este script modifica el motor."""
from pathlib import Path
import json,time,traceback
import cadquery as cq
from OCP.BRepAlgoAPI import BRepAlgoAPI_Check
from OCP.ShapeFix import ShapeFix_Wireframe,ShapeFix_Shape
from OCP.ShapeUpgrade import ShapeUpgrade_UnifySameDomain
ROOT=Path(__file__).resolve().parent
source=Path('/workspace/work/paquete_perfeccion_Visualizador_R7/evidencias/regresion_precision/Bancada_Motor.step')
out=ROOT/'investigacion_bancada';out.mkdir(exist_ok=True);rows=[]
original=cq.importers.importStep(str(source)).val()
check=BRepAlgoAPI_Check(original.wrapped,False,True)
details=[]
for item in check.Result():
    pair=[]
    for s in (item.GetShape1(),item.GetShape2()):
        if s.IsNull():pair.append({'tipo':'Null'});continue
        q=cq.Shape.cast(s);pair.append({'tipo':q.ShapeType(),'vertices':[v.Center().toTuple() for v in q.Vertices()]})
    details.append({'estado':str(item.GetCheckStatus()),'par':pair})
(out/'interferencias_original.json').write_text(json.dumps(details,indent=2))
for mode in ['wireframe','shapefix','unify','shapefix_wireframe']:
    t=time.monotonic();row={'modo':mode,'ok':False}
    try:
        shape=original.copy()
        if mode in ['shapefix','shapefix_wireframe']:
            fix=ShapeFix_Shape(shape.wrapped);fix.SetPrecision(1e-7);fix.SetMaxTolerance(.001);fix.SetMinTolerance(1e-7);fix.Perform();shape=cq.Shape.cast(fix.Shape())
        if mode in ['wireframe','shapefix_wireframe']:
            fix=ShapeFix_Wireframe(shape.wrapped);fix.SetPrecision(.001);fix.SetMaxTolerance(.001);fix.SetMinTolerance(1e-7);row['modificado']=bool(fix.FixSmallEdges());shape=cq.Shape.cast(fix.Shape())
        if mode=='unify':
            fix=ShapeUpgrade_UnifySameDomain(shape.wrapped,True,True,False);fix.Build();shape=cq.Shape.cast(fix.Shape())
        path=out/(mode+'.step');cq.exporters.export(shape,str(path));back=cq.importers.importStep(str(path)).val();check=BRepAlgoAPI_Check(back.wrapped,False,True)
        row.update(ok=bool(back.isValid() and check.IsValid() and len(back.Solids())==1),brep_valido=bool(back.isValid()),interferencias=len(list(check.Result())),caras=len(back.Faces()),volumen=back.Volume())
    except Exception as exc:row['error']=str(exc);traceback.print_exc()
    row['segundos']=time.monotonic()-t;rows.append(row);(out/'resultados.json').write_text(json.dumps(rows,indent=2));print(row,flush=True)
