"""Ensayo nativo aislado usando la protección local ya existente en R7."""
from pathlib import Path
import sys,json,time,traceback
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'motor_experimental'))
from motor_v2 import convertir
src=Path('/workspace/work/paquete_perfeccion_Visualizador_R7/material_pruebas/originales/Bancada_Motor.stl')
spec=next(x for x in json.loads((ROOT/'regresion_historica/protocolo.json').read_text())['casos'] if x['id']=='Bancada_Motor');src=Path(spec['source'])
folder=ROOT/'investigacion_bancada';folder.mkdir(exist_ok=True);start=time.monotonic();r={'ok':False}
with (folder/'protegida.motor.log').open('w') as log:
    try:
        r['resultado']=convertir(src,folder/'protegida.step',log,conservar_vertices=True,proteger_contactos=True,control_avanzado=True);r['ok']=True
    except Exception as e:r['error']=str(e);traceback.print_exc()
r['segundos']=time.monotonic()-start;(folder/'protegida.json').write_text(json.dumps(r,indent=2,ensure_ascii=False));print(json.dumps(r,ensure_ascii=False),flush=True)
