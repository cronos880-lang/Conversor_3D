"""Hipótesis aislada de robustez entre kernels; no modifica el motor congelado."""
from pathlib import Path
import sys,time,json,os,signal,subprocess,psutil
ROOT=Path(__file__).resolve().parent;folder=ROOT/'micro_6558'
if len(sys.argv)>1:
 sys.path.insert(0,str(ROOT/'motor_investigacion_micro'));from recuperacion_numerica import reconstruir
 base=Path('/workspace/work/paquete_perfeccion_Visualizador_R7')
 raise SystemExit(reconstruir(base/'material_pruebas/casos_usuario_r5/6558_fixed.stl',base/'evidencias/caso_final_6558/6558_fixed.reparado.stl',folder/'6558_micro.step',folder/'6558_micro.json',segundos=480))
while not (ROOT/'regresion_externa/resultados_sanos/09_pared_delgada.resultado.json').exists():
 if time.time()>1793025000:raise SystemExit('No se inicia investigación: límite global')
 time.sleep(1)
folder.mkdir(exist_ok=True);start=time.monotonic();peak=0;why=None
with (folder/'prototipo.stdout').open('w') as log:
 p=subprocess.Popen([sys.executable,__file__,'--worker'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True);proc=psutil.Process(p.pid)
 while p.poll() is None:
  try:peak=max(peak,sum(c.memory_info().rss for c in [proc,*proc.children(recursive=True)] if c.is_running()))
  except psutil.Error:pass
  why='tiempo_investigacion' if time.monotonic()-start>540 else 'memoria_investigacion' if peak>4096*1024**2 else None
  if why:os.killpg(p.pid,signal.SIGKILL);p.wait();break
  time.sleep(.2)
(folder/'ejecucion.json').write_text(json.dumps({'codigo':p.returncode,'segundos':time.monotonic()-start,'ram_pico_mib':peak/1024**2,'interrupcion':why,'hipotesis':'Aumentar holguras y longitudes mínimas dentro del presupuesto geométrico existente; no demuestra importación en Onshape.','motor_produccion_modificado':False},indent=2))
