"""Dos ensayos aislados de precisión nativa, sin tocar producción."""
from pathlib import Path
import sys,json,time,traceback
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'motor_experimental'))
from motor_v2 import convertir,_calidad
from reparacion_cad import convertir_marco_local
spec=next(x for x in json.loads((ROOT/'regresion_historica/protocolo.json').read_text())['casos'] if x['id']=='Bancada_Motor');src=Path(spec['source'])
folder=ROOT/'investigacion_bancada';rows=[]
for mode in ['precision_8','marco_precision_8']:
    start=time.monotonic();r={'modo':mode,'ok':False}
    with (folder/(mode+'.motor.log')).open('w') as log:
        try:
            if mode=='precision_8':result=convertir(src,folder/(mode+'.step'),log,flat_tol_deg=8.,precision_reparacion=True,control_avanzado=True)
            else:
                def native(source,destination,log,**kwargs):
                    kwargs['flat_tol_deg']=8.;kwargs['control_avanzado']=True
                    return convertir(source,destination,log,**kwargs)
                result=convertir_marco_local(src,folder/(mode+'.step'),log,native,_calidad)
            r.update(ok=True,resultado=result)
        except Exception as e:r['error']=str(e);traceback.print_exc()
    r['segundos']=time.monotonic()-start;rows.append(r);(folder/'precision.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False));print(json.dumps(r,ensure_ascii=False),flush=True)
    if r['ok']:break
