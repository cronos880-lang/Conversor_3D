from pathlib import Path
import sys,json,time
import numpy as np,cadquery as cq
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'motor_experimental'))
from calidad_topologica import inspeccionar
from saneamiento_cad import comprobar_interferencias
from validacion_reconstruccion import euler_brep
t=time.monotonic();s=cq.importers.importStep(str(ROOT/'entradas_nuevas/6558_fixed_Prueba.step')).val()
data={'solidos':len(s.Solids()),'shells':len(s.Shells()),'caras':len(s.Faces()),'volumen':s.Volume(),'euler':euler_brep(s),'integridad':inspeccionar(s),'interferencias':comprobar_interferencias(s)}
lengths=np.asarray([e.Length() for e in s.Edges()]);areas=np.asarray([f.Area() for f in s.Faces()]);data.update(longitudes_arista_percentiles_mm=np.percentile(lengths,[0,.01,.1,1,5,50,100]).tolist(),areas_cara_percentiles_mm2=np.percentile(areas,[0,.01,.1,1,5,50,100]).tolist(),aristas_menores_1um=int(np.sum(lengths<.001)),aristas_menores_10nm=int(np.sum(lengths<.00001)),caras_menores_1um2=int(np.sum(areas<.000001)),segundos=time.monotonic()-t)
(ROOT/'inspeccion_step_usuario.json').write_text(json.dumps(data,indent=2));print(json.dumps(data),flush=True)
