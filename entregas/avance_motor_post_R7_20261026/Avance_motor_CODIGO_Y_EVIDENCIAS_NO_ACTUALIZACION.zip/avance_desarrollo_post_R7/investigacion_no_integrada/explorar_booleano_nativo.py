"""Prototipos CAD aislados: sólo se aprueban tras controles completos aparte."""
from pathlib import Path
import json,time,traceback
import cadquery as cq
from OCP.BRepAlgoAPI import BRepAlgoAPI_Check,BRepAlgoAPI_Fuse
from OCP.BOPAlgo import BOPAlgo_MakerVolume
from OCP.ShapeFix import ShapeFix_Shape
root=Path(__file__).resolve().parent;out=root/'investigacion_bancada';out.mkdir(exist_ok=True)
source=Path('/workspace/work/paquete_perfeccion_Visualizador_R7/evidencias/regresion_precision/Bancada_Motor.step')
shape=cq.importers.importStep(str(source)).val();check=BRepAlgoAPI_Check(shape.wrapped,False,True);detail=[]
for entry in check.Result():
    row={'estado':str(entry.GetCheckStatus()),'a':[],'b':[]}
    for key,items in [('a',entry.GetFaultyShapes1()),('b',entry.GetFaultyShapes2())]:
        for item in items:
            q=cq.Shape.cast(item);row[key].append({'tipo':q.ShapeType(),'vertices':[v.Center().toTuple() for v in q.Vertices()]})
    detail.append(row)
(out/'interferencias_subformas.json').write_text(json.dumps(detail,indent=2))
rows=[]
for mode in ['maker_0','maker_1e-7','maker_1e-5','autofusion']:
    t=time.monotonic();r={'modo':mode,'ok':False}
    try:
        if mode=='autofusion':
            alg=BRepAlgoAPI_Fuse(shape.wrapped,shape.wrapped);alg.SetNonDestructive(True);alg.Build();result=cq.Shape.cast(alg.Shape())
        else:
            alg=BOPAlgo_MakerVolume();alg.SetIntersect(True);alg.SetAvoidInternalShapes(True);alg.SetNonDestructive(True);alg.SetFuzzyValue(float(mode.split('_')[1]));alg.SetRunParallel(False)
            for face in shape.Faces():alg.AddArgument(face.wrapped)
            alg.Perform();r['errores_booleano']=bool(alg.HasErrors());result=cq.Shape.cast(alg.Shape())
        r.update(tipo=result.ShapeType(),valido_antes=bool(result.isValid()),solidos_antes=len(result.Solids()),caras_antes=len(result.Faces()))
        fix=ShapeFix_Shape(result.wrapped);fix.SetPrecision(1e-7);fix.SetMinTolerance(1e-7);fix.SetMaxTolerance(.001);fix.Perform();result=cq.Shape.cast(fix.Shape())
        path=out/(mode+'.step');cq.exporters.export(result,str(path));back=cq.importers.importStep(str(path)).val();check=BRepAlgoAPI_Check(back.wrapped,False,True)
        r.update(ok=bool(back.isValid() and check.IsValid() and len(back.Solids())==1),valido_despues=bool(back.isValid()),solidos=len(back.Solids()),caras=len(back.Faces()),interferencias=len(list(check.Result())),volumen=back.Volume())
    except Exception as e:r['error']=str(e);traceback.print_exc()
    r['segundos']=time.monotonic()-t;rows.append(r);(out/'booleanos.json').write_text(json.dumps(rows,indent=2));print(r,flush=True)
