# Avance de desarrollo posterior a R7

**No es una actualización ni un instalador. R7 sigue siendo la última versión entregada.**

Por tamaño, la auditoría se distribuye en dos ZIP: `Avance_motor_CODIGO_Y_EVIDENCIAS_NO_ACTUALIZACION.zip` contiene código, informe, pruebas, piezas nuevas y regresión histórica; `Banco_externo_AUDITORIA_NO_ACTUALIZACION.zip` contiene el banco externo. Para consultar toda la auditoría, extraer ambos en la misma carpeta: comparten la raíz `avance_desarrollo_post_R7`. Cada parte tiene su manifiesto SHA256 y el manifiesto global se comprueba cuando están extraídas las dos.

Hay tres reparaciones/conversiones nuevas verificadas. La aprobación global queda bloqueada por la regresión del CAD de Bancada_Motor y por pruebas externas limitadas por recursos. Leer `INFORME_AVANCE_MOTOR.md` y los JSON: no todos los archivos de auditoría están aprobados.

Los cuatro archivos de `STEP_verificados` sí superan el contraste independiente; uno es el soporte de estante que ya funcionaba. Los STEP de `evidencias/regresion_externa/resultados_sanos` y de regresión histórica son salidas para auditoría: consultar el estado de cada ensayo. Los fixtures R7 contienen deliberadamente CAD defectuosos para comprobar su rechazo.

`codigo_modificado` y `CAMBIOS_DESARROLLO.patch` son cambios para revisión y continuidad del desarrollo. **No copiar archivos sueltos sobre el programa de uso.** No se proporciona un nuevo ZIP instalable ni se modifica la web de main.

Para desarrolladores: trabajar con otra copia completa del paquete R7 publicado en `entregas/perfeccion_Visualizador_R7` de la rama `perfeccion_Visualizador`. Aplicar el patch desde la raíz de esa copia con `patch -p1 -i RUTA/CAMBIOS_DESARROLLO.patch`; conservar una segunda copia intacta como evaluador. Se requieren las dependencias bloqueadas R7 y Python 3.12 de 64 bits. El entorno Linux está comprobado; Windows nativo sigue pendiente.

Ejemplos, sustituyendo las rutas y usando el Python del entorno de prueba:

```text
python herramientas/reproducir_pruebas.py --motor COPIA_CANDIDATA/Visor_experimental_fuentes --material-r7 material_pruebas --banco-r7 fixtures_banco_R7 --xml resultados/pruebas.xml
python herramientas/reproducir_nuevos.py --motor COPIA_CANDIDATA/Visor_experimental_fuentes --entradas entradas_nuevas --salida resultados/nuevas
python herramientas/verificar_step_independiente.py --evaluador R7_INTACTA/Visor_experimental_fuentes --stl entradas_nuevas/Soporte_movil_2.stl --step resultados/nuevas/Soporte_movil_2.step --referencia resultados/nuevas/Soporte_movil_2.reparado.saneado.stl --informe resultados/control_soporte.json
```

Para el Lego y el estante, `--referencia` es su STL original; para PEGS, el `.reparado.stl` producido por el ensayo. La herramienta independiente no llama a `_calidad`. Los tres comandos anteriores son las entradas portátiles y aceptan rutas locales explícitas. Los demás scripts de herramientas, investigación y evidencias registran el método ejecutado y conservan rutas/fechas del entorno original; se entregan para auditoría del procedimiento. La prueba API necesita que el entorno permita comunicación local entre sus hilos.

Los tiempos corresponden a una máquina Linux con dos CPU y 8 GiB compartidos entre pruebas; no son una medición de Windows. Onshape y las líneas del 6558 siguen pendientes. Los prototipos fallidos se conservan como registros, sin distribuir sus STEP como aprobados.
