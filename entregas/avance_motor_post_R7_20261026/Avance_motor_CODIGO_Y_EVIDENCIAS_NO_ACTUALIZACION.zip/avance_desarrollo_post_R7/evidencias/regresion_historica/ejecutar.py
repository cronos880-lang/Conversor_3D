from pathlib import Path
import sys,json,time,hashlib,subprocess,os,signal,psutil,shutil
ROOT=Path(__file__).resolve().parent;PARENT=ROOT.parent;EXT=PARENT/'regresion_externa';MOTOR=PARENT/'motor_congelado_A';sys.path.insert(0,str(MOTOR))
from bateria_reparacion import ejecutar
def completed(path):
 try:return len(json.loads(path.read_text())['resultados'])==20
 except (FileNotFoundError,json.JSONDecodeError):return False
while not completed(EXT/'bateria.json'):
 if time.time()>1793028600:raise SystemExit('Límite global de ensayos')
 time.sleep(1)
rows=json.loads((ROOT/'protocolo.json').read_text())['casos'];report=[]
for spec in rows:
 if time.time()>1793028600:raise SystemExit('Límite de ensayos: entregar progreso, sin versión')
 src=Path(spec['source']);assert hashlib.sha256(src.read_bytes()).hexdigest()==spec['sha256']
 print('HISTORICA',spec['id'],flush=True)
 result=ejecutar(MOTOR,src,ROOT/'resultados'/(spec['id']+'.step'),limite=spec['limite_s'],memoria_mb=4096,extra_env={'VISOR_PERFIL':'precision'})
 result.update(id=spec['id'],grupo=spec['grupo'],referencia_step=spec['referencia_step'])
 if result['ok']:
  old=Path(spec['referencia_step']).read_bytes().split(b'DATA;',1)[1];new=(ROOT/'resultados'/(spec['id']+'.step')).read_bytes().split(b'DATA;',1)[1]
  result['data_step_identico_R7']=old==new;result['sha256_data_nueva']=hashlib.sha256(new).hexdigest();result['sha256_data_R7']=hashlib.sha256(old).hexdigest()
 assert hashlib.sha256(src.read_bytes()).hexdigest()==spec['sha256']
 report.append(result);(ROOT/'bateria.json').write_text(json.dumps({'resultados':report},indent=2,ensure_ascii=False));print(spec['id'],result['ok'],result['segundos'],result.get('data_step_identico_R7'),result.get('interrupcion') or result['informe_motor'].get('error',''),flush=True)
