"""Leer los STEP y contrastarlos con los STL originales, fuera de _calidad."""
from pathlib import Path
import sys,time,json,hashlib,traceback
import numpy as np,trimesh,cadquery as cq
from OCP.BRepAlgoAPI import BRepAlgoAPI_Check
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.BRepTools import BRepTools
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,'/workspace/work/paquete_perfeccion_Visualizador_R7/Visor_experimental_fuentes')
from preprocesador_stl import cargar_exacto
from reparador_exacto_aislado import medidas_superficie,ControlExacto
from topologia_vertices import inspeccionar_vertices
from calidad_topologica import inspeccionar
from validacion_reconstruccion import euler_brep,certificar_topologia_step
from invariantes_material import InvariantesMaterial
CASES=[
 ('lego','entradas_nuevas/V_legoBrick4x2.stl','ensayo_primero/V_legoBrick4x2.step','entradas_nuevas/V_legoBrick4x2.stl'),
 ('soporte','entradas_nuevas/Soporte_movil_2.stl','ensayo_primero/Soporte_movil_2.step','ensayo_primero/Soporte_movil_2.reparado.saneado.stl'),
 ('pegs','entradas_nuevas/Technic_PEGS_Cross_x6_A.stl','ensayo_pegs_segundo/Technic_PEGS_Cross_x6_A.step','ensayo_pegs_segundo/Technic_PEGS_Cross_x6_A.reparado.stl'),
 ('estante','entradas_nuevas/Soportes_estante_bobinas_v0.stl','ensayo_primero/Soportes_estante_bobinas_v0.step','entradas_nuevas/Soportes_estante_bobinas_v0.stl'),
 ('micro6558','/workspace/work/paquete_perfeccion_Visualizador_R7/material_pruebas/casos_usuario_r5/6558_fixed.stl','micro_6558/6558_micro.step','/workspace/work/paquete_perfeccion_Visualizador_R7/evidencias/caso_final_6558/6558_fixed.reparado.stl')]
out=ROOT/'verificacion_independiente';out.mkdir(exist_ok=True);rows=[]
for name,source,step,reference in CASES:
 t=time.monotonic();record={'id':name,'ok':False,'metodo':'R7 congelada como evaluador, lectura fría CAD y teselación independiente; no llama _calidad.','tolerancia_mallado_solicitada_mm':.00025}
 try:
  source=ROOT/source;step=ROOT/step;reference=ROOT/reference;assert step.exists()
  raw=cargar_exacto(source);ref=cargar_exacto(reference);s=cq.importers.importStep(str(step)).val();check=BRepAlgoAPI_Check(s.wrapped,False,True)
  record.update(sha256_step=hashlib.sha256(step.read_bytes()).hexdigest(),solidos=len(s.Solids()),shells=len(s.Shells()),brep_valido=s.isValid(),interferencias_occ=not check.IsValid(),integridad=inspeccionar(s),euler_brep=euler_brep(s),euler_referencia=int(ref.euler_number))
  assert record['solidos']==1 and record['brep_valido'] and not record['interferencias_occ']
  record['topologia_material']=certificar_topologia_step(s,ref,InvariantesMaterial(ref))
  copy=s.copy();BRepTools.Clean_s(copy.wrapped);BRepMesh_IncrementalMesh(copy.wrapped,.00025,False,.04,False).Perform();v,f=copy.tessellate(.00025,.04);V=np.asarray([q.toTuple() for q in v]);F=np.asarray(f);_,first,inv=np.unique(np.round(V/1e-10).astype(np.int64),axis=0,return_index=True,return_inverse=True);mesh=trimesh.Trimesh(V[first],inv[F],process=False)
  record.update(caras_teselacion=len(mesh.faces),vertices_teselacion=len(mesh.vertices),estanco=bool(mesh.is_watertight),orientado=bool(mesh.is_winding_consistent),euler_teselacion=int(mesh.euler_number),vertices_no_manifold=inspeccionar_vertices(mesh)['vertices_no_manifold'])
  print('TESSEL',name,{k:record[k] for k in ['caras_teselacion','estanco','orientado','euler_teselacion','vertices_no_manifold']},flush=True)
  record['superficie_bruta_original']=surface=medidas_superficie(raw,mesh)
  record['volumen_error_pct']=volume=100*abs(s.Volume()-abs(raw.volume))/max(abs(raw.volume),1e-30)
  record['caja_error_mm']=box=float(np.abs(mesh.bounds-raw.bounds).max())
  if mesh.is_watertight:record['intersecciones_cgal']=len(ControlExacto(mesh,out/(name+'.off')).pares())
  p95_limit=max(.020,min(.030,float(np.linalg.norm(raw.extents))*.0002));record['limites']={'volumen_pct':.5,'caja_mm':.020,'p95_mm':p95_limit,'max_mm':.060}
  record['criterios']={'superficie_max':surface['max_mm']<=.060,'superficie_p95':surface['p95_mm']<=p95_limit,'volumen':volume<=.5,'caja':box<=.020,'mallado_cerrado':record['estanco'],'orientado':record['orientado'],'vertices_manifold':record['vertices_no_manifold']==0,'euler':record['euler_teselacion']==record['euler_referencia'],'cgal':record.get('intersecciones_cgal')==0,'parametrizacion':record['integridad']['aristas_parametrizacion_incoherente']==0}
  record['criterios']={k:bool(v) for k,v in record['criterios'].items()};record['ok']=all(record['criterios'].values())
  lengths=np.asarray([e.Length() for e in s.Edges()]);areas=np.asarray([f.Area() for f in s.Faces()]);record['microgeometria']={'arista_min_mm':float(lengths.min()),'area_min_mm2':float(areas.min()),'aristas_menores_1um':int(np.sum(lengths<.001)),'aristas_menores_10nm':int(np.sum(lengths<.00001)),'caras_menores_1um2':int(np.sum(areas<.000001))}
 except Exception as e:record['error']=str(e);traceback.print_exc()
 record['segundos']=time.monotonic()-t;rows.append(record);(out/(name+'.json')).write_text(json.dumps(record,indent=2,ensure_ascii=False));(ROOT/'verificacion_nuevos.json').write_text(json.dumps({'resultados':rows},indent=2,ensure_ascii=False));print('VERIFICADO',name,record['ok'],record.get('criterios'),record.get('error'),flush=True)
