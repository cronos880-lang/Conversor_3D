"""Verificación reproducible con utilidades R7 congeladas; no usa _calidad."""
from pathlib import Path
import argparse,hashlib,json,sys,time,traceback

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ['evaluador','stl','step','referencia','informe']:p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();sys.path.insert(0,str(a.evaluador.resolve()));a.informe=a.informe.resolve();a.informe.parent.mkdir(parents=True,exist_ok=True)
    import numpy as np,trimesh,cadquery as cq
    from OCP.BRepAlgoAPI import BRepAlgoAPI_Check
    from OCP.BRepMesh import BRepMesh_IncrementalMesh
    from OCP.BRepTools import BRepTools
    from OCP.TopoDS import TopoDS_Iterator
    from preprocesador_stl import cargar_exacto
    from reparador_exacto_aislado import medidas_superficie,ControlExacto
    from topologia_vertices import inspeccionar_vertices
    from calidad_topologica import inspeccionar
    from validacion_reconstruccion import euler_brep,certificar_topologia_step
    from invariantes_material import InvariantesMaterial
    start=time.monotonic();r={'ok':False,'metodo':'Utilidades R7 congeladas; CAD frío, CGAL, topología y superficies, sin _calidad.'}
    try:
        raw=cargar_exacto(a.stl);reference=cargar_exacto(a.referencia)
        pending=list(cq.importers.importStep(str(a.step)).vals());solids=[]
        while pending:
            item=pending.pop();kind=item.ShapeType()
            if kind=='Solid':solids.append(item);continue
            if kind not in ('Compound','CompSolid'):raise ValueError('STEP con objetos sueltos: '+kind)
            iterator=TopoDS_Iterator(item.wrapped)
            while iterator.More():pending.append(cq.Shape.cast(iterator.Value()));iterator.Next()
        if len(solids)!=1:raise ValueError('Se esperaba un único sólido')
        shape=solids[0]
        check=BRepAlgoAPI_Check(shape.wrapped,False,True)
        r.update(sha256_stl=hashlib.sha256(a.stl.read_bytes()).hexdigest(),sha256_step=hashlib.sha256(a.step.read_bytes()).hexdigest(),solidos=len(shape.Solids()),shells=len(shape.Shells()),brep_valido=bool(shape.isValid()),interferencias_occ=not check.IsValid(),integridad=inspeccionar(shape),euler_brep=euler_brep(shape))
        assert r['solidos']==1 and r['brep_valido'] and not r['interferencias_occ'],'STEP no válido en lectura fría'
        del check
        r['topologia_material']=certificar_topologia_step(shape,reference,InvariantesMaterial(reference))
        work=shape.copy();BRepTools.Clean_s(work.wrapped);BRepMesh_IncrementalMesh(work.wrapped,.00025,False,.04,False).Perform()
        vertices,faces=work.tessellate(.00025,.04);V=np.asarray([v.toTuple() for v in vertices]);F=np.asarray(faces)
        _,first,inverse=np.unique(np.round(V/1e-10).astype(np.int64),axis=0,return_index=True,return_inverse=True)
        mesh=trimesh.Trimesh(V[first],inverse[F],process=False)
        r.update(caras_teselacion=len(mesh.faces),estanco=bool(mesh.is_watertight),orientado=bool(mesh.is_winding_consistent),euler_teselacion=int(mesh.euler_number),vertices_no_manifold=inspeccionar_vertices(mesh)['vertices_no_manifold'])
        r['superficie_bruta_original']=surface=medidas_superficie(raw,mesh)
        r['volumen_error_pct']=volume=100*abs(shape.Volume()-abs(raw.volume))/max(abs(raw.volume),1e-30)
        r['caja_error_mm']=box=float(abs(mesh.bounds-raw.bounds).max())
        if mesh.is_watertight:r['intersecciones_cgal']=len(ControlExacto(mesh,a.informe.with_suffix('.off')).pares())
        limit=max(.020,min(.030,float(np.linalg.norm(raw.extents))*.0002))
        r['limites']={'volumen_pct':.5,'caja_mm':.020,'p95_mm':limit,'max_mm':.060}
        criteria={'superficie_max':surface['max_mm']<=.060,'superficie_p95':surface['p95_mm']<=limit,'volumen':volume<=.5,'caja':box<=.020,'mallado_cerrado':r['estanco'],'orientado':r['orientado'],'vertices_manifold':r['vertices_no_manifold']==0,'euler':r['euler_teselacion']==reference.euler_number,'cgal':r.get('intersecciones_cgal')==0,'parametrizacion':r['integridad']['aristas_parametrizacion_incoherente']==0}
        r['criterios']={k:bool(v) for k,v in criteria.items()};r['ok']=all(r['criterios'].values())
    except Exception as exc:r['error']=str(exc);traceback.print_exc()
    r['segundos']=time.monotonic()-start;a.informe.write_text(json.dumps(r,indent=2,ensure_ascii=False));print(json.dumps({'ok':r['ok'],'informe':str(a.informe),'segundos':r['segundos']}),flush=True)
    return 0 if r['ok'] else 2

if __name__=='__main__':raise SystemExit(main())
