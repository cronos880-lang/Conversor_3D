const {chromium}=require('playwright');
const fs=require('fs');const path=require('path');const crypto=require('crypto');
const root=process.env.VISOR_TRABAJO||__dirname;
const app=process.env.VISOR_APP_ROOT||path.join(root,'motor_experimental');
const url=process.env.VISOR_URL||'http://127.0.0.1:8773';
const output=path.join(root,'pruebas_navegador');fs.mkdirSync(output,{recursive:true});
const cases=[['lego','V_legoBrick4x2','ensayo_primero'],['soporte','Soporte_movil_2','ensayo_primero'],['pegs','Technic_PEGS_Cross_x6_A','ensayo_pegs_segundo']];
const digest=data=>crypto.createHash('sha256').update(data).digest('hex');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});const rows=[];
 try{for(const [id,name,reference] of cases){
  const page=await browser.newPage({viewport:{width:1280,height:900},acceptDownloads:true});let job;const errors=[];const start=Date.now();page.on('pageerror',e=>errors.push(String(e)));
  page.on('response',async r=>{if(r.url().endsWith('/iniciar-conversion'))try{job=(await r.json()).id}catch{}});
  try{
   await page.goto(url);await page.waitForFunction(()=>!document.getElementById('openBtn').disabled);
   if(await page.locator('#conversionProfile').inputValue()!=='precision')throw Error('No está seleccionado el perfil Precisión');
   await page.locator('#fileInput').setInputFiles(path.join(root,'entradas_nuevas',name+'.stl'));
   await page.waitForFunction(()=>!document.getElementById('convertBtn').disabled);await page.locator('#convertBtn').click();
   await page.waitForFunction(()=>document.getElementById('conversionPercent').textContent==='100 %'||document.getElementById('conversionPercent').classList.contains('failed'),{},{timeout:1200000});
   if(await page.locator('#conversionPercent').evaluate(e=>e.classList.contains('failed')))throw Error(await page.locator('#error').innerText());
   await page.waitForFunction(()=>!document.getElementById('exportBtn').disabled,{},{timeout:60000});
   const detail=await page.locator('#details').innerText();const state=await(await page.request.get(url+'/estado-conversion/'+job)).json();
   page.once('dialog',d=>d.accept(name+'_GUI'));const downloading=page.waitForEvent('download');await page.locator('#exportBtn').click();const download=await downloading;
   const destination=path.join(output,id+'_GUI.step');await download.saveAs(destination);await page.screenshot({path:path.join(output,id+'_interfaz.png'),fullPage:true});
   const data=fs.readFileSync(destination);const cli=fs.readFileSync(path.join(root,reference,name+'.step'));
   const body=b=>b.subarray(b.indexOf('DATA;')+5);const same=body(data).equals(body(cli));
   const diagnostic=JSON.parse(fs.readFileSync(path.join(app,'Registros_Conversion',job+'.json'),'utf8'));
   let repair=null;
   if(diagnostic.archivos_reparacion?.reparado){
    const response=await page.request.get(url+diagnostic.archivos_reparacion.reparado);if(!response.ok())throw Error('No se puede descargar el STL reparado');
    const bytes=await response.body();repair={sha256:digest(bytes),bytes:bytes.length,hash_coincide_certificado:digest(bytes)===diagnostic.preprocesamiento.reparado_sha256};
    if(!repair.hash_coincide_certificado)throw Error('El STL descargado no coincide con su certificado');
   }
   const row={id,job,detalle:detail,estado:state,segundos:(Date.now()-start)/1000,sha256_descarga:digest(data),data_step_identico_cli:same,stl_reparado:repair,errores_js:errors,ok:same&&errors.length===0};rows.push(row);
   fs.writeFileSync(path.join(output,id+'.json'),JSON.stringify(row,null,2));fs.writeFileSync(path.join(root,'navegador_resultados.json'),JSON.stringify({resultados:rows},null,2));
   console.log(id,row.ok,row.segundos,detail);if(!row.ok)throw Error('La salida GUI o JavaScript no coincide con lo validado');
  }finally{
   if(job)try{const s=await(await page.request.get(url+'/estado-conversion/'+job)).json();if(s.estado==='ejecutando')await page.request.post(url+'/cancelar-conversion/'+job)}catch{}
   await page.close();
  }
 }}finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
