"""Repetir conversiones, con límites y sin sobrescribir originales.

Usar una copia de R7 con CAMBIOS_DESARROLLO.patch aplicado. No es instalador.
"""
from pathlib import Path
import argparse,hashlib,json,sys

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--motor',type=Path,required=True)
    p.add_argument('--entradas',type=Path,default=Path(__file__).resolve().parent/'entradas_nuevas')
    p.add_argument('--salida',type=Path,required=True)
    p.add_argument('--solo',nargs='*')
    p.add_argument('--limite',type=int,default=1200)
    a=p.parse_args();a.motor=a.motor.resolve();a.entradas=a.entradas.resolve();a.salida=a.salida.resolve()
    if a.entradas==a.salida or a.entradas in a.salida.parents:p.error('Guardar resultados fuera de las entradas originales')
    sys.path.insert(0,str(a.motor))
    from bateria_reparacion import ejecutar
    sources=[x for x in sorted(a.entradas.glob('*.stl')) if not x.name.endswith('_B.stl')]
    if a.solo:sources=[x for x in sources if x.stem in a.solo]
    if not sources:p.error('No se encontraron los STL solicitados')
    a.salida.mkdir(parents=True,exist_ok=True);report=[]
    for source in sources:
        before=hashlib.sha256(source.read_bytes()).hexdigest()
        row=ejecutar(a.motor,source,a.salida/(source.stem+'.step'),limite=a.limite,memoria_mb=4096,extra_env={'VISOR_PERFIL':'precision'})
        assert hashlib.sha256(source.read_bytes()).hexdigest()==before,'Ha cambiado el original'
        row['original_intacto']=True;report.append(row)
        (a.salida/'bateria.json').write_text(json.dumps({'resultados':report},indent=2,ensure_ascii=False))
        print(source.name,row['ok'],row['segundos'],flush=True)
    return 0 if all(x['ok'] for x in report) else 2

if __name__=='__main__':raise SystemExit(main())
