"""Estado de entrega explícito: no oculta regresiones ni ensayos pendientes."""
from pathlib import Path
from datetime import datetime,timezone
import json
root=Path(__file__).resolve().parent
def rows(name):return json.loads((root/name).read_text()).get('resultados',[])
new=[x for x in rows('verificacion_nuevos.json') if x['id'] in ('lego','soporte','pegs','estante')]
hist=rows('regresion_historica/bateria.json');cube=[x for x in hist if x['grupo']=='cubo4'];old=[x for x in hist if x['grupo']=='historica12']
external=rows('regresion_externa/bateria_final.json');oracle=rows('regresion_externa/oraculos_finales.json');ui=rows('navegador_resultados.json')
snapshot=json.loads((root/'prueba_tolerancias_y_cambios.json').read_text())
aux=json.loads((root/'verificacion_auxiliares_pegs.json').read_text())
gates={'nuevas_conversiones_independientes':len(new)==4 and all(x['ok'] for x in new) and aux['ok'],
 'navegador_nuevas_tres':len(ui)==3 and all(x['ok'] and x['data_step_identico_cli'] for x in ui),
 'cubo_cuatro_sin_cambio':len(cube)==4 and all(x['ok'] and x['data_step_identico_R7'] for x in cube),
 'historicas_doce_convertidas':len(old)==12 and all(x['ok'] for x in old),
 'historicas_doce_sin_perdida_de_CAD':len(old)==12 and all(x.get('data_step_identico_R7') for x in old),
 'regresion_completa_veintiuno':len(hist)==21 and all(x['ok'] for x in hist),
 'banco_veinte_conversiones':len(external)==20 and all(x['ok'] for x in external),
 'banco_veinte_contrastes_completos':len(oracle)==20 and all(x['ok'] for x in oracle),
 'modulos_de_tolerancias_y_nucleo_intactos':all(x['identico'] for x in snapshot['modulos_geometricos_identicos'])}
record={'fecha_utc':datetime.now(timezone.utc).isoformat(),'publicar_version':False,'puertas':gates,
 'interpretacion':'La identidad DATA es un certificado suficiente de conservación. Su ausencia requiere una revisión; no prueba por sí sola una regresión. En Bancada se confirmó pérdida de los 25 cilindros y paso de 89 caras CAD a 6277 planos.',
 'bloqueos':['Bancada_Motor: recuperación fiel pero pérdida de superficies CAD útiles; no se considera resuelta la regresión.',
 'Barrido17: motor aprobado y rechazo del CAD R7 defectuoso probado; contraste independiente completo inconcluso por recursos.',
 'Hélice19: dos interrupciones de conversión a900s, sin aprobación en el banco actual.',
 'Perfil spline11 y loft16: criterios de salida cumplidos; STL fuera de calibración de entrada, separados de fallos del conversor.'],
 'sin_afirmar':['14/14 conversiones: embudo aplazado por el usuario','Validación Windows nativo','Onshape y líneas de6558 resueltas','Validación o actualización de WebAssembly de main']}
(root/'PUERTAS_DE_ENTREGA.json').write_text(json.dumps(record,indent=2,ensure_ascii=False));print(json.dumps(record,indent=2,ensure_ascii=False))
