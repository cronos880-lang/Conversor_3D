"""Contraste dirigido: incluye caras de área nula y facetas casi colapsadas.

El muestreo de área no visita caras nulas. Se usa la frontera de la teselación
independiente, nunca la distancia al volumen del sólido.
"""
from pathlib import Path
import sys,json,hashlib
import numpy as np,trimesh
root=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'motor_experimental'))
from preprocesador_stl import cargar_exacto
from saneamiento_malla import quitar_redundancias
sys.path.insert(0,'/workspace/work/paquete_perfeccion_Visualizador_R7/Visor_experimental_fuentes')
from verificacion_reparacion import distancia_malla
raw=cargar_exacto(root/'entradas_nuevas/Technic_PEGS_Cross_x6_A.stl');clean,proof=quitar_redundancias(raw)
keys={tuple(sorted(map(int,f))) for f in clean.faces}
removed=[i for i,f in enumerate(raw.faces) if tuple(sorted(map(int,f))) not in keys]
explored=[1558,1574,1982,2187];ids=sorted(set(removed+explored));rng=np.random.default_rng(26655)
meshfile=root/'verificacion_independiente/pegs.off';surface=trimesh.load(str(meshfile),force='mesh',process=False)
rows=[]
def certify(triangle,limit=.060):
    # La distancia a un conjunto cerrado es 1-Lipschitz. La distancia del
    # centro más el radio cubre todo el triángulo, también si está colapsado.
    pending=np.asarray([triangle]);certified=0.;count=0
    rounding=256*np.finfo(float).eps*max(1.,float(abs(raw.vertices).max()))
    for depth in range(21):
        centers=pending.mean(axis=1);distance=distancia_malla(surface,centers)
        radius=np.linalg.norm(pending-centers[:,None,:],axis=2).max(axis=1)
        upper=distance+radius+rounding;ok=upper<=limit
        count+=len(pending)
        if ok.any():certified=max(certified,float(upper[ok].max()))
        if ok.all():return {'ok':True,'cota_max_mm':certified,'triangulos_evaluados':count,'profundidad':depth,'margen_redondeo_mm':rounding}
        if np.any(distance>limit) or depth==20 or count>100000:break
        next_level=[]
        for t in pending[~ok]:
            lengths=[np.linalg.norm(t[(i+1)%3]-t[i]) for i in range(3)];i=int(np.argmax(lengths));a,b,c=t[i],t[(i+1)%3],t[(i+2)%3];m=(a+b)/2
            next_level.extend(([a,m,c],[m,b,c]))
        pending=np.asarray(next_level)
    return {'ok':False,'motivo':'Cobertura inconclusa o punto fuera del límite','triangulos_evaluados':count}

for i in ids:
    triangle=raw.triangles[i];uv=rng.uniform(0,1,(500,2));uv[uv.sum(axis=1)>1]=1-uv[uv.sum(axis=1)>1]
    points=np.vstack((triangle,triangle.mean(axis=0),triangle[0]+uv[:,0,None]*(triangle[1]-triangle[0])+uv[:,1,None]*(triangle[2]-triangle[0])))
    d=distancia_malla(surface,points)
    rows.append({'cara':i,'retirada_en_saneamiento':i in removed,'muestras':len(points),'max_mm':float(d.max()),'p95_dirigido_mm':float(np.percentile(d,95)),'cobertura_completa_hacia_frontera_teselada':certify(triangle)})
record={'ok':all(x['max_mm']<=.060 and x['cobertura_completa_hacia_frontera_teselada']['ok'] for x in rows),'metodo':'Muestreo baricéntrico dirigido y cobertura adaptativa 1-Lipschitz de cada triángulo retirado hacia la frontera teselada del STEP final. No distancia al volumen sólido. Máximo0.060mm sin ampliar. P95 dirigido no es percentil global por área. La cota es hacia la teselación independiente; no se presenta como cota global exacta hacia el B-Rep.',
 'sha256_frontera_off':hashlib.sha256(meshfile.read_bytes()).hexdigest(),'caras_retiradas':removed,'caras':rows,'max_mm':max(x['max_mm'] for x in rows)}
(root/'verificacion_auxiliares_pegs.json').write_text(json.dumps(record,indent=2,ensure_ascii=False));print(json.dumps(record,indent=2,ensure_ascii=False),flush=True)
