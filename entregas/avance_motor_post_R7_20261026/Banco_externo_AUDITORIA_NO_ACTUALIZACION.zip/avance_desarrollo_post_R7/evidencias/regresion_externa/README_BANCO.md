# Banco externo para auditoría, sin actualización del programa

Este ZIP complementa al archivo principal de código y evidencias. Extraer ambos bajo la misma raíz avance_desarrollo_post_R7. Consultar el informe principal y los JSON antes de considerar un STEP aprobado.

Resultado real: 19 conversiones internas completadas; 16 contrastes externos completos aprobados. Los casos11 y16 cumplen la salida CAD, pero sus STL superan el límite de calibración de entrada. El17 tiene un contraste independiente inconcluso por recursos y el19 agota el tiempo de conversión. Los intentos fallidos se conservan. Los scripts registran el procedimiento ejecutado y requieren adaptar las rutas del entorno original para repetir el banco.

Las referencias CAD, STL y salidas del candidato están incluidas. Procedencia, avisos y licencias de las fuentes públicas están en procedencia_y_licencias. No hay instalador ni una versión nueva del Visor.
