from pathlib import Path
import sys,json,time,os,signal,subprocess,psutil
ROOT=Path(__file__).resolve().parent;folder=ROOT/'oraculos';folder.mkdir(exist_ok=True);report=[]
for spec in json.loads((ROOT/'corpus.json').read_text())['casos']:
 name=spec['id'];motor=ROOT/'resultados_sanos'/(name+'.resultado.json')
 while not motor.exists():
  if time.time()>1793028600:raise SystemExit('Límite global de pruebas alcanzado')
  time.sleep(.5)
 data=json.loads(motor.read_text());out=folder/(name+'.json')
 if not data['ok']:record={'id':name,'ok':False,'ejecutado':False,'error_motor':data['informe_motor'].get('error'),'interrupcion_motor':data.get('interrupcion')}
 else:
  start=time.monotonic();peak=0;reason=None;print('CONTRASTANDO',name,flush=True)
  with (folder/(name+'.stdout.txt')).open('w') as log:
   p=subprocess.Popen([sys.executable,str(ROOT/'oraculo_cad.py'),name],stdout=log,stderr=subprocess.STDOUT,start_new_session=True);proc=psutil.Process(p.pid)
   while p.poll() is None:
    try:peak=max(peak,sum(c.memory_info().rss for c in [proc,*proc.children(recursive=True)] if c.is_running()))
    except psutil.Error:pass
    reason='tiempo_evaluador' if time.monotonic()-start>900 else 'memoria_evaluador' if peak>3000*1024**2 else None
    if reason:os.killpg(p.pid,signal.SIGKILL);p.wait();break
    time.sleep(.2)
  record=json.loads(out.read_text()) if out.exists() else {'id':name,'ok':False,'ejecutado':True,'error':reason or 'Evaluador no emitió informe'}
  record.update(limite_s=900,ram_pico_mib=peak/1024**2,codigo=p.returncode)
 out.write_text(json.dumps(record,indent=2,ensure_ascii=False));report.append(record);(ROOT/'oraculos.json').write_text(json.dumps({'resultados':report},indent=2,ensure_ascii=False));print(name,record['ok'],record.get('criterios') or record.get('error'),flush=True)
