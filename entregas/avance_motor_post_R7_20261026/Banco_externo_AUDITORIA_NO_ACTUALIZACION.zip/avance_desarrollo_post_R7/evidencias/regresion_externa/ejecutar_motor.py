from pathlib import Path
import sys,json,time,hashlib
ROOT=Path(__file__).resolve().parent;MOTOR=ROOT.parent/'motor_congelado_A';sys.path.insert(0,str(MOTOR))
from bateria_reparacion import ejecutar
rows=json.loads((ROOT/'corpus.json').read_text())['casos'];manifest=json.loads((ROOT.parent/'motor_A_sha256.json').read_text());report=[]
for r in rows:
 if time.time()>1793028600:raise SystemExit('Límite global de pruebas alcanzado')
 assert all(hashlib.sha256((MOTOR/n).read_bytes()).hexdigest()==h for n,h in manifest.items())
 print('CONVIRTIENDO',r['id'],flush=True)
 result=ejecutar(MOTOR,ROOT/r['stl'],ROOT/'resultados_sanos'/(r['id']+'.step'),limite={1:300,2:480,3:720,4:900}[r['nivel']],memoria_mb=4096,extra_env={'VISOR_PERFIL':'precision'})
 result['id']=r['id'];report.append(result);(ROOT/'bateria.json').write_text(json.dumps({'resultados':report},indent=2,ensure_ascii=False));print(r['id'],result['ok'],result['segundos'],result.get('interrupcion') or result['informe_motor'].get('error',''),flush=True)
