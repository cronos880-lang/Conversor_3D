from pathlib import Path
import sys,time,json,hashlib,subprocess,os,signal,psutil,shutil
ROOT=Path(__file__).resolve().parent;MOTOR=ROOT.parent/'motor_congelado_A';sys.path.insert(0,str(MOTOR))
from bateria_reparacion import ejecutar
from oraculo_cad import distances_to_cad
import cadquery as cq,numpy as np
s=cq.Workplane('XY').box(10,10,10).val();observed=distances_to_cad(np.array([[0,0,0],[6,0,0],[5,0,0.]]),s)
assert np.allclose(observed,[5,1,0],rtol=0,atol=1e-10)
(ROOT/'control_distancia_frontera.json').write_text(json.dumps({'ok':True,'esperado_mm':[5,1,0],'observado_mm':observed.tolist(),'nota':'El centro del sólido dista5mm de su frontera; nunca debe medirse cero por estar dentro del volumen.'},indent=2))
while True:
 try:
  motors=json.loads((ROOT/'bateria.json').read_text())['resultados']
  if len(motors)==20:break
 except (FileNotFoundError,json.JSONDecodeError):pass
 if time.time()>1793028600:raise SystemExit('Límite global de pruebas')
 time.sleep(1)
report=[];folder=ROOT/'oraculos';folder.mkdir(exist_ok=True)
for spec in json.loads((ROOT/'corpus.json').read_text())['casos']:
 name=spec['id'];m=next(x for x in motors if x['id']==name)
 if m.get('interrupcion'):
  archive=ROOT/'intentos_recursos'/name;archive.mkdir(parents=True,exist_ok=True)
  for f in (ROOT/'resultados_sanos').glob(name+'*'):
   if f.is_file():shutil.copyfile(f,archive/f.name)
  print('REPETIR MOTOR POR RECURSOS',name,flush=True)
  updated=ejecutar(MOTOR,ROOT/spec['stl'],ROOT/'resultados_sanos'/(name+'.step'),limite=m['limite_s'],memoria_mb=4096,extra_env={'VISOR_PERFIL':'precision'});m.update(updated);m['id']=name;m['repetido_por_recursos']=True
 if not m['ok']:
  record={'id':name,'ok':False,'ejecutado':False,'error_motor':m['informe_motor'].get('error'),'interrupcion_motor':m.get('interrupcion')}
 else:
  print('CONTRASTE FRONTERA',name,flush=True);start=time.monotonic();peak=0;reason=None;path=folder/(name+'.json')
  with (folder/(name+'.stdout.txt')).open('w') as log:
   p=subprocess.Popen([sys.executable,str(ROOT/'oraculo_cad.py'),name],stdout=log,stderr=subprocess.STDOUT,start_new_session=True);proc=psutil.Process(p.pid)
   while p.poll() is None:
    try:peak=max(peak,sum(c.memory_info().rss for c in [proc,*proc.children(recursive=True)] if c.is_running()))
    except psutil.Error:pass
    reason='tiempo_evaluador' if time.monotonic()-start>900 else 'memoria_evaluador' if peak>4096*1024**2 else None
    if reason:os.killpg(p.pid,signal.SIGKILL);p.wait();break
    time.sleep(.2)
  record=json.loads(path.read_text()) if path.exists() else {'id':name,'ok':False,'ejecutado':True,'error':reason or 'Sin informe'}
  record.update(limite_s=900,limite_ram_mib=4096,ram_pico_mib=peak/1024**2,codigo=p.returncode)
 (folder/(name+'.json')).write_text(json.dumps(record,indent=2,ensure_ascii=False));report.append(record);(ROOT/'oraculos_finales.json').write_text(json.dumps({'resultados':report},indent=2,ensure_ascii=False));(ROOT/'bateria_final.json').write_text(json.dumps({'resultados':motors},indent=2,ensure_ascii=False));print(name,record['ok'],record.get('criterios') or record.get('error'),flush=True)
