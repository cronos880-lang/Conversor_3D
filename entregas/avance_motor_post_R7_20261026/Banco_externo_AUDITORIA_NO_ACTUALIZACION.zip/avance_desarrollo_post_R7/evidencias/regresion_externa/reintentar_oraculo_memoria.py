"""Repetición limitada de un verificador interrumpido; conserva el intento."""
import json,os,signal,subprocess,sys,time
from pathlib import Path
import psutil
root=Path(__file__).resolve().parent
name=sys.argv[1];out=root/'oraculos_memoria';out.mkdir(exist_ok=True)
start=time.monotonic();peak=0;why=None
with (out/(name+'.stdout.txt')).open('w') as log:
    p=subprocess.Popen([sys.executable,str(root/'oraculo_cad_memoria.py'),name],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    proc=psutil.Process(p.pid)
    while p.poll() is None:
        try:peak=max(peak,sum(q.memory_info().rss for q in [proc,*proc.children(recursive=True)] if q.is_running()))
        except psutil.Error:pass
        why='tiempo_evaluador' if time.monotonic()-start>900 else 'memoria_evaluador' if peak>4096*1024**2 else None
        if why:os.killpg(p.pid,signal.SIGKILL);p.wait();break
        time.sleep(.2)
path=out/(name+'.json')
record=json.loads(path.read_text()) if path.exists() else {'id':name,'ok':False,'ejecutado':True,'error':why or 'Sin informe'}
record.update(limite_s=900,limite_ram_mib=4096,ram_pico_mib=peak/1024**2,codigo=p.returncode)
path.write_text(json.dumps(record,indent=2,ensure_ascii=False));print(json.dumps(record,ensure_ascii=False),flush=True)
