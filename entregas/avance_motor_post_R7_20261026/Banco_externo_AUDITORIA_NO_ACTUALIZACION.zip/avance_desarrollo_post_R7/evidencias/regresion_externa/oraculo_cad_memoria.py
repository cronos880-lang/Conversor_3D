"""Mismo oráculo v5 y mallado absoluto; extremos nativos sin listas de puntos.

No amplía ningún umbral. Evita duplicar millones de nodos en objetos Python.
"""
import json,sys
import numpy as np
from OCP.Bnd import Bnd_Box
from OCP.BRep import BRep_Tool
from OCP.BRepTools import BRepTools
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.TopLoc import TopLoc_Location
import oraculo_cad as oracle

def bounds_streaming(shape,deflection=.00025):
    work=shape.copy();BRepTools.Clean_s(work.wrapped)
    BRepMesh_IncrementalMesh(work.wrapped,deflection,False,.04,False).Perform()
    box=Bnd_Box();box.SetGap(0.)
    for face in work.Faces():
        location=TopLoc_Location()
        tri=BRep_Tool.Triangulation_s(face.wrapped,location)
        if tri is None or not tri.MinMax(box,location.Transformation(),True):
            raise ValueError('Una cara carece de triangulación verificable')
    if box.IsVoid():raise ValueError('Caja vacía')
    result=np.asarray(box.Get()).reshape(2,3)
    if not np.isfinite(result).all():raise ValueError('Caja no finita')
    BRepTools.Clean_s(work.wrapped)
    return result

if __name__=='__main__':
    name=sys.argv[1]
    convergence=[]
    def bounded_memory_box(shape):
        coarse=bounds_streaming(shape,.001)
        fine=bounds_streaming(shape,.0005)
        delta=float(np.abs(fine-coarse).max())
        convergence.append(delta)
        if delta>.00025:raise ValueError('La caja no converge dentro de 0.00025 mm; prueba inconclusa')
        return fine
    oracle.bounds=bounded_memory_box
    spec=next(x for x in json.loads((oracle.ROOT/'corpus.json').read_text())['casos'] if x['id']==name)
    record=oracle.validate(spec,oracle.ROOT/'resultados_sanos'/(name+'.step'))
    record['version_oraculo']='5-memoria-convergencia'
    record['implementacion_caja']='Extremos nativos; mallados 0.001 y 0.0005 mm / 0.04 rad. Convergencia exigida <=0.00025 mm; se suma el doble del cambio a la comparación. Estimación, no cota matemática global. Umbral geométrico invariable 0.020 mm.'
    record['convergencia_cajas_mm']=convergence
    if len(convergence)==2 and 'criterios' in record:
        measured=record['caja_error_mm']+2*sum(convergence)
        record['caja_error_con_margen_convergencia_mm']=measured
        record['criterios']['caja']=bool(measured<=.020)
        record['ok']=all(record['criterios'].values())
    path=oracle.ROOT/'oraculos_memoria';path.mkdir(exist_ok=True)
    (path/(name+'.json')).write_text(json.dumps(record,indent=2,ensure_ascii=False))
    print(json.dumps({'id':name,'ok':record['ok'],'error':record.get('error'),'segundos':record['segundos']}),flush=True)
