"""Contraste CAD original/STEP de salida. No usa _calidad ni sus mediciones."""
from pathlib import Path
import hashlib,json,sys,time,traceback
import numpy as np,cadquery as cq
from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.BRepTools import BRepTools
from OCP.BRepClass import BRepClass_FaceClassifier
from OCP.BRepClass3d import BRepClass3d_SolidClassifier
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeVertex
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
from OCP.BRepAlgoAPI import BRepAlgoAPI_Check
from OCP.TopAbs import TopAbs_IN,TopAbs_ON
from OCP.gp import gp_Pnt,gp_Pnt2d
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.BRepTools import BRepTools
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'motor_R7_inmutable'))
from preprocesador_stl import cargar_exacto
from validacion_reconstruccion import euler_brep
from verificacion_reparacion import distancia_malla

def surface_samples(shape,seed=20261026):
 rng=np.random.default_rng(seed);points=[];vertices=shape.Vertices();edges=shape.Edges();faces=shape.Faces()
 for i in (range(len(vertices)) if len(vertices)<=256 else rng.choice(len(vertices),128,replace=False)):
  points.append(vertices[int(i)].Center().toTuple())
 for i in (range(len(edges)) if len(edges)<=128 else rng.choice(len(edges),128,replace=False)):
  for t in (.2,.5,.8):
   try:points.append(edges[int(i)].positionAt(t).toTuple())
   except Exception:pass
 for i in (range(len(faces)) if len(faces)<=144 else rng.choice(len(faces),144,replace=False)):
  face=faces[int(i)];u0,u1,v0,v1=BRepTools.UVBounds_s(face.wrapped)
  if not np.all(np.isfinite([u0,u1,v0,v1])):continue
  surf=BRepAdaptor_Surface(face.wrapped)
  for a in (.19,.5,.81):
   for b in (.23,.5,.77):
    u=u0+a*(u1-u0);v=v0+b*(v1-v0)
    if BRepClass_FaceClassifier(face.wrapped,gp_Pnt2d(u,v),1e-9).State() in (TopAbs_IN,TopAbs_ON):
     p=surf.Value(u,v);points.append((p.X(),p.Y(),p.Z()))
 if not points:raise ValueError('No se obtuvieron muestras CAD verificables')
 points=np.asarray(points);_,idx=np.unique(np.round(points/1e-9).astype(np.int64),axis=0,return_index=True)
 return points[np.sort(idx)]

def distances_to_cad(points,target):
 values=[];test=BRepExtrema_DistShapeShape();test.LoadS2(target.wrapped)
 for p in points:
  vertex=BRepBuilderAPI_MakeVertex(gp_Pnt(*map(float,p))).Vertex();test.LoadS1(vertex);test.Perform()
  if not test.IsDone() or not np.isfinite(test.Value()):raise ValueError('Una proyección CAD no se pudo verificar')
  values.append(test.Value())
 return np.asarray(values)

def stats(d):return {'muestras':len(d),'media_mm':float(np.mean(d)),'p95_mm':float(np.percentile(d,95)),'max_mm':float(np.max(d))}
def bounds(shape):
 # La caja fría de superficies offset puede ser conservadora, no un extremo
 # geométrico alcanzable. Medir todos los casos con el mismo mallado absoluto.
 work=shape.copy();BRepTools.Clean_s(work.wrapped)
 BRepMesh_IncrementalMesh(work.wrapped,.00025,False,.04,False).Perform()
 vertices,_=work.tessellate(.00025,.04);v=np.asarray([p.toTuple() for p in vertices])
 if len(v)==0 or not np.all(np.isfinite(v)):raise ValueError('Caja CAD no verificable')
 return np.asarray([v.min(axis=0),v.max(axis=0)])

def material_checks(reference,candidate,mesh):
 rng=np.random.default_rng(71133);uniform=rng.uniform(mesh.bounds[0]-.2,mesh.bounds[1]+.2,size=(800,3))
 take=rng.choice(len(mesh.faces),size=min(160,len(mesh.faces)),replace=False);centers=mesh.triangles_center[take];normals=mesh.face_normals[take]
 probes=np.vstack([uniform,*[centers+sign*eps*normals for eps in (.09,.2,.5) for sign in (-1,1)]])
 gap=distancia_malla(mesh,probes);probes=probes[gap>.08]
 a=BRepClass3d_SolidClassifier(reference.wrapped);b=BRepClass3d_SolidClassifier(candidate.wrapped);mismatch=[];n_in=0;n_out=0
 for p in probes:
  point=gp_Pnt(*map(float,p));a.Perform(point,1e-9);b.Perform(point,1e-9)
  ai=a.State()==TopAbs_IN;bi=b.State()==TopAbs_IN;n_in+=int(ai);n_out+=int(not ai)
  if ai!=bi:mismatch.append({'xyz_mm':p.tolist(),'material_referencia':ai,'material_resultado':bi})
 return {'puntos':len(probes),'interiores_referencia':n_in,'exteriores_referencia':n_out,'banda_excluida_mm':.08,'discrepancias':len(mismatch),'ejemplos':mismatch[:12]}

def validate(spec,output):
 start=time.monotonic();r={'id':spec['id'],'ok':False,'ejecutado':True,'version_oraculo':4,
  'limites':{'volumen_pct':.5,'caja_mm':.020,'p95_mm':.020,'max_mm':.060},
  'nota':'Muestreo exacto de caras/aristas CAD y clasificación de material; no cota Hausdorff global. Ambos CAD se leen con OpenCascade.'}
 def progress(stage):
  folder=ROOT/'progreso_evaluador';folder.mkdir(exist_ok=True)
  data={'fase':stage,'segundos':time.monotonic()-start,'informe_parcial':r}
  p=folder/(spec['id']+'.json');tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(data,indent=2,ensure_ascii=False));tmp.replace(p)
  print('FASE',spec['id'],stage,flush=True)
 try:
  progress('leyendo CAD y STEP')
  source=ROOT/spec['stl'];reference_path=ROOT/spec['referencia_step'];assert hashlib.sha256(source.read_bytes()).hexdigest()==spec['sha256_stl'];assert hashlib.sha256(reference_path.read_bytes()).hexdigest()==spec['sha256_step_referencia']
  original=cq.importers.importStep(str(reference_path)).val();candidate=cq.importers.importStep(str(output)).val();r['solidos']=len(candidate.Solids());r['brep_valido']=bool(candidate.isValid())
  assert r['solidos']==1 and r['brep_valido'],'El STEP no contiene un sólido válido'
  progress('comprobando interferencias CAD antes de mallar')
  check=BRepAlgoAPI_Check(candidate.wrapped,False,True);r['interferencias_occ']=not check.IsValid()
  if r['interferencias_occ']:
   r['criterios']={'interferencias':False}
   raise ValueError('Interferencias CAD en lectura fría: rechazo antes de mallar el STEP')
  volume_error=100*abs(candidate.Volume()-original.Volume())/original.Volume();r['volumen_error_pct']=float(volume_error)
  if volume_error>.5:raise ValueError('Volumen distinto del CAD original')
  box_error=float(np.abs(bounds(candidate)-bounds(original)).max());r['caja_error_mm']=box_error
  r['metodo_caja']='Extremos de vértices de mallado CAD absoluto 0.00025 mm / 0.04 rad; umbral 0.020 mm sin ampliar. Estimación geométrica, no cota exacta global.'
  progress('muestreando caras y aristas CAD');a=surface_samples(original);b=surface_samples(candidate,20261027)
  progress('proyectando CAD original sobre resultado');da=distances_to_cad(a,candidate);r['referencia_a_resultado']=stats(da)
  progress('proyectando resultado sobre CAD original');db=distances_to_cad(b,original);r['resultado_a_referencia']=stats(db)
  progress('calibrando STL de entrada')
  mesh=cargar_exacto(source)
  # Comprobar también que el STL de entrada aproximaba al CAD que se usa de verdad.
  prep1=distancia_malla(mesh,a);rng=np.random.default_rng(1991);t=np.vstack((mesh.vertices,mesh.triangles_center));t=t[rng.choice(len(t),size=min(600,len(t)),replace=False)];prep2=distances_to_cad(t,original)
  r['calibracion_stl']={'cad_a_stl':stats(prep1),'stl_a_cad':stats(prep2),'limite_max_mm':.005,'ok':bool(max(prep1.max(),prep2.max())<=.005)}
  progress('comprobando topología');chi=euler_brep(candidate);r['euler_referencia']=spec['euler_cad'];r['euler_resultado']=chi;r['shells_referencia']=len(original.Shells());r['shells_resultado']=len(candidate.Shells());r['caras_resultado']=len(candidate.Faces())
  progress('interferencias CAD comprobadas en lectura fría')
  progress('clasificando puntos de material');r['material']=material_checks(original,candidate,mesh)
  criteria={'volumen':volume_error<=.5,'caja':box_error<=.020,'superficie_p95':max(np.percentile(da,95),np.percentile(db,95))<=.020,
   'superficie_max':max(da.max(),db.max())<=.060,'euler':chi==spec['euler_cad'],'shells':len(original.Shells())==len(candidate.Shells()),
   'interferencias':not r['interferencias_occ'],'material':r['material']['discrepancias']==0,'calibracion_entrada':r['calibracion_stl']['ok']}
  criteria={k:bool(v) for k,v in criteria.items()}
  r['criterios']=criteria;r['ok']=all(criteria.values())
 except Exception as exc:r['error']=str(exc);traceback.print_exc()
 r['segundos']=time.monotonic()-start;return r

if __name__=='__main__':
 name=sys.argv[1];spec=next(x for x in json.loads((ROOT/'corpus.json').read_text())['casos'] if x['id']==name)
 out=ROOT/'oraculos';out.mkdir(exist_ok=True);record=validate(spec,ROOT/'resultados_sanos'/(name+'.step'))
 (out/(name+'.json')).write_text(json.dumps(record,indent=2,ensure_ascii=False));print(json.dumps({'id':name,'ok':record['ok'],'error':record.get('error'),'segundos':record['segundos']}),flush=True)
