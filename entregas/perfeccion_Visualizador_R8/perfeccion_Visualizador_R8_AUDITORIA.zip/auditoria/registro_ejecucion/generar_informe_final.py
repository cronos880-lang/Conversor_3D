from pathlib import Path
import json,csv,datetime,hashlib,xml.etree.ElementTree as ET,shutil
ROOT=Path(__file__).resolve().parent
def read(name):return json.loads((ROOT/name).read_text())
def quality(r):return r.get('diagnostico',{}).get('calidad') or r.get('informe_motor',{}).get('resultado',{}).get('calidad',{})
def main():
 cli=read('regresion_cli.json')['resultados'];gui=read('navegador_resultados.json')['resultados'];protocol=json.loads(Path('/workspace/work/mejora_motor_post_r7_20261026/regresion_historica/protocolo.json').read_text())
 index={r['id']:r for r in cli+gui};rows=[index[c['id']] for c in protocol['casos']]
 assert len(rows)==21 and all(r['ok'] for r in rows),'La regresión obligatoria no está aprobada'
 assert all(r.get('original_sin_modificar',True) and not r.get('errores_js') for r in rows)
 cold=read('lectura_fria_final.json');assert all(r['ok'] for r in cold)
 assert len([r for r in cold if Path(r['archivo']).stem in {c['id'] for c in protocol['casos']}])==21
 cancel=read('cancelacion_resultado.json');assert cancel['ok']
 contrasts={name:read('navegador/'+name+'_contraste_independiente.json') for name in ['Bancada_Motor','pinza']}
 for name,r in contrasts.items():
  assert r['step_exacto'] and 'geometria_R7' in r and not r.get('error')
  assert r['cilindros_respaldados']['confirmados']==r['cilindros_respaldados']['preservados']
  assert len(r['frontera_tres_resoluciones']['resoluciones'])==3
  assert all(m['cerrado'] and m['orientado'] and m['intersecciones_cgal']==0 for m in r['frontera_tres_resoluciones']['resoluciones'])
 xml=ET.parse(ROOT/'pruebas_R8_completas.xml');suites=list(xml.iter('testsuite'));stats={k:sum(int(s.get(k,0)) for s in suites) for k in ['tests','failures','errors','skipped']};assert stats['tests']==213 and not any(stats[k] for k in ['failures','errors','skipped'])
 assert read('auditoria_tolerancias.json')['sin_relajacion']
 summary={'fecha_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'version':'R8 experimental','compilacion':'2026.10.27-contornos-verificados','regresion':{'casos':21,'aprobados':21,'cubo_y_giros':4,'historicas_originales':13,'originales_totales':14,'embudo':'aplazado por el usuario'},'unidades':stats,'tolerancias_sin_relajar':True,'cancelacion_y_nueva_conversion':True,'windows_nativo':'NO EJECUTADO','Onshape':'NO EJECUTADO','casos':[]}
 table=['| Pieza | Ruta real | Tiempo (s) | Caras STEP | Máx. mm | Caja mm | Volumen % | DATA igual R7 |','|---|---|---:|---:|---:|---:|---:|---|']
 for r in rows:
  q=quality(r);v={'id':r['id'],'ok':r['ok'],'ruta':r['ruta'],'segundos':r['segundos'],'ram_pico_mb':r.get('ram_pico_mb',r.get('diagnostico',{}).get('ram_pico_mb')),'caras_step':q.get('caras_step'),'max_mm':q.get('desviacion_max_verificada_mm'),'caja_mm':q.get('caja_error_mm'),'volumen_error_pct':q.get('volumen_error_pct'),'DATA_identico_R7':r.get('DATA_identico_R7'),'sha256_step':r.get('sha256_step')};summary['casos'].append(v)
  table.append(f"| {r['id']} | {'Visor' if r['ruta']=='interfaz_navegador' else 'CLI'} | {r['segundos']:.1f} | {v['caras_step']} | {v['max_mm']} | {v['caja_mm']} | {v['volumen_error_pct']} | {'sí' if v['DATA_identico_R7'] else 'no'} |")
 old_counts={r['id']:r for r in read('control_exacto_referencias_R7.json')}
 representation=['| Pieza | Caras R7 | CAD exacto R7 | Caras R8 | Representación R8 |','|---|---:|---|---:|---|']
 for r in rows:
  q=quality(r);mode=r.get('informe_motor',{}).get('resultado',{}).get('modo','');strategy=r.get('diagnostico',{}).get('estrategia','');label='Recuperación facetada' if mode=='recuperacion_facetada' or 'numerica' in strategy or 'facetada' in strategy or 'facetada' in r.get('detalle','').lower() else 'CAD validado';old=old_counts[r['id']];representation.append(f"| {r['id']} | {old['caras']} | {'sí' if old['exacto'] else 'no'} | {q.get('caras_step')} | {label} |")
 recent=[r for r in gui if r['grupo']=='recientes'];summary['recientes']=[{'id':r['id'],'ok':r['ok'],'error':r.get('error'),'segundos':r['segundos'],'caras_step':quality(r).get('caras_step'),'detalle':r.get('detalle')} for r in recent]
 text='''# Visor STL → STEP R8 experimental completa

Esta entrega integra en el Visor para Windows la recuperación automática de encuentros entre superficies CAD y la normalización conservadora de ciclos circulares/elípticos. Se usa una copia independiente; se mantiene la prioridad de las conversiones anteriores y el perfil Precisión. No modifica R7 ni la web de main.

## Avance demostrado

- **Bancada_Motor:** el STEP de referencia R7 tenía 89 caras y no superaba la comprobación CAD exacta. R8 entrega 1.896 caras, con 15 cilindros respaldados por el STL, coherencia exacta y BOP aprobado. El ajuste de tres ciclos partidos elimina tres aristas redundantes sin desplazar vértices, elevar tolerancias ni quitar superficies. El nuevo resultado también genera fronteras cerradas y orientadas en tres discretizaciones finas, sin autointersecciones CGAL. No se afirma una reducción de caras frente a R7 en esta pieza.
- **Pinza:** pasa de 2.144 caras planas en la referencia R7 a 448 caras con 10 cilindros respaldados por el STL. STEP exacto, BOP aprobado y tres fronteras finas comprobadas. Es reconstrucción de superficies; no recupera el historial paramétrico original.
- **Cubo-carrito y tres giros:** las cuatro conversiones completas aprueban ahora también la comprobación CAD exacta. La referencia R7 del cubo tenía 255 caras y fallaba ese nuevo control; la recuperación conservadora entrega 1.152 caras facetadas, regenerando y contrastando primero la unión desde los componentes originales. No se presenta como reconstrucción analítica de sus curvas. La prueba del cubo desde la interfaz también descarga el STEP y contrasta su huella con el archivo validado por el servidor.
- **Control de reintentos y memoria:** tras un rechazo CAD exacto y un rescate de contornos agotado se pasa a la recuperación conservadora aislada, sin repetir ajustes incompatibles. Esto corrige el agotamiento de memoria observado en M3 PClip con límites de 4.500 y 5.500 MiB; la fila de interfaz y su diagnóstico registran el consumo de esta copia. No se amplía el límite del programa.
- Se exige coherencia CAD exacta además del control ordinario. Un resultado ya sometido a BOP en el trabajador sólo evita repetir ese mismo control cuando coincide el SHA-256 completo del STEP. El padre vuelve a abrir el archivo y repite geometría y coherencia exacta; cualquier cambio de bytes invalida esa prueba. No es una caché entre conversiones.

## Pruebas de esta copia

**213 pruebas automáticas aprobadas, cero fallos, errores u omisiones.** Incluyen negativos de objetos sueltos, autointerferencias, STEP ordinariamente válidos pero incoherentes en el control exacto, cuerpos pequeños independientes, soportes cónicos distintos, prueba BOP alterada y cancelación/arranque.

**21/21 conversiones de regresión aprobadas:** cuatro cubos, trece de las catorce históricas y cuatro adicionales de usuario. M3 PClip, Bancada, pinza, cubo y 6558 se ejecutaron desde la interfaz real con Playwright/Chromium: importar, convertir y exportar. Las otras dieciséis usaron el mismo motor completo por CLI. Pieza Nueva se ejecutó en una segunda cola, una vez terminadas la interfaz y sus contrastes, con las mismas fuentes, perfil y límites; se conserva su registro y la huella del STEP copiado. Cada STEP descargado coincide byte a byte con el validado por el servidor. Se hizo además una nueva lectura fría estricta de los resultados, exigiendo un único sólido positivo y coherencia CAD exacta.

**Embudo permanece aplazado por instrucción del propietario. No se declara 14/14.** Los SHA-256 de entradas y de las 126 fuentes congeladas se conservan. Los originales no se modifican.

Se contrastaron además los STEP realmente descargados de Bancada y pinza con el evaluador geométrico R7 y el control de frontera M1 inmutables. Ambos conservan todos los cilindros confirmados y pasan geometría, topología de material y tres discretizaciones sin intersecciones CGAL. El BOP obligatorio es el ejecutado por el motor R8; el contraste independiente no lo sustituye.

Se probó cancelar mediante Nuevo durante una conversión, negar la descarga del trabajo cancelado y convertir/exportar después una caja. Se comprobó la reapertura de la misma instancia y el rechazo de otra aplicación que ocupe el puerto. Los registros y capturas se incluyen en la auditoría.

### Medidas reales de regresión

Los tiempos pertenecen a un entorno Linux de referencia con dos CPU y trabajos de prueba concurrentes. No son una predicción del tiempo en Windows. «DATA igual R7» compara la sección de datos STEP omitiendo el encabezado; una diferencia requiere revisar los controles, no demuestra por sí sola una regresión.

'''+ '\n'.join(table)+'\n\n### Representación comparada\n\n'+ '\n'.join(representation)+'\n\n## Entradas recientes adicionales\n\n'
 for r in summary['recientes']:text+=f"- **{r['id']}**: {'aprobado' if r['ok'] else 'rechazado'}, {r['segundos']:.1f} s. "+(str(r.get('detalle') or r.get('error') or '')).replace('\n',' ')+'\n'
 text+='''
## Representación y equivalencia de las fuentes

La regresión acredita conversión, validez y geometría. **En algunas piezas aumentan las caras o se usa recuperación facetada frente al STEP antiguo**, porque el nuevo control rechaza ajustes que R7 aceptaba sin coherencia CAD exacta. No se declara mejor editabilidad para todas las piezas ni una reducción general de caras. La interfaz identifica la recuperación facetada.

La aplicación y las pruebas de esta entrega se validan sobre una copia congelada de 126 archivos. Sus huellas se comprueban en la batería y al extraer los ZIP. Los ensayos anteriores se conservan separados; no se suman como conversiones aprobadas de esta copia.

La recuperación de referencias con costuras reproduce las correcciones certificadas existentes o la lectura heredada `process=True`. Esta última exige conservar cada faceta y limitar el cambio de coordenadas al redondeo original de Trimesh, 1e-8 mm; también comprueba cierre, orientación y contactos entre abanicos. No autoriza tapar un agujero. En el Lego histórico el desplazamiento medido fue de 3,524e-16 mm.

La discrepancia dimensional imprimible y la coherencia interna de un B-Rep son controles distintos. Una separación de unas milésimas puede quedar por debajo de la precisión de la impresora y aun así incumplir la correspondencia de curvas y superficies del STEP. R8 exige ambos controles, con los límites geométricos originales.

## Tolerancias y alcance

Los archivos de perfiles, holgura geométrica, validación densa y política de tiempos permanecen byte a byte iguales a R7. La auditoría AST de constantes confirma: caja 0,020 mm; volumen 0,5 %; p95 base 0,020 mm, con las condiciones originales; máximo observado 0,060 mm. El perfil opcional Impresión 0,08 mm sigue existiendo y no se selecciona automáticamente. Todas las pruebas de esta entrega usaron Precisión.

Se amplía únicamente el presupuesto acotado del trabajador de reconstrucción según triángulos, de 300 a 900 s. Se conservan los límites de recursos de la aplicación. La comprobación BOP puede tardar minutos; se añaden mensajes de fase y se evita duplicarla sobre los mismos bytes validados. No se promete una aceleración general del conversor.

## Uso y pendientes

Extraer el ZIP completo en una carpeta nueva y abrir **Iniciar.bat** en la raíz. Contiene la carpeta **Visor_experimental_fuentes** y todos sus módulos. Puede reutilizar, en lectura, el entorno de R7 mediante el selector de carpeta. Si no hay entorno compatible, ejecutar **Instalar_Entorno.bat** con Python 3.12 de 64 bits. R8 se abre en **http://127.0.0.1:8772** y muestra su versión; R7 puede permanecer en 8771. La identidad de instancia evita abrir otra copia por error.

**Windows nativo no se ha ejecutado en este entorno Linux.** Se han comprobado lanzadores, rutas con espacios, selección de entorno, saltos CRLF y disponibilidad de ruedas Windows CPython 3.12 de los componentes CAD críticos. Esto no sustituye tu prueba real en Windows. **Onshape tampoco se ha ejecutado**: las líneas que observabas en 6558 requieren nueva comprobación visual allí; no se declara corregido ese defecto por el solo hecho de pasar los controles locales. La K1C no se ha probado.

No se garantiza reparación de STL arbitrarios ni recuperación analítica de cualquier curva. Los STEP de recuperación facetada se identifican en la interfaz. El modo de superficies sigue requiriendo validación y puede ceder a una recuperación conservadora o rechazar la pieza. Las pruebas negativas defectuosas y los intentos de desarrollo descartados se conservan separados de los resultados aprobados.

La auditoría separada incluye materiales, referencias R7, fuentes del evaluador, XML de pruebas, protocolo portable, registros, huellas y herramientas de reproducción. Los resultados STEP se entregan en un ZIP separado para que el programa sea ligero de descargar. `archivos_modificados` y el parche registran los cambios acumulados desde la R7 entregada.
'''
 (ROOT/'INFORME_RESULTADOS.md').write_text(text,encoding='utf-8');(ROOT/'ACEPTACION_R8.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False))
 with (ROOT/'RESULTADOS_REGRESION.csv').open('w',newline='',encoding='utf-8-sig') as f:
  writer=csv.DictWriter(f,fieldnames=list(summary['casos'][0]));writer.writeheader();writer.writerows(summary['casos'])
 print('INFORME APROBADO',len(rows),'casos, recientes',sum(r['ok'] for r in recent),'/',len(recent))
if __name__=='__main__':main()
