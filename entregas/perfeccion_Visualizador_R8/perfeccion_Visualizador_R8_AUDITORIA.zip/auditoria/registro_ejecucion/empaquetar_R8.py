"""Empaquetar únicamente la candidata congelada y las evidencias reales."""
from pathlib import Path
import json,hashlib,zipfile,shutil
ROOT=Path(__file__).resolve().parent
STAGE=ROOT/'preparacion_entrega'
OUT=ROOT/'entrega_GitHub/perfeccion_Visualizador_R8'
EXTRACT=ROOT/'verificacion paquete R8'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(a,b):b.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(a,b)
def archive(base,target,prefix=''):
 files=sorted(p for p in base.rglob('*') if p.is_file() and p.name!='MANIFIESTO_SHA256.json')
 assert not any(any(x in p.parts for x in ['.venv','__pycache__','.pytest_cache']) for p in files)
 manifest={str(p.relative_to(base)):sha(p) for p in files}
 (base/'MANIFIESTO_SHA256.json').write_text(json.dumps(manifest,indent=2));files.append(base/'MANIFIESTO_SHA256.json')
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in sorted(files):z.write(p,str(Path(prefix)/p.relative_to(base)))
 assert target.stat().st_size<95*1024**2,(target.name,target.stat().st_size)
 with zipfile.ZipFile(target) as z:assert z.testzip() is None
 return {'archivo':target.name,'bytes':target.stat().st_size,'sha256':sha(target),'ficheros':len(files)}
def main():
 accept=json.loads((ROOT/'ACEPTACION_R8.json').read_text());assert accept['regresion']['aprobados']==21
 OUT.mkdir(parents=True,exist_ok=True);app=STAGE/'programa';qa=STAGE/'auditoria';results=STAGE/'resultados';results.mkdir(exist_ok=True)
 for name in ['INFORME_RESULTADOS.md','ACEPTACION_R8.json','RESULTADOS_REGRESION.csv','auditoria_tolerancias.json','ENTORNO.json','archivos_modificados_R7.json']:
  copy(ROOT/name,app/name);copy(ROOT/name,qa/name);copy(ROOT/name,OUT/name)
 for name in ['regresion_cli.json','navegador_resultados.json','cancelacion_resultado.json','lectura_fria_final.json','inventario_referencias_R7.json','orquestacion_paralela.json','reabrir_misma_copia.stdout','pruebas_R8_completas.xml','pruebas_R8_completas.stdout']:
  copy(ROOT/name,qa/name)
 for name in ['probar_cancelacion.cjs','auditar_steps_finales.py','generar_informe_final.py','empaquetar_R8.py','probar_paquete_extraido.cjs']:
  copy(ROOT/name,qa/'registro_ejecucion'/name)
 for folder in ['regresion_cli','navegador']:
  for p in (ROOT/folder).iterdir():
   if not p.is_file():continue
   copy(p,results/folder/p.name)
   if p.suffix in ['.json','.png'] or p.name.endswith('.stdout'):copy(p,qa/'evidencias'/folder/p.name)
 logs=ROOT/'motor_R8_VALIDACION_DEFINITIVA/Registros_Conversion'
 for p in logs.iterdir():
  if p.is_file():copy(p,results/'Registros_Conversion'/p.name)
 # Las fuentes se comprueban por su manifiesto, sin copiar registros generados.
 manifest=json.loads((ROOT/'motor_R8_VALIDACION_DEFINITIVA_sha256.json').read_text())
 assert len(manifest)==126 and all(sha(app/'Visor_experimental_fuentes'/rel)==digest for rel,digest in manifest.items())
 for rel in manifest:copy(app/'Visor_experimental_fuentes'/rel,OUT/'Visor_experimental_fuentes'/rel)
 for name in ['Iniciar.bat','Instalar_Entorno.bat','LEEME_PRIMERO.txt']:copy(app/name,OUT/name)
 for change in json.loads((ROOT/'archivos_modificados_R7.json').read_text()):
  rel=change['archivo'];copy(app/'Visor_experimental_fuentes'/rel,OUT/'archivos_modificados'/rel)
 for name in ['CAMBIOS_DESDE_R7.patch','REPRODUCIR.md']:
  copy(qa/name,OUT/name)
 copy(ROOT/'motor_R8_VALIDACION_DEFINITIVA_sha256.json',OUT/'FUENTES_SHA256.json')
 packages=[archive(app,OUT/'perfeccion_Visualizador_R8_EXPERIMENTAL_COMPLETA.zip'),archive(qa,OUT/'perfeccion_Visualizador_R8_AUDITORIA.zip','auditoria'),archive(results,OUT/'perfeccion_Visualizador_R8_RESULTADOS_STEP.zip','resultados')]
 (OUT/'PAQUETES_SHA256.json').write_text(json.dumps(packages,indent=2))
 assert not EXTRACT.exists(),'Usar directorio nuevo para verificar la extracción real'
 EXTRACT.mkdir()
 for p in packages:
  with zipfile.ZipFile(OUT/p['archivo']) as z:z.extractall(EXTRACT/('programa' if 'COMPLETA' in p['archivo'] else '.'))
 for folder in ['programa','auditoria','resultados']:
  base=EXTRACT/folder;mf=json.loads((base/'MANIFIESTO_SHA256.json').read_text())
  for rel,digest in mf.items():assert sha(base/rel)==digest,(folder,rel)
 assert all(sha(EXTRACT/'programa/Visor_experimental_fuentes'/rel)==digest for rel,digest in manifest.items())
 report={'CRC_tres_zip':True,'extraccion_real':True,'directorio_con_espacios':True,'fuentes_126_identicas':True,'registros_entorno_no_incluidos_en_programa':True,'prueba_arranque_extraido':'pendiente','paquetes':packages}
 (OUT/'VERIFICACION_PAQUETE.json').write_text(json.dumps(report,indent=2))
 (OUT/'README.md').write_text('''# Visor completo Windows · R8 experimental

[**Descargar el programa completo R8**](./perfeccion_Visualizador_R8_EXPERIMENTAL_COMPLETA.zip?raw=true)

Extrae todo en una carpeta nueva y abre **Iniciar.bat**. Si descargaste el repositorio entero con Code → Download ZIP, entra en `entregas/perfeccion_Visualizador_R8` y abre allí `Iniciar.bat`; también incluye las fuentes completas sin comprimir. Incluye `Visor_experimental_fuentes`. Si aparece un selector, elige la carpeta de R7 para reutilizar su entorno sin modificarlo; también puedes ejecutar `Instalar_Entorno.bat`. Python 3.12 de 64 bits. Encabezado R8 y puerto **8772**.

[Resultados reales y límites](./INFORME_RESULTADOS.md) · [Resultados CSV](./RESULTADOS_REGRESION.csv) · [Huellas de los ZIP](./PAQUETES_SHA256.json)

21/21 conversiones de regresión, cubo y tres giros, 213 pruebas automáticas. Bancada y pinza recuperan encuentros entre superficies y conservan los cilindros confirmados, con control CAD exacto y contraste independiente. Las tolerancias de Precisión siguen iguales a R7. Embudo permanece aplazado: no se declara 14/14.

**Windows nativo y Onshape siguen pendientes de prueba en esos entornos.** La validación real de esta entrega se ejecutó en Linux y navegador Chromium. No se declara resuelto el defecto visual de 6558 en Onshape.

Para revisar o reproducir, sin necesidad de descargarlos para usar el programa:

- [Kit de auditoría y materiales](./perfeccion_Visualizador_R8_AUDITORIA.zip?raw=true).
- [STEP, registros y reparaciones realmente obtenidos](./perfeccion_Visualizador_R8_RESULTADOS_STEP.zip?raw=true).
- [Reproducción](./REPRODUCIR.md), [fuentes modificadas](./archivos_modificados), [parche acumulado desde R7](./CAMBIOS_DESDE_R7.patch).

Esta es una copia experimental independiente del conversor web de main. No sustituye R7 ni recupera el historial paramétrico original.
''',encoding='utf-8')
 print(json.dumps(report,indent=2),flush=True)
if __name__=='__main__':main()
