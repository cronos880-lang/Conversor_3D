const {chromium}=require('playwright');const fs=require('fs'),path=require('path');
const root=__dirname,url='http://127.0.0.1:8774';
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 const page=await browser.newPage({acceptDownloads:true});const errors=[];page.on('pageerror',e=>errors.push(String(e)));let job;
 page.on('response',async r=>{if(r.url().endsWith('/iniciar-conversion'))try{job=(await r.json()).id}catch{}});
 const result={ok:false};
 try{
 await page.goto(url);await page.waitForFunction(()=>!document.getElementById('openBtn').disabled);
 await page.locator('#fileInput').setInputFiles('/workspace/work/paquete_perfeccion_Visualizador_R7/material_pruebas/stl_regresion_14/Bancada_Motor.stl');
 await page.waitForFunction(()=>!document.getElementById('convertBtn').disabled);await page.locator('#convertBtn').click();
 await page.waitForTimeout(3000);
 const cancelledJob=job;await page.locator('#newBtn').click();
 let state;for(let i=0;i<120;i++){state=await(await page.request.get(url+'/estado-conversion/'+cancelledJob)).json();if(state.estado!=='ejecutando')break;await page.waitForTimeout(500)}
 result.cancelacion=state;result.descarga_cancelada_http=(await page.request.get(url+'/descargar-conversion/'+cancelledJob)).status();
 if(state.estado!=='cancelado'||result.descarga_cancelada_http!==404)throw Error('La cancelación no bloquea la salida');
 await page.screenshot({path:path.join(root,'navegador','cancelacion.png')});
 await page.locator('#fileInput').setInputFiles(path.join(root,'caja_control.stl'));await page.waitForFunction(()=>!document.getElementById('convertBtn').disabled);
 await page.locator('#convertBtn').click();await page.waitForFunction(()=>document.getElementById('conversionPercent').textContent==='100 %'||document.getElementById('conversionPercent').classList.contains('failed'),{},{timeout:180000});
 if(await page.locator('#conversionPercent').evaluate(e=>e.classList.contains('failed')))throw Error(await page.locator('#error').innerText());
 page.once('dialog',d=>d.accept('caja_despues_cancelar'));const downloading=page.waitForEvent('download');await page.locator('#exportBtn').click();await(await downloading).saveAs(path.join(root,'navegador','caja_despues_cancelar.step'));
 result.nuevo_trabajo=await(await page.request.get(url+'/estado-conversion/'+job)).json();result.ok=result.nuevo_trabajo.estado==='terminado'&&job!==cancelledJob&&errors.length===0;
 await page.screenshot({path:path.join(root,'navegador','despues_cancelacion.png')});
 }catch(e){result.error=String(e)}finally{result.errores_js=errors;fs.writeFileSync(path.join(root,'cancelacion_resultado.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
