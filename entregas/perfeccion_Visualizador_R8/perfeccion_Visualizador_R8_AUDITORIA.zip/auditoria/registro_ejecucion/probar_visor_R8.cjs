const {chromium}=require('playwright');
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const root=__dirname,app=path.join(root,'motor_R8_VALIDACION_DEFINITIVA'),url='http://127.0.0.1:8774';
const output=path.join(root,'navegador');fs.mkdirSync(output,{recursive:true});
const protocol=JSON.parse(fs.readFileSync('/workspace/work/mejora_motor_post_r7_20261026/regresion_historica/protocolo.json'));
const cases=['M3 PClip - 2mm','cubo-carrito','Bancada_Motor','pinza','6558_fixed'].map(id=>protocol.casos.find(c=>c.id===id));
for(const name of ['V_legoBrick4x2','Soporte_movil_2','Technic_PEGS_Cross_x6_A'])cases.push({id:name,source:'/workspace/work/mejora_cad_post_avance_20261026/entradas_nuevas/'+name+'.stl',grupo:'recientes'});
if(process.env.VISOR_CASOS){const selected=process.env.VISOR_CASOS.split(',');for(let i=cases.length-1;i>=0;i--)if(!selected.includes(cases[i].id))cases.splice(i,1);}
const digest=data=>crypto.createHash('sha256').update(data).digest('hex');
(async()=>{
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});const rows=process.env.VISOR_ANEXAR==='1'?JSON.parse(fs.readFileSync(path.join(root,'navegador_resultados.json'))).resultados.filter(r=>!cases.some(c=>c.id===r.id)):[];
for(let i=0;i<120;i++){try{const ready=await fetch(url+'/version');if(ready.ok)break}catch{}await new Promise(resolve=>setTimeout(resolve,500));}
try{for(const item of cases){
const page=await browser.newPage({viewport:{width:1280,height:900},acceptDownloads:true});let job;const errors=[];let start=Date.now();const sourceHash=digest(fs.readFileSync(item.source));
page.on('pageerror',e=>errors.push(String(e)));page.on('response',async r=>{if(r.url().endsWith('/iniciar-conversion'))try{job=(await r.json()).id}catch{}});
let row={id:item.id,grupo:item.grupo,ruta:'interfaz_navegador',sha256:sourceHash,ok:false};
try{
 if(item.id==='Bancada_Motor'){while(!fs.existsSync(path.join(root,'pruebas_R8_completas.xml')))await new Promise(resolve=>setTimeout(resolve,1000));}
 if(item.id==='Bancada_Motor'){for(;;){let rows=[];try{rows=JSON.parse(fs.readFileSync(path.join(root,'regresion_cli.json'))).resultados}catch{}const lego=rows.find(r=>r.id==='1x1-lego-brick');if(lego){if(!lego.ok)throw Error('Primero resolver la regresión del Lego histórico');break}await new Promise(resolve=>setTimeout(resolve,1000));}}
 start=Date.now();console.log('INICIO',item.id);
 const identity=await(await page.request.get(url+'/version')).json();if(identity.instancia!==digest(Buffer.from(path.resolve(app))).slice(0,20))throw Error('El servidor pertenece a otra carpeta');
 await page.goto(url);await page.waitForFunction(()=>!document.getElementById('openBtn').disabled);
 if(!(await page.title()).includes('R8'))throw Error('Título distinto de R8');
 if(await page.locator('#conversionProfile').inputValue()!=='precision')throw Error('Perfil por defecto distinto de Precisión');
 await page.locator('#fileInput').setInputFiles(item.source);await page.waitForFunction(()=>!document.getElementById('convertBtn').disabled);
 await page.locator('#convertBtn').click();
 await page.waitForFunction(()=>document.getElementById('conversionPercent').textContent==='100 %'||document.getElementById('conversionPercent').classList.contains('failed'),{},{timeout:2200000});
 row.estado=await(await page.request.get(url+'/estado-conversion/'+job)).json();
 if(await page.locator('#conversionPercent').evaluate(e=>e.classList.contains('failed')))throw Error(await page.locator('#error').innerText());
 await page.waitForFunction(()=>!document.getElementById('exportBtn').disabled,{},{timeout:60000});row.detalle=await page.locator('#details').innerText();
 page.once('dialog',d=>d.accept(item.id+'_R8'));const downloading=page.waitForEvent('download');await page.locator('#exportBtn').click();const download=await downloading;
 const destination=path.join(output,item.id+'.step');await download.saveAs(destination);const bytes=fs.readFileSync(destination);
 row.sha256_step=digest(bytes);row.descarga_identica_backend=bytes.equals(fs.readFileSync(path.join(app,'Registros_Conversion',job+'.step')));
 const diagnostic=JSON.parse(fs.readFileSync(path.join(app,'Registros_Conversion',job+'.json'),'utf8'));row.diagnostico=diagnostic;
 if(diagnostic.archivos_reparacion?.reparado){const response=await page.request.get(url+diagnostic.archivos_reparacion.reparado);if(!response.ok())throw Error('No se descarga STL reparado');const data=await response.body();fs.writeFileSync(path.join(output,item.id+'_reparado.stl'),data);row.reparacion_hash_coincide=digest(data)===diagnostic.preprocesamiento.reparado_sha256;if(!row.reparacion_hash_coincide)throw Error('STL reparado distinto del certificado');}
 if(item.referencia_step){const b=fs.readFileSync(item.referencia_step);row.DATA_identico_R7=bytes.subarray(bytes.indexOf('DATA;')).equals(b.subarray(b.indexOf('DATA;')));}
 row.ok=row.descarga_identica_backend&&errors.length===0;
}catch(e){row.error=String(e);console.error(item.id,row.error)}finally{
 row.job=job;row.segundos=(Date.now()-start)/1000;row.errores_js=errors;row.original_sin_modificar=sourceHash===digest(fs.readFileSync(item.source));
 if(job){try{row.estado_final=await(await page.request.get(url+'/estado-conversion/'+job)).json();if(row.estado_final.estado==='ejecutando')await page.request.post(url+'/cancelar-conversion/'+job)}catch{}}
 await page.screenshot({path:path.join(output,item.id+'.png'),fullPage:true}).catch(()=>{});rows.push(row);fs.writeFileSync(path.join(output,item.id+'.json'),JSON.stringify(row,null,2));fs.writeFileSync(path.join(root,'navegador_resultados.json'),JSON.stringify({resultados:rows},null,2));console.log('FINAL',item.id,row.ok,row.segundos);await page.close();
}
}}finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
