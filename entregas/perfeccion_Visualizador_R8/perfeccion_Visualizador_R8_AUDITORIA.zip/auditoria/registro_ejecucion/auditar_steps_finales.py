"""Lectura fría independiente de todos los STEP realmente entregados por cada ruta."""
from pathlib import Path
import json,hashlib,sys,time
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'motor_R8_VALIDACION_DEFINITIVA'))
from calidad_topologica import leer_solido_step_estricto
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_SOLID
from collections import Counter
cache={}
if (ROOT/'lectura_fria_final.json').exists():
 cache={r['archivo']:r for r in json.loads((ROOT/'lectura_fria_final.json').read_text())}
approved={}
for name,folder in [('regresion_cli.json','regresion_cli'),('navegador_resultados.json','navegador')]:
 for record in json.loads((ROOT/name).read_text())['resultados']:
  if record['ok']:approved[str(Path(folder)/(record['id']+'.step'))]=record['sha256_step']
if (ROOT/'cancelacion_resultado.json').exists() and json.loads((ROOT/'cancelacion_resultado.json').read_text())['ok']:
 approved['navegador/caja_despues_cancelar.step']=None
rows=[]
for folder in ['regresion_cli','navegador']:
 for p in sorted((ROOT/folder).glob('*.step')):
  relative=str(p.relative_to(ROOT))
  if relative not in approved:continue
  row={'archivo':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()};start=time.monotonic()
  if approved[relative] is not None:assert row['sha256']==approved[relative]
  previous=cache.get(relative)
  if previous and previous['ok'] and previous['sha256']==row['sha256']:
   rows.append(previous);continue
  try:
   shape=leer_solido_step_estricto(p)
   row.update(solidos=len(shape.Solids()),caras=len(shape.Faces()),aristas=len(shape.Edges()),volumen_mm3=shape.Volume(),exacto=BRepCheck_Analyzer(shape.wrapped,True,False,True).IsValid(),tipos=dict(Counter(str(BRepAdaptor_Surface(f.wrapped).GetType()) for f in shape.Faces())))
   row['ok']=row['solidos']==1 and row['exacto'] and row['volumen_mm3']>0
  except Exception as e:row.update(ok=False,error=str(e))
  row['segundos']=time.monotonic()-start;rows.append(row);(ROOT/'lectura_fria_final.json').write_text(json.dumps(rows,indent=2));print(row['archivo'],row['ok'],row.get('caras'),flush=True)
(ROOT/'lectura_fria_final.json').write_text(json.dumps(rows,indent=2))
raise SystemExit(0 if rows and all(r['ok'] for r in rows) else 1)
