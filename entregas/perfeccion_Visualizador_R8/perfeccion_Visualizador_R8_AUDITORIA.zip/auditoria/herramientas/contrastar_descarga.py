from pathlib import Path
import argparse,subprocess,os,sys
p=argparse.ArgumentParser();p.add_argument("stl",type=Path);p.add_argument("step",type=Path);p.add_argument("informe",type=Path);a=p.parse_args()
root=Path(__file__).resolve().parent.parent
raise SystemExit(subprocess.run([sys.executable,str(root/"herramientas/contraste_geometrico_independiente.py"),str(a.stl.resolve()),str(a.step.resolve()),str(a.informe.resolve())],env={**os.environ,"VISOR_EVALUADOR_R7":str(root/"evaluador_R7_inmutable"),"VISOR_CONTROL_FRONTERA":str(root/"herramientas/control_frontera_inmutable_M1.py"),"OMP_NUM_THREADS":"1","OPENBLAS_NUM_THREADS":"1"}).returncode)
