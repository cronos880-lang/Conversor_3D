"""Repetir los 21 casos contra el motor indicado, sin inventar éxitos."""
from pathlib import Path
import argparse,sys,json,hashlib
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--motor',type=Path,required=True);p.add_argument('--auditoria',type=Path,required=True);p.add_argument('--salida',type=Path,required=True);a=p.parse_args()
 motor=a.motor.resolve();root=a.auditoria.resolve();out=a.salida.resolve();out.mkdir(parents=True,exist_ok=True)
 sys.path.insert(0,str(motor));from bateria_reparacion import ejecutar
 manifest=json.loads((root/'motor_R8_VALIDACION_DEFINITIVA_sha256.json').read_text());cases=json.loads((root/'PROTOCOLO_PORTABLE.json').read_text())['casos'];rows=[]
 for case in cases:
  for rel,sha in manifest.items():assert hashlib.sha256((motor/rel).read_bytes()).hexdigest()==sha,rel
  source=root/case['source'];assert hashlib.sha256(source.read_bytes()).hexdigest()==case['sha256']
  row=ejecutar(motor,source,out/(case['id']+'.step'),limite=case['limite_s'],memoria_mb=4500,extra_env={'VISOR_PERFIL':'precision'})
  row['id']=case['id'];rows.append(row);(out/'resultados.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False));print(case['id'],row['ok'],row['segundos'],flush=True)
 return 0 if len(rows)==21 and all(r['ok'] for r in rows) else 1
if __name__=='__main__':raise SystemExit(main())
