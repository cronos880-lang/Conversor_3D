import cadquery as cq,numpy as np,time,json
from pathlib import Path
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeVertex
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
from OCP.gp import gp_Pnt
import trimesh
s=cq.importers.importStep('/workspace/work/perfeccion_Visualizador_r2/evidencias/aceptados_finales/Pieza ambigua.step').solids().val()
m=trimesh.load('/workspace/work/casos_usuario_r3/Pieza ambigua.stl',force='mesh')
p=m.vertices[np.linspace(0,len(m.vertices)-1,200,dtype=int)]
out={}
for reuse in (False,True):
 start=time.perf_counter();d=[];ext=BRepExtrema_DistShapeShape();ext.LoadS2(s.Shells()[0].wrapped)
 for x in p:
  v=BRepBuilderAPI_MakeVertex(gp_Pnt(*map(float,x))).Vertex()
  if reuse:ext.LoadS1(v)
  else:ext=BRepExtrema_DistShapeShape(v,s.Shells()[0].wrapped)
  ext.Perform();assert ext.IsDone();d.append(ext.Value())
 out[str(reuse)]={'segundos':time.perf_counter()-start,'distancias':d};print(reuse,out[str(reuse)]['segundos'],flush=True)
assert np.allclose(out['False']['distancias'],out['True']['distancias'],rtol=0,atol=1e-10)
Path('evidencias/comparacion_distancias_reutilizadas.json').write_text(json.dumps(out,indent=2))
