# perfeccion_Visualizador

El cubo-carrito y sus tres giros han pasado conversión STEP y reimportación con
los límites geométricos originales. También pasan 35 pruebas y las 12 regresiones
que antes convertían. La validación global de 14 piezas y Windows está pendiente.

1. Abrir `INFORME_RESULTADOS.md` para ver resultados y límites reales.
2. Para probar el CAD directamente: `evidencias/cubo_bateria/cubo-carrito.step`.
3. Para probar la aplicación: conservar esta carpeta separada y abrir
   `Visor_experimental_fuentes/LEEME.txt`. No sobrescribir la instalación estable.

Es la copia Python experimental del Visor aportado. La aplicación WebAssembly de
GitHub Pages conserva su versión anterior. El ZIP incluye fuentes completas,
parche, STL de prueba, STEP válidos, registros y resultados verificables.
