# perfeccion_Visualizador — fase cubo-carrito

Esta copia contiene una implementación de diagnóstico y reparación conservadora.
No es una sustitución estable de R1. Consultar `../INFORME_RESULTADOS.md` y las
evidencias incluidas en la entrega para conocer los resultados reales.

La unión de la malla del cubo-carrito y la conversión CAD son puertas distintas.
Un STL reparado no autoriza a declarar válido el STEP. El motor sigue rechazando
los candidatos que no pasan sus controles geométricos originales.

Esta fase añade una ruta CAD de mayor precisión únicamente tras una reparación
booleana verificada y para mallas de hasta 5.000 triángulos. No depende del nombre
del archivo. Las entradas sanas siguen sus estrategias anteriores. La nueva
ruta limita ajustes de regiones a 0,015 mm, B-splines a 0,005 mm y aristas a
0,003 mm; rechaza coeficientes numéricamente desproporcionados. El validador
histórico y todos sus límites conservan su código original.

Los resultados efectivos del cubo y tres giros, las regresiones repetidas y
las pruebas pendientes se detallan en el informe. El embudo se ha aplazado
por indicación del propietario. No se declara superada la batería global de 14.

Windows y la edición Move face de Onshape requieren ejecución real externa.
La disponibilidad de dependencias Windows no equivale a haber probado Windows.

Trabajar en esta carpeta independiente. El servidor experimental usa el puerto
8766; la R1 original usa 8765. El HTML, sus cuatro botones, título y flujo Nuevo
se conservan sin cambios. `VISOR_PREPROCESADOR=0` permite ejecutar el núcleo de
entrada histórico para comparar; no convierte un fallo en éxito.
