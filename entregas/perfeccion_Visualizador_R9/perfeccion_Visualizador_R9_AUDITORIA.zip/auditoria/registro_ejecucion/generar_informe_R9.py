"""Publicar resultados únicamente cuando terminen todos los controles previstos."""
from pathlib import Path
import json,hashlib,datetime,csv,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent
R8=Path('/workspace/work/r8_integracion_verificada_20261027')
def read(name):return json.loads((ROOT/name).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def quality(row):return row.get('diagnostico',{}).get('calidad') or row.get('informe_motor',{}).get('resultado',{}).get('calidad',{})
def main():
    manifest=read('FUENTES_R9_SHA256.json')
    assert all(sha(ROOT/'motor_R9_CONGELADO'/p)==v for p,v in manifest.items())
    rows=read('regresion_cli.json')['resultados']+read('navegador_resultados.json')['resultados']
    index={r['id']:r for r in rows};protocol=read('preparacion_entrega/auditoria/PROTOCOLO_PORTABLE.json')
    required=[index[c['id']] for c in protocol['casos']]
    assert len(required)==21 and all(r['ok'] for r in required)
    assert all(index[c['id']]['segundos']<=c['limite_s'] for c in protocol['casos']), 'Una conversión excedió el presupuesto del protocolo'
    assert len(rows)==24 and len(index)==24 and all(r['ok'] for r in rows)
    assert all(not r.get('errores_js') and r.get('original_sin_modificar',True) for r in rows)
    gui=[r for r in rows if r['ruta']=='interfaz_navegador'];assert len(gui)==9
    assert all(r['descarga_identica_backend'] for r in gui)
    suites=list(ET.parse(ROOT/'pruebas_R9_completas.xml').iter('testsuite'))
    stats={k:sum(int(s.get(k,0)) for s in suites) for k in ['tests','failures','errors','skipped']}
    assert stats['tests']==233 and not any(stats[k] for k in ['failures','errors','skipped'])
    cold=read('lectura_fria_R9.json');assert all(r['ok'] for r in cold)
    assert len([r for r in cold if Path(r['archivo']).stem in index])==24
    cancel=read('cancelacion_resultado.json');assert cancel['ok']
    controls={n:read('contrastes_independientes/'+n+'.json') for n in ['LLanta_Trasera','V_legoBrick4x2']}
    assert all(v['aprobado'] and v['step_exacto'] for v in controls.values())
    assert controls['LLanta_Trasera']['cilindros']['conservados']==controls['LLanta_Trasera']['cilindros']['confirmados_fuente']==15
    assert controls['V_legoBrick4x2']['cilindros']['conservados']>=12
    assert controls['V_legoBrick4x2']['topologia_material']['cavidades_preservadas']==8
    assert read('AUDITORIA_TOLERANCIAS.json')['sin_relajar']
    summary={'version':'R9 experimental','compilacion':'2026.10.27-cilindros-verificados',
             'fecha_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'fuentes_congeladas':len(manifest),'pruebas_automaticas':stats,
             'regresion':{'casos':21,'aprobados':21,'cubo_y_giros':4,'historicas':13,'historicas_totales':14,'Embudo':'aplazado por el usuario'},
             'recientes_adicionales':3,'interfaz_real':9,'CLI':15,'tolerancias_sin_relajar':True,
             'Windows_nativo':'NO EJECUTADO','Onshape':'NO EJECUTADO','K1C':'NO EJECUTADO','casos':[]}
    tables=['| Pieza | Ruta | s | Caras R8 → R9 | Caras cilíndricas R8 → R9 | Máx. observado mm | Error volumen % | DATA igual R8 |',
            '|---|---|---:|---:|---:|---:|---:|---|']
    comparisons=[]
    old={Path(v['archivo']).stem:v for v in json.loads((R8/'lectura_fria_final.json').read_text())}
    ordered=required+[index[n] for n in ['V_legoBrick4x2','Soporte_movil_2','Technic_PEGS_Cross_x6_A']]
    for row in ordered:
        q=quality(row);folder='navegador' if row['ruta']=='interfaz_navegador' else 'regresion_cli';step=ROOT/folder/(row['id']+'.step')
        assert sha(step)==row['sha256_step']
        if row['id'] in controls:assert controls[row['id']]['sha256_step']==sha(step)
        source_record=next((c for c in protocol['casos'] if c['id']==row['id']),None)
        if source_record:assert row['sha256']==source_record['sha256']
        assert q['perfil_validacion']['id']=='precision' and q['integridad_cad']['brep_exacto']
        assert q['interferencias_comprobadas_en_frio'] and q['autointerferencias_occ'] is False
        before=old[row['id']];before_cyl=sum(v for k,v in before['tipos'].items() if 'Cylinder' in k)
        current_cyl=sum(v for k,v in q['tipos_caras'].items() if 'Cylinder' in k)
        reference=R8/before['archivo'];a=step.read_bytes();b=reference.read_bytes();same=a[a.index(b'DATA;'):]==b[b.index(b'DATA;'):]
        r={'id':row['id'],'ruta':row['ruta'],'segundos':row['segundos'],'caras_R8':before['caras'],'caras_R9':q['caras_step'],
           'caras_cilindricas_R8':before_cyl,'caras_cilindricas_R9':current_cyl,'max_observado_mm':q['desviacion_max_verificada_mm'],
           'caja_error_mm':q['caja_error_mm'],'volumen_error_pct':q['volumen_error_pct'],'DATA_identico_R8':same,'sha256_step':sha(step)}
        summary['casos'].append(r);comparisons.append(r)
        tables.append(f"| {row['id']} | {'Visor' if folder=='navegador' else 'CLI'} | {row['segundos']:.1f} | {before['caras']} → {q['caras_step']} | {before_cyl} → {current_cyl} | {r['max_observado_mm']} | {r['volumen_error_pct']} | {'sí' if same else 'no'} |")
    wheel=quality(index['LLanta_Trasera']);lego=quality(index['V_legoBrick4x2'])
    assert wheel['caras_step']<=100 and lego['caras_step']<.75*1692
    text=f'''# Visor STL → STEP · R9 experimental completa

La R8 conseguía convertir muchas piezas recurriendo a caras planas en superficies cilíndricas. Esta copia experimental corrige encuentros y costuras de cilindros y añade reconstrucción local después de una recuperación facetada. El coordinador del motor (`motor_v2.py`), los perfiles, los límites globales y los validadores geométricos conservan sus archivos originales. R7, R8 y la web de main permanecen separados.

## Mejora demostrada en el programa completo

- **Llanta trasera:** de **4.195 caras planas y ningún cilindro** a **{wheel['caras_step']} caras**, de las que {wheel['tipos_caras'].get('GeomAbs_Cylinder',0)} son cilíndricas. Se conservan los **15 cilindros confirmados en el STL**. Una superficie física puede estar dividida en dos caras para colocar su costura; treinta caras cilíndricas no significan treinta cilindros físicos. Máximo geométrico observado: **{wheel['desviacion_max_verificada_mm']} mm**.
- **Lego 4×2:** de **1.692 caras planas y ningún cilindro** a **{lego['caras_step']} caras**, con **{lego['tipos_caras'].get('GeomAbs_Cylinder',0)} caras cilíndricas**. El contraste independiente acredita {controls['V_legoBrick4x2']['cilindros']['conservados']} de los {controls['V_legoBrick4x2']['cilindros']['confirmados_fuente']} soportes cilíndricos confirmados; los restantes siguen sin reconstrucción analítica confirmada. El inventario independiente incluye también detalles cilíndricos parciales: se distingue de las 19 paredes completas elegibles para la reconstrucción local. Se conservan **las ocho cavidades**. Máximo observado: **{lego['desviacion_max_verificada_mm']} mm**. Es un STEP mixto; las otras zonas conservan facetas y se indica en la interfaz.

Ambos se han importado, convertido y descargado desde la interfaz real con Chromium. Los archivos descargados coinciden byte a byte con los validados por el servidor. El contraste independiente se ejecuta sobre esos mismos archivos, identificados por SHA-256, usando la geometría R7 y el control de frontera M1 inmutables.

## Cambios del motor

1. Se distingue una costura entre mitades del **mismo cilindro** de una intersección entre cilindros diferentes. No se fusionan radios ni ejes próximos que representen superficies distintas. Se mantiene primero la reconstrucción anterior; las medias cañas adicionales sólo se ensayan después de un rechazo real.
2. Se verifica también la proyección geométrica dentro del **recorte UV real** de la cara. Esto evita un falso rechazo de OCC observado en un borde circular. No basta con estar cerca del cilindro infinito: los tests de cilindros truncados y ventanas taladradas deben seguir rechazándose.
3. En una recuperación facetada ya válida se pueden reemplazar paredes completas con dos anillos planos, circulares y coaxiales. Se comprueba el interior de las facetas, no sólo sus vértices; la cota radial local es **0,008 mm**. Se rechazan polígonos poco resueltos, ranuras, conicidad real y bandas que invadan una pared vecina. Los booleanos son no destructivos y usan fuzzy **0**.
4. La mejora local corre aislada y conserva una copia del STEP previo. Exige una reducción de caras y vuelve a validar geometría, cilindros, material y tres mallados finos. Si falla, se agota su tiempo o faltan pruebas, se conserva la recuperación anterior. La publicación de la candidata se hace mediante sustitución atómica, después de verificar sus huellas.

Se ensayó una compactación de la llanta a 38 caras. Aunque pasaba los controles generales de geometría y CAD exacto, falló el control topológico adicional y **se descartó**. No se ha rebajado ese control para aprobarla.

## Pruebas reales de esta copia congelada

**233 pruebas automáticas, cero fallos, errores u omisiones.** Incluyen negativos de costuras, radios distintos, recortes con ventanas, polígonos, conos, ranuras, paredes delgadas, preservación de una cavidad, inmutabilidad de la base, tiempo agotado y reutilización del entorno R8 sin modificarlo.

**21/21 conversiones principales aprobadas:** cubo-carrito y tres giros, trece de las catorce históricas y cuatro casos adicionales del protocolo. Se ejecutaron seis por interfaz y quince por CLI. Además aprobaron Lego4×2, soporte móvil y Technic por la interfaz: **24 conversiones distintas**, nueve de ellas mediante el flujo real del navegador. Cada STEP se volvió a abrir en frío exigiendo un único sólido positivo y coherencia CAD exacta. La batería incorpora BOP; los contrastes independientes no lo sustituyen.

**Embudo sigue aplazado por instrucción del propietario. No se declara 14/14.** Octogon y Barrera_Lego sólo se recibieron como STEP, por lo que no se han vuelto a convertir en esta entrega. Su inspección de R8 se conserva separada.

El contraste independiente de llanta y Lego comprueba geometría con R7, coherencia exacta, topología de material y tres discretizaciones finas cerradas, orientadas y sin intersecciones CGAL. En Lego se exige conservar las ocho cavidades; el inventario reconoce expresamente las paredes que siguen facetadas.

Se probó cancelar con Nuevo, bloquear la descarga cancelada y convertir/exportar después una caja. Las huellas de las {len(manifest)} fuentes se verifican durante las pruebas y al extraer el paquete. Los originales STL no se modifican.

## Comparación completa con R8

Los tiempos son medidas reales en Linux, con dos CPU de cuota y colas de prueba concurrentes. No son una predicción de velocidad en Windows ni una comparación de rendimiento controlada con R8. Buscar una mejor reconstrucción puede añadir tiempo a piezas que finalmente conservan facetas. «DATA igual R8» compara la sección geométrica STEP omitiendo su encabezado; una diferencia se juzga mediante los controles, no por el texto del archivo.

'''+ '\n'.join(tables)+'''

## Precisión y límites que permanecen

El coordinador motor_v2.py, los perfiles, la política global de tiempo y memoria, la normalización de referencias y los validadores geométricos/topológicos permanecen byte a byte iguales a R8. Precisión mantiene caja 0,020 mm, volumen 0,5 %, p95 base 0,020 mm con sus condiciones originales, y máximo base 0,060 mm. La cota local de reconstrucción es adicional; no aumenta esos límites. Los máximos de la tabla son observados y no una garantía absoluta para cualquier punto de cualquier STL.

El perfil Impresión 3D sigue permitiendo otro presupuesto de error, pero no es un selector de suavizado ni obliga a recuperar más cilindros. Todas estas pruebas usaron Automático (precisión). No se cambia automáticamente a 0,08 para obtener una conversión.

Algunas piezas conservan superficies facetadas. No se afirma que todas recuperen cilindros, que todas tengan menos caras, ni que se haya recuperado el historial paramétrico original. La mezcla de caras analíticas y facetas se identifica en la interfaz. La geometría CAD exacta y una menor triangulación son controles distintos; superar uno no demuestra el otro.

## Uso y pruebas pendientes

Extrae el ZIP completo en una carpeta nueva y abre **Iniciar.bat**. Incluye **Visor_experimental_fuentes** y los lanzadores. Si aparece el selector, elige tu carpeta R7 o R8 para reutilizar su entorno sin modificarla. Si necesitas uno nuevo, usa Instalar_Entorno.bat con Python 3.12 de 64 bits. R9 abre **http://127.0.0.1:8775**; R8 puede seguir en 8772 y R7 en 8771. El encabezado debe mostrar **R9 experimental**.

**Windows nativo no se ha ejecutado en este entorno Linux.** Se comprobaron lanzadores, comillas, CRLF, rutas con espacios, selección del entorno y la versión servida. Las dependencias no cambian respecto a R8; la comprobación de disponibilidad de sus ruedas Windows se conserva como evidencia, y no equivale a probar Windows. **Onshape y la K1C tampoco se han probado.** El defecto visual de 6558 necesita comprobación allí; no se da por resuelto por convertir correctamente.

La entrega incluye fuentes completas y modificadas, parche desde R8, manifiestos, registros, STEP realmente obtenidos, capturas de la interfaz y materiales para repetir la batería. Las capturas del Visor muestran el STL de entrada; la calidad del STEP se acredita por la inspección CAD de los archivos exportados. Los resultados descartados se mantienen separados de los aprobados.
'''
    (ROOT/'INFORME_RESULTADOS.md').write_text(text,encoding='utf-8')
    (ROOT/'ACEPTACION_R9.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
    with (ROOT/'RESULTADOS_REGRESION.csv').open('w',encoding='utf-8-sig',newline='') as file:
        writer=csv.DictWriter(file,fieldnames=list(comparisons[0]));writer.writeheader();writer.writerows(comparisons)
    print('INFORME APROBADO:21 principales +3 recientes,233 tests,contrastes y lectura fría completos',flush=True)
if __name__=='__main__':main()
