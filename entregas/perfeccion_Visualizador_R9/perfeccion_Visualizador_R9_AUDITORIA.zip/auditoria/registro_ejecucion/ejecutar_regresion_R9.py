import sys,json,hashlib,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
MOTOR=ROOT/'motor_R9_CONGELADO'
sys.path.insert(0,str(MOTOR))
from bateria_reparacion import ejecutar
protocol=json.loads(Path('/workspace/work/mejora_motor_post_r7_20261026/regresion_historica/protocolo.json').read_text())
manifest=json.loads((ROOT/'FUENTES_R9_SHA256.json').read_text())
cases=[c for c in protocol['casos'] if c['id'] not in ['Bancada_Motor','pinza','cubo-carrito','6558_fixed','M3 PClip - 2mm','LLanta_Trasera']]
cases.sort(key=lambda c:0 if c['id']=='1x1-lego-brick' else 1 if c['grupo']=='historica12' else 2 if c['grupo']=='cubo4' else 4 if c['id']=='Pieza_Nueva_Detenida' else 3)
out=ROOT/'regresion_cli';out.mkdir(exist_ok=True)
rows=[]
while True:
 try:
  browser=json.loads((ROOT/'navegador_resultados.json').read_text())['resultados'];lego=next((x for x in browser if x['id']=='V_legoBrick4x2'),None)
  if lego is not None:
   if not lego['ok']:raise RuntimeError('Resolver primero Lego4x2 desde la interfaz')
   break
 except (FileNotFoundError,json.JSONDecodeError):pass
 time.sleep(1)
for case in cases:
 for rel,sha in manifest.items():
  assert hashlib.sha256((MOTOR/rel).read_bytes()).hexdigest()==sha,rel
 source=Path(case['source']);assert hashlib.sha256(source.read_bytes()).hexdigest()==case['sha256']
 print('INICIO',case['id'],flush=True)
 row=ejecutar(MOTOR,source,out/(case['id']+'.step'),limite=case['limite_s'],memoria_mb=4500,extra_env={'VISOR_PERFIL':'precision','PYTHONDONTWRITEBYTECODE':'1'})
 row['id']=case['id'];row['grupo']=case['grupo'];row['ruta']='CLI'
 assert hashlib.sha256(source.read_bytes()).hexdigest()==case['sha256']
 if row['ok']:
  a=(out/(case['id']+'.step')).read_bytes();b=Path(case['referencia_step']).read_bytes()
  row['DATA_identico_R7']=a[a.index(b'DATA;'):]==b[b.index(b'DATA;'):]
 rows.append(row);(ROOT/'regresion_cli.json').write_text(json.dumps({'resultados':rows},indent=2,ensure_ascii=False))
 print('FINAL',case['id'],row['ok'],row['segundos'],flush=True)
