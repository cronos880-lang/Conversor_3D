"""Empaquetar la candidata aceptada y verificar una extracción real."""
from pathlib import Path
import json,hashlib,zipfile,shutil
ROOT=Path(__file__).resolve().parent
STAGE=ROOT/'preparacion_entrega';OUT=ROOT/'entrega_GitHub/perfeccion_Visualizador_R9'
EXTRACT=ROOT/'verificacion paquete R9'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(a,b):b.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(a,b)
def archive(base,target,prefix=''):
    files=sorted(p for p in base.rglob('*') if p.is_file() and p.name!='MANIFIESTO_SHA256.json'
                 and not any(x in p.parts for x in ['__pycache__','.pytest_cache','.venv']))
    manifest={str(p.relative_to(base)):sha(p) for p in files}
    (base/'MANIFIESTO_SHA256.json').write_text(json.dumps(manifest,indent=2));files.append(base/'MANIFIESTO_SHA256.json')
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(files):z.write(p,str(Path(prefix)/p.relative_to(base)))
    assert target.stat().st_size<95*1024**2,(target.name,target.stat().st_size)
    with zipfile.ZipFile(target) as z:assert z.testzip() is None
    return {'archivo':target.name,'bytes':target.stat().st_size,'sha256':sha(target),'ficheros':len(files)}

def main():
    acceptance=json.loads((ROOT/'ACEPTACION_R9.json').read_text());assert acceptance['regresion']['aprobados']==21
    assert acceptance['pruebas_automaticas']['tests']==233
    app=STAGE/'programa';qa=STAGE/'auditoria';results=STAGE/'resultados';targets=STAGE/'comparar_cilindros'
    OUT.mkdir(parents=True,exist_ok=True)
    for name in ['INFORME_RESULTADOS.md','ACEPTACION_R9.json','RESULTADOS_REGRESION.csv','AUDITORIA_TOLERANCIAS.json','ARCHIVOS_MODIFICADOS_R8.json','FUENTES_R9_SHA256.json','ENTORNO_R9.json']:
        for folder in [app,qa,OUT]:copy(ROOT/name,folder/name)
    for name in ['pruebas_R9_completas.xml','pruebas_R9_completas.stdout','regresion_cli.json','navegador_resultados.json','cancelacion_resultado.json','lectura_fria_R9.json']:
        copy(ROOT/name,qa/name)
    for name in ['probar_visor_R9.cjs','probar_cancelacion.cjs','auditar_steps_R9.py','ejecutar_regresion_R9.py','generar_informe_R9.py','empaquetar_R9.py','cerrar_auditorias.py']:
        copy(ROOT/name,qa/'registro_ejecucion'/name)
    copy(ROOT/'contrastar_cilindros_independiente.py',qa/'herramientas/contrastar_cilindros_independiente.py')
    for p in (ROOT/'contrastes_independientes').iterdir():
        if p.is_file():copy(p,qa/'contrastes_independientes'/p.name)
    shutil.copytree(ROOT/'incidencias_orquestacion',qa/'incidencias_orquestacion_NO_APROBADAS',dirs_exist_ok=True)
    for name in ['LLanta_Trasera_independiente.stdout','V_legoBrick4x2_independiente.stdout']:
        copy(ROOT/name,qa/name)
    approved_names={r['id']+'.step' for name in ['regresion_cli.json','navegador_resultados.json'] for r in json.loads((ROOT/name).read_text())['resultados'] if r['ok']}|{'caja_despues_cancelar.step'}
    for folder in ['regresion_cli','navegador']:
        for p in (ROOT/folder).iterdir():
            if not p.is_file():continue
            if p.suffix.lower()=='.step' and p.name not in approved_names:continue
            copy(p,results/folder/p.name)
            if p.suffix=='.json':copy(p,qa/'evidencias'/folder/p.name)
    gui=json.loads((ROOT/'navegador_resultados.json').read_text())['resultados']
    cancellation=json.loads((ROOT/'cancelacion_resultado.json').read_text());assert cancellation['ok']
    jobs={r['job'] for r in gui}|{cancellation['cancelacion']['id'],cancellation['nuevo_trabajo']['id']}
    for job in jobs:
        for p in (ROOT/'motor_R9_CONGELADO/Registros_Conversion').glob(job+'.*'):
            if job==cancellation['cancelacion']['id'] and p.suffix=='.step':continue
            copy(p,results/'Registros_Conversion'/p.name)
    targets.mkdir(exist_ok=True)
    for name in ['LLanta_Trasera','V_legoBrick4x2']:
        p=ROOT/'navegador'/(name+'.step')
        row=next(r for r in gui if r['id']==name);assert sha(p)==row['sha256_step']
        copy(p,targets/(name+'_R9.step'));copy(p,OUT/'STEP_PARA_PROBAR'/(name+'_R9.step'))
    (targets/'LEEME.txt').write_text('STEP obtenidos realmente desde la interfaz R9 y contrastados con el servidor por SHA-256.\nLlanta: 53 caras y 15 cilindros fuente conservados. Lego4x2: 1149 caras, 12 cilíndricas; otras zonas siguen facetadas.\nImporta estos archivos en tu CAD para compararlos con R8. Onshape y Windows nativo no se han ejecutado aquí.\nConsulta INFORME_RESULTADOS.md para los límites y las medidas geométricas.\n',encoding='utf-8')
    manifest=json.loads((ROOT/'FUENTES_R9_SHA256.json').read_text())
    for rel,digest in manifest.items():
        p=app/'Visor_experimental_fuentes'/rel;assert sha(p)==digest
        copy(p,OUT/'Visor_experimental_fuentes'/rel)
    for change in json.loads((ROOT/'ARCHIVOS_MODIFICADOS_R8.json').read_text()):
        rel=change['archivo'];copy(app/'Visor_experimental_fuentes'/rel,OUT/'archivos_modificados'/rel)
    for name in ['Iniciar.bat','Instalar_Entorno.bat','LEEME_PRIMERO.txt']:copy(app/name,OUT/name)
    for name in ['CAMBIOS_DESDE_R8.patch','REPRODUCIR.md']:copy(qa/name,OUT/name)
    packages=[archive(app,OUT/'perfeccion_Visualizador_R9_EXPERIMENTAL_COMPLETA.zip'),
              archive(qa,OUT/'perfeccion_Visualizador_R9_AUDITORIA.zip','auditoria'),
              archive(results,OUT/'perfeccion_Visualizador_R9_RESULTADOS_STEP.zip','resultados'),
              archive(targets,OUT/'R9_CILINDROS_PARA_COMPARAR.zip','STEP_PARA_PROBAR')]
    (OUT/'PAQUETES_SHA256.json').write_text(json.dumps(packages,indent=2))
    assert not EXTRACT.exists(),'Verificar en una carpeta nueva'
    EXTRACT.mkdir()
    for entry in packages[:3]:
        with zipfile.ZipFile(OUT/entry['archivo']) as z:z.extractall(EXTRACT/('programa' if 'COMPLETA' in entry['archivo'] else '.'))
    for folder in ['programa','auditoria','resultados']:
        base=EXTRACT/folder
        for rel,digest in json.loads((base/'MANIFIESTO_SHA256.json').read_text()).items():assert sha(base/rel)==digest,(folder,rel)
    assert all(sha(EXTRACT/'programa/Visor_experimental_fuentes'/p)==v for p,v in manifest.items())
    verification={'CRC_cuatro_zip':True,'extraccion_real':True,'ruta_con_espacios':True,'fuentes_identicas':len(manifest),
                  'arranque_extraido':'pendiente','Windows_nativo':False,'Onshape':False,'paquetes':packages}
    (OUT/'VERIFICACION_PAQUETE.json').write_text(json.dumps(verification,indent=2))
    (OUT/'README.md').write_text('''# Visor completo para Windows · R9 experimental

[**Descargar R9 completa**](./perfeccion_Visualizador_R9_EXPERIMENTAL_COMPLETA.zip?raw=true) · [**STEP de llanta y Lego para comparar**](./R9_CILINDROS_PARA_COMPARAR.zip?raw=true)

Extrae todo en una carpeta nueva y abre **Iniciar.bat**. Incluye `Visor_experimental_fuentes`. Si descargas el repositorio entero con Code → Download ZIP, entra en `entregas/perfeccion_Visualizador_R9` y abre allí Iniciar.bat: también incluye las fuentes sin comprimir. Puede reutilizar el entorno de R7 o R8 sin modificarlo; si necesitas instalar uno, usa Instalar_Entorno.bat con Python 3.12 de 64 bits. Encabezado **R9 experimental**, puerto **8775**.

La llanta pasa de 4.195 caras planas a 53 caras y conserva sus 15 cilindros confirmados. Lego4×2 pasa de 1.692 caras planas a 1.149 caras, con 12 cilíndricas; mantiene ocho cavidades y otras zonas siguen facetadas. Se exige geometría, CAD exacto, BOP y las verificaciones adicionales de reconstrucción. Los límites de Precisión no se amplían.

[Informe real y limitaciones](./INFORME_RESULTADOS.md) · [Tabla CSV](./RESULTADOS_REGRESION.csv) · [Verificación del paquete](./VERIFICACION_PAQUETE.json)

21/21 conversiones principales y 3 recientes, 233 pruebas automáticas. Embudo sigue aplazado: no se declara 14/14. **Windows nativo, Onshape y K1C siguen pendientes de prueba.** La revisión visual de 6558 en Onshape no se declara resuelta. No se promete reconstrucción completa ni menos facetas en todas las piezas.

Material adicional, innecesario para usar el programa:

- [Kit de auditoría](./perfeccion_Visualizador_R9_AUDITORIA.zip?raw=true).
- [Todos los STEP y registros obtenidos](./perfeccion_Visualizador_R9_RESULTADOS_STEP.zip?raw=true).
- [Reproducción](./REPRODUCIR.md), [archivos modificados](./archivos_modificados) y [parche desde R8](./CAMBIOS_DESDE_R8.patch).
- [STEP individuales](./STEP_PARA_PROBAR).

Esta es una copia experimental independiente. No modifica R8, R7 ni la web de main. No recupera el historial paramétrico original.
''',encoding='utf-8')
    print(json.dumps(verification,indent=2),flush=True)
if __name__=='__main__':main()
