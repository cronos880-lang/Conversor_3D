"""Lectura fría de los archivos aprobados, con caché sólo para bytes idénticos."""
from pathlib import Path
import sys,json,hashlib,time,collections
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'motor_R9_CONGELADO'))
from calidad_topologica import leer_solido_step_estricto
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.BRepAdaptor import BRepAdaptor_Surface
cache={}
if (ROOT/'lectura_fria_R9.json').exists():
    cache={r['archivo']:r for r in json.loads((ROOT/'lectura_fria_R9.json').read_text())}
until=time.monotonic()+3*3600
while True:
    approved={}
    for name,folder in [('regresion_cli.json','regresion_cli'),('navegador_resultados.json','navegador')]:
        try:
            for row in json.loads((ROOT/name).read_text())['resultados']:
                if row['ok']:approved[str(Path(folder)/(row['id']+'.step'))]=row['sha256_step']
        except (FileNotFoundError,json.JSONDecodeError):pass
    try:
        if json.loads((ROOT/'cancelacion_resultado.json').read_text())['ok']:
            approved['navegador/caja_despues_cancelar.step']=None
    except (FileNotFoundError,json.JSONDecodeError):pass
    for rel,expected in sorted(approved.items()):
        path=ROOT/rel;digest=hashlib.sha256(path.read_bytes()).hexdigest()
        if expected is not None:assert digest==expected,rel
        if rel in cache and cache[rel]['ok'] and cache[rel]['sha256']==digest:continue
        start=time.monotonic();shape=leer_solido_step_estricto(path)
        row={'archivo':rel,'sha256':digest,'solidos':len(shape.Solids()),'caras':len(shape.Faces()),
             'volumen_mm3':shape.Volume(),'exacto':BRepCheck_Analyzer(shape.wrapped,True,False,True).IsValid(),
             'tipos':dict(collections.Counter(str(BRepAdaptor_Surface(f.wrapped).GetType()) for f in shape.Faces()))}
        row['ok']=row['solidos']==1 and row['volumen_mm3']>0 and row['exacto'];row['segundos']=time.monotonic()-start
        cache[rel]=row;(ROOT/'lectura_fria_R9.json').write_text(json.dumps(list(cache.values()),indent=2))
        print(rel,row['ok'],row['caras'],flush=True)
        assert row['ok'],rel
    if '--seguir' not in sys.argv or len(approved)==25:break
    if time.monotonic()>until:raise TimeoutError('La regresión no terminó a tiempo para cerrar la lectura fría')
    time.sleep(1)
