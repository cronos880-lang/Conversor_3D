"""Esperar el fin de la cola de interfaz y contrastar los STEP descargados."""
from pathlib import Path
import time,json,subprocess,os,sys,hashlib
ROOT=Path(__file__).resolve().parent
until=time.monotonic()+2*3600
while True:
    try:
        rows=json.loads((ROOT/'navegador_resultados.json').read_text())['resultados']
        if len(rows)==9:
            assert all(r['ok'] for r in rows),'Hay una conversión de interfaz rechazada'
            break
    except (FileNotFoundError,json.JSONDecodeError):pass
    if time.monotonic()>until:raise TimeoutError('La interfaz no terminó la batería prevista')
    time.sleep(1)
env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1'}
def run(command,log):
    with (ROOT/log).open('w') as file:
        result=subprocess.run(command,cwd=ROOT,env=env,stdout=file,stderr=subprocess.STDOUT)
    if result.returncode:raise RuntimeError('Revisar '+log)
    print('APROBADO',log,flush=True)
run(['node','probar_cancelacion.cjs'],'cancelacion.stdout')
assert json.loads((ROOT/'cancelacion_resultado.json').read_text())['ok']
run([sys.executable,'auditar_steps_R9.py'],'lectura_fria_inicial.stdout')
row={r['id']:r for r in rows}
root_material=Path('/workspace/work/paquete_perfeccion_Visualizador_R3/material_pruebas/stl_regresion_14')
contrasts=ROOT/'contrastes_independientes';contrasts.mkdir(exist_ok=True)
for name,source,extra in [('LLanta_Trasera',root_material/'LLanta_Trasera.stl',['--todos','--minimo','15']),
                          ('V_legoBrick4x2',Path('/workspace/work/mejora_cad_post_avance_20261026/entradas_nuevas/V_legoBrick4x2.stl'),['--minimo','12'])]:
    step=ROOT/'navegador'/(name+'.step')
    assert hashlib.sha256(step.read_bytes()).hexdigest()==row[name]['sha256_step']
    run([sys.executable,'contrastar_cilindros_independiente.py',str(source),str(step),str(contrasts/(name+'.json')),*extra],name+'_independiente.stdout')
    assert json.loads((contrasts/(name+'.json')).read_text())['aprobado']
run([sys.executable,'auditar_steps_R9.py','--seguir'],'lectura_fria_completa.stdout')
print('AUDITORIAS COMPLETAS',flush=True)
