# Revisión de calidad de STEP aportados por el usuario · R8

Inspección real de nueve STEP recibidos: importación estricta con Open CASCADE, tipos de caras, áreas, dimensiones, volumen y coherencia CAD exacta. No se ha modificado el motor ni generado una nueva versión.

| Archivo | Caras | Planas | Cilíndricas | B-spline | Triángulos planos | CAD exacto |
|---|---:|---:|---:|---:|---:|---|
| spur.step | 1405 | 1371 | 34 | 0 | 0 | sí |
| LLanta_Trasera.step | 4195 | 4195 | 0 | 0 | 2466 | sí |
| maneta.step | 9351 | 9351 | 0 | 0 | 8792 | sí |
| Technic.step | 2044 | 2044 | 0 | 0 | 1945 | sí |
| Bancada_Motor.step | 1896 | 1140 | 15 | 741 | 1084 | sí |
| Octogon.step | 3775 | 3775 | 0 | 0 | 1840 | sí |
| Barrera_Lego.step | 91 | 67 | 24 | 0 | 3 | sí |
| Lego4x2.step | 1692 | 1692 | 0 | 0 | 819 | sí |

| chasis -.step | 13803 | 13803 | 0 | 0 | 12581 | sí |

Seis archivos (Llanta, maneta, Technic, Octogon, Lego4x2 y chasis) sólo contienen superficies planas. Los triángulos son facetas del B-Rep, no sólo el mallado de visualización. Spur y Barrera conservan caras cilíndricas. Bancada conserva quince caras cilíndricas, pero contiene además 741 parches B-spline; no puede considerarse una salida limpia por contar sólo sus cilindros.

El número de caras cilíndricas no representa necesariamente el número de cilindros físicos distintos. Los recortes pueden dividir una superficie en varias caras.

En cinco entradas la sección DATA completa coincide con un STEP de las pruebas congeladas de R8; resultados_nueve.json identifica cuáles. En las otras tres no se afirma identidad de geometría sólo por coincidir los recuentos. La inspección de estos adjuntos no es un nuevo ensayo de BOP, geometría contra STL ni importación en Onshape.

El usuario volvió a enviar chasis -.step comprimido en RAR. Se ha extraído e inspeccionado el archivo de 37.254.098 bytes: 13.803 caras planas, de las que 12.581 son triangulares; cero caras cilíndricas; un sólido y coherencia CAD exacta aprobada. Su sección DATA coincide con la referencia chasis - Part 2.step validada en R8. Este adjunto ya queda revisado; la limitación anterior de transferencia está resuelta.

Los perfiles se comprobaron en las fuentes congeladas: Precisión admite caja 0,020 mm, máximo base 0,060 mm y p95 original; Impresión admite caja 0,040 mm, p95 0,040 mm y máximo 0,080 mm. Ambos conservan volumen 0,5 % y los controles CAD. El perfil cambia la aceptación geométrica; no selecciona una reconstrucción de cilindros diferente ni fija una resolución de triangulación. Sólo se recibió una salida por pieza, por lo que no se afirma equivalencia numérica de dos exportaciones de perfiles distintos.

Los registros de las referencias R8 de Llanta y maneta documentan rechazo de la reconstrucción previa por coherencia CAD exacta y paso a recuperación facetada. Technic y Lego4x2 usan también recuperación numérica verificada. Cambiar la tolerancia dimensional no subsana ese fallo de curvas y recortes.

Prioridad propuesta: reconstrucción y uniones de cilindros en Lego4x2 y Llanta con los STL originales ya disponibles; comprobar caras analíticas conservadas, reducción de facetas, recortes válidos y geometría. Ampliar después a maneta y Technic, manteniendo la regresión y el cubo. No reducir sólo el número de caras sustituyendo triángulos por pequeños parches B-spline.

Los STL de Octogon y Barrera_Lego no se han localizado entre los materiales disponibles; sus STEP sí han sido inspeccionados.
