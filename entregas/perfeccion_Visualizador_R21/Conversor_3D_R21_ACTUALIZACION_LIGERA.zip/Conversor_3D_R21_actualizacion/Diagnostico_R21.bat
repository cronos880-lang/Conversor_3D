@echo off
setlocal
cd /d "%~dp0"
set "PYTHONUTF8=1"
set "PYTHONDONTWRITEBYTECODE=1"
if exist "..\Conversor_3D_R20_experimental\.venv_r20\Scripts\python.exe" (
  "..\Conversor_3D_R20_experimental\.venv_r20\Scripts\python.exe" -B "r21_launcher.py" --diagnostico %*
) else (
  py -3.12 -B "r21_launcher.py" --diagnostico %*
)
if errorlevel 1 pause
