@echo off
setlocal
cd /d "%~dp0"
set "PYTHONUTF8=1"
set "PYTHONDONTWRITEBYTECODE=1"
set "PYTHONNOUSERSITE=1"
set "PYTHONHOME="
set "PYTHONPATH="
set "VIRTUAL_ENV="
echo R21 COMPLETA - entorno propio, independiente de R20.
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0r21_full_bootstrap.ps1" diagnose %*
if errorlevel 1 goto error
if not "%CONVERSOR3D_SIN_PAUSA%"=="1" if not "diagnose"=="start" pause
exit /b 0
:error
echo Consulta datos\arranque_R21.log y datos\instalacion_R21.log.
if not "%CONVERSOR3D_SIN_PAUSA%"=="1" pause
exit /b 2
