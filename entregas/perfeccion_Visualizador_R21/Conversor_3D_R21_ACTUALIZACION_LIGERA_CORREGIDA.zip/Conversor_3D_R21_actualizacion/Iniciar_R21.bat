@echo off
setlocal
cd /d "%~dp0"
set "PYTHONUTF8=1"
set "PYTHONDONTWRITEBYTECODE=1"
set "PYTHONHOME="
set "PYTHONPATH="
echo Preparando R21. El entorno y los datos de R20 se conservan.
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0r21_bootstrap.ps1"  %*
if errorlevel 1 goto error
if not "%CONVERSOR3D_SIN_PAUSA%"=="1" if ""=="--diagnostico" pause
exit /b 0
:error
echo Consulta datos\arranque_R21.log. El programa no ha terminado correctamente.
if not "%CONVERSOR3D_SIN_PAUSA%"=="1" pause
exit /b 2
