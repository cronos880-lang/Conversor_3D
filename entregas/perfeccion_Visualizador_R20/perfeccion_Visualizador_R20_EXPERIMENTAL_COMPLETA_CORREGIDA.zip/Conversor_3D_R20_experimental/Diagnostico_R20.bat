@echo off
setlocal
cd /d "%~dp0"
set "PYTHONUTF8=1"
set "PYTHONDONTWRITEBYTECODE=1"
set "PYTHONNOUSERSITE=1"
set "PYTHONHOME="
set "PYTHONPATH="
if exist ".venv_r20\Scripts\python.exe" goto propio
py -3.12 -c "import sys,struct; sys.exit(0 if sys.version_info[:2]==(3,12) and struct.calcsize('P')==8 else 1)" >nul 2>&1
if not errorlevel 1 goto lanzador_py
python -c "import sys,struct; sys.exit(0 if sys.version_info[:2]==(3,12) and struct.calcsize('P')==8 else 1)" >nul 2>&1
if not errorlevel 1 goto lanzador_python
echo R20 requiere Python 3.12 de 64 bits. Comprueba la instalacion usada por R19.
echo Puedes instalarlo desde https://www.python.org/downloads/windows/
goto error
:propio
".venv_r20\Scripts\python.exe" -B "visor\scripts\manage_environment.py" diagnose %*
goto resultado
:lanzador_py
py -3.12 -B "visor\scripts\manage_environment.py" diagnose %*
goto resultado
:lanzador_python
python -B "visor\scripts\manage_environment.py" diagnose %*
:resultado
if errorlevel 1 goto error
if not "%CONVERSOR3D_SIN_PAUSA%"=="1" pause
exit /b 0
:error
echo ERROR R20. Consulta datos\instalacion_R20.log o ejecuta Diagnostico_R20.bat.
if not "%CONVERSOR3D_SIN_PAUSA%"=="1" pause
exit /b 2
