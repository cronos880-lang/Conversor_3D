from pathlib import Path
import sys,json,time,collections
import cadquery as cq
from OCP.ShapeUpgrade import ShapeUpgrade_UnifySameDomain
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.BRepAdaptor import BRepAdaptor_Surface
ROOT=Path(__file__).resolve().parent
source=Path('/workspace/work/mejora_cilindros_post_R8_20261027/navegador/Bancada_Motor.step')
rows=[]
for tolerance in (1e-9,1e-7):
    start=time.monotonic();shape=cq.importers.importStep(str(source)).val()
    op=ShapeUpgrade_UnifySameDomain(shape.wrapped,True,True,True);op.SetSafeInputMode(True)
    op.SetLinearTolerance(tolerance);op.SetAngularTolerance(tolerance);op.AllowInternalEdges(False);op.Build()
    result=cq.Shape.cast(op.Shape());folder=ROOT/'consolidacion_bancada'/str(tolerance);folder.mkdir(parents=True,exist_ok=True)
    cq.exporters.export(result,str(folder/'candidato.step'));cold=cq.importers.importStep(str(folder/'candidato.step')).val()
    row=dict(tolerancia=tolerance,caras=len(cold.Faces()),solidos=len(cold.Solids()),exacto=bool(BRepCheck_Analyzer(cold.wrapped,True,False,True).IsValid()),tipos=dict(collections.Counter(str(BRepAdaptor_Surface(f.wrapped).GetType()) for f in cold.Faces())),segundos=time.monotonic()-start)
    rows.append(row);print(row,flush=True);(ROOT/'consolidacion_bancada.json').write_text(json.dumps(rows,indent=2))
