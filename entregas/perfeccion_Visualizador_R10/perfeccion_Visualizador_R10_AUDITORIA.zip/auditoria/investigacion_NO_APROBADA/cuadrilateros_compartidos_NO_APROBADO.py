"""Partición de regiones libres con cuatro lados y aristas CAD compartidas.

No altera las curvas exteriores: las divide por parámetro y mantiene los mismos
vértices en ambas caras vecinas. Rechaza regiones con huecos o sin centro visible.
La partición es una propuesta y debe superar todos los validadores del motor.
"""
import numpy as np
from OCP.BRep import BRep_Builder, BRep_Tool
from OCP.BRepClass import BRepClass_FaceClassifier
from OCP.GeomAPI import GeomAPI_Interpolate
from OCP.ShapeAnalysis import ShapeAnalysis_Surface
from OCP.TColgp import TColgp_HArray1OfPnt
from OCP.TopAbs import TopAbs_FORWARD, TopAbs_REVERSED, TopAbs_IN, TopAbs_ON
from OCP.TopoDS import TopoDS_Edge, TopoDS_Vertex
from OCP.gp import gp_Pnt, gp_Pnt2d


def subdividir(faces, primary, oldloops, surfaces, curves, newedges, endpoints,
               newverts, positions, projector, _depth=0):
    if _depth > 20:
        raise ValueError('La partición de regiones cóncavas excede su presupuesto.')
    builder = BRep_Builder()
    targets = set(range(len(faces))) - primary
    for fi in targets:
        loops = oldloops[fi]
        if len(loops) != 1 or not 3 <= len(loops[0][0]) <= 24:
            raise ValueError('La región libre no admite una partición simple y acotada.')

    split = {}
    for ei in sorted({ei for fi in targets for ei, _ in oldloops[fi][0][0]}):
        curve, first, last = curves[ei]
        mid = (first + last) / 2
        vi = max(newverts) + 1
        point = curve.Value(mid)
        vertex = TopoDS_Vertex()
        builder.MakeVertex(vertex, point, 1e-7)
        newverts[vi] = vertex
        positions[vi] = np.array(point.Coord())
        a, b = endpoints[ei]
        halves = []
        for lo, hi, start, end in ((first, mid, a, vi), (mid, last, vi, b)):
            edge = TopoDS_Edge()
            builder.MakeEdge(edge, curve, 1e-7)
            builder.Add(edge, newverts[start].Oriented(TopAbs_FORWARD))
            builder.Add(edge, newverts[end].Oriented(TopAbs_REVERSED))
            builder.Range(edge, lo, hi)
            key = max(newedges) + 1
            curves[key] = (curve, lo, hi)
            endpoints[key] = (start, end)
            newedges[key] = edge
            halves.append(key)
        split[ei] = (*halves, vi)

    def halves(ei, forward):
        a, b, _ = split[ei]
        return [(a, True), (b, True)] if forward else [(b, False), (a, False)]

    specs = []
    for fi, face in enumerate(faces):
        if fi not in targets:
            loops = []
            for lp, orientation in oldloops[fi]:
                expanded = []
                for ei, forward in lp:
                    expanded.extend(halves(ei, forward) if ei in split else [(ei, forward)])
                loops.append((expanded, orientation))
            specs.append((fi, loops, False))
            continue

        lp, orientation = oldloops[fi][0]
        surface = surfaces[fi]
        analysis = ShapeAnalysis_Surface(surface)
        original_surface = BRep_Tool.Surface_s(face.wrapped)
        original_analysis = ShapeAnalysis_Surface(original_surface)

        def inside_new_uv(uv, strict=False):
            point = surface.Value(*map(float, uv))
            old_uv = (gp_Pnt2d(*map(float, uv)) if point.Distance(original_surface.Value(*map(float, uv))) < 1e-10
                      else original_analysis.ValueOfUV(point, 1e-10))
            state = BRepClass_FaceClassifier(face.wrapped, old_uv, 1e-9).State()
            return state == TopAbs_IN if strict else state in (TopAbs_IN, TopAbs_ON)
        mids = [positions[split[ei][2]] for ei, _ in lp]
        seeds = getattr(face, 'mid_seed_uv', None)
        uv_mids = np.array([(analysis.NextValueOfUV(gp_Pnt2d(*map(float, seeds[i])),gp_Pnt(*map(float,p)),1e-10,-1.)
                            if seeds is not None else analysis.ValueOfUV(gp_Pnt(*map(float, p)), 1e-10)).Coord()
                            for i,p in enumerate(mids)])
        v, t = face.copy().tessellate(.02)
        xyz = np.array([p.toTuple() for p in v])
        triangles = xyz[np.array(t)]
        area = np.linalg.norm(np.cross(triangles[:, 1] - triangles[:, 0],
                                       triangles[:, 2] - triangles[:, 0]), axis=1)
        candidates = [np.array(face.Center().toTuple())]
        candidates.extend(triangles[area.argsort()[::-1][:40]].mean(axis=1))
        chosen = None
        for candidate_index,candidate in enumerate(candidates):
            known = getattr(face, 'center_uv', None) if candidate_index == 0 else None
            center_uv = np.array(known if known is not None else analysis.ValueOfUV(gp_Pnt(*map(float, candidate)), 1e-10).Coord())
            if not inside_new_uv(center_uv, strict=True):
                continue
            mapped = uv_mids.copy()
            for dim, periodic in ((0, surface.IsUPeriodic()), (1, surface.IsVPeriodic())):
                if periodic:
                    period = surface.UPeriod() if dim == 0 else surface.VPeriod()
                    mapped[:, dim] += np.round((center_uv[dim] - mapped[:, dim]) / period) * period
            visible = all(inside_new_uv(center_uv + fraction * (uv - center_uv))
                for uv in mapped for fraction in (.25, .5, .75))
            if visible:
                chosen = center_uv, mapped
                break
        if chosen is None:
            return _partir_concava(fi, faces, primary, oldloops, surfaces, curves,
                                  newedges, endpoints, newverts, positions, projector, _depth)
        center_uv, mapped_mids = chosen
        old_center = np.array(surface.Value(*map(float, center_uv)).Coord())
        center = projector.batch([old_center])[0]
        if np.linalg.norm(center - old_center) > .06:
            raise ValueError('El centro propuesto queda demasiado lejos del STL.')
        cv = TopoDS_Vertex()
        builder.MakeVertex(cv, gp_Pnt(*map(float, center)), 1e-7)
        spokes = []
        for (ei, _), midpoint, start_uv in zip(lp, mids, mapped_mids):
            q = np.array([surface.Value(*map(float, start_uv + fraction *
                           (center_uv - start_uv))).Coord() for fraction in np.linspace(0, 1, 17)])
            q = projector.batch(q)
            q[0], q[-1] = midpoint, center
            points = TColgp_HArray1OfPnt(1, len(q))
            for j, p in enumerate(q, 1):
                points.SetValue(j, gp_Pnt(*map(float, p)))
            fit = GeomAPI_Interpolate(points, False, 1e-12)
            fit.Perform()
            if not fit.IsDone():
                raise ValueError('No converge una curva interior compartida.')
            curve = fit.Curve()
            first, last = curve.FirstParameter(), curve.LastParameter()
            edge = TopoDS_Edge()
            builder.MakeEdge(edge, curve, 1e-7)
            builder.Add(edge, newverts[split[ei][2]].Oriented(TopAbs_FORWARD))
            builder.Add(edge, cv.Oriented(TopAbs_REVERSED))
            builder.Range(edge, first, last)
            key = max(newedges) + 1
            newedges[key], curves[key] = edge, (curve, first, last)
            spokes.append(key)
        for i, (ei, forward) in enumerate(lp):
            previous, prev_forward = lp[i - 1]
            quad = [halves(ei, forward)[0], (spokes[i], True),
                    (spokes[i - 1], False), halves(previous, prev_forward)[1]]
            specs.append((fi, [(quad, orientation)], True))
        print('[Cuadriláteros] región', fi, 'parches', len(lp), flush=True)
    return specs


def _partir_concava(fi, faces, primary, oldloops, surfaces, curves, newedges,
                    endpoints, newverts, positions, projector, depth):
    """Recorta orejas interiores y comparte sus diagonales, sin cerrar agujeros."""
    import cadquery as cq
    face, surface = faces[fi], surfaces[fi]
    loop, orientation = oldloops[fi][0]
    if len(loop) <= 3:
        raise ValueError('La región triangular no tiene un interior verificable.')
    analysis = ShapeAnalysis_Surface(surface)
    original_analysis = ShapeAnalysis_Surface(BRep_Tool.Surface_s(face.wrapped))
    vids = [endpoints[ei][0 if forward else 1] for ei, forward in loop]
    uv = np.array([analysis.ValueOfUV(gp_Pnt(*map(float, positions[v])), 1e-10).Coord()
                   for v in vids])
    for dim, periodic in ((0, surface.IsUPeriodic()), (1, surface.IsVPeriodic())):
        if periodic:
            uv[:, dim] = np.unwrap(uv[:, dim], period=surface.UPeriod() if dim == 0 else surface.VPeriod())
    def cross(a, b):
        return a[0]*b[1] - a[1]*b[0]
    area = sum(cross(a, b) for a, b in zip(uv, np.roll(uv, -1, axis=0))) / 2
    eps = max(1e-15, float(np.ptp(uv, axis=0).max())**2 * 1e-13)
    if abs(area) <= eps:
        raise ValueError('El contorno cóncavo no tiene área paramétrica positiva.')
    sign = np.sign(area)
    def interior(p):
        point = surface.Value(*map(float, p))
        old_uv = original_analysis.ValueOfUV(point, 1e-10)
        return BRepClass_FaceClassifier(face.wrapped, old_uv, 1e-9).State() in (TopAbs_IN, TopAbs_ON)
    remaining = list(range(len(uv)))
    triangles = []
    while len(remaining) > 3:
        found = False
        for index, b in enumerate(remaining):
            a, c = remaining[index-1], remaining[(index+1) % len(remaining)]
            p, q, r = uv[[a, b, c]]
            if cross(q-p, r-q)*sign <= eps:
                continue
            others = [i for i in remaining if i not in (a, b, c)]
            if any(min(cross(q-p, uv[i]-p)*sign,
                       cross(r-q, uv[i]-q)*sign,
                       cross(p-r, uv[i]-r)*sign) >= -eps for i in others):
                continue
            if not all(interior(p+(r-p)*t) for t in (.25, .5, .75)):
                continue
            if not interior((p+q+r)/3):
                continue
            triangles.append((a, b, c))
            remaining.pop(index)
            found = True
            break
        if not found:
            raise ValueError('No se demuestra una triangulación interior de la región cóncava.')
    triangles.append(tuple(remaining))
    if abs(sum(abs(cross(uv[b]-uv[a], uv[c]-uv[a]))/2 for a,b,c in triangles)-abs(area)) > max(1e-10,abs(area)*1e-9):
        raise ValueError('La partición no conserva el área paramétrica del contorno.')

    lookup = {(i, (i+1) % len(loop)): item for i, item in enumerate(loop)}
    lookup.update({(b,a):(ei,not forward) for (a,b),(ei,forward) in list(lookup.items())})
    builder = BRep_Builder()
    def edge_for(a, b):
        if (a,b) in lookup:
            return lookup[a,b]
        samples = np.array([surface.Value(*map(float, uv[a]+t*(uv[b]-uv[a]))).Coord()
                            for t in np.linspace(0, 1, 17)])
        samples = projector.batch(samples)
        samples[0], samples[-1] = positions[vids[a]], positions[vids[b]]
        array = TColgp_HArray1OfPnt(1, len(samples))
        for j, point in enumerate(samples, 1):
            array.SetValue(j, gp_Pnt(*map(float, point)))
        fit = GeomAPI_Interpolate(array, False, 1e-12)
        fit.Perform()
        if not fit.IsDone():
            raise ValueError('No converge una diagonal interior compartida.')
        curve = fit.Curve()
        first, last = curve.FirstParameter(), curve.LastParameter()
        edge = TopoDS_Edge()
        builder.MakeEdge(edge, curve, 1e-7)
        builder.Add(edge, newverts[vids[a]].Oriented(TopAbs_FORWARD))
        builder.Add(edge, newverts[vids[b]].Oriented(TopAbs_REVERSED))
        builder.Range(edge, first, last)
        key = max(newedges)+1
        newedges[key], curves[key], endpoints[key] = edge, (curve, first, last), (vids[a],vids[b])
        lookup[a,b], lookup[b,a] = (key,True), (key,False)
        return key, True

    class ReferenceTriangle:
        def __init__(self, tri):
            self.tri = tri
            self.wrapped = face.wrapped
            self.center_uv = uv[list(tri)].mean(axis=0)
            self.mid_seed_uv = [(uv[a]+uv[b])/2 for a,b in zip(tri,tri[1:]+tri[:1])]
        def Center(self):
            return cq.Vector(surface.Value(*map(float, uv[list(self.tri)].mean(axis=0))).Coord())
        def copy(self):
            return self
        def tessellate(self, _):
            return [cq.Vector(surface.Value(*map(float, uv[i])).Coord()) for i in self.tri], [(0,1,2)]

    new_faces, new_primary, new_loops, new_surfaces, parents = [], set(), {}, {}, []
    for old_i, original in enumerate(faces):
        if old_i != fi:
            j = len(new_faces)
            new_faces.append(original)
            new_loops[j], new_surfaces[j] = oldloops[old_i], surfaces[old_i]
            parents.append(old_i)
            if old_i in primary:
                new_primary.add(j)
            continue
        for tri in triangles:
            j = len(new_faces)
            new_faces.append(ReferenceTriangle(tri))
            new_loops[j] = [([edge_for(a,b) for a,b in zip(tri, tri[1:]+tri[:1])],orientation)]
            new_surfaces[j] = surface
            parents.append(fi)
    print('[Cuadriláteros] región cóncava',fi,'partes interiores',len(triangles),flush=True)
    result = subdividir(new_faces, new_primary, new_loops, new_surfaces, curves,
                         newedges, endpoints, newverts, positions, projector, depth+1)
    return [(parents[index],loops,fan) for index,loops,fan in result]
