"""Configurar fixtures explícitos: fallar si faltan, sin omitir pruebas."""
from pathlib import Path
import argparse,os,subprocess,sys

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--motor',type=Path,required=True)
    p.add_argument('--material-r7',type=Path,required=True)
    p.add_argument('--banco-r7',type=Path,required=True,help='Banco R7 anterior; el STEP 17 debe ser el defectuoso de R7, no el del candidato')
    p.add_argument('--xml',type=Path,required=True)
    p.add_argument('--solo-nuevas',action='store_true')
    a=p.parse_args();motor=a.motor.resolve();material=a.material_r7.resolve();bank=a.banco_r7.resolve()
    mapping={'VISOR_MATERIAL_PRUEBAS':material,
      **{f'VISOR_CASOS_R{n}':material/f'casos_usuario_r{n}' for n in range(2,6)},
      'VISOR_RESULTADOS_R5':material/'fixtures_reparador_r5',
      'VISOR_FIXTURE_CACHE_R2':material/'regresiones_cad_no_aceptados/4600_fixed.step',
      'VISOR_FIXTURE_DENSO_R2':material/'regresiones_cad_no_aceptados/Pieza ambigua.step',
      'VISOR_FIXTURE_RESCATE_R3':material/'regresiones_cad_no_aceptados/Con fallos pero si step.step',
      'VISOR_BATERIA_EXTERNA':bank}
    required=[*mapping.values(),bank/'stl_sanos/17_barrido_spline.stl',bank/'resultados_sanos/17_barrido_spline.step']
    missing=[str(x) for x in required if not x.exists()]
    if missing:p.error('Faltan fixtures: '+', '.join(missing))
    env={**os.environ,**{k:str(v) for k,v in mapping.items()},'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'}
    a.xml=a.xml.resolve();a.xml.parent.mkdir(parents=True,exist_ok=True)
    cases=['test_saneamiento_verificado.py','test_servidor_reparacion.py'] if a.solo_nuevas else ['.']
    return subprocess.run([sys.executable,'-m','pytest','-q',*cases,'--junitxml',str(a.xml)],cwd=motor,env=env).returncode

if __name__=='__main__':raise SystemExit(main())
