"""Contraste de STEP reales con geometría R7 y mallado M1 inmutables.

El inventario de cilindros se mide aquí con proyección geométrica y pertenencia
al recorte UV. Un cilindro infinito cercano no demuestra conservación de su cara.
"""
from pathlib import Path
import argparse,os,sys,json,hashlib,time,traceback,importlib.util,tempfile,math
ROOT=Path(__file__).resolve().parent
QA=ROOT.parent if ROOT.name=='herramientas' else ROOT/'preparacion_entrega/auditoria'
parser=argparse.ArgumentParser();parser.add_argument('stl',type=Path);parser.add_argument('step',type=Path);parser.add_argument('informe',type=Path)
parser.add_argument('--todos',action='store_true');parser.add_argument('--minimo',type=int,default=1);args=parser.parse_args()
frozen=Path(os.environ.get('VISOR_EVALUADOR_R7',str(QA/'evaluador_R7_inmutable')))
control_path=Path(os.environ.get('VISOR_CONTROL_FRONTERA',str(QA/'herramientas/control_frontera_inmutable_M1.py')))
sys.path[:0]=[str(frozen),str(frozen/'motor_superficies')]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
record={'aprobado':False,'sha256_stl':sha(args.stl),'sha256_step':sha(args.step),'evaluador_R7':str(frozen),'control_M1':sha(control_path)};start=time.monotonic()
try:
    import numpy as np,cadquery as cq
    from preprocesador_stl import cargar_exacto
    from motor_v2 import _calidad
    from OCP.BRepCheck import BRepCheck_Analyzer
    from OCP.BRep import BRep_Tool
    from OCP.BRepAdaptor import BRepAdaptor_Surface
    from OCP.BRepClass import BRepClass_FaceClassifier
    from OCP.BRepTools import BRepTools
    from OCP.GeomAPI import GeomAPI_ProjectPointOnSurf
    from OCP.BRepExtrema import BRepExtrema_DistShapeShape
    from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeVertex
    from OCP.GeomAbs import GeomAbs_Cylinder
    from OCP.gp import gp_Pnt,gp_Pnt2d
    from OCP.TopAbs import TopAbs_IN,TopAbs_ON
    original=cargar_exacto(args.stl)
    record['geometria_R7']=_calidad(args.stl,args.step,original,control_avanzado=False)
    # Releer después del muestreo para juzgar el archivo, no una caché de teselado.
    shape=cq.importers.importStep(str(args.step)).val()
    record['step_exacto']=BRepCheck_Analyzer(shape.wrapped,True,False,True).IsValid()
    if not record['step_exacto']:raise ValueError('El STEP no es CAD exacto')
    from meshfit_detect import detect
    detection,working=detect(str(args.stl),angle_tol_deg=32.,rms_tol_rel=.01,flat_tol_deg=8.,scan_mode=False)
    spec=importlib.util.spec_from_file_location('control_inmutable',control_path);control=importlib.util.module_from_spec(spec);spec.loader.exec_module(control)
    required=control.cilindros_respaldados(detection,working)
    faces=[f for f in shape.Faces() if BRepAdaptor_Surface(f.wrapped).GetType()==GeomAbs_Cylinder]
    supports=[]
    for index,p in enumerate(required):
        axis=p['eje']/np.linalg.norm(p['eje']);matches=[]
        for face in faces:
            cylinder=BRepAdaptor_Surface(face.wrapped).Cylinder();a=np.array(cylinder.Axis().Direction().Coord());q=np.array(cylinder.Location().Coord())
            if (abs(cylinder.Radius()-p['radio'])<=.008 and abs(a@axis)>=.99999
                    and np.linalg.norm(np.cross(q-p['centro'],axis))<=.008):matches.append(face)
        points=p['puntos'];ids=set(np.linspace(0,len(points)-1,min(40,len(points))).astype(int))
        for dim in range(3):ids.update([int(points[:,dim].argmin()),int(points[:,dim].argmax())])
        maximum=0.
        for i in ids:
            point=gp_Pnt(*map(float,points[i]));distance=math.inf
            for face in matches:
                operation=BRepExtrema_DistShapeShape(BRepBuilderAPI_MakeVertex(point).Vertex(),face.wrapped)
                if operation.IsDone():distance=min(distance,float(operation.Value()))
                surface=BRep_Tool.Surface_s(face.wrapped);projection=GeomAPI_ProjectPointOnSurf(point,surface)
                u0,u1,_,_=BRepTools.UVBounds_s(face.wrapped)
                for solution in range(1,projection.NbPoints()+1):
                    u,v=projection.Parameters(solution);period=surface.UPeriod();base=round(((u0+u1)*.5-u)/period)
                    for offset in (base,base-1,base+1):
                        uv=gp_Pnt2d(u+offset*period,v)
                        if BRepClass_FaceClassifier(face.wrapped,uv,1e-9).State() in (TopAbs_IN,TopAbs_ON):
                            distance=min(distance,float(point.Distance(surface.Value(uv.X(),uv.Y()))))
            maximum=max(maximum,distance)
        supports.append({'indice':index,'radio_fuente_mm':p['radio'],'conservado_como_cilindro':bool(matches) and maximum<=.008,
                         'max_distancia_a_cara_recortada_mm':maximum if math.isfinite(maximum) else None,'muestras':len(ids)})
    preserved=sum(x['conservado_como_cilindro'] for x in supports)
    record['cilindros']={'confirmados_fuente':len(required),'conservados':preserved,'restantes_sin_reconstruccion_analitica_confirmada':len(required)-preserved,'control_mm':.008,'soportes':supports}
    if preserved<args.minimo or (args.todos and preserved!=len(required)):raise ValueError('No se conserva el inventario cilíndrico exigido para este ensayo')
    from invariantes_material import InvariantesMaterial
    from validacion_reconstruccion import certificar_topologia_step
    record['topologia_material']=certificar_topologia_step(shape,original,InvariantesMaterial(original))
    with tempfile.TemporaryDirectory(prefix='visor_independiente_R10_') as directory:
        record['frontera_tres_resoluciones']=control.certificar_mallado(shape,original,Path(directory)/'control.off',record['geometria_R7'])
    if record['sha256_step']!=sha(args.step) or record['sha256_stl']!=sha(args.stl):raise ValueError('Un archivo cambió durante el contraste')
    record['aprobado']=True
except Exception as exc:record['error']=str(exc);traceback.print_exc()
record['segundos']=time.monotonic()-start;args.informe.parent.mkdir(parents=True,exist_ok=True);args.informe.write_text(json.dumps(record,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps({'aprobado':record['aprobado'],'error':record.get('error'),'segundos':record['segundos'],'cilindros':record.get('cilindros',{}).get('conservados')}),flush=True)
raise SystemExit(0 if record['aprobado'] else 2)
