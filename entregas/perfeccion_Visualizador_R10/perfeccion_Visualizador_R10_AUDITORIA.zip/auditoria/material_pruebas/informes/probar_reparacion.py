import sys,json, pathlib,time
sys.path.insert(0,'/mnt/data/Easy_Analysis/sources/meshfit-master/meshfit-master')
import numpy as np, trimesh
from meshfit_repair import repair_mesh,_boundary_loops
R=pathlib.Path('/mnt/data/Easy_Analysis')

def diag(m):
 F=np.asarray(m.faces);V=np.asarray(m.vertices)
 E=np.sort(F[:,[[0,1],[1,2],[2,0]]].reshape(-1,2),axis=1)
 _,k=np.unique(E,return_counts=True,axis=0)
 return {'faces':len(F),'components':len(m.split(only_watertight=False)),'watertight':bool(m.is_watertight),'volume':round(float(m.volume),6),'bbox':np.ptp(V,axis=0).round(6).tolist(), 'boundary_edges':int((k==1).sum()),'nonmanifold_edges':int((k>2).sum()),'winding':bool(m.is_winding_consistent),'loops':len(_boundary_loops(F))}

def save(case,m):
 t=time.monotonic(); a=diag(m)
 print('case',case,'before',a,flush=True)
 try:
  x,mapper,info=repair_mesh(m,verbose=False)
  b=diag(x)
  print('case',case,'after',b,'info',info,'sec',round(time.monotonic()-t,3),flush=True)
  return {'before':a,'after':b,'info':info,'elapsed':round(time.monotonic()-t,3)}
 except Exception as e:
  print('case',case,'ERR',repr(e),flush=True)
  return {'before':a,'error':str(e)}
res={}
orig=trimesh.load('/mnt/data/cubo-carrito.stl',force='mesh',process=True)
res['cubo-carrito']=save('cubo-carrito',orig)
repaired=trimesh.load('/mnt/data/cubo-carrito_REPARADO.stl',force='mesh',process=True)
res['cubo-carrito_reparado']=save('cubo-carrito_reparado',repaired)
# One face missing from regular cube
cube=trimesh.creation.box(extents=(20,20,20));cube.update_faces(np.arange(len(cube.faces))!=0);cube.remove_unreferenced_vertices()
res['cubo_falta_un_triangulo']=save('cubo_falta_un_triangulo',cube)
# Larger functional opening (remove a whole wall face, e.g. one pair triangles)
box=trimesh.creation.box(extents=(20,20,20));box.update_faces(~np.isin(np.arange(len(box.faces)), [0,2]));box.remove_unreferenced_vertices()
res['cubo_abierto_dos_triangulos']=save('cubo_abierto_dos_triangulos',box)
# separate two closed solids (should keep distinct if they are separate)
m2=trimesh.util.concatenate([trimesh.creation.box(extents=(10,10,10)),trimesh.creation.box(extents=(4,4,4),transform=trimesh.transformations.translation_matrix((30,0,0)))])
res['dos_cuerpos_cerrados']=save('dos_cuerpos_cerrados',m2)
(R/'prueba_reparacion_resultados.json').write_text(json.dumps(res,indent=2,ensure_ascii=False))
