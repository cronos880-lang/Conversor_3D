import sys,json,time
sys.path.insert(0,'/mnt/data/Easy_Analysis/sources/meshfit-master/meshfit-master')
import trimesh,numpy as np
from meshfit_repair import repair_mesh
from meshfit_step import _close_mesh
m=trimesh.creation.icosphere(subdivisions=3, radius=10)
m.update_faces(np.arange(len(m.faces))!=50);m.remove_unreferenced_vertices()
print('sphere before',len(m.faces),m.is_watertight, 'volume',m.volume,flush=True)
t=time.time()
try:
 x, fm, info=repair_mesh(m,verbose=True)
 print('sphere after',len(x.faces),x.is_watertight,'volume',x.volume,'info',info,'secs',round(time.time()-t,3),flush=True)
except Exception as e:print('sphere ERROR',repr(e),flush=True)
orig=trimesh.load('/mnt/data/cubo-carrito.stl',force='mesh',process=True)
t=time.time()
try:
 v,f,closed,inf=_close_mesh(np.asarray(orig.vertices),np.asarray(orig.faces), rounds=6)
 out=trimesh.Trimesh(vertices=v,faces=f,process=True)
 print('close_mesh on orig cubo',inf,'flag',closed,'watertight',out.is_watertight,'components',len(out.split(only_watertight=False)),'volume',out.volume,'old',orig.volume,'bboxdiff',np.max(np.abs(out.extents-orig.extents)),'secs',time.time()-t,flush=True)
except Exception as e:print('close mesh ERROR',repr(e),flush=True)
