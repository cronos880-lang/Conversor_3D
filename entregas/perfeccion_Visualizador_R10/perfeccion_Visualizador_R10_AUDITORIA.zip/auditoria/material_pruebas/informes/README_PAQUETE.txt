PAQUETE DE AUDITORÍA / FUTURA SESIÓN CODEX
23 octubre 2026

Este ZIP reúne: nueve ZIP originales del amigo, V4.0 R1 exacta del Visor,
14 STL históricos, cubo-carrito original y reparado, informe, pruebas reproducibles
y encargo de Codex preparado. Ningún archivo de producción ha sido editado.

LEER PRIMERO:
  informes/INFORME_COMPARATIVO_V4_R1_EASYMESHFIT.md
  informes/ENCARGO_Codex_PREPARADO.md

No asumir que un STL estanco representa un solo sólido ni que una superficie
abierta exportada a STEP sea un sólido CAD válido. No aceptar reparaciones sin
comparaciones geométricas con la referencia; conservar las cotas de nuestro Visor.

No se ejecutaron los nueve motores completos en Windows; solo análisis de código,
14 auditorías topológicas, experimentos de reparación y algunos ejemplos sintéticos.
