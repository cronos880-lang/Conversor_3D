# Preparación para una sesión futura de Codex — Visor STL → STEP

**No ejecutar este encargo hasta que el propietario decida iniciar Codex.** Trabajar sobre copia del ZIP `Visor_STL_STEP_V4_0_USO_R1_CORREGIDO.zip`; no modificar la V3 estable ni la R1 de uso.

## Objetivo acotado

Añadir a V4 R1 un preprocesador **opcional, conservador y verificado** para STL defectuosos, que diagnostique con precisión el motivo del rechazo y repare solo cuando pueda demostrar preservación dimensional y topológica. Mantener las estrategias CAD y la UI actuales. No prometer universalidad.

## Hechos y código de referencia

- `motor_v2.py`: rechazo prematuro de STL abiertos/múltiples componentes en `convertir()`, líneas 253–263.
- `motor_superficies/meshfit_repair.py`: copia íntegra del reparador de `meshfit-master/meshfit_repair.py`, pero solo rellena bucles de borde y filtra caras/islas; NO arregla `cubo-carrito.stl`.
- `meshfit-master/meshfit_guard.py`, `meshfit_qc.py`, `bateria.py`, `taller.py`: ejemplos para adaptar procesos vigilados y batería reproducible, sin reemplazar los límites del Visor.
- `meshfit-master/meshfit_step.py::_close_mesh` no es adecuado para STL arbitrario: sobre el cubo-carrito generó 2 cuerpos estancos con +1,1687 % de volumen.

## Fases, con puertas de calidad

1. Clasificador topológico independiente: aristas 1 / 2 / >2 caras, caras degeneradas/duplicadas, componentes individuales estancos o abiertos, orientación, intersecciones o superficies de contacto. Reporte JSON con ruta seleccionada y gravedad.
2. Reparación **local** de agujeros pequeños, con preservación de zonas funcionales y validación independiente. Cuando el problema sea ambiguo, no reparar silenciosamente.
3. Fusión geométrica de múltiples sólidos cerrados **en contacto o solapados**, distinta del relleno de agujeros. Emplear operación booleana robusta y verificar agujeros interiores; si el motor/librería no puede garantizar el resultado, detenerse con error concreto.
4. Integrar antes de la comprobación de estanquidad del motor, conservando el STL original como referencia y guardando el STL reparado e informe cuando sea útil. Motor existente sin cambios salvo paso de entrada.
5. Pruebas automáticas antes/después, en Windows y en un entorno de referencia, incluyendo geometrías rotadas y una suite de regresión de los 14 STL históricos. Validar STEP reimportado y reportar medidas.

## Restricciones estrictas

- No relajar las cotas ni tolerancias: 0,020 mm en bbox, 0,5 % de volumen de referencia válida, p95 0,020–0,030 mm y máximo observado 0,060 mm según condiciones originales.
- No tratar mallas abiertas de escáner como sólidos imprimibles simplemente exportando una superficie NURBS sin cerrar.
- No tapar agujeros mecánicos, canales o roscas intencionales.
- No aceptar una unión basada solo en `is_watertight=True`: también comprobar componentes, volumen y coincidencia geométrica. El caso `cubo-carrito.stl` es el contraejemplo.
- No eliminar cuerpos pequeños mediante un simple porcentaje de triángulos sin validar intención o contacto.
- No entregar una versión hasta corregir efectivamente al menos `cubo-carrito` y pasar las regresiones; no reemplazar motor entero a ciegas.

## Referencias de prueba

`/mnt/data/Easy_Analysis/diagnostico_topologias_resultados.json`, `prueba_reparacion_resultados.json`, `INFORME_COMPARATIVO_V4_R1_EASYMESHFIT.md`. STL de prueba en `Easy_Analysis/benchmarks/files/`, más `/mnt/data/cubo-carrito.stl` y `/mnt/data/cubo-carrito_REPARADO.stl`.

## Qué entregar

Código con pruebas unitarias de topología y reparaciones, comparación de indicadores sobre las 14 piezas y casos negativos, informe de cambios y riesgos residuales, y solo entonces ZIP experimental independiente si todo ha pasado. La evaluación en Onshape sigue siendo necesaria para la editabilidad *Move face*.
