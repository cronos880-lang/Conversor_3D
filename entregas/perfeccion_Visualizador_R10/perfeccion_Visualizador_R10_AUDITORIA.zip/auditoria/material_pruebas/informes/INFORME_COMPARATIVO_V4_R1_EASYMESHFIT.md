# Auditoría técnica: Visor STL → STEP V4.0 Uso R1 y nueve ramas de EasyMeshFit

**Fecha:** 23 de octubre de 2026  
**Alcance:** revisión estática de código, dependencias y recorridos de conversión; pruebas dinámicas de reparación de STL y auditoría topológica de 14 piezas propias más `cubo-carrito`. **No se ha integrado ni publicado una nueva versión del Visor.**

## 1. Resumen ejecutivo

1. **El Visor V4.0 R1 bloquea la reparación antes de ejecutarla.** En `motor_v2.py`, líneas 253–263, rechaza cualquier STL que no sea estanco, tenga orientación inconsistente o tenga más de un componente. Paradójicamente, `motor_superficies/meshfit_repair.py` ya contiene el mismo reparador de escaneos de EasyMeshFit, y `motor_superficies/meshfit_brep.py`, líneas 1933–1939, intenta usarlo si le llega una malla abierta. Pero la primera comprobación normalmente impide llegar a esa ruta.
2. **No basta con quitar esa comprobación.** `meshfit_repair.repair_mesh()` detecta y rellena bucles de bordes; no fusiona correctamente los sólidos cerrados que se tocan ni resuelve todos los defectos no manifold.
3. **`cubo-carrito.stl` no tiene un agujero de superficie.** Sus 1.880 triángulos forman dos cuerpos individualmente estancos y orientados; como conjunto aparecen cuatro aristas no manifold, ningún borde abierto. Necesita **fusión geométrica controlada** de dos componentes, no rellenar agujeros a ciegas.
4. **Hay capacidades aprovechables en la rama `meshfit-master`:** `meshfit_guard.py` (límites de RAM/tiempo en procesos secundarios), `meshfit_qc.py` (comprobación de STEP reimportado), `bateria.py` y `taller.py` (pruebas de regresión con referencias e informes), y comprobaciones adicionales de orientación, área y round-trip en `meshfit_brep.py`. Deben adaptarse a nuestros umbrales estrictos y a que nuestro servidor ya aísla el motor en un proceso; no copiarlas íntegramente.
5. **`meshfit_open.py` no es un reparador universal de sólidos.** Genera una superficie NURBS abierta para escaneos de tipo banda con dos contornos largos. Útil como modo explícito y separado; no produce un STEP sólido para modificar e imprimir por defecto.
6. **La versión "más completa" no es necesariamente mejor en cada caso.** `meshfit-master` agrupa más subsistemas, mientras las otras ramas contienen experimentos y variantes concretas. No hay evidencias de que sustituir el núcleo del Visor por el del amigo mejore Brick, Maneta o las dimensiones.

## 2. Inventario: se han abierto los NUEVE ZIP del RAR

| Archivo dentro del RAR | Ámbito visible al inspeccionar su código |
|---|---|
| `meshfit-auto-fillets-nurbs.zip` | Base reducida orientada a fillets y NURBS; carece de `meshfit_repair.py`. |
| `meshfit-casa-sin-subir-2026-07-08.zip` | Variante de desarrollo anterior, con detectores/NURBS y sin el módulo de reparación posterior. |
| `meshfit-wip-armonico-2fases.zip` | Experimentación de reconstrucción orgánica/armónica; incluye reparador de escaneo. |
| `meshfit-2.zip` | Motor más amplio de detección, superficies y reparación de agujeros. |
| `meshfit-rosca-altura.zip` | Variante con cambios de reconocimiento de roscas/altura. |
| `meshfit-stl-estanco.zip` | Refuerzos para exportar STEP y volver a generar STL cerrado; reparador incluido. |
| `meshfit-vista-solido.zip` | Taller e inspección de calidad del sólido, además del motor. |
| `meshfit-taller-superficie-abierta-20261019.zip` | Taller, QC y un módulo específico para reconstruir **superficies abiertas**. |
| `meshfit-master.zip` | Conjunto más amplio de los aportados: taller, batería, QC, superficies abiertas, guardia de recursos, correcciones de B-Rep y salida STL. |

El módulo `meshfit_repair.py` de las siete ramas que lo contienen tiene **el mismo hash SHA-256** (`57a6357729...`); exactamente ese módulo también está en `Visor R1/motor_superficies`. No son siete soluciones independientes para mallas abiertas.

En cambio, las ramas contienen revisiones diferentes de `meshfit_brep.py` y `meshfit_step.py`. En `meshfit-master` hay funciones nuevas de validación de caras (`_covers`, `_roundtrip_bad`, `_area_mismatch`, `_misoriented_faces`) respecto a nuestra copia, además de una implementación más robusta de `step_to_stl`. Los cambios no son intercambiables sin pruebas.

## 3. Auditoría real de nuestro V4.0 Uso R1

- **Arquitectura:** servidor + motor separado; carga STL con `trimesh`, detecta regiones geométricas, construye B-Rep con OpenCascade y valida el STEP después de escribirlo. Dispone de distintas estrategias de rescate.
- **Fidelidad geométrica actual:** límite de diferencia dimensional de `0,020 mm`, volumen `0,5 %`, desviación superficial p95 `0,020 mm` (puede llegar a `0,030 mm` en piezas grandes), máximo observado `0,060 mm`, más margen acotado por simplificación. Estos límites no deben relajarse para aceptar reparaciones.
- **Debilidad topológica:** `motor_v2.convertir()` rechaza a nivel global antes de cualquier reparación. Además exige **un único componente**; dos sólidos estancos separados no necesariamente deberían fusionarse, y dos sólidos que se tocan requieren analizar su unión.
- **Debilidad de UX:** el mensaje "debe estar cerrado" mezcla varias causas distintas (bordes abiertos, aristas no manifold, varios cuerpos, orientación). Debe mostrar un diagnóstico específico y no responsabilizar genéricamente al STL.
- **Fortaleza que conservar:** análisis CAD posterior a reimportación, distancia STL↔STEP, preservación del STL original, motor de superficies probado en piezas digitales y controles geométricos estrictos.

## 4. Pruebas topológicas: las 14 piezas habituales y el archivo descargado

El análisis se ha realizado cargando los STL originales con `trimesh`, contando componentes y aristas según incidencias triangulares y consultando la estanquidad.

- **14/14 STL del banco histórico:** todos tienen un solo componente estanco, aristas abiertas = 0 y aristas no manifold = 0. Incluye Brick, Maneta, Grapa, Bancada, Chasis, Conector, Clip, Llanta, Embudo, Estefi, Pinza, Tirante, Spoiler y Spur.
- **`cubo-carrito.stl`:** 1.880 caras, 2 componentes individuales estancos (1.248 y 632 triángulos), 0 aristas abiertas, **4 aristas no manifold**. Dimensiones `[44,831001, 44,831001, 184,784988] mm`; volumen firmado de suma `59.242,563133 mm³`.
- **`cubo-carrito_REPARADO.stl` existente:** 1.864 caras, un componente estanco, 0 aristas no manifold y dimensiones conservadas dentro del redondeo numérico. Volumen `59.242,408553 mm³`, diferencia respecto a la suma anterior **−0,000261 %**. Esto valida ese archivo concreto como ejemplo de reparación, no un algoritmo universal.

Los registros completos están en `diagnostico_topologias_resultados.json`.

## 5. Ensayos reales de reparación con el motor del amigo

| Entrada / método | Resultado medido | Interpretación |
|---|---|---|
| `cubo-carrito.stl` → `meshfit_repair.repair_mesh()` | No cambia nada: 2 cuerpos; 4 aristas no manifold; 0 bucles de borde. | **No resuelve nuestro caso real.** |
| Cubo con un triángulo eliminado → `repair_mesh()` | No lo rellena; abertura considerada grande frente a la diagonal global. | Protege ciertas aberturas, pero el criterio es muy aproximado. |
| Cubo con dos triángulos eliminados → `repair_mesh()` | No lo rellena; queda abierto. | Idem. |
| Icosfera subdividida con un triángulo eliminado → `repair_mesh()` | Añade 9 triángulos y cierra el agujero; malla estanca. | Sí sirve para **agujeros pequeños de escaneo**. |
| Dos sólidos cerrados separados → `repair_mesh()` | Devuelve los dos sin tocar. | No une componentes. |
| `cubo-carrito.stl` → `_close_mesh()` de `meshfit-master/meshfit_step.py` | Aparece como estanco, pero siguen **2 cuerpos** y el volumen sube a `59.934,916885 mm³`: **+1,1687 %**. | **No es aceptable para nuestra aplicación.** `_close_mesh()` fue concebido para reparar mallas resultantes de teselar un STEP, no para fusionar STL arbitrarios. |

La función del amigo elimina también islas con menos del 0,5 % de caras de la mayor componente (junto con otras condiciones). En escaneos eso puede quitar ruido; en piezas mecánicas podría eliminar una característica o cuerpo pequeño intencionado. Su suavizado bilaplaciano modifica los vértices nuevos: tampoco garantiza precisión local en encajes o agujeros.

Pruebas reproducibles: `probar_reparacion.py`, `pruebas_extra.py` y `prueba_reparacion_resultados.json`.

## 6. Qué reutilizar y qué NO

### A. Prioridad alta — integración controlada

1. **Clasificador de defectos previo al motor.** Contar: cuerpos cerrados, bordes abiertos, aristas no manifold, degenerados/duplicados y orientación. Elegir ruta de reparación por **tipo de defecto**, no por nombre del STL ni una opción global de suavizado.
2. **Relleno local selectivo** basado en `meshfit_repair.py` para agujeros pequeños, con umbrales de **error geométrico real** y protección de huecos funcionales. Requiere ajustar la lógica para que solo se acepte el resultado cuando sea un único sólido apropiado, o cuando la política permita varios cuerpos independientes.
3. **Unión de cuerpos cerrados que se tocan/solapan**, utilizando una operación booleana robusta (por ejemplo kernel CAD o librería de mallas verificada), con diagnóstico de superficies coplanares y eliminación de caras interiores. Debe comprobar que no elimina canales, agujeros pasantes ni superficies útiles. **Esta función no viene resuelta por `meshfit_repair.py`; hay que desarrollarla y probarla.**
4. **Control de recursos**, adaptando ideas de `meshfit_guard.py` al servidor actual: memoria real del proceso, límites para rescates y cancelación efectiva; no ejecutar la misma estrategia varias veces sin nueva información.
5. **Batería automatizada de regresión**, basada en la organización de `bateria.py`/`taller.py`: huellas de archivo, conversión individual, tiempo y RAM, STEP reimportado, validez, número de cuerpos, dimensiones, volumen, distancias y tipo de caras. Debe usar los umbrales MÁS estrictos del Visor, no los umbrales permisivos de exploración del amigo.

### B. Prioridad media — investigaciones separadas

- Validación interna adicional de B-Rep del `meshfit-master`: áreas de caras, orientación topológica, caras defectuosas tras exportación/importación, comprobación completa de regiones candidatas. Podría ayudar a identificar costuras y reconstrucciones con volumen falseado; algunas operaciones son costosas y deben perfilarse.
- `step_to_stl` de `meshfit-master` ofrece una ruta de comprobación al volver a imprimir. **No adoptar automáticamente su reparador final `_close_mesh`**, que alteró el cubo-carrito; probarlo específicamente en geometría derivada de STEP y validar el resultado.
- `meshfit_open.py` como exportación OPCIONAL de una superficie abierta, claramente diferenciada de un STEP sólido. No usar para fingir cierre de objetos 3D.

### C. No incorporar directamente

- Suavizados/idealización global de escaneos como opción automática para STL digitales de diseño: pueden deformar agujeros, roscas, radios y superficies de encaje.
- Rellenar todo bucle de borde porque `is_watertight=False` (podría tapar aberturas deliberadas).
- Eliminar automáticamente pequeños componentes por recuento relativo de triángulos (pueden ser geometría funcional).
- La reparación agresiva `_close_mesh()` como solución general: el ensayo concreto evidencia una alteración excesiva del volumen y ausencia de unión real.
- Sustituir todo `motor_superficies` por `meshfit-master` sin medir regresiones, o aceptar la evaluación más permisiva de volumen del amigo: nuestro límite es 0,5 % y la función `meshfit_qc._verdict` considera 2 % sin alerta ámbar para piezas sin suavizado.

## 7. Arquitectura recomendada para la siguiente versión

```text
STL ORIGINAL (inmutable)
       │
       ▼
Diagnóstico topológico completo (+ informe claro)
       │
       ├─ 1 componente cerrado correcto ───────────────┐
       ├─ pequeños defectos locales ─ reparación local ┤
       ├─ varios cerrados en contacto ─ unión booleana ┤
       ├─ cuerpos separados ─ solicitar política (*) ──┤
       └─ ambigüedad / riesgo dimensional ─ RECHAZAR   │
                                                       ▼
               VALIDACIÓN INDEPENDIENTE DEL STL PREPARADO
          (volumen, bbox, piezas, paredes, agujeros, distancias)
                                                       │
                                                       ▼
                               MOTOR CAD V4 R1 INTACTO
                                                       │
                                                       ▼
                  VALIDACIÓN STEP REIMPORTADO + INFORME
```

(*) No unir en falso cuerpos espacialmente separados. El usuario puede querer un conjunto de piezas distinto de un sólido único.

Importante: el criterio de aceptación de una reparación **no puede comparar exclusivamente un volumen escalar**, porque dos errores locales opuestos pueden compensarse; hace falta comprobar superficies, topología, agujeros pasantes y orientación. Para entradas originalmente abiertas, el volumen de partida puede no ser físicamente interpretable: habrá que definir un objetivo de referencia según el tipo de reparación y pedir confirmación si es ambiguo.

## 8. Batería de aceptación para una integración futura

**Casos positivos:** 14 STL históricos deben conservar al menos su calidad de referencia; `cubo-carrito.stl` debe terminar con 1 malla cerrada sin modificar la geometría en exceso; icosfera con abertura pequeña debe cerrarse sin ondulaciones inesperadas; repetir girando la pieza en los ejes 3D.

**Casos negativos obligatorios:** cubo con abertura grande o una pared ausente (no sellar sin consentimiento), piezas separadas (no fusionar por cercanía), modelo con canal interior/ranura/rosca funcional (no rellenar), malla con aletas sin volumen (no crear volumen espurio), intersecciones complejas (explicar el fallo si no es segura la unión).

**Invariantes de salida:** si se genera un STEP: reimportar con OpenCascade, exactamente la cantidad de sólidos esperada, `BRepCheck_Analyzer` válido, dimensiones dentro de 0,020 mm, error de volumen dentro de 0,5 % respecto al **sólido de referencia verificado**, distancia de superficies dentro de los límites actuales, evitar peor número de caras/costuras si no hay mejora de fidelidad; revisión funcional *Move face* con Onshape cuando sea posible. Para la reparación previa de dos sólidos que se tocan, aspirar a una discrepancia de volumen muy inferior a 0,5 % respecto a la unión exacta (en `cubo-carrito`, el archivo de referencia difiere solo 0,000261 % respecto a la suma original).

**Compatibilidad:** Windows 64 bits + dependencias fijadas. No modificar la UI de cuatro botones, ni el nombre y posición del título, ni el flujo `Nuevo` para cancelar. Los mensajes deben indicar de forma distinta `borde abierto`, `unión no manifold`, `múltiples cuerpos`, `orientación` y `no se pudo garantizar reparación sin cambiar cotas`.

## 9. Límites de este estudio

- Se inspeccionó y comparó el código de los nueve ZIP y el ZIP concreto `Visor_STL_STEP_V4_0_USO_R1_CORREGIDO.zip`.
- Se ejecutaron **pruebas topológicas y del módulo de reparación** con STL reales y sintéticos. **No** se han ejecutado las nueve interfaces en Windows, la batería privada del amigo (sus STL se encuentran en rutas de sus ordenadores) ni una prueba completa de conversión STEP con cada variante.
- Una función disponible en el código no demuestra que sea apta para todas las piezas o que sus afirmaciones en comentarios hayan sido verificadas aquí.
- No se ha cambiado ningún archivo del Visor utilizado por el usuario; no se ha producido una nueva versión instalable.

## 10. Conclusión

**Aprovechar EasyMeshFit sí merece la pena, pero integrando mecanismos concretos de diagnóstico, reparación local, validación y QA.** Para `cubo-carrito` el avance imprescindible no es más relleno de agujeros: es un **módulo nuevo de unión de componentes cerrados con verificación dimensional**, seguido del motor de CAD ya existente. Esta ampliación debe quedar detrás de una clasificación conservadora y verificable, para que los STL ya correctos sigan funcionando exactamente igual.
