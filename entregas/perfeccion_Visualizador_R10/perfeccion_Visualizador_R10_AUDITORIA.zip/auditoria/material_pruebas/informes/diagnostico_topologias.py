import pathlib,sys,json,time
import numpy as np, trimesh
ROOT=pathlib.Path('/mnt/data/Easy_Analysis/benchmarks/files');paths=sorted(ROOT.glob('*.stl'))
paths+=[pathlib.Path('/mnt/data/cubo-carrito.stl'),pathlib.Path('/mnt/data/cubo-carrito_REPARADO.stl')]
res=[]
for path in paths:
 start=time.monotonic()
 m=trimesh.load(path,force='mesh',process=True)
 F=np.asarray(m.faces); V=np.asarray(m.vertices)
 edges=np.sort(F[:,[[0,1],[1,2],[2,0]]].reshape(-1,2),axis=1)
 _,n=np.unique(edges,axis=0,return_counts=True)
 comps=m.split(only_watertight=False)
 out={'archivo':path.name,'caras':len(F),'vertices':len(V),'cuerpos':len(comps),'cuerpos_estancos':sum(bool(c.is_watertight) for c in comps),'estanco':bool(m.is_watertight),'orientacion_consistente':bool(m.is_winding_consistent),'volumen_valido':bool(m.is_volume),'aristas_abiertas':int((n==1).sum()),'aristas_no_manifold':int((n>2).sum()),'volumen_mm3':round(float(m.volume),5),'dimensiones_mm':m.extents.round(6).tolist(),'segundos':round(time.monotonic()-start,2)}
 print(f"{out['archivo'][:27]:28s} tri={out['caras']:>7} components={out['cuerpos']} watertight={str(out['estanco']):<5} border={out['aristas_abiertas']:>5} nonmanifold={out['aristas_no_manifold']:>3} t={out['segundos']:>4}",flush=True)
 res.append(out)
path=pathlib.Path('/mnt/data/Easy_Analysis/diagnostico_topologias_resultados.json');path.write_text(json.dumps(res,ensure_ascii=False,indent=2))
