from pathlib import Path
import json,hashlib,zipfile,shutil
R=Path(__file__).resolve().parent;OLD=Path('/workspace/work/mejora_cilindros_post_R8_20261027')
STAGE=R/'preparacion_entrega';OUT=R/'entrega_GitHub/perfeccion_Visualizador_R10';EXTRACT=R/'verificacion paquete R10'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def copy(a,b):b.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(a,b)
def archive(base,target,prefix=''):
 files=sorted(p for p in base.rglob('*') if p.is_file() and p.name!='MANIFIESTO_SHA256.json' and not any(x in p.parts for x in ['__pycache__','.pytest_cache','.venv']))
 manifest={str(p.relative_to(base)):sha(p) for p in files};(base/'MANIFIESTO_SHA256.json').write_text(json.dumps(manifest,indent=2));files.append(base/'MANIFIESTO_SHA256.json')
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in sorted(files):z.write(p,str(Path(prefix)/p.relative_to(base)))
 assert target.stat().st_size<95*1024**2,(target.name,target.stat().st_size)
 with zipfile.ZipFile(target) as z:assert z.testzip() is None
 return {'archivo':target.name,'bytes':target.stat().st_size,'sha256':sha(target),'ficheros':len(files)}

def main():
 acceptance=load(R/'ACEPTACION_R10.json');assert acceptance['regresion']['aprobados']==24
 app=STAGE/'programa';qa=STAGE/'auditoria';results=STAGE/'resultados';comparison=STAGE/'comparacion_Tirante'
 OUT.mkdir(parents=True,exist_ok=True)
 summary=['INFORME_RESULTADOS.md','ACEPTACION_R10.json','RESULTADOS_REGRESION.csv','RESULTADOS_REGRESION.json','AUDITORIA_TOLERANCIAS.json','AUDITORIA_PRIORIDAD.json','ARCHIVOS_MODIFICADOS_R9.json','FUENTES_R10_SHA256.json','NUCLEO_EJECUTADO_R10_SHA256.json','ENTORNO_R10.json']
 for name in summary:
  for folder in [app,qa,OUT]:copy(R/name,folder/name)
 evidence=['pruebas_R10_fuentes_finales.xml','pruebas_R10_fuentes_finales.stdout','regresion_cli.json','navegador_resultados.json','cancelacion_resultado.json','lectura_fria_R10.json']
 for name in evidence:copy(R/name,qa/name)
 for name in ['pruebas_R10.stdout','pruebas_R10_completas.xml','pruebas_rescate.stdout','pruebas_rescate_R10.xml']:
  copy(R/name,qa/'incidencias_NO_APROBADAS'/name)
 (qa/'incidencias_NO_APROBADAS/LEEME.md').write_text('Las primeras pruebas incluyeron una ejecución sin CGAL en PYTHONPATH y un test de derivadas sin escala física. No son aprobaciones. El registro vigente es pruebas_R10_fuentes_finales.xml, sin fallos ni omisiones. Los intentos de superficies libres se descartaron y no están activos en el programa.\n')
 for base in ['compacto_circulos/maneta','compacto_cuadrilateros/maneta','analitico_ajustado/1x1-lego-brick']:
  folder=R/base
  if folder.exists():
   for p in folder.iterdir():
    if p.is_file() and p.suffix=='.json':copy(p,qa/'investigacion_NO_APROBADA'/base/p.name)
 for name in ['compacto_auto/maneta/VALIDACION_INTERRUMPIDA.json','compacto_auto2/maneta/VALIDACION_INTERRUMPIDA.json']:
  if (R/name).exists():copy(R/name,qa/'investigacion_NO_APROBADA'/name)
 for name in ['prototipo_compacto.py','ajustar_primitivas.py','cuadrilateros_compartidos_NO_APROBADO.py','probar_consolidacion.py','cilindros_respaldados_prototipos.json','analitico_lego.stdout']:
  if (R/name).exists():copy(R/name,qa/'investigacion_NO_APROBADA'/Path(name).name)
 (qa/'investigacion_NO_APROBADA/LEEME.md').write_text('Código de investigación y registros rechazados; no se instala ni se importa desde el Visor. Las rutas de los ensayos reflejan el entorno original. No usar sus STEP como resultados aprobados. La maneta falló la frontera fina y dos grupos cilíndricos; la bancada falló encuentros/parches. Los toros del Lego 1x1 no se incluyeron en el rescate activo.\n')
 for name in ['probar_visor_R10.cjs','probar_cancelacion.cjs','probar_paquete_extraido.cjs','auditar_steps_R10.py','ejecutar_regresion_R10.py','generar_informe_R10.py','empaquetar_R10.py','cerrar_auditorias.py','preparar_entrega_R10.py','registrar_entorno.py','auditar_prioridad.py']:
  copy(R/name,qa/'registro_ejecucion'/name)
 copy(R/'contrastar_cilindros_independiente.py',qa/'herramientas/contrastar_cilindros_independiente.py')
 for p in (R/'contrastes_independientes').iterdir():
  if p.is_file():copy(p,qa/'contrastes_independientes'/p.name)
 original_analysis=Path('/workspace/work/analisis_usuario_R9_20261027')
 for p in original_analysis.glob('*'):
  if p.is_file() and p.suffix in ['.md','.json']:copy(p,qa/'analisis_adjuntos_usuario'/p.name)
 for folder in ['regresion_cli','navegador']:
  for p in (R/folder).iterdir():
   if p.is_file():
    copy(p,results/folder/p.name)
    if p.suffix=='.json':copy(p,qa/'evidencias'/folder/p.name)
 gui=load(R/'navegador_resultados.json')['resultados'];cancel=load(R/'cancelacion_resultado.json');assert cancel['ok']
 jobs={r['job'] for r in gui}|{cancel['cancelacion']['id'],cancel['nuevo_trabajo']['id']}
 for job in jobs:
  for p in (R/'motor_R10_CONGELADO/Registros_Conversion').glob(job+'.*'):
   if job==cancel['cancelacion']['id'] and p.suffix=='.step':continue
   copy(p,results/'Registros_Conversion'/p.name)
 comparison.mkdir(parents=True,exist_ok=True)
 copy(R/'regresion_cli/Tirante.step',comparison/'Tirante_R10.step');copy(OLD/'regresion_cli/Tirante.step',comparison/'Tirante_R9.step')
 copy(R/'regresion_cli/Tirante.step',OUT/'STEP_PARA_PROBAR/Tirante_R10.step')
 (comparison/'LEEME.txt').write_text('Tirante_R9.step: 13.122 caras planas. Tirante_R10.step: 22 caras, diez cilíndricas, diez planas y dos superficies de revolución. Mismo STL original y perfil Precisión. R10 pasa CAD exacto, BOP, fidelidad geométrica, cilindros fuente, topología/material y tres mallados finos sin cruces CGAL. Consulta el informe para medidas y limitaciones. No se ha probado en Onshape ni Windows nativo.\n')
 manifest=load(R/'FUENTES_R10_SHA256.json')
 for rel,digest in manifest.items():
  p=app/'Visor_experimental_fuentes'/rel;assert sha(p)==digest;copy(p,OUT/'Visor_experimental_fuentes'/rel)
 for change in load(R/'ARCHIVOS_MODIFICADOS_R9.json'):
  rel=change['archivo'];copy(app/'Visor_experimental_fuentes'/rel,OUT/'archivos_modificados'/rel)
 for name in ['Iniciar.bat','Instalar_Entorno.bat','LEEME_PRIMERO.txt']:copy(app/name,OUT/name)
 for name in ['CAMBIOS_DESDE_R9.patch','REPRODUCIR.md']:copy(qa/name,OUT/name)
 packages=[archive(app,OUT/'perfeccion_Visualizador_R10_EXPERIMENTAL_COMPLETA.zip'),archive(qa,OUT/'perfeccion_Visualizador_R10_AUDITORIA.zip','auditoria'),archive(results,OUT/'perfeccion_Visualizador_R10_RESULTADOS_STEP.zip','resultados'),archive(comparison,OUT/'R10_TIRANTE_PARA_COMPARAR.zip','STEP_PARA_PROBAR')]
 (OUT/'PAQUETES_SHA256.json').write_text(json.dumps(packages,indent=2))
 assert not EXTRACT.exists(),'Verificar en una carpeta nueva'
 EXTRACT.mkdir()
 # Extract every archive and compare every contained file against its own manifest.
 for entry in packages:
  target=EXTRACT/('programa' if 'COMPLETA' in entry['archivo'] else '.')
  with zipfile.ZipFile(OUT/entry['archivo']) as z:z.extractall(target)
 for folder in ['programa','auditoria','resultados','STEP_PARA_PROBAR']:
  base=EXTRACT/folder
  for rel,digest in load(base/'MANIFIESTO_SHA256.json').items():assert sha(base/rel)==digest,(folder,rel)
 assert all(sha(EXTRACT/'programa/Visor_experimental_fuentes'/p)==v for p,v in manifest.items())
 (OUT/'VERIFICACION_PAQUETE.json').write_text(json.dumps({'CRC_cuatro_zip':True,'extraccion_real':True,'ruta_con_espacios':True,'fuentes_identicas':len(manifest),'arranque_extraido':'pendiente','Windows_nativo':False,'Onshape':False,'paquetes':packages},indent=2))
 (OUT/'README.md').write_text('''# Visor completo para Windows · R10 experimental

[**Descargar R10 completa**](./perfeccion_Visualizador_R10_EXPERIMENTAL_COMPLETA.zip?raw=true) · [**Comparar el tirante R9/R10**](./R10_TIRANTE_PARA_COMPARAR.zip?raw=true)

Extrae todo en una carpeta nueva y abre **Iniciar.bat**. Incluye `Visor_experimental_fuentes`. Si descargas todo el repositorio con Code → Download ZIP, entra en `entregas/perfeccion_Visualizador_R10` y abre allí Iniciar.bat. Puede reutilizar el entorno de R7, R8 o R9 sin modificarlo. Encabezado **R10 experimental**, puerto **8776**. Python 3.12 de 64 bits.

El tirante pasa de **13.122 caras planas a 22 caras**, con diez cilíndricas y dos superficies de revolución. La nueva reconstrucción sólo se intenta tras el rechazo de las rutas anteriores; mantiene los mismos controles geométricos, CAD exacto, BOP, material, cilindros y tres fronteras finas CGAL. La bancada y la maneta conservan su resultado R9 y siguen pendientes de mejora. No se promete una mejora en todas las piezas ni mayor velocidad.

[Informe de resultados reales](./INFORME_RESULTADOS.md) · [Tabla CSV](./RESULTADOS_REGRESION.csv) · [Verificación del paquete](./VERIFICACION_PAQUETE.json) · [STEP del tirante](./STEP_PARA_PROBAR/Tirante_R10.step?raw=true)

24 conversiones aprobadas y batería automática sin fallos ni omisiones. Incluye cubo-carrito y sus tres giros; Embudo continúa aplazado, por lo que no se declara 14/14. **Windows nativo, Onshape y K1C no se han ejecutado aquí.**

Material para desarrollo y revisión:

- [Auditoría y reproducción](./perfeccion_Visualizador_R10_AUDITORIA.zip?raw=true).
- [Todos los STEP y registros](./perfeccion_Visualizador_R10_RESULTADOS_STEP.zip?raw=true).
- [Archivos modificados](./archivos_modificados), [parche desde R9](./CAMBIOS_DESDE_R9.patch) y [reproducción](./REPRODUCIR.md).

R10 es una copia experimental independiente; las versiones anteriores y la web de main se conservan.
''',encoding='utf-8')
 print(json.dumps(packages),flush=True)
if __name__=='__main__':main()
