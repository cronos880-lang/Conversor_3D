from pathlib import Path
import os,sys,json,platform,importlib.metadata as meta,hashlib
R=Path(__file__).resolve().parent
sys.path.insert(0,'/workspace/work/herramientas_r5')
packages={}
for name in ['cadquery','cadquery-ocp','trimesh','numpy','scipy','vtk','shapely','fastapi','uvicorn','python-multipart','manifold3d','psutil','networkx','gpytoolbox','cgal','libigl','pytest']:
 try:packages[name]=meta.version(name)
 except meta.PackageNotFoundError:packages[name]='no encontrado'
record={'plataforma':platform.platform(),'python':sys.version,'paquetes':packages,'Windows_nativo':False,'Onshape':False,'K1C':False,'cgroup_cpu_max':Path('/sys/fs/cgroup/cpu.max').read_text().strip(),'cgroup_memoria_max':Path('/sys/fs/cgroup/memory.max').read_text().strip(),'dependencias_CGAL_Linux':'Instaladas previamente en herramientas_r5, añadidas a PYTHONPATH para la QA. Las versiones figuran en requirements_bloqueadas.txt.','periodo_UTC':{'inicio':'2026-10-27 21:14 UTC','maximo_autorizado':'2026-10-28 02:14 UTC'}}
(R/'ENTORNO_R10.json').write_text(json.dumps(record,indent=2,ensure_ascii=False))
print(record['cgroup_cpu_max'],record['cgroup_memoria_max'])
