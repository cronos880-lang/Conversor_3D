"""Preparar fuentes portables y material de reproducción sin tocar R9."""
from pathlib import Path
import json,hashlib,shutil,difflib
R=Path(__file__).resolve().parent
OLD=Path('/workspace/work/mejora_cilindros_post_R8_20261027')
M=R/'motor_R10_CONGELADO';STAGE=R/'preparacion_entrega';APP=STAGE/'programa';QA=STAGE/'auditoria'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(a,b):b.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(a,b)

def prepare():
 manifest=json.loads((R/'FUENTES_R10_SHA256.json').read_text())
 for rel,digest in manifest.items():
  p=M/rel;assert sha(p)==digest;copy(p,APP/'Visor_experimental_fuentes'/rel)
 APP.mkdir(parents=True,exist_ok=True)
 for action in ['Iniciar','Instalar_Entorno']:
  text='@echo off\nsetlocal\ncd /d "%~dp0"\ncall "%~dp0Visor_experimental_fuentes\\'+action+'.bat"\nexit /b %errorlevel%\n'
  (APP/(action+'.bat')).write_bytes(text.replace('\n','\r\n').encode())
 (APP/'LEEME_PRIMERO.txt').write_text('''VISOR STL -> STEP R10 EXPERIMENTAL COMPLETA

Extrae TODO en una carpeta NUEVA. Conserva R7, R8 y R9.
Abre Iniciar.bat. Puede reutilizar el entorno de R7, R8 o R9 sin modificarlo.
Si falta un entorno compatible, usa Instalar_Entorno.bat (Python 3.12 de 64 bits).
Comprueba el encabezado R10 experimental y http://127.0.0.1:8776.

Incluye la carpeta Visor_experimental_fuentes. No copies ficheros sobre tu versión anterior.
Mantén Automático (precisión). El perfil 0.08 no obliga a reconocer más cilindros.

La mejora nueva reconstruye encuentros de planos, cilindros y superficies de revolución,
únicamente después del rechazo de las rutas anteriores y con todos los controles.
Consulta INFORME_RESULTADOS.md: no todas las piezas ganan calidad en esta entrega.
Windows nativo, Onshape y la impresora K1C no se pueden ejecutar en este entorno Linux.
''',encoding='utf-8')
 copy(R/'FUENTES_R10_SHA256.json',APP/'FUENTES_SHA256.json')
 for folder in ['material_pruebas','banco_negativo_R7','evaluador_R7_inmutable','entradas_recientes']:
  shutil.copytree(OLD/'preparacion_entrega/auditoria'/folder,QA/folder,dirs_exist_ok=True)
 for name in ['EVALUADOR_R7_SHA256.json','compatibilidad_wheels_windows.json']:
  copy(OLD/'preparacion_entrega/auditoria'/name,QA/name)
 for name in ['control_frontera_inmutable_M1.py','reproducir_pruebas.py']:
  copy(OLD/'preparacion_entrega/auditoria/herramientas'/name,QA/'herramientas'/name)
 protocol=json.loads((OLD/'preparacion_entrega/auditoria/PROTOCOLO_PORTABLE.json').read_text())
 for case in protocol['casos']:
  refs=[OLD/f/(case['id']+'.step') for f in ['regresion_cli','navegador']]
  ref=next(p for p in refs if p.exists());target=QA/'referencias_R9'/ref.name;copy(ref,target)
  case['referencia_step']='referencias_R9/'+ref.name;case['sha256_referencia_R9']=sha(target)
  assert sha(QA/case['source'])==case['sha256']
 protocol.update(version='R10',motor='../programa/Visor_experimental_fuentes',
                 alcance='21 casos principales, tres recientes por navegador; Embudo aplazado. El informe identifica cada ruta real.')
 (QA/'PROTOCOLO_PORTABLE.json').write_text(json.dumps(protocol,indent=2,ensure_ascii=False))
 tool=(OLD/'preparacion_entrega/auditoria/herramientas/reproducir_regresion.py').read_text().replace('FUENTES_R9_SHA256','FUENTES_R10_SHA256')
 (QA/'herramientas/reproducir_regresion.py').write_text(tool)
 (QA/'REPRODUCIR.md').write_text('''# Reproducción de R10

Extrae el programa y la auditoría como carpetas hermanas `programa` y `auditoria`.
Usa Python 3.12 y las dependencias bloqueadas del Visor; para pytest instala además `requirements_pruebas.txt`.

```
python auditoria/herramientas/reproducir_pruebas.py --motor programa/Visor_experimental_fuentes --material-r7 auditoria/material_pruebas --banco-r7 auditoria/banco_negativo_R7 --xml pruebas.xml
python auditoria/herramientas/reproducir_regresion.py --motor programa/Visor_experimental_fuentes --auditoria auditoria --salida resultados
```

La herramienta repite las conversiones por CLI; el registro entregado distingue CLI y navegador reales. No implica una prueba de Windows nativo ni de WebAssembly. Los evaluadores previos se conservan para los contrastes independientes. Embudo está aplazado.
''')
 before=json.loads((OLD/'FUENTES_R9_SHA256.json').read_text());changes=[];patch=[]
 for rel,digest in manifest.items():
  if before.get(rel)==digest:continue
  a=OLD/'motor_R9_CONGELADO'/rel;b=M/rel
  changes.append({'archivo':rel,'sha256_R9':before.get(rel),'sha256_R10':digest})
  copy(b,STAGE/'archivos_modificados'/rel)
  patch.extend(difflib.unified_diff(a.read_text().splitlines(keepends=True) if a.exists() else [],b.read_text().splitlines(keepends=True),fromfile='R9/'+rel if a.exists() else '/dev/null',tofile='R10/'+rel))
 (R/'ARCHIVOS_MODIFICADOS_R9.json').write_text(json.dumps(changes,indent=2));(QA/'CAMBIOS_DESDE_R9.patch').write_text(''.join(patch))
 # The actual numerical/topological acceptance code must be byte-identical.
 guards=['perfiles_precision.py','perfiles_cad.py','motor_superficies/contornos_compatibles.py','motor_superficies/fijacion_contornos.py','motor_v2.py','calidad_topologica.py','saneamiento_cad.py','validacion_reconstruccion.py','invariantes_material.py','prueba_cad.py','motor_superficies/pcurvas_compartidas.py']
 records=[]
 for rel in guards:
  if not (M/rel).exists():continue
  records.append({'archivo':rel,'R9':sha(OLD/'motor_R9_CONGELADO'/rel),'R10':sha(M/rel),'identico':sha(OLD/'motor_R9_CONGELADO'/rel)==sha(M/rel)})
 assert all(r['identico'] for r in records)
 (R/'AUDITORIA_TOLERANCIAS.json').write_text(json.dumps({'limites_modificados':False,'controles':records},indent=2))
 print('PREPARADO',len(manifest),'archivos,',len(changes),'cambios,',len(records),'controles idénticos')
if __name__=='__main__':prepare()
