from pathlib import Path
import json,hashlib,ast
R=Path(__file__).resolve().parent;OLD=Path('/workspace/work/mejora_cilindros_post_R8_20261027/motor_R9_CONGELADO');NEW=R/'motor_R10_CONGELADO'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=ast.parse((OLD/'reconstruccion_curvas.py').read_text());new=ast.parse((NEW/'reconstruccion_curvas.py').read_text())
a={x.name:x for x in old.body if isinstance(x,ast.FunctionDef)};b={x.name:x for x in new.body if isinstance(x,ast.FunctionDef)}
records=[]
for name,node in a.items():
 other=b['_intentar_refinar_R9' if name=='intentar_refinar' else name]
 clone=ast.parse(ast.unparse(other)).body[0];clone.name=name
 same=ast.dump(node,include_attributes=False)==ast.dump(clone,include_attributes=False)
 records.append({'funcion_R9':name,'conservada':same});assert same,name
manifest=json.loads(Path('/workspace/work/mejora_cilindros_post_R8_20261027/FUENTES_R9_SHA256.json').read_text())
unchanged=[];changed=[]
for rel,sha in manifest.items():
 if rel.endswith('.py') and not Path(rel).name.startswith('test_'):
  (unchanged if digest(NEW/rel)==sha else changed).append(rel)
assert set(changed)=={'arrancar.py','entorno_local.py','reconstruccion_curvas.py','version_programa.py'},changed
record={'funciones_R9':records,'nucleo_R9_sin_cambios':unchanged,'modulos_R9_modificados':changed,
        'nuevos_modulos':['reconstruccion_analitica.py','motor_superficies/encuentros_analiticos.py'],
        'prioridad':'El wrapper intenta primero _intentar_refinar_R9. Sólo ante su rechazo llama al rescate nuevo. Se prueba con centinelas independientes.',
        'controladores_de_aceptacion':'motor_v2, perfiles_precision, calidad_topologica, saneamiento_cad, validacion_reconstruccion, invariantes_material, prueba_cad y pcurvas_compartidas conservan los mismos bytes R9.'}
(R/'AUDITORIA_PRIORIDAD.json').write_text(json.dumps(record,indent=2,ensure_ascii=False));print('Funciones conservadas',len(records),'módulos idénticos',len(unchanged))
