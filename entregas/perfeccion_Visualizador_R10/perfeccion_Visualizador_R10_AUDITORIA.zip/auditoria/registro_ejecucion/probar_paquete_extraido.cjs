const {chromium}=require('playwright');const fs=require('fs'),path=require('path'),crypto=require('crypto');
const root=__dirname,app=path.join(root,'verificacion paquete R10','programa','Visor_experimental_fuentes'),url='http://127.0.0.1:8881';
const digest=b=>crypto.createHash('sha256').update(b).digest('hex');
(async()=>{
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});const page=await browser.newPage({acceptDownloads:true});const errors=[];let job;
page.on('pageerror',e=>errors.push(String(e)));page.on('response',async r=>{if(r.url().endsWith('/iniciar-conversion'))try{job=(await r.json()).id}catch{}});
const report={ok:false,extraido:app};
try{
report.identidad=await(await page.request.get(url+'/version')).json();if(report.identidad.instancia!==digest(Buffer.from(path.resolve(app))).slice(0,20))throw Error('El servidor es de otra carpeta');
await page.goto(url);await page.waitForFunction(()=>!document.getElementById('openBtn').disabled);report.titulo=await page.title();if(!report.titulo.includes('R10'))throw Error('Título incorrecto');
if(await page.locator('#conversionProfile').inputValue()!=='precision')throw Error('Perfil por defecto incorrecto');
await page.locator('#fileInput').setInputFiles(path.join(root,'caja_control.stl'));await page.waitForFunction(()=>!document.getElementById('convertBtn').disabled);await page.locator('#convertBtn').click();
await page.waitForFunction(()=>document.getElementById('conversionPercent').textContent==='100 %'||document.getElementById('conversionPercent').classList.contains('failed'),{},{timeout:180000});
if(await page.locator('#conversionPercent').evaluate(e=>e.classList.contains('failed')))throw Error(await page.locator('#error').innerText());
page.once('dialog',d=>d.accept('caja_paquete'));const waiting=page.waitForEvent('download');await page.locator('#exportBtn').click();const file=await waiting;const destination=path.join(root,'verificacion paquete R10','caja_paquete.step');await file.saveAs(destination);
const bytes=fs.readFileSync(destination);report.descarga_identica_backend=bytes.equals(fs.readFileSync(path.join(app,'Registros_Conversion',job+'.step')));report.sha256_step=digest(bytes);report.diagnostico=JSON.parse(fs.readFileSync(path.join(app,'Registros_Conversion',job+'.json')));report.ok=report.descarga_identica_backend&&errors.length===0;
await page.screenshot({path:path.join(root,'verificacion paquete R10','caja_paquete.png')});
}catch(e){report.error=String(e)}finally{report.errores_js=errors;fs.writeFileSync(path.join(root,'prueba_paquete_extraido.json'),JSON.stringify(report,null,2));console.log(JSON.stringify({ok:report.ok,error:report.error}));await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
