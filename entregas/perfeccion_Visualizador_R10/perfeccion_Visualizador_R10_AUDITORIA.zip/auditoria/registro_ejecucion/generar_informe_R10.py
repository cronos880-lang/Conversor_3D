from pathlib import Path
import json,csv,hashlib,xml.etree.ElementTree as ET,datetime
R=Path(__file__).resolve().parent;OLD=Path('/workspace/work/mejora_cilindros_post_R8_20261027')
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def data(p):a=p.read_bytes();return a[a.index(b'DATA;'):]
def quality(row):return row['diagnostico']['calidad'] if row['ruta']=='interfaz_navegador' else row['informe_motor']['resultado']['calidad']

def main():
 cli=load(R/'regresion_cli.json')['resultados'];gui=load(R/'navegador_resultados.json')['resultados'];rows=cli+gui
 assert len(cli)==15 and len(gui)==9 and len({r['id'] for r in rows})==24
 assert all(r['ok'] for r in rows)
 tests=ET.parse(R/'pruebas_R10_fuentes_finales.xml').find('.//testsuite')
 assert int(tests.get('tests'))>=249 and tests.get('errors')=='0' and tests.get('failures')=='0' and tests.get('skipped')=='0',tests.attrib
 cold=load(R/'lectura_fria_R10.json');assert len(cold)==25 and all(x['ok'] for x in cold)
 assert load(R/'cancelacion_resultado.json')['ok']
 manifest=load(R/'FUENTES_R10_SHA256.json');core=load(R/'NUCLEO_EJECUTADO_R10_SHA256.json')
 assert all(sha(R/'motor_R10_CONGELADO'/p)==v for p,v in manifest.items())
 assert all(manifest[p]==v for p,v in core.items()),'El núcleo probado debe ser el entregado'
 table=[]
 for row in rows:
  folder='navegador' if row['ruta']=='interfaz_navegador' else 'regresion_cli'
  p=R/folder/(row['id']+'.step');prev=OLD/folder/p.name;q=quality(row)
  assert sha(p)==row['sha256_step']
  identical=data(p)==data(prev)
  table.append(dict(pieza=row['id'],ruta=row['ruta'],ok=True,caras=q['caras_step'],tipos=q['tipos_caras'],segundos=row['segundos'],
                    max_observado_mm=q['desviacion_max_verificada_mm'],error_caja_mm=q['caja_error_mm'],error_volumen_pct=q['volumen_error_pct'],DATA_identico_R9=identical,sha256_step=sha(p)))
 unchanged=[r for r in table if r['DATA_identico_R9']];changed=[r for r in table if not r['DATA_identico_R9']]
 tirante=next(r for r in rows if r['id']=='Tirante');tq=quality(tirante);tp=tirante['informe_motor']['resultado']['saneamiento_cad']
 assert tq['caras_step']==22 and tq['tipos_caras']['GeomAbs_Cylinder']==10 and tp['metodo']=='encuentros_analiticos_certificados'
 assert len(tp['mallado_fino']['resoluciones'])==3 and all(x['intersecciones_cgal']==0 and x['cerrado'] and x['orientado'] for x in tp['mallado_fino']['resoluciones'])
 acceptance={'version':'R10 experimental','fecha_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'regresion':{'principales':21,'recientes':3,'aprobados':24,'DATA_identicos_R9':len(unchanged),'modificados':[r['pieza'] for r in changed]},
             'pruebas_automaticas':{k:int(tests.get(k)) for k in ['tests','errors','failures','skipped']},
             'lectura_fria':{'archivos':len(cold),'aprobados':len(cold)},'tirante':tq,'prueba_encuentros':tp,
             'limites_modificados':False,'cancelacion_y_conversion_posterior':True,'Embudo':'Aplazado por el usuario; no se declara 14/14',
             'Windows_nativo':False,'Onshape':False,'K1C':False,'nucleo_entregado_identico_al_ejecutado':True}
 (R/'ACEPTACION_R10.json').write_text(json.dumps(acceptance,indent=2,ensure_ascii=False))
 (R/'RESULTADOS_REGRESION.json').write_text(json.dumps(table,indent=2,ensure_ascii=False))
 with (R/'RESULTADOS_REGRESION.csv').open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=list(table[0]));w.writeheader();w.writerows(table)
 lines=['# Visor R10 experimental: resultados reales','',
 'La mejora demostrada de esta entrega está en el tirante: **13.122 caras planas en R9 → 22 caras en R10**, con diez caras cilíndricas, diez planas y dos superficies de revolución. Se obtiene desde el STL mediante el motor completo, sin seleccionar un caso por su nombre. La bancada y la maneta todavía necesitan otra mejora; no se presentan como resueltas.','',
 '## Qué cambia y cómo se protege lo que funciona','',
 'Se añade una reconstrucción acotada de los encuentros entre planos, cilindros y superficies de revolución, únicamente después del rechazo de las estrategias R9. Se reconstruyen vértices y aristas compartidas, se prolonga el perfil cúbico de revolución sin alterar su intervalo original y se verifica la correspondencia de las curvas 3D con sus curvas UV. Las elipses de radios iguales a menos de 1e-12 mm se escriben como círculos, con el mismo eje, parametrización y tolerancia; las elipses reales se conservan.','',
 'La nueva ruta requiere una sola componente STL sana, cerrada y orientada, hasta 20.000 triángulos y hasta 192 caras CAD compactas. Rechaza superficies libres y toroidales que esta entrega no verifica. No rellena huecos ni cambia automáticamente la intención geométrica. Tiene trabajador aislado, vigilancia de recursos y un plazo de 450 s adicional para esta propuesta. Si falla, no sustituye el candidato. La nueva ruta no garantiza que el motor sea más rápido.','',
 f'**{len(unchanged)}/24 resultados conservan el bloque DATA de R9 idéntico byte a byte.** Resultados distintos: '+', '.join(r['pieza'] for r in changed)+'. Las huellas del núcleo de 84 archivos ejecutado y entregado coinciden. Las correcciones posteriores a la primera instantánea afectan a pruebas, documentación y saltos de línea del instalador; no cambian el núcleo CAD de esas conversiones.','',
 '## Geometría del tirante','',
 '| Medida | Resultado R10 | Límite original de Precisión |','|---|---:|---:|',
 f'| Error relativo de volumen | {tq["volumen_error_pct"]:.6f} % | 0,5 % |',
 f'| Diferencia de caja | {tq["caja_error_mm"]:.6f} mm | 0,02 mm |',
 f'| p95 denso máximo | {max(tq["inspeccion_densa"]["stl_a_cad"]["p95_mm"],tq["inspeccion_densa"]["cad_a_stl"]["p95_mm"]):.8f} mm | 0,02 mm |',
 f'| Distancia máxima observada | {tq["desviacion_max_verificada_mm"]:.6f} mm | 0,06 mm |',
 '| Tolerancia máxima de aristas CAD | 0,0000001 mm | Sin aumento |','',
 'El STEP reimportado contiene un único sólido válido, supera el control CAD exacto y BOP no encuentra interferencias. Conserva Euler −10. Los seis grupos cilíndricos confirmados por el detector sobre el STL se mantienen dentro de las caras recortadas, con el control previo de 0,008 mm. No se sustituye ese control por distancia a un cilindro infinito.','',
 '| Deflexión de mallado | Triángulos | Cerrado y orientado | Intersecciones CGAL |','|---|---:|---|---:|']
 for mesh in tp['mallado_fino']['resoluciones']:
  lines.append(f'| {mesh["deflexion_mm"]} mm | {mesh["caras"]} | Sí | {mesh["intersecciones_cgal"]} |')
 lines+=['','Las distancias se contrastan con muestras deterministas y con los tres mallados de frontera; no constituyen una demostración de distancia Hausdorff global para STL arbitrarios.','',
 '## Batería completa','',
 f'**{tests.get("tests")} pruebas automáticas aprobadas, sin omisiones.** 21 conversiones principales y tres recientes aprobadas; 15 por CLI y nueve mediante Chromium, con carga, conversión y descarga real. Se comprueba la identidad del servidor, el perfil Precisión, los bytes descargados y la conservación del STL original. La lectura fría independiente de los 24 STEP y la caja posterior a la cancelación también pasa.','',
 'Los 21 casos principales incluyen cubo-carrito y tres giros, las doce piezas históricas restantes y cinco regresiones adicionales. En total se conservan trece de las catorce históricas: **Embudo continúa aplazado por indicación del usuario; no se declara 14/14**. Los tres recientes son Lego 4×2, soporte móvil y Technic PEGS.','',
 '| Pieza | Caras STEP | Máximo observado (mm) | DATA igual a R9 |','|---|---:|---:|---|']
 for row in table:lines.append(f'| {row["pieza"]} | {row["caras"]} | {row["max_observado_mm"]:.6f} | {"Sí" if row["DATA_identico_R9"] else "No"} |')
 lines+=['','Los tiempos individuales y las huellas constan en RESULTADOS_REGRESION.csv y en los registros JSON. Se ejecutaron colas concurrentes en un entorno Linux limitado a dos CPU y 8 GiB; sus tiempos no se presentan como referencia del ordenador del usuario.','',
 '## Lo descartado y lo que falta','',
 'Las variantes compactas de la maneta llegaron a superar comprobaciones CAD y algunas medidas, pero fallaron la frontera fina CGAL y la conservación de dos grupos cilíndricos. Se descartaron. Las variantes de la bancada fallaron encuentros o parches interiores verificables y también se descartaron. La propuesta toroidal de Lego 1×1 no alcanzó la coherencia exigida en los vértices. Ninguna de esas variantes ni sus atajos forman parte de la ruta activa.','',
 'La llanta conserva la mejora ya aprobada de R9. La bancada, maneta y las zonas aún facetadas siguen pendientes; una conversión correcta no equivale a recuperar todas las superficies analíticas. Octogon y Barrera_Lego sólo se habían recibido como STEP en el lote anterior y no se declaran reconvertidos.','',
 'La primera ejecución de pytest se lanzó sin el directorio de dependencias CGAL de este entorno Linux y produjo fallos de preparación; además se corrigió una aserción de derivadas para medir el error físico de Taylor y se aislaron los tests de caché R9 de la estrategia nueva. Se conserva el registro rechazado. La batería válida se repitió con las dependencias explícitas; no se rebajaron los controles geométricos ni se ocultaron pruebas.','',
 '**No ejecutado aquí:** Windows nativo, importación en Onshape y prueba física en Creality K1C. La entrega incluye el Visor completo preparado para Windows y las dependencias fijadas, pero necesita esa validación en su sistema. La inspección visual de Onshape no se declara resuelta por el control OCC.','',
 '## Uso y reproducción','',
 'Extrae el ZIP completo en una carpeta nueva y abre Iniciar.bat. Incluye Visor_experimental_fuentes; puede reutilizar el entorno CAD de R7, R8 o R9 sin modificarlo. Encabezado R10 experimental, puerto 8776. Mantén Automático (precisión). El perfil 0,08 permite otro error geométrico; no fuerza más cilindros ni mejora por sí solo la topología.','',
 'La auditoría separada incluye entradas, referencias, evaluadores anteriores, scripts de reproducción, hashes, pruebas, incidencias y registros. Los archivos modificados y el parche desde R9 se entregan por separado. Las versiones anteriores y la web de main permanecen intactas.']
 (R/'INFORME_RESULTADOS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
 print('ACEPTACIÓN',len(rows),'conversiones',tests.get('tests'),'tests',len(unchanged),'DATA idénticos')
if __name__=='__main__':main()
