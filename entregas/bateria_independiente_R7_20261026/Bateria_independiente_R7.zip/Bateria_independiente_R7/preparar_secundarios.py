"""Variantes controladas; no cuentan como modelos externos distintos."""
from pathlib import Path
import hashlib,json
import numpy as np,trimesh,cadquery as cq
from oraculo_cad import ROOT
from preprocesador_stl import cargar_exacto
from validacion_reconstruccion import euler_brep

corpus=json.loads((ROOT/'corpus.json').read_text())['casos'];folder=ROOT/'stl_secundarios';folder.mkdir(exist_ok=True);refs=ROOT/'referencias_secundarios';refs.mkdir(exist_ok=True);rows=[]
base=next(x for x in corpus if x['id']=='02_taladro');mesh=cargar_exacto(ROOT/base['stl']);cad=cq.importers.importStep(str(ROOT/base['referencia_step'])).val()
def add(name,m,shape,kind,expected,limit=300,extra=None,details=None):
 stl=folder/(name+'.stl');step=refs/(name+'.step');stl.write_bytes(m.export(file_type='stl'));shape.exportStep(str(step));row={'id':name,'tipo':kind,'origen_externo':base['url_fuente'] if kind=='defecto_controlado' else details['url_fuente'],
  'stl':str(stl.relative_to(ROOT)),'referencia_step':str(step.relative_to(ROOT)),'sha256_stl':hashlib.sha256(stl.read_bytes()).hexdigest(),'sha256_step_referencia':hashlib.sha256(step.read_bytes()).hexdigest(),
  'euler_cad':int(euler_brep(shape)),'solidos_referencia':len(shape.Solids()),'objetivo':expected,'limite_motor_s':limit,'limite_oraculo_s':600,'extra_env':extra or {},'detalles':details or {}}
 rows.append(row)

dup=trimesh.Trimesh(mesh.vertices.copy(),np.vstack((mesh.faces,mesh.faces[[0,5]])),process=False);add('D01_caras_duplicadas',dup,cad,'defecto_controlado','reparar')
faces=mesh.faces.copy();faces[[0,5,9]]=faces[[0,5,9]][:,::-1];flipped=trimesh.Trimesh(mesh.vertices.copy(),faces,process=False);add('D02_orientacion_parcial',flipped,cad,'defecto_controlado','reparar')
rng=np.random.default_rng(260102);delta=rng.normal(0,.00015,mesh.vertices.shape);noise=trimesh.Trimesh(mesh.vertices+delta,mesh.faces.copy(),process=False);add('D03_ruido_micrometrico',noise,cad,'defecto_controlado','reparar',600,details={'sigma_mm':.00015,'max_desplazamiento_mm':float(np.linalg.norm(delta,axis=1).max())})
opened=mesh.copy();opened.update_faces(np.arange(len(mesh.faces))!=int(np.argmax(mesh.area_faces)));add('D04_hueco_grande',opened,cad,'defecto_controlado','rechazo_o_reparacion_verificada')
island=trimesh.creation.box(extents=[.2]*3);island.apply_translation([35,0,0]);tiny=cq.Solid.makeBox(.2,.2,.2,cq.Vector(34.9,-.1,-.1));compound=cq.Compound.makeCompound([cad,tiny]);add('D05_isla_pequena_separada',trimesh.util.concatenate((mesh,island)),compound,'defecto_controlado','rechazar_sin_eliminar_cuerpos')
second=mesh.copy();second.apply_translation([20,0,0]);union=cad.fuse(cad.translate((20,0,0)));assert len(union.Solids())==1 and union.isValid();add('D06_solidos_solapados',trimesh.util.concatenate((mesh,second)),union,'defecto_controlado','reparar',600,details={'referencia_de_intencion':'Unión CAD de las dos copias, definida antes de convertir','traslacion_mm':[20,0,0]})

for ident in ['02_taladro','09_pared_delgada','16_loft']:
 row=next(x for x in corpus if x['id']==ident);m=cargar_exacto(ROOT/row['stl']);m.apply_transform(trimesh.transformations.rotation_matrix(.43,[1,2,3]));shape=cq.importers.importStep(str(ROOT/row['referencia_step'])).val().rotate((0,0,0),(1,2,3),float(np.degrees(.43)));add('R_'+ident,m,shape,'rotacion','convertir_y_preservar',900,details={'url_fuente':row['url_fuente'],'angulo_rad':.43,'eje':[1,2,3]})
row=next(x for x in corpus if x['id']=='17_barrido_spline');m=cargar_exacto(ROOT/row['stl']);shape=cq.importers.importStep(str(ROOT/row['referencia_step'])).val();add('G17_control_interferencias',m,shape,'diagnostico_bandera_existente','comparar_sin_contar_como_R7_predeterminada',900,{'VISOR_VERIFICAR_INTERFERENCIAS_CAD':'1'},details={'url_fuente':row['url_fuente'],'nota':'Bandera ya incluida en R7; el código del motor permanece idéntico.'})
(ROOT/'protocolo_secundarios.json').write_text(json.dumps({'seleccion_antes_de_ejecutar':True,'nota':'La calibración STL/CAD no es requisito en defectos introducidos deliberadamente. Se conservan todas las puertas geométricas, de material y topología. Un rechazo seguro no se cuenta como reparación.','casos':rows},indent=2,ensure_ascii=False));print('Preparadas',len(rows),'variantes controladas.')
