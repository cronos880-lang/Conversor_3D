"""Preparar kits de prueba y evidencia sin publicar ni cambiar el motor."""
from pathlib import Path
import json,hashlib,shutil,zipfile,datetime
ROOT=Path(__file__).resolve().parent
DEST=ROOT/'entrega_final'
FULL=DEST/'Bateria_independiente_R7'
SMALL=DEST/'Piezas_para_probar_R7'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def copy(src,dst):
    dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
def zip_folder(folder):
    path=DEST/(folder.name+'.zip')
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for f in sorted(folder.rglob('*')):
            if f.is_file():z.write(f,folder.name+'/'+f.relative_to(folder).as_posix())
    with zipfile.ZipFile(path) as z:assert z.testzip() is None
    return {'archivo':path.name,'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'git_blob_sha1':hashlib.sha1(b'blob '+str(path.stat().st_size).encode()+b'\0'+path.read_bytes()).hexdigest()}
def main():
    assert not DEST.exists(),'No sobrescribir una entrega existente'
    FULL.mkdir(parents=True);SMALL.mkdir()
    corpus=read(ROOT/'corpus.json')['casos'];summary=read(ROOT/'resumen_final.json')
    assert len(corpus)==20 and read(ROOT/'integridad_motor_R7.json')['ok'] and read(ROOT/'procedencia_verificada.json')['ok']
    # Sólo los archivos exactos de la R7 publicada, sin registros ni cachés generados.
    for name,data in read(ROOT/'integridad_motor_R7.json')['archivos'].items():
        src=ROOT/'motor_R7_inmutable'/name
        assert hashlib.sha256(src.read_bytes()).hexdigest()==data['sha256_esperado']
        copy(src,FULL/'motor_R7_inmutable'/name)
    # Fuentes externas seleccionadas y licencias completas.
    for spec in corpus:copy(ROOT/spec['archivo_fuente'],FULL/spec['archivo_fuente'])
    for group in ('cadquery','mfcad'):copy(ROOT/f'fuentes_{group}/LICENSE',FULL/f'fuentes_{group}/LICENSE')
    # Los scripts históricos se conservan; reproducir.py es la entrada sin fecha límite.
    for src in ROOT.glob('*.py'):copy(src,FULL/src.name)
    for name in ('reproducir_17_navegador.cjs','LEEME.md','INFORME_CAPACIDAD_R7.md','requirements_bateria.txt',
                 'piezas_referencia.png','capacidad_r7.png','capacidad_r7.svg','corpus.json','protocolo.json',
                 'protocolo_secundarios.json','protocolo_complementario.json','protocolo_complementario_inicial.json','bateria_sanos.json','bateria_secundarios.json',
                 'oraculos_sanos.json','oraculos_sanos_primer_resumen.json','oraculos_secundarios.json','resumen_final.json',
                 'entorno_ensayado.json','integridad_motor_R7.json','procedencia_verificada.json','referencias_certificadas.json',
                 'evaluador_verificado.json','equivalencia_cache_distancias.json','revision_cajas_todos.json',
                 'revision_cajas_cad.json','caja_20_convergencia.json','confirmacion_barrido_spline.json',
                 'resultados_sanos.csv','resultados_secundarios.csv','resultado_complementario_20.csv','resultados_para_probar.csv'):
        copy(ROOT/name,FULL/name)
    # Entradas y CAD esperado; omitir temporales OFF usados por CGAL.
    for folder in ('stl_sanos','referencias','stl_secundarios','referencias_secundarios','stl_complementarios','calibracion_evaluador'):
        for src in (ROOT/folder).rglob('*'):
            if src.is_file() and src.suffix in ('.stl','.step','.json'):copy(src,FULL/src.relative_to(ROOT))
    for folder in ('oraculos','oraculos_secundarios','resultados_sanos','resultados_secundarios','repro_navegador','diagnostico_20'):
        for src in (ROOT/folder).rglob('*'):
            if src.is_file() and (src.suffix in ('.json','.jsonl','.txt','.log','.png') or (folder=='diagnostico_20' and src.suffix=='.stl') or src.name.endswith('.antes_serializacion')):
                copy(src,FULL/src.relative_to(ROOT))
    for src in ROOT.glob('*.stdout'):copy(src,FULL/'registros_sesion'/src.name)
    copy(ROOT/'comprobacion_preparacion_C20/calibracion.json',FULL/'comprobacion_preparacion_C20/calibracion.json')
    index={};approved=FULL/'STEP_APROBADOS';rejected=FULL/'NO_APROBADOS';unverified=FULL/'SIN_VERIFICAR'
    for d in (approved,rejected,unverified):d.mkdir(exist_ok=True)
    for spec in corpus:
        n=spec['id'];o=read(ROOT/'oraculos'/(n+'.json'));src=ROOT/'resultados_sanos'/(n+'.step')
        folder=approved if o['ok'] else unverified if o.get('calibracion_stl',{}).get('ok') is False or 'criterios' not in o else rejected
        dst=folder/src.name;copy(src,dst);index[n]=dst.relative_to(FULL).as_posix()
    for spec in read(ROOT/'protocolo_secundarios.json')['casos']:
        n=spec['id'];src=ROOT/'resultados_secundarios'/(n+'.step')
        if not src.exists():continue
        o=read(ROOT/'oraculos_secundarios'/(n+'.json'))
        folder=approved if o.get('geometria_referencia_ok') else rejected if o.get('criterios') else unverified
        dst=folder/src.name;copy(src,dst);index[n]=dst.relative_to(FULL).as_posix()
    o=read(ROOT/'complementario_20/contraste.json')
    folder=approved if o['ok'] else rejected
    dst=folder/'C20_remallado_fino.step';copy(ROOT/'complementario_20/resultado.step',dst);index['C20_remallado_fino']=dst.relative_to(FULL).as_posix()
    for src in (ROOT/'complementario_20').glob('*'):
        if src.is_file() and src.suffix in ('.json','.txt','.log'):copy(src,FULL/src.relative_to(ROOT))
    dst=rejected/'17_barrido_spline_UI.step';copy(ROOT/'repro_navegador/17_barrido_spline_UI.step',dst);index['17_barrido_spline_UI']=dst.relative_to(FULL).as_posix()
    (FULL/'indice_step.json').write_text(json.dumps(index,indent=2,ensure_ascii=False),encoding='utf-8')
    (rejected/'LEEME.txt').write_text('SALIDAS NO APROBADAS. R7 predeterminada ofrece el barrido 17 como correcto, pero se ha confirmado autointersección CAD. Se conserva exclusivamente para reproducir el fallo.\n',encoding='utf-8')
    (unverified/'LEEME.txt').write_text('El ensayo 20 inicial se excluye por calibración insuficiente de su STL respecto al CAD original (0.0053766 > 0.005 mm). No se presenta como error dimensional del conversor. Utilizar la repetición C20 del kit.\n',encoding='utf-8')
    manifest={p.relative_to(FULL).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(FULL.rglob('*')) if p.is_file()}
    (FULL/'MANIFIESTO_SHA256.json').write_text(json.dumps({'algoritmo':'SHA-256','archivos':manifest},indent=2,ensure_ascii=False),encoding='utf-8')
    # Kit ligero: veinte geometrías para probar, sustituyendo sólo la discretización 20.
    for spec in corpus[:-1]:copy(ROOT/spec['stl'],SMALL/'STL'/Path(spec['stl']).name)
    copy(ROOT/'stl_complementarios/C20_remallado_fino.stl',SMALL/'STL/20_placa_curva_mallado_fino.stl')
    for spec in corpus:copy(ROOT/spec['referencia_step'],SMALL/'CAD_ESPERADO'/Path(spec['referencia_step']).name)
    for name in ('INFORME_CAPACIDAD_R7.md','resultados_para_probar.csv','piezas_referencia.png','capacidad_r7.png'):
        copy(ROOT/name,SMALL/name)
    copy(ROOT/'repro_navegador/aprobacion_interfaz.png',SMALL/'repro_navegador/aprobacion_interfaz.png')
    for group in ('cadquery','mfcad'):copy(ROOT/f'fuentes_{group}/LICENSE',SMALL/'LICENCIAS'/f'{group}.txt')
    (SMALL/'LEEME.txt').write_text('20 PIEZAS EXTERNAS PARA PROBAR EN TU R7\n\nExtraer y cargar los archivos de STL/ en tu Visor habitual, perfil Precisión. No copiar nada sobre el programa. Empezar por 01–05 y continuar en orden.\n\nEl caso 17 es un FALLO CONOCIDO: la R7 predeterminada aprueba una salida con autointersección CAD. Conservar sólo como prueba; no dar su STEP por bueno.\n\nLa pieza 20 utiliza el mallado fino C20. Su CAD es el mismo que el caso 20 inicial del informe; la discretización inicial no cumplía la calibración de entrada. La malla fina contiene 44 pares de triángulos con intersección CGAL: es una prueba problemática adicional, cuya salida STEP pasa el contraste CAD y tiene 0 pares CGAL al teselar. resultados_para_probar.csv indica los resultados de estos veinte archivos concretos.\n\nCAD_ESPERADO/ contiene la referencia original normalizada a 40 mm. No es la salida del Visor. El kit reproducible completo contiene las salidas y evidencias originales.\n\nFuentes: CadQuery/cadquery (Apache-2.0), commit 8178185a24a035c9af7f4679033be14267f6a6ef, y hducg/MFCAD (MIT), commit ef6d58a40164d5192666821ce98d0cc90e379fac. Licencias completas en LICENCIAS/. Fuentes y modificaciones de preparación en el kit completo.\n',encoding='utf-8')
    assert len(list((SMALL/'STL').glob('*.stl')))==20
    assert len(list((FULL/'stl_sanos').glob('*.stl')))==20
    assert len(list((FULL/'fuentes_cadquery').glob('*.py')))==17
    zips=[zip_folder(SMALL),zip_folder(FULL)]
    assert all(x['bytes']<100*1024**2 for x in zips),'GitHub limita a 100 MiB por archivo'
    (DEST/'DESCARGAS_SHA256.json').write_text(json.dumps({'archivos':zips},indent=2),encoding='utf-8')
    print(json.dumps(zips,indent=2))
if __name__=='__main__':main()
