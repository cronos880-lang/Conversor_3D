"""Repetir únicamente contrastes que quedaron incompletos por tiempo del evaluador."""
from pathlib import Path
import json,os,signal,subprocess,sys,time,psutil
ROOT=Path(__file__).resolve().parent
limit=float(os.environ.get('ORACULO_LIMITE_S','600'))
for name in sys.argv[1:]:
 folder=ROOT/'oraculos';old=folder/(name+'.json');archive=folder/('primer_intento' if limit==600 else 'intento_600s');archive.mkdir(exist_ok=True)
 if old.exists():old.rename(archive/old.name)
 stdout=folder/(name+'.stdout.txt')
 if stdout.exists():stdout.rename(archive/stdout.name)
 start=time.monotonic();peak=0;reason=None
 with stdout.open('w',buffering=1) as log:
  p=subprocess.Popen([sys.executable,str(ROOT/'oraculo_cad.py'),name],stdout=log,stderr=subprocess.STDOUT,start_new_session=True);proc=psutil.Process(p.pid)
  while p.poll() is None:
   try:peak=max(peak,sum(x.memory_info().rss for x in [proc,*proc.children(recursive=True)] if x.is_running()))
   except psutil.Error:pass
   if time.monotonic()-start>limit:reason='tiempo_oraculo_ampliado'
   if peak>3000*1024**2:reason='memoria_oraculo'
   if reason:os.killpg(p.pid,signal.SIGKILL);p.wait();break
   time.sleep(.2)
 r=json.loads(old.read_text()) if old.exists() else {'id':name,'ok':False,'ejecutado':True,'error':reason or 'Sin informe'}
 r.update(repeticion_por_tiempo_del_evaluador=True,limite_oraculo_s=limit,ram_oraculo_mb=peak/1024**2,codigo_oraculo=p.returncode)
 old.write_text(json.dumps(r,indent=2,ensure_ascii=False));print(name,r['ok'],r.get('criterios') or r.get('error'),flush=True)
