"""Comprobar los SHA-256 de todos los archivos originales del kit, sin dependencias."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFIESTO_SHA256.json').read_text(encoding='utf-8'))
errors=[]
for name,expected in manifest['archivos'].items():
    p=root/name
    if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=expected:
        errors.append(name)
print('INTEGRIDAD CORRECTA' if not errors else 'ARCHIVOS AUSENTES O MODIFICADOS',len(manifest['archivos']))
for name in errors:print(name)
raise SystemExit(bool(errors))
