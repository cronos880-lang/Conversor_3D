"""Recalcular sólo la caja para TODOS los STEP, conservando el resto de mediciones.

La caja fría OCC puede ser conservadora en superficies offset. La versión 3
usa extremos de mallado CAD fino; no se cambia el umbral de 0.020 mm.
"""
from pathlib import Path
import json,time,shutil
import cadquery as cq,numpy as np
from oraculo_cad import ROOT,bounds

changes=[]
groups=[('corpus.json','casos','oraculos','resultados_sanos'),('protocolo_secundarios.json','casos','oraculos_secundarios','resultados_secundarios')]
for source,key,folder,outputs in groups:
 for spec in json.loads((ROOT/source).read_text())[key]:
  name=spec['id'];path=ROOT/folder/(name+'.json');out=ROOT/outputs/(name+'.step')
  if not path.exists() or not out.exists():continue
  record=json.loads(path.read_text())
  if 'criterios' not in record:continue
  archive=ROOT/folder/'antes_revision_caja';archive.mkdir(exist_ok=True)
  assert not (archive/path.name).exists(),'No sobrescribir evidencia anterior'
  shutil.copyfile(path,archive/path.name);start=time.monotonic()
  ref=cq.importers.importStep(str(ROOT/spec['referencia_step'])).val();result=cq.importers.importStep(str(out)).val()
  a=bounds(ref);b=bounds(result);error=float(np.abs(a-b).max())
  change={'id':name,'error_caja_fria_anterior_mm':record['caja_error_mm'],'error_caja_mallado_fino_mm':error,
          'caja_referencia':a.tolist(),'caja_salida':b.tolist(),'limite_caja_mm':.020,'ok':error<=.020,'segundos':time.monotonic()-start}
  changes.append(change);record['caja_error_mm']=error;record['criterios']['caja']=bool(error<=.020)
  record.update(version_oraculo=3,actualizacion_solo_caja=True,revision_caja=change,
     metodo_caja='Extremos de vértices de mallado CAD absoluto 0.00025 mm / 0.04 rad; umbral 0.020 mm sin ampliar. Estimación geométrica, no cota exacta global.')
  record['ok']=all(record['criterios'].values())
  if 'criterios_reparacion' in record:
   criteria={k:v for k,v in record['criterios'].items() if not(k=='calibracion_entrada' and spec.get('tipo')=='defecto_controlado')}
   record['criterios_reparacion']=criteria;record['geometria_referencia_ok']=all(criteria.values())
   record['objetivo_cumplido']=record['geometria_referencia_ok'];record['reparacion_demostrada']=record['geometria_referencia_ok'] and spec.get('tipo')=='defecto_controlado'
  path.write_text(json.dumps(record,indent=2,ensure_ascii=False));print(name,change['error_caja_fria_anterior_mm'],error,record['ok'],flush=True)
  del ref,result
(ROOT/'revision_cajas_todos.json').write_text(json.dumps({'version_evaluador':3,'actualizacion':'Se conservan distancias, calibración, volumen, topología, material e interferencias; se recalcula sólo caja para todos los casos con STEP y contraste terminado.','casos':changes},indent=2,ensure_ascii=False))
rows=[json.loads(p.read_text()) for p in sorted((ROOT/'oraculos_secundarios').glob('*.json'))]
(ROOT/'oraculos_secundarios.json').write_text(json.dumps({'resultados':rows},indent=2,ensure_ascii=False))
