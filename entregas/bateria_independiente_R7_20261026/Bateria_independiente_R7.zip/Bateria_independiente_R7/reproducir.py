"""Repetir un caso en una carpeta nueva, conservando la evidencia entregada.

python reproducir.py 02_taladro --salida mi_prueba
python reproducir.py 17_barrido_spline --solo-contraste --salida contraste_17
Las variantes D*, R* y G17 también se aceptan por su identificador.
"""
from pathlib import Path
import argparse, hashlib, json, os, shutil, signal, subprocess, sys, time

ROOT = Path(__file__).resolve().parent

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding='utf-8')

def worker(folder):
    import oraculo_cad as oracle
    oracle.ROOT = folder
    spec = read(folder/'caso.json')
    result = oracle.validate(spec, folder/'resultado.step')
    if spec.get('tipo') == 'defecto_controlado' and result.get('criterios'):
        result['calibracion_entrada_excluida_por_defecto_controlado'] = True
        result['criterios_salida'] = {k:v for k,v in result['criterios'].items() if k != 'calibracion_entrada'}
        result['ok'] = all(result['criterios_salida'].values())
    write(folder/'contraste.json', result)
    return 0 if result['ok'] else 2

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('caso')
    ap.add_argument('--salida', type=Path, required=True)
    ap.add_argument('--solo-contraste', action='store_true')
    ap.add_argument('--limite-oraculo', type=int)
    args = ap.parse_args()
    rows = read(ROOT/'corpus.json')['casos'] + read(ROOT/'protocolo_secundarios.json')['casos']
    if (ROOT/'protocolo_complementario.json').exists():
        rows += read(ROOT/'protocolo_complementario.json')['casos']
    spec = next((x for x in rows if x['id'] == args.caso), None)
    if spec is None:
        ap.error('Identificador desconocido; consulta resultados_sanos.csv y resultados_secundarios.csv')
    integrity = read(ROOT/'integridad_motor_R7.json')['archivos']
    for name, record in integrity.items():
        actual = hashlib.sha256((ROOT/'motor_R7_inmutable'/name).read_bytes()).hexdigest()
        if actual != record['sha256_esperado']:
            raise ValueError('Motor distinto del publicado: '+name)
    folder = args.salida.resolve()
    folder.mkdir(parents=True, exist_ok=False)
    for field in ('stl', 'referencia_step'):
        src = ROOT/spec[field]
        dst = folder/spec[field]
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)
    write(folder/'caso.json', spec)
    os.environ.update(OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')
    if args.solo_contraste:
        index = read(ROOT/'indice_step.json')
        if args.caso not in index:
            raise ValueError('Este caso no produjo STEP; no hay salida histórica que contrastar')
        shutil.copyfile(ROOT/index[args.caso], folder/'resultado.step')
    else:
        sys.path.insert(0, str(ROOT/'motor_R7_inmutable'))
        from bateria_reparacion import ejecutar
        env = {'VISOR_PERFIL':'precision', 'VISOR_VERIFICAR_INTERFERENCIAS_CAD':'0', **spec.get('extra_env', {})}
        result = ejecutar(ROOT/'motor_R7_inmutable', folder/spec['stl'], folder/'resultado.step',
                          limite=spec['limite_motor_s'], memoria_mb=4096, extra_env=env)
        if not result['ok']:
            print('RECHAZADO O INTERRUMPIDO: consulta', folder/'resultado.resultado.json')
            return 3
    import psutil
    cap = args.limite_oraculo or (1200 if args.caso == '20_placa_curva' else 600)
    start, peak, reason = time.monotonic(), 0, None
    with (folder/'contraste.stdout.txt').open('w', encoding='utf-8') as log:
        proc = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), '--worker', str(folder)],
                                stdout=log, stderr=subprocess.STDOUT, start_new_session=os.name != 'nt')
        monitor = psutil.Process(proc.pid)
        while proc.poll() is None:
            try:
                peak = max(peak, sum(x.memory_info().rss for x in [monitor, *monitor.children(recursive=True)] if x.is_running()))
            except psutil.Error:
                pass
            reason = 'tiempo_evaluador' if time.monotonic()-start > cap else 'memoria_evaluador' if peak > 3000*1024**2 else None
            if reason:
                if os.name == 'nt':
                    subprocess.run(['taskkill', '/F', '/T', '/PID', str(proc.pid)], capture_output=True)
                else:
                    os.killpg(proc.pid, signal.SIGKILL)
                proc.wait()
                break
            time.sleep(.2)
    write(folder/'recursos_contraste.json', {'limite_s':cap, 'segundos':time.monotonic()-start,
          'ram_pico_mb':peak/1024**2, 'interrupcion':reason, 'codigo':proc.returncode})
    if reason or not (folder/'contraste.json').exists():
        print('SIN VERIFICAR: el evaluador no terminó; consulta', folder)
        return 4
    result = read(folder/'contraste.json')
    print('CONTRASTE APROBADO' if result['ok'] else 'CONTRASTE NO APROBADO', folder/'contraste.json')
    return 0 if result['ok'] else 2

if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--worker':
        raise SystemExit(worker(Path(sys.argv[2])))
    raise SystemExit(main())
