"""Preparar CAD externos y STL; no importa ni modifica el conversor."""
from pathlib import Path
import ast,hashlib,json,sys,time,traceback
import numpy as np,trimesh,cadquery as cq
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.BRepTools import BRepTools
from OCP.BRepAdaptor import BRepAdaptor_Surface
from collections import Counter

ROOT=Path(__file__).resolve().parent
SPEC=[
 ('01_bloque',1,1,'result','Bloque rectangular'),
 ('02_taladro',1,2,'result','Bloque con taladro central'),
 ('03_disco_hueco',1,4,'result','Disco con abertura rectangular'),
 ('04_contorno_arcos',1,5,'result','Extrusión de líneas y arcos'),
 ('05_dos_hexagonos',1,8,'result','Placa con dos huecos hexagonales'),
 ('06_soporte_cojinete',2,3,'result','Soporte con taladro, cajeados y redondeos'),
 ('07_patron_taladros',2,7,'result','Disco con cuatro taladros'),
 ('08_taladros_inclinados',2,15,'result','Placa con taladros inclinados'),
 ('09_pared_delgada',2,17,'result','Caja abierta con pared fina'),
 ('10_avellanados',2,19,'result','Placa con cuatro avellanados'),
 ('11_perfil_spline',3,10,'result','Perfil spline extruido'),
 ('12_ladrillo_3x2',3,100,'tmp','Ladrillo hueco 3x2 con tubos interiores'),
 ('13_mfcad_chaflanes',3,'0-0-0-0-0-23.step',None,'Modelo de mecanizado MFCAD, serie 0'),
 ('14_mfcad_mixto',3,'0-0-0-0-10-23.step',None,'Modelo de mecanizado MFCAD, serie 10'),
 ('15_mfcad_combinado',3,'0-0-0-1-3-23.step',None,'Modelo de mecanizado MFCAD, serie 1/3'),
 ('16_loft',4,18,'result','Transición de círculo a rectángulo'),
 ('17_barrido_spline',4,23,'defaultSweep','Sección circular sobre recorrido spline'),
 ('18_barrido_variable',4,24,'recttocircleSweep','Barrido con varias secciones rectangulares y circulares'),
 ('19_helice',4,25,'result','Perfil cerrado barrido en hélice'),
 ('20_placa_curva',4,101,'plate_1','Placa fina de doble curvatura'),
]

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def spec_rows():
 rows=[]
 for name,level,number,var,label in SPEC:
  group='cadquery' if isinstance(number,int) else 'mfcad'
  path=next((ROOT/'fuentes_cadquery').glob(f'Ex{number:03d}_*.py')) if group=='cadquery' else ROOT/'fuentes_mfcad'/number
  commit='8178185a24a035c9af7f4679033be14267f6a6ef' if group=='cadquery' else 'ef6d58a40164d5192666821ce98d0cc90e379fac'
  repo='CadQuery/cadquery' if group=='cadquery' else 'hducg/MFCAD'
  upstream='examples/'+path.name if group=='cadquery' else 'dataset/step/'+path.name
  rows.append({'id':name,'nivel':level,'descripcion':label,'grupo':group,'archivo_fuente':str(path.relative_to(ROOT)),
   'url_fuente':f'https://github.com/{repo}/blob/{commit}/{upstream}','commit_fuente':commit,'sha256_fuente':sha(path),
   'variable':var,'parametros':{'lbumps':3,'wbumps':2,'thin':False} if number==100 else {},
   'limite_motor_s':{1:300,2:480,3:720,4:900}[level],'limite_oraculo_s':240,'limite_ram_mb':4096})
 return rows

class Parameters(ast.NodeTransformer):
 def __init__(self,values):self.values=values
 def visit_Assign(self,node):
  self.generic_visit(node)
  if len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id in self.values:node.value=ast.Constant(self.values[node.targets[0].id])
  return node

def build(row):
 start=time.monotonic();record={**row,'preparacion_ok':False};folder=ROOT/'referencias';folder.mkdir(exist_ok=True);inputs=ROOT/'stl_sanos';inputs.mkdir(exist_ok=True)
 try:
  path=ROOT/row['archivo_fuente']
  if row['grupo']=='cadquery':
   tree=ast.parse(path.read_text());allowed={'cadquery','math'}
   for node in ast.walk(tree):
    if isinstance(node,ast.Import):assert all(n.name in allowed for n in node.names)
    if isinstance(node,ast.ImportFrom):assert node.module in allowed
   if row['variable']=='plate_1':
    stop=next(i for i,n in enumerate(tree.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='plate_1' for t in n.targets));tree.body=tree.body[:stop+1]
   tree=ast.fix_missing_locations(Parameters(row['parametros']).visit(tree));ns={'show_object':lambda *a,**k:None};exec(compile(tree,str(path),'exec'),ns)
   model=ns[row['variable']];shape=model.val() if isinstance(model,cq.Workplane) else model
  else:shape=cq.importers.importStep(str(path)).val()
  solids=shape.Solids();assert len(solids)==1,'La referencia no es un único sólido';shape=solids[0];assert shape.isValid() and shape.Volume()>0
  bbox=shape.BoundingBox();dims=np.array([bbox.xlen,bbox.ylen,bbox.zlen]);factor=40./dims.max();record['dimensiones_fuente_mm']=dims.tolist();record['escala_preparacion']=float(factor)
  shape=shape.scale(float(factor));bbox=shape.BoundingBox();shape=shape.translate((-(bbox.xmin+bbox.xmax)/2,-(bbox.ymin+bbox.ymax)/2,-(bbox.zmin+bbox.zmax)/2))
  step=folder/(row['id']+'.step');shape.exportStep(str(step));back=cq.importers.importStep(str(step)).val();assert back.isValid() and len(back.Solids())==1
  # Mallado absoluto; CadQuery.mesh usa deflexión relativa por defecto.
  work=back.copy();BRepTools.Clean_s(work.wrapped);BRepMesh_IncrementalMesh(work.wrapped,.003,False,.08,False).Perform();vertices,faces=work.tessellate(.003,.08)
  V=np.asarray([v.toTuple() for v in vertices]);F=np.asarray(faces);keys=np.round(V/1e-8).astype(np.int64);_,first,inverse=np.unique(keys,axis=0,return_index=True,return_inverse=True);merged=V[first];F=inverse[F]
  cross=np.cross(merged[F[:,1]]-merged[F[:,0]],merged[F[:,2]]-merged[F[:,0]]);F=F[np.any(cross!=0,axis=1)];mesh=trimesh.Trimesh(merged,F,process=False)
  stl=inputs/(row['id']+'.stl');stl.write_bytes(mesh.export(file_type='stl'))
  # Lectura exacta del STL binario que recibirá R7, sin soldado adicional.
  sys.path.insert(0,str(ROOT/'motor_R7_inmutable'));from preprocesador_stl import cargar_exacto
  from topologia_vertices import inspeccionar_vertices
  from reparador_exacto_aislado import ControlExacto
  m=cargar_exacto(stl);topology=inspeccionar_vertices(m)
  assert m.is_watertight and m.is_winding_consistent and topology['vertices_no_manifold']==0,'El STL no tiene topología sana'
  off=folder/(row['id']+'.off');pairs=ControlExacto(m,off).pares();assert not pairs,'El mallado contiene intersecciones exactas'
  assert len(m.split(only_watertight=False))==1 and m.volume>0
  assert 100*abs(m.volume-back.Volume())/back.Volume()<.1
  from validacion_reconstruccion import euler_brep
  chi=euler_brep(back);assert chi==m.euler_number,'El mallado no conserva Euler'
  types=Counter(str(BRepAdaptor_Surface(f.wrapped).GetType()).split('.')[-1] for f in back.Faces())
  record.update(preparacion_ok=True,referencia_step=str(step.relative_to(ROOT)),stl=str(stl.relative_to(ROOT)),sha256_step_referencia=sha(step),sha256_stl=sha(stl),
   triangulos=int(len(m.faces)),vertices=int(len(m.vertices)),volumen_cad_mm3=float(back.Volume()),volumen_stl_mm3=float(m.volume),
   euler_cad=int(chi),euler_stl=int(m.euler_number),caras_cad=len(back.Faces()),tipos_caras=dict(types),
   dimensiones_normalizadas_mm=m.extents.tolist(),topologia_vertices=topology,intersecciones_cgal=0,
   preparacion={'dimension_maxima_cad_mm':40,'deflexion_absoluta_solicitada_mm':.003,'angulo_rad':.08,'rejilla_union_vertices_mm':1e-8,'formato_stl':'binario float32','normalizacion_antes_de_convertir':True})
 except Exception as exc:record.update(error=str(exc));traceback.print_exc()
 record['segundos_preparacion']=time.monotonic()-start
 (folder/(row['id']+'.json')).write_text(json.dumps(record,indent=2,ensure_ascii=False));print(row['id'],record['preparacion_ok'],record.get('triangulos'),record.get('error'),flush=True)
 return record

if __name__=='__main__':
 rows=spec_rows()
 if len(sys.argv)>1:build(next(r for r in rows if r['id']==sys.argv[1]))
 else:
  protocol={'version':'Batería independiente R7 2026-10-26','motor_publicado_commit':'6477c78cbb95373a6363cbc32e3d51a3935c4c72','modo':'precision','seleccion_antes_de_observar_resultados':True,'casos':rows,
   'nota':'20 geometrías externas. Escala uniforme a 40 mm antes de generar STL y referencia; R7 no escala resultados. Niveles orientativos por familias geométricas, no umbral universal. El mallado y la validación CAD comparten OpenCascade; se explicita ese sesgo.'}
  (ROOT/'protocolo.json').write_text(json.dumps(protocol,indent=2,ensure_ascii=False))
  import subprocess
  prepared=[]
  for row in rows:
   print('PREPARANDO',row['id'],flush=True)
   try:subprocess.run([sys.executable,__file__,row['id']],timeout=180,check=True)
   except Exception as exc:print('Preparación interrumpida:',str(exc),flush=True)
   p=ROOT/'referencias'/(row['id']+'.json');prepared.append(json.loads(p.read_text()) if p.exists() else {**row,'preparacion_ok':False,'error':'Preparación sin informe'})
   (ROOT/'corpus.json').write_text(json.dumps({'casos':prepared},indent=2,ensure_ascii=False))
