"""Pruebas secundarias después de las 20 conversiones principales."""
from pathlib import Path
import datetime,json,sys,time
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'motor_R7_inmutable'))
from bateria_reparacion import ejecutar
rows=json.loads((ROOT/'protocolo_secundarios.json').read_text())['casos'];report=[]
while not (ROOT/'resultados_sanos/20_placa_curva.resultado.json').exists():time.sleep(2)
deadline=datetime.datetime(2026,10,26,12,0,tzinfo=datetime.timezone.utc).timestamp()
for spec in rows:
 if time.time()>deadline-30:
  report.append({**spec,'ok':False,'no_ejecutado':True,'motivo':'presupuesto global'});continue
 print('SECUNDARIO',spec['id'],flush=True)
 env={'VISOR_PERFIL':'precision',**spec.get('extra_env',{})}
 r=ejecutar(ROOT/'motor_R7_inmutable',ROOT/spec['stl'],ROOT/'resultados_secundarios'/(spec['id']+'.step'),limite=min(spec['limite_motor_s'],int(deadline-time.time())),memoria_mb=4096,extra_env=env);r.update(id=spec['id'],tipo=spec['tipo'])
 report.append(r);p=ROOT/'bateria_secundarios.json';tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps({'resultados':report},indent=2,ensure_ascii=False));tmp.replace(p);print(spec['id'],r['ok'],r['segundos'],r.get('interrupcion') or r['informe_motor'].get('error',''),flush=True)
