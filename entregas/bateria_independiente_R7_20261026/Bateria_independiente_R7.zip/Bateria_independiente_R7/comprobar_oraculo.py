"""Controles del evaluador; no cuentan como piezas externas del conversor."""
from pathlib import Path
import hashlib,json
import numpy as np,cadquery as cq,trimesh
from oraculo_cad import validate,ROOT
from OCP.BRepTools import BRepTools
from OCP.BRepMesh import BRepMesh_IncrementalMesh

folder=ROOT/'calibracion_evaluador';folder.mkdir(exist_ok=True)
def spec_for(name,shape,chi):
 ref=folder/(name+'.step');stl=folder/(name+'.stl');shape.exportStep(str(ref));w=shape.copy();BRepTools.Clean_s(w.wrapped);BRepMesh_IncrementalMesh(w.wrapped,.001,False,.04,False).Perform();v,f=w.tessellate(.001,.04);v=np.asarray([p.toTuple() for p in v]);_,idx,inv=np.unique(np.round(v/1e-8).astype(np.int64),axis=0,return_index=True,return_inverse=True);stl.write_bytes(trimesh.Trimesh(v[idx],inv[np.asarray(f)],process=False).export(file_type='stl'))
 return {'id':name,'stl':str(stl.relative_to(ROOT)),'referencia_step':str(ref.relative_to(ROOT)),'sha256_stl':hashlib.sha256(stl.read_bytes()).hexdigest(),'sha256_step_referencia':hashlib.sha256(ref.read_bytes()).hexdigest(),'euler_cad':chi}
rows=[]
box=cq.Solid.makeBox(20,15,5);s=spec_for('identidad',box,2);r=validate(s,folder/'identidad.step');assert r['ok'],r;rows.append(r)
shift=folder/'desplazado.step';box.translate((.1,0,0)).exportStep(str(shift));r=validate(s,shift);assert not r['ok'] and not r['criterios']['caja'] and not r['criterios']['superficie_max'];r['control_negativo_correcto']=True;rows.append(r)
outer=cq.Solid.makeBox(20,20,.02);hole=cq.Solid.makeCylinder(.05,.02,cq.Vector(10,10,0));perforated=outer.cut(hole);s=spec_for('microtaladro',perforated,0);filled=folder/'relleno.step';outer.exportStep(str(filled));r=validate(s,filled);assert not r['ok'] and not r['criterios']['euler'] and r['volumen_error_pct']<.5;r['control_negativo_correcto']=True;rows.append(r)
(ROOT/'evaluador_verificado.json').write_text(json.dumps({'ok':True,'controles':rows},indent=2,ensure_ascii=False));print('Evaluador: identidad aprobada; desplazamiento y relleno de taladro rechazados.')
