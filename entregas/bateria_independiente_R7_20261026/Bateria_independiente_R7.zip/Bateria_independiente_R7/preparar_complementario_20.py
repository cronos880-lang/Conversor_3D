"""Declarar una repetición por discretización de entrada insuficiente; no cambia R7."""
from pathlib import Path
import json,hashlib,shutil,datetime
ROOT=Path(__file__).resolve().parent
base=next(x for x in json.loads((ROOT/'corpus.json').read_text())['casos'] if x['id']=='20_placa_curva')
cal=json.loads((ROOT/'diagnostico_20/calibracion.json').read_text());assert cal['calibracion_ok']
folder=ROOT/'stl_complementarios';folder.mkdir(exist_ok=True)
path=folder/'C20_remallado_fino.stl';shutil.copyfile(ROOT/'diagnostico_20/20_mallado_fino_calibracion.stl',path)
row={**base,'id':'C20_remallado_fino','tipo':'calibracion_entrada_complementaria','stl':str(path.relative_to(ROOT)),
     'sha256_stl':hashlib.sha256(path.read_bytes()).hexdigest(),'triangulos':cal['triangulos'],
     'limite_motor_s':900,'limite_oraculo_s':600,'extra_env':{},'calibracion_previa':cal,
     'nota':'Mismo CAD y transformación que el caso 20 original. Nueva discretización absoluta 0.00025 mm y 0.02 rad, sin cambiar el motor ni aflojar la calibración 0.005 mm. El intento original queda registrado y excluido de éxitos.'}
(ROOT/'protocolo_complementario.json').write_text(json.dumps({'declarado_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'seleccion_antes_de_ejecutar':True,'motivo':'Calibración de entrada original: 0.0053766 mm > 0.005 mm. Repetición con mallado más fino, no nueva geometría.','casos':[row]},indent=2,ensure_ascii=False))
print(row['id'],row['triangulos'])
