"""Contrastar variantes controladas; distinguir rechazo seguro y reparación."""
from pathlib import Path
import json,os,signal,subprocess,sys,time,psutil
from oraculo_cad import ROOT,validate
rows=json.loads((ROOT/'protocolo_secundarios.json').read_text())['casos'];folder=ROOT/'oraculos_secundarios';folder.mkdir(exist_ok=True)

if len(sys.argv)>1:
 spec=next(x for x in rows if x['id']==sys.argv[1]);r=validate(spec,ROOT/'resultados_secundarios'/(spec['id']+'.step'))
 if r.get('criterios'):
  criteria={k:v for k,v in r['criterios'].items() if not (k=='calibracion_entrada' and spec['tipo']=='defecto_controlado')}
  r['criterios_reparacion']=criteria;r['geometria_referencia_ok']=all(criteria.values());r['calibracion_entrada_excluida_por_defecto_controlado']=spec['tipo']=='defecto_controlado'
 else:r['geometria_referencia_ok']=False
 (folder/(spec['id']+'.json')).write_text(json.dumps(r,indent=2,ensure_ascii=False));raise SystemExit(0)

report=[]
for spec in rows:
 name=spec['id'];result=ROOT/'resultados_secundarios'/(name+'.resultado.json')
 while True:
  if time.time()>1793016000:raise SystemExit('Presupuesto global agotado')
  try:motor=json.loads(result.read_text());break
  except (FileNotFoundError,json.JSONDecodeError):time.sleep(1)
 path=folder/(name+'.json')
 if not motor['ok']:
  acceptable=spec['objetivo'] in ('rechazo_o_reparacion_verificada','rechazar_sin_eliminar_cuerpos')
  r={'id':name,'motor_ok':False,'evaluado_cad':False,'rechazo_seguro':True,'objetivo_cumplido':acceptable,'reparacion_demostrada':False,'motivo_motor':motor['informe_motor'].get('error'),'interrupcion_motor':motor.get('interrupcion')}
 else:
  print('CONTRASTE SECUNDARIO',name,flush=True);start=time.monotonic();peak=0;reason=None
  with (folder/(name+'.stdout.txt')).open('w',buffering=1) as log:
   p=subprocess.Popen([sys.executable,__file__,name],stdout=log,stderr=subprocess.STDOUT,start_new_session=True);proc=psutil.Process(p.pid)
   while p.poll() is None:
    try:peak=max(peak,sum(x.memory_info().rss for x in [proc,*proc.children(recursive=True)] if x.is_running()))
    except psutil.Error:pass
    if time.monotonic()-start>600:reason='tiempo_evaluador_secundario'
    if peak>3000*1024**2:reason='memoria_evaluador_secundario'
    if reason:os.killpg(p.pid,signal.SIGKILL);p.wait();break
    time.sleep(.2)
  r=json.loads(path.read_text()) if path.exists() else {'id':name,'geometria_referencia_ok':False,'error':reason or 'Sin informe'}
  r.update(motor_ok=True,evaluado_cad=True,objetivo_cumplido=bool(r.get('geometria_referencia_ok')),reparacion_demostrada=bool(r.get('geometria_referencia_ok')) and spec['tipo']=='defecto_controlado',rechazo_seguro=False,ram_oraculo_mb=peak/1024**2)
 path.write_text(json.dumps(r,indent=2,ensure_ascii=False));report.append(r);temp=ROOT/'oraculos_secundarios.tmp';temp.write_text(json.dumps({'resultados':report},indent=2,ensure_ascii=False));temp.replace(ROOT/'oraculos_secundarios.json');print(name,r.get('objetivo_cumplido'),r.get('rechazo_seguro'),r.get('error'),flush=True)
