"""Consumir salidas terminadas, en un segundo proceso acotado por modelo."""
from pathlib import Path
import json,os,signal,subprocess,sys,time
import psutil
ROOT=Path(__file__).resolve().parent
rows=json.loads((ROOT/'corpus.json').read_text())['casos'];report=[]
for spec in rows:
 name=spec['id'];result=ROOT/'resultados_sanos'/(name+'.resultado.json')
 while True:
  if time.time()>1793016000:raise SystemExit('Presupuesto global de oráculos agotado')
  try:
   motor=json.loads(result.read_text());break
  except (FileNotFoundError,json.JSONDecodeError):time.sleep(1)
 dst=ROOT/'oraculos';dst.mkdir(exist_ok=True);path=dst/(name+'.json')
 if not motor['ok']:
  r={'id':name,'ok':False,'ejecutado':False,'motivo':'El motor no generó un STEP aprobado','interrupcion_motor':motor.get('interrupcion')};path.write_text(json.dumps(r,indent=2));report.append(r)
 else:
  print('CONTRASTANDO',name,flush=True);start=time.monotonic();peak=0;why=None
  with (dst/(name+'.stdout.txt')).open('w',buffering=1) as log:
   p=subprocess.Popen([sys.executable,str(ROOT/'oraculo_cad.py'),name],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   process=psutil.Process(p.pid)
   while p.poll() is None:
    try:peak=max(peak,sum(x.memory_info().rss for x in [process,*process.children(recursive=True)] if x.is_running()))
    except psutil.Error:pass
    if time.monotonic()-start>spec['limite_oraculo_s']:why='tiempo_oraculo'
    if peak>3000*1024**2:why='memoria_oraculo'
    if why:os.killpg(p.pid,signal.SIGKILL);p.wait();break
    time.sleep(.2)
  r=json.loads(path.read_text()) if path.exists() else {'id':name,'ok':False,'ejecutado':True,'error':why or 'Sin informe de contraste'}
  r['ram_oraculo_mb']=peak/1024**2;r['codigo_oraculo']=p.returncode;path.write_text(json.dumps(r,indent=2,ensure_ascii=False));report.append(r)
  print(name,r['ok'],r.get('criterios') or r.get('error'),flush=True)
 (ROOT/'oraculos_sanos.json').write_text(json.dumps({'resultados':report},indent=2,ensure_ascii=False))
