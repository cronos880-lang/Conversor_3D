"""Reproducir la discretización fina C20 desde su CAD esperado, sin tocar R7."""
from pathlib import Path
import argparse,json,hashlib
import cadquery as cq,numpy as np,trimesh
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.BRepTools import BRepTools
from oraculo_cad import ROOT,surface_samples,distances_to_cad,stats
from verificacion_reparacion import distancia_malla
from preprocesador_stl import cargar_exacto
from reparador_exacto_aislado import ControlExacto

ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--salida',type=Path,required=True);args=ap.parse_args()
folder=args.salida.resolve();folder.mkdir(parents=True,exist_ok=False)
shape=cq.importers.importStep(str(ROOT/'referencias/20_placa_curva.step')).val();work=shape.copy()
BRepTools.Clean_s(work.wrapped);BRepMesh_IncrementalMesh(work.wrapped,.00025,False,.02,False).Perform()
v,f=work.tessellate(.00025,.02);V=np.asarray([x.toTuple() for x in v]);F=np.asarray(f)
_,first,inv=np.unique(np.round(V/1e-8).astype(np.int64),axis=0,return_index=True,return_inverse=True)
F=inv[F];V=V[first];cross=np.cross(V[F[:,1]]-V[F[:,0]],V[F[:,2]]-V[F[:,0]]);F=F[np.any(cross!=0,axis=1)]
mesh=trimesh.Trimesh(V,F,process=False);path=folder/'20_mallado_fino_calibracion.stl';path.write_bytes(mesh.export(file_type='stl'))
mesh=cargar_exacto(path);a=surface_samples(shape);d1=distancia_malla(mesh,a)
rng=np.random.default_rng(1991);t=np.vstack((mesh.vertices,mesh.triangles_center));t=t[rng.choice(len(t),size=min(600,len(t)),replace=False)];d2=distances_to_cad(t,shape)
pairs=ControlExacto(mesh,folder/'control_exacto.off').pares()
record={'deflexion_solicitada_mm':.00025,'angular_rad':.02,'triangulos':len(mesh.faces),'vertices':len(mesh.vertices),
 'cerrado':mesh.is_watertight,'orientacion_consistente':mesh.is_winding_consistent,'euler_stl':int(mesh.euler_number),
 'intersecciones_cgal':len(pairs),'sha256_stl':hashlib.sha256(path.read_bytes()).hexdigest(),
 'cad_a_stl':stats(d1),'stl_a_cad':stats(d2),'calibracion_max_mm':.005,'calibracion_ok':bool(max(d1.max(),d2.max())<=.005)}
(folder/'calibracion.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(record),flush=True)
assert record['calibracion_ok'] and record['cerrado'] and record['orientacion_consistente']
if pairs:print('ATENCION: entrada calibrada geométricamente pero con intersecciones CGAL; no clasificar como malla sana.',flush=True)
