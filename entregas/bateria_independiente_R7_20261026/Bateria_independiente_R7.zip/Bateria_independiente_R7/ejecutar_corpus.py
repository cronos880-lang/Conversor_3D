"""Ensayo del motor R7 publicado, sin ajustes para los modelos de prueba."""
from pathlib import Path
import datetime,hashlib,json,os,sys,time,platform
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'motor_R7_inmutable'))
from bateria_reparacion import ejecutar

def atomic(path,data):
 temp=path.with_suffix(path.suffix+'.tmp');temp.write_text(json.dumps(data,indent=2,ensure_ascii=False));temp.replace(path)

def main():
 corpus=json.loads((ROOT/'corpus.json').read_text())['casos'];assert len(corpus)==20
 report={'motor':'R7 publicada sin modificaciones','commit_motor':'6477c78cbb95373a6363cbc32e3d51a3935c4c72','modo':'precision','plataforma':platform.platform(),
  'cpu_cgroup':Path('/sys/fs/cgroup/cpu.max').read_text().strip(),'ram_cgroup':Path('/sys/fs/cgroup/memory.max').read_text().strip(),'resultados':[]}
 deadline=datetime.datetime(2026,10,26,12,0,tzinfo=datetime.timezone.utc).timestamp()
 for spec in corpus:
  name=spec['id'];print('CONVIRTIENDO',name,flush=True)
  if not spec['preparacion_ok'] or time.time()>deadline-10:
   report['resultados'].append({'id':name,'ok':False,'no_ejecutado':True,'motivo':'referencia no sana' if not spec['preparacion_ok'] else 'presupuesto global'});atomic(ROOT/'bateria_sanos.json',report);continue
  source=ROOT/spec['stl'];assert hashlib.sha256(source.read_bytes()).hexdigest()==spec['sha256_stl']
  row=ejecutar(ROOT/'motor_R7_inmutable',source,ROOT/'resultados_sanos'/(name+'.step'),
   limite=min(spec['limite_motor_s'],max(1,int(deadline-time.time()))),memoria_mb=spec['limite_ram_mb'],extra_env={'VISOR_PERFIL':'precision'})
  row.update(id=name,nivel=spec['nivel'],tipo_ensayo='motor_completo_R7')
  report['resultados'].append(row);atomic(ROOT/'bateria_sanos.json',report)
  print(name,'OK' if row['ok'] else 'RECHAZADO',row['segundos'],'s',row.get('interrupcion') or row['informe_motor'].get('tipo_error',''),flush=True)
 return 0 if all(r['ok'] for r in report['resultados']) else 1

if __name__=='__main__':raise SystemExit(main())
