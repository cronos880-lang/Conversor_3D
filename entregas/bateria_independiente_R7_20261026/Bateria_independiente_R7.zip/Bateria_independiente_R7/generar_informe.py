"""Consolidar exclusivamente registros reales, sin sustituir resultados del motor."""
from pathlib import Path
import csv, hashlib, json, collections, datetime
ROOT=Path(__file__).resolve().parent
def read(name):return json.loads((ROOT/name).read_text(encoding='utf-8'))
def write(name,data):(ROOT/name).write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf-8')
def dump_csv(name,rows):
    with (ROOT/name).open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def maximum(o,key,metric):
    return max(o.get('referencia_a_resultado',{}).get(metric,0),o.get('resultado_a_referencia',{}).get(metric,0)) if key in o else None
def fmt(x,d=3):return '—' if x is None else f'{x:.{d}f}'

def main():
    corpus=read('corpus.json')['casos'];motors={x['id']:x for x in read('bateria_sanos.json')['resultados']}
    oracles=[];rows=[]
    for spec in corpus:
        name=spec['id'];m=motors[name];o=read('oraculos/'+name+'.json');oracles.append(o)
        quality=m['informe_motor'].get('resultado',{}).get('calidad',{})
        status='ENTRADA_NO_CALIBRADA' if o.get('calibracion_stl',{}).get('ok') is False else 'APROBADO' if o.get('ok') else 'NO_APROBADO' if 'criterios' in o else 'SIN_VERIFICAR'
        rows.append({'id':name,'nivel_orientativo':spec['nivel'],'pieza':spec['descripcion'],'triangulos_stl':spec['triangulos'],
          'caras_cad_original':spec['caras_cad'],'caras_step':quality.get('caras_step'),'modo_motor':m['informe_motor'].get('resultado',{}).get('modo'),
          'tipos_caras_step':json.dumps(quality.get('tipos_caras'),ensure_ascii=False),'motor_acepta':m['ok'],'contraste_cad':status,
          'segundos_motor':m['segundos'],'ram_pico_motor_mib':m['ram_pico_mb'],'limite_motor_s':m['limite_s'],
          'segundos_contraste':o.get('segundos'),'limite_contraste_s':o.get('limite_oraculo_s',240),
          'p95_max_bidireccional_mm':maximum(o,'referencia_a_resultado','p95_mm'),'desviacion_max_muestreada_mm':maximum(o,'referencia_a_resultado','max_mm'),
          'error_volumen_pct':o.get('volumen_error_pct'),'error_caja_mm':o.get('caja_error_mm'),
          'interferencias_occ':o.get('interferencias_occ'),'euler_original':spec['euler_cad'],'euler_step':o.get('euler_resultado'),
          'entrada_calibrada':o.get('calibracion_stl',{}).get('ok'),'revision_caja_segundos':o.get('revision_caja',{}).get('segundos',0),
          'discrepancias_material':o.get('material',{}).get('discrepancias'),'tolerancia_interna_brep_max_mm':quality.get('integridad_cad',{}).get('tolerancia_max_mm'),
          'fuente':spec['url_fuente'],'sha256_stl':spec['sha256_stl'],'sha256_step':m.get('sha256_step'),
          'incidencias':'; '.join(k for k,v in o.get('criterios',{}).items() if not v) or o.get('error','')})
    old=ROOT/'oraculos_sanos.json'
    if not (ROOT/'oraculos_sanos_primer_resumen.json').exists():old.rename(ROOT/'oraculos_sanos_primer_resumen.json')
    write('oraculos_sanos.json',{'nota':'Consolidación final de los veinte JSON individuales; incluye las repeticiones por tiempo del evaluador.','resultados':oracles})
    secondary=read('protocolo_secundarios.json')['casos'];sm={x['id']:x for x in read('bateria_secundarios.json')['resultados']};sr=[]
    for spec in secondary:
        n=spec['id'];m=sm[n];o=read('oraculos_secundarios/'+n+'.json')
        state='SIN_VERIFICAR_POR_RECURSOS' if m.get('interrupcion') or o.get('error') else 'REPARADO_Y_VERIFICADO' if o.get('reparacion_demostrada') else 'CONVERTIDO_Y_VERIFICADO' if o.get('geometria_referencia_ok') else 'RECHAZADO' if not m['ok'] else 'NO_APROBADO'
        sr.append({'id':n,'tipo':spec['tipo'],'estado':state,'motor_acepta':m['ok'],'segundos_motor':m['segundos'],'ram_pico_mib':m['ram_pico_mb'],
          'objetivo_previsto':spec['objetivo'],'objetivo_cumplido':bool(o.get('objetivo_cumplido')) and not bool(m.get('interrupcion')),
          'reparacion_demostrada':o.get('reparacion_demostrada',False),'contraste_cad':o.get('geometria_referencia_ok'),
          'p95_max_bidireccional_mm':maximum(o,'referencia_a_resultado','p95_mm'),'desviacion_max_muestreada_mm':maximum(o,'referencia_a_resultado','max_mm'),
          'error_volumen_pct':o.get('volumen_error_pct'),'error_caja_mm':o.get('caja_error_mm'),
          'interferencias_occ':o.get('interferencias_occ'),'incidencia':m.get('interrupcion') or o.get('error') or m['informe_motor'].get('error',''),
          'configuracion_extra':json.dumps(spec.get('extra_env',{}))})
    dump_csv('resultados_sanos.csv',rows);dump_csv('resultados_secundarios.csv',sr)
    counts=collections.Counter(r['contraste_cad'] for r in rows);modes=collections.Counter(r['modo_motor'] for r in rows)
    summary={'motor_commit':'6477c78cbb95373a6363cbc32e3d51a3935c4c72','motor_modificado':False,'piezas_externas_distintas':20,
      'motor_acepta':sum(r['motor_acepta'] for r in rows),'contraste_cad':dict(counts),'modos':dict(modes),
      'defectos_controlados':{k:sum(r['estado']==k for r in sr if r['tipo']=='defecto_controlado') for k in ('REPARADO_Y_VERIFICADO','RECHAZADO','SIN_VERIFICAR_POR_RECURSOS')},
      'rotaciones_verificadas':sum(r['estado']=='CONVERTIDO_Y_VERIFICADO' for r in sr if r['tipo']=='rotacion'),
      'secundarios':sr,'tabla_principal':rows}
    complementary_motor=read('complementario_20/resultado.resultado.json')
    complementary_oracle=read('complementario_20/contraste.json')
    summary['repeticion_20_entrada_fina']={'motor_ok':complementary_motor['ok'],'cad_ok':complementary_oracle['ok'],
      'segundos_motor':complementary_motor['segundos'],'triangulos_entrada':97208,'nueva_geometria':False,
      'intersecciones_cgal_entrada':44,'entrada_sana':False,
      'control_cgal_salida':read('complementario_20/control_cgal_salida.json')}
    summary['geometrias_distintas_aprobadas_tras_recalibrar_20']=counts['APROBADO']+int(complementary_oracle['ok'])
    cq=complementary_motor['informe_motor']['resultado']['calidad']
    fine={**rows[-1],'id':'C20_remallado_fino','triangulos_stl':97208,'caras_step':cq['caras_step'],
      'modo_motor':complementary_motor['informe_motor']['resultado']['modo'],'tipos_caras_step':json.dumps(cq.get('tipos_caras')),
      'motor_acepta':complementary_motor['ok'],'contraste_cad':'APROBADO' if complementary_oracle['ok'] else 'NO_APROBADO',
      'segundos_motor':complementary_motor['segundos'],'ram_pico_motor_mib':complementary_motor['ram_pico_mb'],
      'segundos_contraste':complementary_oracle.get('segundos'),'limite_contraste_s':600,
      'p95_max_bidireccional_mm':maximum(complementary_oracle,'referencia_a_resultado','p95_mm'),
      'desviacion_max_muestreada_mm':maximum(complementary_oracle,'referencia_a_resultado','max_mm'),
      'error_volumen_pct':complementary_oracle.get('volumen_error_pct'),'error_caja_mm':complementary_oracle.get('caja_error_mm'),
      'interferencias_occ':complementary_oracle.get('interferencias_occ'),'euler_step':complementary_oracle.get('euler_resultado'),
      'entrada_calibrada':complementary_oracle.get('calibracion_stl',{}).get('ok'),'revision_caja_segundos':0,
      'discrepancias_material':complementary_oracle.get('material',{}).get('discrepancias'),
      'sha256_stl':read('protocolo_complementario.json')['casos'][0]['sha256_stl'],'sha256_step':complementary_motor.get('sha256_step'),
      'incidencias':'; '.join(k for k,v in complementary_oracle.get('criterios',{}).items() if not v)}
    dump_csv('resultado_complementario_20.csv',[fine])
    test_rows=[{**r,'archivo_stl':r['id']+'.stl'} for r in rows[:-1]]+[{**fine,'archivo_stl':'20_placa_curva_mallado_fino.stl'}]
    dump_csv('resultados_para_probar.csv',test_rows)
    write('resumen_final.json',summary)
    p=read('protocolo.json');p['sha256_evaluador']=hashlib.sha256((ROOT/'oraculo_cad.py').read_bytes()).hexdigest()
    p['ampliaciones_tiempo_evaluador']={'16_loft':600,'18_barrido_variable':600,'19_helice':600,'20_placa_curva':[600,1200]}
    p['nota_ampliaciones']='Sólo presupuesto del evaluador independiente. No cambia el motor, sus límites, los puntos, ni ningún umbral geométrico.'
    p['version_evaluador']=4
    p['datos_historicos']='Los contrastes completos conservan su versión original; versión 3 recalcula sólo las cajas. La versión 4 entregada adelanta la misma puerta de interferencias CAD antes del mallado y evita agotar memoria en el fallo 17. No cambia los criterios de aceptación.'
    p['revision_caja']='Se sustituye la caja fría OCC conservadora por extremos de mallado CAD absoluto 0.00025 mm / 0.04 rad. Se recalcula para TODOS los casos; se preservan datos anteriores en antes_revision_caja. Mismo umbral 0.020 mm. Convergencia contrastada en la placa offset.'
    write('protocolo.json',p)
    b17=next(r for r in rows if r['id']=='17_barrido_spline');g17=next(r for r in sr if r['id']=='G17_control_interferencias')
    lines=['# Capacidad del Visor R7: batería externa del 26/10/2026','',
      f"**De los veinte ensayos iniciales, R7 acepta todos; el contraste CAD aprueba {counts['APROBADO']}, detecta {counts['NO_APROBADO']} salida defectuosa y excluye {counts['ENTRADA_NO_CALIBRADA']} por discretización de entrada insuficiente.** La aceptación de la interfaz no demuestra por sí sola que el STEP sea correcto.",'',
      f"La placa del ensayo excluido se ha vuelto a mallar más finamente, sin modificar su CAD ni el motor ni ampliar tolerancias. Su repetición {'supera' if complementary_oracle['ok'] else 'no supera'} el contraste completo. Así, se han verificado {summary['geometrias_distintas_aprobadas_tras_recalibrar_20']} de las 20 geometrías distintas con R7 predeterminada, incluyendo esa repetición por separado. **La malla fina contiene 44 pares de triángulos con intersección CGAL: no se cuenta como otro caso de entrada sana.** Los dos intentos de la placa quedan registrados.",'',
      '**Fallo reproducido: `17_barrido_spline`.** Un STL sano produce un STEP con autointersección CAD. R7 lo ofrece como «Precisión alcanzada». El fallo se ha confirmado tanto con el motor completo como mediante conversión y descarga desde la interfaz. El STEP defectuoso queda en `NO_APROBADOS/`, para reproducir el problema. No debe usarse como conversión aprobada.','',
      'Esta entrega es un kit de evaluación de R7, **no una actualización del Visor**. No se ha cambiado ningún archivo del motor: los 96 archivos del inventario publicado coinciden por SHA-256. No se ha desarrollado ni denominado una R8. La web WebAssembly de `main` queda fuera de este ensayo.','',
      '## Piezas y procedencia','',
      'Se congelaron veinte geometrías antes de observar resultados: diecisiete ejemplos públicos de [CadQuery](https://github.com/CadQuery/cadquery/tree/8178185a24a035c9af7f4679033be14267f6a6ef/examples), Apache-2.0, y tres modelos STEP de [MFCAD](https://github.com/hducg/MFCAD/tree/ef6d58a40164d5192666821ce98d0cc90e379fac/dataset/step), MIT. Cada caso conserva URL, commit, fuente original y SHA-256 en `corpus.json`. Las fuentes seleccionadas y licencias completas se incluyen. No son piezas aportadas por el usuario.','',
      'Los STL se han generado aquí a partir de esos CAD públicos; no se presentan como STL descargados ni como escaneos reales. Antes de convertir, se aplica al CAD una escala uniforme hasta 40 mm de dimensión máxima y un centrado. Se generan de la misma geometría el STEP de referencia y el STL binario. La malla usa deflexión absoluta solicitada de 0,003 mm y ángulo de 0,08 rad. No se escala el resultado para hacerlo pasar.','',
      'Las veinte referencias contienen un sólido válido sin interferencias OCC. Los veinte STL iniciales son cerrados, orientados, sin vértices no manifold ni intersecciones CGAL y conservan Euler. La calibración geométrica adicional exige desviación máxima muestreada ≤ 0,005 mm: pasan diecinueve entradas y la placa 20 llega a 0,005377 mm, por lo que se excluye ese intento. Un mallado más fino de la misma placa reduce su máximo medido a 0,003195 mm antes de convertirla. Hay de 12 a 53.862 triángulos en los veinte originales y 97.208 en la repetición fina; de 3 a 31 caras CAD originales. El ladrillo es un 3×2 hueco; MFCAD aporta mecanizado poliédrico, no tres modelos industriales curvos.','',
      '![Veinte CAD originales utilizados](piezas_referencia.png)','',
      'Los cuatro grupos, de cinco piezas cada uno, ordenan familias de dificultad orientativa. No forman una escala universal: una pieza de mecanizado plana puede resultar más sencilla que una caja de pared fina del grupo anterior.','',
      '## Resultado de cada conversión','',
      'Todos los tiempos son del motor completo y están en segundos. «CAD» es el contraste adicional, no la declaración de éxito del Visor. «S» identifica la ruta `superficies`; «F», `recuperacion_facetada`. La ruta S también puede conservar parches planos y no implica un historial paramétrico. «Caras» compara CAD original → STEP exportado. La tabla conserva los veinte intentos iniciales; la repetición de 20 se documenta a continuación.','',
      '| ID y pieza | Grupo | Triángulos | Caras | Ruta | Tiempo s | CAD |',
      '|---|---:|---:|---:|:---:|---:|:---:|']
    for r in rows:lines.append(f"| {r['id']} — {r['pieza']} | {r['nivel_orientativo']} | {r['triangulos_stl']} | {r['caras_cad_original']} → {r['caras_step']} | {'F' if r['modo_motor']=='recuperacion_facetada' else 'S'} | {r['segundos_motor']:.1f} | {r['contraste_cad']} |")
    lines+=['',f"Rutas observadas: {dict(modes)}. Los detalles de tipos de superficie, RAM, tolerancias internas B-rep, errores, muestras y fuentes están en `resultados_sanos.csv` y en los JSON de evidencia.",'',
      f"**Repetición `C20_remallado_fino`:** {complementary_motor['segundos']:.1f} s de conversión; CAD {'APROBADO' if complementary_oracle['ok'] else 'NO APROBADO'}; {complementary_oracle.get('caras_resultado')} caras de salida; p95 bidireccional {maximum(complementary_oracle,'referencia_a_resultado','p95_mm'):.6f} mm; máximo muestreado {maximum(complementary_oracle,'referencia_a_resultado','max_mm'):.6f} mm. La deflexión solicitada baja a 0,00025 mm y el ángulo a 0,02 rad. No cambia ninguna tolerancia de aceptación. El protocolo complementario se fijó antes de ejecutar esta repetición y conserva su motivo. La verificación posterior de esa misma malla detectó 44 pares CGAL; la regeneración obtiene exactamente su SHA-256. Se conserva como variante problemática con CAD esperado conocido y salida comprobada, sin sumarla a las dieciocho entradas sanas aprobadas.",'',
      'Se comprobó también la teselación de las caras planas del STEP fino, conservando doble precisión: 20.036 triángulos, malla cerrada y orientada, **0 pares CGAL**, frente a 44 en la entrada. La salida conserva además Euler, material y geometría dentro de los límites del contraste. `complementario_20/control_cgal_salida.json` registra su huella y el método; es una evidencia adicional de recuperación de esta variante concreta.','',
      'Los modelos sencillos con cilindros y avellanados permiten recuperar superficies compactas: por ejemplo, el soporte conserva 23 caras y el ladrillo 31. Sin embargo, el patrón de taladros pasa de 7 a 891 caras, la pared fina de 23 a 5.307, y el loft de 12 a 19.766. Estos STEP pueden superar las comprobaciones geométricas y seguir siendo incómodos para editar. Una salida con miles de planos no equivale a recuperar sus curvas originales.','',
      'El barrido variable tarda unos 13,7 minutos y es el caso más lento. La pared fina tarda 397,5 s con 5.804 triángulos, mientras que el soporte tarda 7,9 s con 6.360. El tipo de geometría y la ruta de reconstrucción pesan más que el recuento de triángulos por sí solo. Estos resultados no permiten atribuir los límites de tiempo al ordenador del usuario.','',
      '![Tiempo y número de caras por pieza](capacidad_r7.png)','',
      '## El falso positivo del barrido spline','',
      f"La referencia tiene 3 caras y la salida 5. El error de volumen es {b17['error_volumen_pct']:.6f} %, el de caja {b17['error_caja_mm']:.6f} mm y la desviación máxima del contraste {b17['desviacion_max_muestreada_mm']:.6f} mm. El p95 adicional CAD→resultado es 0,021425 mm, por encima de 0,020 mm. Este p95 usa puntos de caras y aristas, distintos del muestreo del motor; no se confunden ambas distribuciones.",'',
      'Además de esa diferencia de muestreo, `BRepAlgoAPI_Check` informa `BOPAlgo_SelfIntersect` al reimportar el STEP en un proceso frío, antes de teselar. `isValid()` devuelve True y hay un sólido: esas dos condiciones no bastan para descartar autointersecciones. La referencia fría no tiene esa incidencia.','',
      'La prueba de navegador usa Chromium sobre Linux, perfil Precisión, carga STL, conversión, aprobación al 100 % y descarga. El bloque DATA descargado es idéntico al del ensayo del motor, y vuelve a dar autointersección al leerlo. `repro_navegador/flujo.json`, `contraste_descarga.json` y `confirmacion_barrido_spline.json` documentan la comprobación.','',
      '![La interfaz R7 acepta la salida defectuosa](repro_navegador/aprobacion_interfaz.png)','',
      'La captura muestra la previsualización del STL y la aprobación de la conversión; no es una inspección visual del STEP. La lectura fría es la evidencia del defecto CAD. La cobertura del control de interferencias en todas las rutas de reconstrucción merece prioridad en el siguiente bloque de desarrollo.','',
      '## Defectos y estabilidad: diez pruebas adicionales','',
      'Son variantes de los modelos anteriores, no diez geometrías externas nuevas. Se declararon antes de ejecutarlas en `protocolo_secundarios.json`.','',
      '| Variante | Resultado real | Tiempo s |', '|---|---|---:|']
    for r in sr:lines.append(f"| {r['id']} | {r['estado']} | {r['segundos_motor']:.1f} |")
    lines+=['',
      'Se demuestran dos reparaciones: ruido micrométrico (σ=0,00015 mm, perturbaciones menores de 0,001 mm) y dos sólidos solapados cuya referencia esperada se fijó expresamente como su unión CAD. Ambas salidas pasan el contraste contra la geometría original prescrita. Esto no permite generalizar a cualquier solapamiento ambiguo.','',
      'R7 rechaza caras duplicadas y tres caras con orientación invertida: son dos capacidades de reparación aún pendientes. También rechaza un hueco grande y un pequeño cuerpo separado de 0,2 mm: evita inventar el cierre o eliminar ese cuerpo. No se contabilizan los cuatro rechazos como reparaciones.','',
      'Las tres rotaciones rígidas (0,43 rad sobre el eje 1,2,3, aplicadas al CAD y al STL) conservan la geometría. El número de caras y los tiempos pueden cambiar con la pose; no se demuestra invariancia del coste ni de la segmentación.','',
      f"La variante `G17_control_interferencias` activa exclusivamente la bandera ya existente `VISOR_VERIFICAR_INTERFERENCIAS_CAD=1`: **{g17['estado']}**, {g17['segundos_motor']:.1f} s. Incidencia: {g17['incidencia'] or 'ninguna registrada'}. Es un diagnóstico con configuración distinta; no modifica el resultado de la R7 predeterminada ni se presenta como una corrección terminada.",'',
      '## Qué comprueba el evaluador','',
      'El evaluador no invoca `_calidad` ni acepta sus métricas como prueba. Reabre el CAD original y el STEP exportado y calcula distancias con proyecciones BRepExtrema, en ambos sentidos. Muestrea vértices, posiciones de aristas y puntos UV interiores de caras, con semillas fijas y límites de muestras. Comprueba también volumen, caja, Euler, envolventes, interferencias OCC y clasificación interior/exterior de puntos de material.','',
      '| Criterio de salida | Umbral |','|---|---:|',
      '| Error de volumen | ≤ 0,5 % |','| Coordenadas extremas estimadas de la caja | ≤ 0,020 mm |','| p95 de distancias, en ambos sentidos | ≤ 0,020 mm |','| Máximo observado en las muestras | ≤ 0,060 mm |','| Sólidos válidos | 1 |','| Euler y envolventes | iguales al original |','| Interferencias OCC | 0 |','| Clasificación de material | 0 discrepancias fuera de banda de 0,08 mm |','',
      'En la placa offset se detectó que la caja fría OCC sobreestima un extremo en unos 2,39 mm; ese dato no se interpreta como pérdida física de 2,39 mm. Para todos los casos se recalculó sólo la caja con extremos de un mallado CAD absoluto de 0,00025 mm y 0,04 rad, conservando el resto de mediciones y los registros previos. En la placa, reducir la deflexión de 0,0005 a 0,00025 mm cambia los extremos menos de 0,000208 mm. La caja pasa a ser una estimación geométrica uniforme, no una cota analítica global; su límite sigue siendo 0,020 mm. `revision_cajas_todos.json` documenta cada cambio, incluidos los aprobados.','',
      'La banda de 0,08 mm sólo excluye puntos cercanos a la superficie en la prueba de material. **No es una tolerancia de conversión ni un perfil de impresión**: las distancias siguen limitadas por 0,020/0,060 mm. La tolerancia interna de una arista B-rep tampoco equivale a un error geométrico medido; se conserva como dato separado en el CSV.','',
      'En los seis STL dañados deliberadamente se excluye sólo la calibración geométrica de la entrada frente al CAD sano. Todas las condiciones de salida permanecen intactas. Los límites de este evaluador no se ampliaron para aprobar casos. Tampoco se cambió el perfil Precisión del Visor.','',
      'Los controles del propio evaluador pasan: identidad aprobada, desplazamiento de 0,1 mm rechazado y microtaladro rellenado rechazado por topología aunque la diferencia de volumen sea menor del 0,5 %. Se corrigió al principio una serialización JSON de booleanos NumPy; esos intentos se archivaron y repitieron, sin contarlos como fallos del motor.','',
      'Se aceleró el evaluador conservando la forma CAD objetivo entre proyecciones. Se mantuvieron los mismos puntos y umbrales; 54 mediciones comparadas en tres modelos, incluido un STEP facetado grande, no muestran ninguna diferencia numérica. El hash final del evaluador y la verificación de equivalencia constan en el protocolo.','',
      'Al probar la reproducción desde el ZIP extraído se detectó otro problema del evaluador: mallar finamente el STEP defectuoso 17 antes de comprobar interferencias superó su límite de 3.000 MiB. La versión 4 entregada adelanta esa misma comprobación CAD a la lectura fría y rechaza el STEP antes de mallarlo. No se cuenta el agotamiento de memoria como rechazo geométrico ni se amplía el presupuesto. Los datos completos previos y el evaluador de versión 3 se conservan para auditoría; el orden nuevo no cambia ninguna condición de aceptación.','',
      '## Tiempo, recursos y límites de esta conclusión','',
      'Entorno: Linux, Python 3.12.14, CadQuery 2.8.0 y OpenCascade 7.9.3.1.1, cuota de 2 CPU y 8 GiB de RAM. BLAS/OMP limitados a un hilo. Un motor a la vez; parte de los contrastes CAD se ejecutó simultáneamente, compartiendo CPU. La RAM pico del motor principal va de aproximadamente 0,56 a 2,04 GiB. Los tiempos son de pared observados, no mediciones del ordenador del usuario ni de Windows.','',
      'El motor dispone de 4.096 MiB por proceso y presupuestos de 300/480/720/900 s según el grupo. Las veinte conversiones principales terminan dentro de ellos. Los procesos de contraste completos disponen de 3.000 MiB: inicialmente 240 s; se amplió a 600 s para 16,18,19,20 y después a 1.200 s para 20, conservando los intentos anteriores. La revisión posterior de sólo cajas se ejecutó como análisis aparte, bajo el límite global de 8 GiB, sin registrar su pico individual. Son límites del **contraste**, distintos del tiempo de conversión; un contraste interrumpido se etiqueta SIN_VERIFICAR.','',
      'Son geometrías seleccionadas y limpias, normalizadas a 40 mm, con pocos defectos sintéticos. El generador CAD y el lector de resultados comparten OpenCascade, aunque el evaluador es código separado del motor. No representan escaneos, grandes corpus industriales, ruido real ni todos los STL arbitrarios. Las distancias y el material se muestrean; no se demuestra una cota Hausdorff global ni la ausencia matemática de toda pérdida local.','',
      'No se ha probado Windows nativo, la web WebAssembly, importación en otros CAD ni impresión en la Creality K1C. Tampoco se han repetido en este ensayo las piezas históricas del usuario: el código R7 está intacto y esta batería aporta casos nuevos, sin reemplazar las pruebas anteriores.','',
      '## Uso del kit y siguiente paso','',
      'Para probar en el Visor que ya tienes, extrae el ZIP y abre los STL de `stl_sanos/`, empezando por 01–05. No copies archivos del kit sobre tu instalación. `referencias/` contiene el CAD esperado; `STEP_APROBADOS/` sólo salidas que superan este contraste, `NO_APROBADOS/` conserva el fallo, y `SIN_VERIFICAR/` se usa para cualquier salida inconclusa.','',
      '`LEEME.md` explica la reproducción por caso y la comprobación de integridad. `resultados_sanos.csv` y `resultados_secundarios.csv` se pueden abrir en una hoja de cálculo. Las evidencias conservan informes, registros, fuentes, semillas y presupuestos, incluidos los intentos incompletos del evaluador.','',
      'El siguiente desarrollo debe comenzar por impedir que una salida con interferencias CAD reciba aprobación, cubrir esa comprobación en todas las rutas y verificar una alternativa segura. Después conviene reducir los miles de parches de las familias que aquí recurren a facetas y mejorar duplicados/orientación. Cualquier cambio deberá repetir esta batería y las regresiones históricas. Esta evaluación deja un caso sano que reproduce el falso positivo y una referencia CAD con la que demostrar la corrección.','']
    (ROOT/'INFORME_CAPACIDAD_R7.md').write_text('\n'.join(lines),encoding='utf-8')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.patches import Patch
    fig,(ax,bx)=plt.subplots(1,2,figsize=(15,10),sharey=True,layout='constrained')
    ys=list(range(len(rows)));colors=[{'APROBADO':'#167a5a','NO_APROBADO':'#bb2d3b','SIN_VERIFICAR':'#b47c1a','ENTRADA_NO_CALIBRADA':'#b47c1a'}[r['contraste_cad']] for r in rows]
    ax.barh(ys,[r['segundos_motor'] for r in rows],color=colors)
    ax.set_yticks(ys,[r['id'] for r in rows]);ax.invert_yaxis();ax.set_xlabel('Tiempo de conversión (s), escala logarítmica');ax.set_xscale('log');ax.set_xlim(2,1800);ax.grid(axis='x',alpha=.2)
    for y,r in zip(ys,rows):ax.text(r['segundos_motor']*1.05,y,f"{r['segundos_motor']:.1f}",va='center',fontsize=8)
    bx.barh([y-.17 for y in ys],[r['caras_cad_original'] for r in rows],height=.34,color='#4872ad',label='CAD original')
    bx.barh([y+.17 for y in ys],[r['caras_step'] for r in rows],height=.34,color=colors,label='STEP R7')
    bx.set_xscale('log');bx.set_xlabel('Caras CAD → STEP, escala logarítmica');bx.grid(axis='x',alpha=.2)
    bx.legend(handles=[Patch(color='#4872ad',label='CAD original'),Patch(color='#167a5a',label='STEP contrastado'),Patch(color='#bb2d3b',label='STEP no aprobado'),Patch(color='#b47c1a',label='Entrada no calibrada')],loc='upper right')
    fig.suptitle('R7 sin cambios · 20 ensayos iniciales · contraste contra CAD original',fontsize=15)
    fig.supxlabel('Linux · 2 CPU / 8 GiB · verificaciones parcialmente concurrentes · no mide el PC del usuario',fontsize=10)
    fig.savefig(ROOT/'capacidad_r7.png',dpi=160);fig.savefig(ROOT/'capacidad_r7.svg');plt.close(fig)
    print(json.dumps({'conteos':dict(counts),'secundarios':[(r['id'],r['estado']) for r in sr]},ensure_ascii=False))

if __name__=='__main__':main()
