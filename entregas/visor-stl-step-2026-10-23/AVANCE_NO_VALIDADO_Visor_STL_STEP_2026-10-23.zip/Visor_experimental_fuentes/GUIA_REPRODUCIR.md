# Reproducir y continuar el trabajo

Primero leer `ESTADO_VALIDACION.md` y el informe de resultados de la entrega.
No sobrescribir una instalación estable. La carpeta `Visor_experimental_fuentes`
contiene la aplicación completa; no incluye un Python preinstalado.

## Entorno

Windows: ejecutar `Instalar_Entorno.bat`. Para las pruebas, instalar además:

```bat
.venv\Scripts\python.exe -m pip install -r requirements_pruebas.txt
set VISOR_MATERIAL_PRUEBAS=..\material_pruebas
.venv\Scripts\python.exe -m pytest -q
```

Linux de referencia (Python 3.12, 64 bits):

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements_pruebas.txt
VISOR_MATERIAL_PRUEBAS=../material_pruebas .venv/bin/python -m pytest -q --junitxml=../nuevas_pruebas/pruebas.xml
```

El TestClient de FastAPI necesita sockets locales permitidos por el entorno.
Los tests no envían piezas a servicios remotos. El freeze completo del entorno
de referencia está en las evidencias; el instalador Windows usa las dependencias
principales fijadas de R1, Manifold/psutil fijados y networkx 3.6.1, que la ruta
de perfiles ya utilizaba pero la R1 no declaraba.

## Diagnóstico y reparación independientes

```sh
python diagnosticar_stl.py original.stl --completo --salida diagnostico.json
python preparar_stl.py original.stl preparado.stl
python preparar_stl.py abierto.stl cerrado.stl --referencia-cierre referencia_cerrada.stl
```

El cierre local requiere la referencia explícita, los mismos vértices, entre 1 y
4 triángulos faltantes y un defecto de diámetro máximo 1 mm / 5 % de diagonal.
Sin referencia se rechaza la ambigüedad, también en agujeros pequeños de escáner.
Una abertura funcional no se sella por el hecho de que sea pequeña.

Las uniones se limitan a 20.000 triángulos y 8 cuerpos cerrados. Se conservan los
componentes pequeños. Los contactos por punto/arista y cuerpos separados se
rechazan. Una interfaz plana que ya comparte aristas puede normalizarse dentro
de 0,000020 mm para corregir redondeo STL; no se unen cuerpos por proximidad.
La malla serializada vuelve a contrastarse con la unión poliédrica independiente
OCC: caja y máximo superficial observado 0,002 mm, volumen 0,001 %. Son límites
adicionales: los controles CAD originales no cambian.

## Conversión y batería

```sh
python motor_v2.py preparado.stl salida.step
python bateria_reparacion.py --motor . --stl ../material_pruebas/stl_regresion_14 --salida ../nuevas_pruebas/experimental
python bateria_reparacion.py --motor . --stl ../material_pruebas/caso_cubo_carrito --solo cubo-carrito.stl --salida ../nuevas_pruebas/cubo
```

Para obtener una nueva referencia, extraer el ZIP original de R1 a otra carpeta
y ejecutar la misma batería con `--motor` apuntando a esa carpeta intacta. Usar
el mismo entorno y los mismos STL, comprobar SHA-256 y evitar carga concurrente
para comparar tiempos de forma representativa.

```sh
python evaluar_aceptacion.py --referencia ../nuevas_pruebas/referencia --experimental ../nuevas_pruebas/experimental --cubo ../nuevas_pruebas/cubo/cubo-carrito.resultado.json --pruebas ../nuevas_pruebas/pruebas.xml --salida ../nuevas_pruebas/aceptacion.json
```

La puerta exige las 14 conversiones, comparación de calidad, reimportación de
cada STEP y conversión válida del cubo-carrito. Mantiene Windows pendiente hasta
aportar evidencia nativa; no lo deduce del sistema donde se preparan los paquetes.
Las pruebas unitarias y rotaciones son puertas adicionales documentadas en el
informe: una ejecución correcta de la app no sustituye esas pruebas.

## Evidencias del servidor

`Registros_Conversion/<id>.entrada.json` conserva el diagnóstico. Si se repara,
también conserva `<id>.original.stl` y `<id>.reparado.stl`, incluso si el CAD falla.
El diagnóstico incluye rutas `/reparacion/<id>/informe`, `/original` y `/reparado`.
El proceso CAD y sus descendientes se supervisan por tiempo/RAM y se detienen al
cancelar con Nuevo. La evidencia Windows de taskkill sigue pendiente.

## Trabajo que requiere otra puerta de calidad

No sustituir el núcleo para sortear un rechazo. Si se desarrolla una corrección
del exportador B-Rep/STEP, probarla solo en una rama separada, reimportar el STEP,
comparar contra la unión de referencia y repetir las 14 piezas con los mismos
límites. No usar `_close_mesh` ni suavizado como atajo. No entregar un STEP
facetado de auditoría como si fuese el CAD editable final del Visor.
