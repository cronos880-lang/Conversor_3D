# AVANCE EXPERIMENTAL — NO APTO PARA SUSTITUIR R1

Esta copia contiene una implementación de diagnóstico y reparación conservadora.
No es una versión declarada terminada. Consultar `INFORME_RESULTADOS.md` y las
evidencias incluidas en la entrega para conocer los resultados reales.

La unión de la malla del cubo-carrito y la conversión CAD son puertas distintas.
Un STL reparado no autoriza a declarar válido el STEP. El motor sigue rechazando
los candidatos que no pasan sus controles geométricos originales.

Windows y la edición Move face de Onshape requieren ejecución real externa.
La disponibilidad de dependencias Windows no equivale a haber probado Windows.

Trabajar en esta carpeta independiente. El servidor experimental usa el puerto
8766; la R1 original usa 8765. El HTML, sus cuatro botones, título y flujo Nuevo
se conservan sin cambios. `VISOR_PREPROCESADOR=0` permite ejecutar el núcleo de
entrada histórico para comparar; no convierte un fallo en éxito.
