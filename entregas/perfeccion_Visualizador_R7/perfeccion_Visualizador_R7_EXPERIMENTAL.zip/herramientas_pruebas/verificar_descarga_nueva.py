from pathlib import Path
import sys
sys.path.insert(0,str(Path.cwd()))
import hashlib,json,time
import numpy as np,trimesh,cadquery as cq
from OCP.BRepClass3d import BRepClass3d_SolidClassifier
from OCP.TopAbs import TopAbs_IN,TopAbs_OUT
from OCP.gp import gp_Pnt
from calidad_topologica import inspeccionar
from saneamiento_cad import comprobar_interferencias
from validacion_reconstruccion import euler_brep
from reparador_exacto_aislado import ControlExacto,medidas_superficie
from preprocesador_stl import cargar_exacto
from topologia_vertices import inspeccionar_vertices

start=time.monotonic()
browser=json.loads(Path('evidencias/navegador_Pieza_Nueva_Detenida_r7.json').read_text())
record=json.loads(Path('Registros_Conversion',browser['id']+'.json').read_text())
path=Path('evidencias/navegador_Pieza_Nueva_Detenida_r7.step')
source=Path('/workspace/work/casos_usuario_r5/Pieza_Nueva_Detenida.stl')
raw=path.read_bytes();assert raw==Path('Registros_Conversion',browser['id']+'.step').read_bytes()
assert hashlib.sha256(source.read_bytes()).hexdigest()==record['sha256_stl']
solid=cq.importers.importStep(str(path)).val();integrity=inspeccionar(solid)
assert integrity['brep_valido'] and integrity['solidos']==1 and len(solid.Shells())==5
valid,count=comprobar_interferencias(solid);assert valid and count==0
assert euler_brep(solid)==-186
classifier=BRepClass3d_SolidClassifier(solid.wrapped)
topology=record['calidad']['recuperacion_numerica']['topologia']
assert topology['cavidades_preservadas']==4
for probe in topology['probes_cavidades']:
 for key,expected in [('punto_vacio_mm',TopAbs_OUT),('punto_material_mm',TopAbs_IN)]:
  classifier.Perform(gp_Pnt(*probe[key]),1e-10);assert classifier.State()==expected
vertices,faces=solid.copy().tessellate(1e-6)
V=np.asarray([v.toTuple() for v in vertices]);keys=np.round(V/1e-10).astype(np.int64)
_,first,inverse=np.unique(keys,axis=0,return_index=True,return_inverse=True)
mesh=trimesh.Trimesh(V[first],inverse[np.asarray(faces)],process=False)
vertex_report=inspeccionar_vertices(mesh)
assert mesh.is_watertight and mesh.is_winding_consistent and mesh.euler_number==-186
assert vertex_report['vertices_no_manifold']==0
assert len(ControlExacto(mesh,Path('work/descarga_nueva.off')).pares())==0
distances=medidas_superficie(cargar_exacto(source),mesh)
assert distances['max_mm']<=.060 and distances['p95_mm']<=.020
data=raw.split(b'DATA;',1)[1]
previous=Path('Registros_Conversion/c4c90e9afa7e.step').read_bytes().split(b'DATA;',1)[1]
out={'ok':True,'id':browser['id'],'sha256_step':hashlib.sha256(raw).hexdigest(),
     'sha256_data':hashlib.sha256(data).hexdigest(),'data_identico_primer_recorrido':data==previous,
     'integridad':integrity,'caras':len(solid.Faces()),'shells':len(solid.Shells()),
     'cavidades_verificadas':4,'euler_brep':euler_brep(solid),'euler_teselacion':int(mesh.euler_number),
     'autointerferencias_occ':0,'autointersecciones_cgal':0,'topologia_vertices':vertex_report,
     'superficie_original':distances,'segundos':time.monotonic()-start}
Path('evidencias/navegador_nueva_step_reimportado.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,ensure_ascii=False))
