from pathlib import Path
import sys;sys.path.insert(0,str(Path.cwd()))
import json,hashlib,cadquery as cq
from calidad_topologica import inspeccionar as _integridad_cad
from saneamiento_cad import comprobar_interferencias
p=Path('evidencias/navegador_30383_r7.step');old=Path('/workspace/work/perfeccion_Visualizador_r6/evidencias/navegador_30383_r6.step');solid=cq.importers.importStep(str(p)).val();data=p.read_bytes().split(b'DATA;',1)[1];assert data==old.read_bytes().split(b'DATA;',1)[1];integrity=_integridad_cad(solid);valid,interferences=comprobar_interferencias(solid);assert integrity['brep_valido'] and integrity['solidos']==1 and len(solid.Faces())==182 and not interferences
r={'ok':True,'brep_reimportado':integrity,'caras':len(solid.Faces()),'autointerferencias_occ':False,'data_identico_R6':True,'sha256_data':hashlib.sha256(data).hexdigest()};Path('evidencias/navegador_step_reimportado.json').write_text(json.dumps(r,indent=2));print(r)
