from pathlib import Path
import sys,time,json,traceback,numpy as np,trimesh
sys.path.insert(0,str(Path.cwd()))
import cadquery as cq
from preprocesador_stl import cargar_exacto
from reparador_exacto_aislado import medidas_superficie,ControlExacto
from topologia_vertices import inspeccionar_vertices
out=[]
for name in ['6558_fixed','Pieza_Nueva_Detenida']:
 start=time.monotonic();row={'archivo':name}
 try:
  solid=cq.importers.importStep('work/'+name+'_conjunto.step').val();vertices,faces=solid.copy().tessellate(1e-6);V=np.array([p.toTuple() for p in vertices]);F=np.array(faces);keys=np.round(V/1e-10).astype(np.int64);_,first,inverse=np.unique(keys,axis=0,return_index=True,return_inverse=True);candidate=trimesh.Trimesh(V[first],inverse[F],process=False);reference=cargar_exacto(Path('work/'+name+'_conjunto.stl'));row.update(euler=int(candidate.euler_number),euler_referencia=int(reference.euler_number),estanco=bool(candidate.is_watertight),orientado=bool(candidate.is_winding_consistent),vertices=len(candidate.vertices),caras=len(candidate.faces),topologia_vertices=inspeccionar_vertices(candidate));print('MESH',name,{k:v for k,v in row.items() if k!='topologia_vertices'},flush=True)
  row['superficie_original']=medidas_superficie(cargar_exacto(Path('/workspace/work/casos_usuario_r5')/(name+'.stl')),candidate)
  if candidate.is_watertight:row['intersecciones_cgal']=len(ControlExacto(candidate,Path('work/'+name+'_step_tess.off')).pares())
 except Exception as exc:row['error']=str(exc);traceback.print_exc()
 row['segundos']=time.monotonic()-start;out.append(row);Path('evidencias/superficies_step_independientes.json').write_text(json.dumps(out,indent=2));print('RESULT',row,flush=True)
