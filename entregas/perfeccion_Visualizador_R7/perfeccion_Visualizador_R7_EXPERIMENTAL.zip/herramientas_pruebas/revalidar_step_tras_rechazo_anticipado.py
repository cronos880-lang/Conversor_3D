from pathlib import Path
import sys
sys.path.insert(0,str(Path.cwd()))
import json,time,trimesh
from motor_v2 import _calidad
from preprocesador_stl import cargar_exacto

def read(p):return json.loads(Path(p).read_text())
cases=[]
base=Path('evidencias/caso_final_6558')
cases.append(('6558',Path('/workspace/work/casos_usuario_r5/6558_fixed.stl'),base/'6558_fixed.step',read(base/'bateria.json')['resultados'][0]['informe_motor']['resultado']['calidad']))
browser=read('evidencias/navegador_Pieza_Nueva_Detenida_r7.json')
cases.append(('Nueva',Path('/workspace/work/casos_usuario_r5/Pieza_Nueva_Detenida.stl'),Path('evidencias/navegador_Pieza_Nueva_Detenida_r7.step'),read('Registros_Conversion/'+browser['id']+'.json')['calidad']))
base=Path('evidencias/cubo_precision')
cube=next(r for r in read(base/'bateria.json')['resultados'] if r['archivo']=='cubo-carrito.stl')
cases.append(('cubo',base/'cubo-carrito.reparado.stl',base/'cubo-carrito.step',cube['informe_motor']['resultado']['calidad']))
rows=[]
for name,source,step,previous in cases:
 start=time.monotonic();q=_calidad(source,step,trimesh.load(str(source),force='mesh',process=True) if name=='cubo' else cargar_exacto(source),control_avanzado=True)
 keys=['caras_step','tipos_caras','volumen_error_pct','caja_error_mm','integridad_cad','distancia_stl_step_mm','distancia_step_stl_mm','inspeccion_densa']
 differences=[k for k in keys if q[k]!=previous[k]]
 assert not differences,(name,differences)
 rows.append({'caso':name,'ok':True,'metricas_identicas_antes_despues':True,'calidad_repetida':q,'segundos':time.monotonic()-start})
 Path('evidencias/revalidacion_tras_rechazo_anticipado.json').write_text(json.dumps(rows,indent=2))
 print(name,'aprobado con métricas idénticas',flush=True)
