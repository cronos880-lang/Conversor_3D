const {chromium}=require('playwright');const fs=require('fs');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 const page=await browser.newPage({viewport:{width:1440,height:900},acceptDownloads:true});const errors=[];let id;
 page.on('pageerror',e=>errors.push(String(e)));
 try{
 await page.goto('http://127.0.0.1:8771');await page.waitForFunction(()=>!document.getElementById('openBtn').disabled);
 const label=await page.locator('#conversionProfile option:checked').innerText();
 if(await page.locator('#conversionProfile').inputValue()!=='precision'||label!=='Automático (precisión)')throw Error('Modo automático incorrecto');
 await page.locator('#fileInput').setInputFiles('/workspace/work/rar_usuario_20261024/30383_alternate_fixed.stl');
 await page.waitForFunction(()=>!document.getElementById('convertBtn').disabled);
 page.on('response',async r=>{if(r.url().endsWith('/iniciar-conversion'))try{id=(await r.json()).id}catch{}});
 await page.locator('#convertBtn').click();
 await page.waitForFunction(()=>document.getElementById('conversionPercent').textContent==='100 %'||document.getElementById('conversionPercent').classList.contains('failed'),{},{timeout:360000});
 if(await page.locator('#conversionPercent').evaluate(el=>el.classList.contains('failed')))throw Error(await page.locator('#error').innerText());
 const detail=await page.locator('#details').innerText();
 if(!detail.includes('Precisión alcanzada')||!detail.includes('182 caras'))throw Error(detail);
 const state=await(await page.request.get('http://127.0.0.1:8771/estado-conversion/'+id)).json();
 if(state.precision_alcanzada!=='precision'||state.desviacion_max_mm>.060)throw Error('No conserva precisión');
 const diagnostic=JSON.parse(fs.readFileSync('Registros_Conversion/'+id+'.json','utf8'));
 if(diagnostic.perfil!=='precision'||diagnostic.calidad.perfil_validacion.id!=='precision')throw Error('Perfil incorrecto');
 page.once('dialog',d=>d.accept('30383_automatico'));
 const waiting=page.waitForEvent('download');await page.locator('#exportBtn').click();const download=await waiting;await download.saveAs('evidencias/navegador_30383_r7.step');
 await page.screenshot({path:'evidencias/navegador_r7_sano.png',fullPage:true});
 await page.locator('#conversionProfile').selectOption('impresion');if(!await page.locator('#exportBtn').isDisabled())throw Error('Cambio de modo no invalida STEP');
 await page.locator('#newBtn').click();await page.waitForFunction(()=>document.getElementById('fileName').textContent==='Sin archivo');
 fs.writeFileSync('evidencias/navegador_r7_sano.json',JSON.stringify({ok:true,id,modo_predeterminado:label,detalle_conversion:detail,estado:state,errores_js:errors,flujo:['importar','convertir en automático','100%','182 caras','precisión alcanzada','descargar','cambiar modo invalida STEP','Nuevo']},null,2));
 if(errors.length)throw Error(errors.join('\n'));console.log('Chromium: Automático R7, precisión, 182 caras y descarga aprobados');
 }finally{
 if(id)try{const state=await(await page.request.get('http://127.0.0.1:8771/estado-conversion/'+id)).json();if(state.estado==='ejecutando')await page.request.post('http://127.0.0.1:8771/cancelar-conversion/'+id)}catch{}
 await browser.close();
 }
})().catch(e=>{console.error(e);process.exitCode=1});
