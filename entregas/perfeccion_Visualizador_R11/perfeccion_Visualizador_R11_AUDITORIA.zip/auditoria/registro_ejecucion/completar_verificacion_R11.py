"""Cerrar la validación y los paquetes sólo después de completar la regresión real. No publica."""
from pathlib import Path
import os,sys,json,time,hashlib,subprocess,urllib.request
R=Path(__file__).resolve().parent;PY=sys.executable
ENV={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':'/workspace/work/herramientas_r5'}
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(args,log,timeout=1200,cwd=R,env=ENV):
 print('EJECUTAR',Path(str(args[1])).name,flush=True)
 with (R/log).open('w') as f:subprocess.run(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout,check=True)
def rows(name):
 try:return load(R/name)['resultados']
 except (FileNotFoundError,json.JSONDecodeError):return []
deadline=time.monotonic()+2*3600;previous=None
while True:
 cli=rows('regresion_cli.json');gui=rows('navegador_resultados.json')
 state=(len(cli),len(gui),sum(r['ok'] for r in cli+gui))
 if state!=previous:print('REGRESION',state,flush=True);previous=state
 assert all(r['ok'] for r in cli+gui),'Una conversión falló; se detiene el cierre.'
 if len(cli)==15 and len(gui)==9:break
 if time.monotonic()>deadline:raise TimeoutError('La regresión sigue incompleta; no empaquetar como terminada.')
 time.sleep(5)
manifest=load(R/'FUENTES_R11_SHA256.json');assert all(sha(R/'motor_R11_CONGELADO'/p)==h for p,h in manifest.items())
run(['node','probar_cancelacion.cjs'],'cancelacion.stdout',timeout=300)
assert load(R/'cancelacion_resultado.json')['ok']
run([PY,'validar_candidata.py','maneta',str(R/'regresion_cli/maneta.step')],'maneta_final_R10.stdout',timeout=600)
run([PY,'validar_candidata.py','Grapa',str(R/'regresion_cli/Grapa.step')],'grapa_final_R10.stdout',timeout=600)
proof={}
old=Path('/workspace/work/mejora_superficies_post_R9_20261027');before=load(old/'FUENTES_R10_SHA256.json')
assert all(sha(old/'motor_R10_CONGELADO'/p)==h for p,h in before.items())
for name,folder in [('Bancada_Motor','navegador'),('maneta','regresion_cli'),('Grapa','regresion_cli')]:
 step=R/folder/(name+'.step');validation=step.with_name(step.stem+'_validacion_R10.json');q=load(validation)
 assert q['ok'] and sha(step)==q['step_sha256']
 proof[name]=dict(ok=True,step=str(step.relative_to(R)),sha256_step=q['step_sha256'],validacion=str(validation.relative_to(R)),evaluador='R10 congelada, 133 archivos comprobados',calidad=q['calidad'],grupos_cilindricos=q['cilindros']['preservados'])
(R/'contrastes_finales_R10.json').write_text(json.dumps(proof,indent=2,ensure_ascii=False))
until=time.monotonic()+300
while True:
 try:
  cold=load(R/'lectura_fria_R11.json')
  if len(cold)==25 and all(x['ok'] for x in cold):break
 except (FileNotFoundError,json.JSONDecodeError):pass
 if time.monotonic()>until:raise TimeoutError('La lectura fría no ha cerrado sus 25 archivos.')
 time.sleep(2)
run([PY,'generar_informe_R11.py'],'informe.stdout')
run([PY,'empaquetar_R11.py'],'empaquetado.stdout')
app=R/'verificacion paquete R11/programa/Visor_experimental_fuentes'
env={**ENV,'VISOR_PORT':'8882','VISOR_NO_ABRIR_NAVEGADOR':'1'}
with (R/'servidor_extraido.stdout').open('w') as log:
 server=subprocess.Popen([PY,'arrancar.py','--entorno-listo'],cwd=app,env=env,stdout=log,stderr=subprocess.STDOUT)
 try:
  until=time.monotonic()+120
  while True:
   if server.poll() is not None:raise RuntimeError('El lanzador extraído se detuvo.')
   try:
    with urllib.request.urlopen('http://127.0.0.1:8882/version',timeout=1) as response:
     identity=json.load(response)
    assert identity['instancia']==hashlib.sha256(str(app.resolve()).encode()).hexdigest()[:20]
    break
   except OSError:
    if time.monotonic()>until:raise TimeoutError('El paquete no arranca.')
    time.sleep(.5)
  run([PY,'probar_fuentes_extraidas.py'],'pruebas_extraidas_lanzador.stdout',timeout=300)
  run(['node','probar_paquete_extraido.cjs'],'navegador_extraido.stdout',timeout=300)
  assert load(R/'prueba_paquete_extraido.json')['ok']
  run([PY,'cerrar_paquete_R11.py'],'cierre_paquete.stdout')
 finally:
  server.terminate()
  try:server.wait(timeout=15)
  except subprocess.TimeoutExpired:server.kill();server.wait()
print('VALIDACION_Y_PAQUETES_TERMINADOS. Revisar antes de publicar en GitHub.',flush=True)
