"""Dos procesos CLI independientes; reservar CPU para las pruebas de interfaz."""
from pathlib import Path
import json,hashlib,threading,time,concurrent.futures,sys
R=Path(__file__).resolve().parent;M=R/'motor_R11_CONGELADO';sys.path.insert(0,str(M));from bateria_reparacion import ejecutar
protocol=json.loads(Path('/workspace/work/mejora_motor_post_r7_20261026/regresion_historica/protocolo.json').read_text());cases=[c for c in protocol['casos'] if c['id'] not in ['Bancada_Motor','pinza','cubo-carrito','6558_fixed','M3 PClip - 2mm','LLanta_Trasera']]
old=Path('/workspace/work/mejora_superficies_post_R9_20261027');timings={r['id']:r['segundos'] for r in json.loads((old/'regresion_cli.json').read_text())['resultados']};cases.sort(key=lambda c:-timings[c['id']]);manifest=json.loads((R/'FUENTES_R11_SHA256.json').read_text());output=R/'regresion_cli';output.mkdir(exist_ok=True);slots=threading.Semaphore(1)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check():
 for rel,digest in manifest.items():assert sha(M/rel)==digest,rel
def extra_slot():
 while (R/'RESERVA_INTERFAZ').exists():time.sleep(.5)
 slots.release()
threading.Thread(target=extra_slot,daemon=True).start()
def run(case):
 with slots:
  check();source=Path(case['source']);assert sha(source)==case['sha256'];print('INICIO',case['id'],flush=True)
  row=ejecutar(M,source,output/(case['id']+'.step'),limite=case['limite_s'],memoria_mb=4500,extra_env={'VISOR_PERFIL':'precision','PYTHONDONTWRITEBYTECODE':'1'})
  row.update(id=case['id'],grupo=case['grupo'],ruta='CLI');assert sha(source)==case['sha256'];check()
  if row['ok']:
   a=(output/(case['id']+'.step')).read_bytes();b=(old/'regresion_cli'/(case['id']+'.step')).read_bytes();row['DATA_identico_R10']=a[a.index(b'DATA;'):]==b[b.index(b'DATA;'):]
  print('FINAL',case['id'],row['ok'],row['segundos'],flush=True);return row
rows=json.loads((R/'regresion_cli.json').read_text())['resultados'] if (R/'regresion_cli.json').exists() else []
rows=[r for r in rows if r['ok'] and (output/(r['id']+'.step')).exists() and sha(output/(r['id']+'.step'))==r['sha256_step']]
completed={r['id'] for r in rows};cases=[c for c in cases if c['id'] not in completed]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for future in concurrent.futures.as_completed([pool.submit(run,c) for c in cases]):
  rows.append(future.result());(R/'regresion_cli.json').write_text(json.dumps({'resultados':rows},indent=2,ensure_ascii=False))
assert len(rows)==15 and all(r['ok'] for r in rows)
