from pathlib import Path
import json,hashlib,shutil,ast
R=Path(__file__).resolve().parent;P=R/'motor_producto';M=R/'motor_R11_CONGELADO';OLD=Path('/workspace/work/mejora_superficies_post_R9_20261027/motor_R10_CONGELADO')
assert not M.exists(),'No sobrescribir un núcleo congelado'
(P/'LEEME.txt').write_text('VISOR STL -> STEP R11 EXPERIMENTAL\n\nAbre Iniciar.bat de la carpeta principal. Conserva tus versiones anteriores.\nPython 3.12 de 64 bits. Puede reutilizar el entorno de R7, R8, R9 o R10.\nEncabezado R11 experimental, puerto 8777.\n\nLa nueva fase mide perfiles de revolución y extrusión desde el STL y conserva\nprimero la conversión anterior. Sólo sustituye el STEP tras validar geometría,\nCAD exacto, cilindros, material y tres mallados finos sin cruces.\nLos límites de aceptación originales se mantienen. El ajuste interno no requiere\nninguna opción nueva en la interfaz. Consulta INFORME_RESULTADOS.md en la entrega.\nWindows nativo, Onshape y K1C requieren prueba externa.\n',encoding='utf-8')
(P/'ESTADO_VALIDACION.md').write_text('# R11 experimental\n\nLa entrega incluye el informe de resultados y sus registros reales. El arranque no demuestra una conversión correcta. Se mantienen los evaluadores geométricos y CAD de R10. Las pruebas del paquete especifican Linux/navegador; Windows nativo, Onshape y K1C no están disponibles en este entorno. Los fixtures de rechazo conservan sus nombres históricos y no son resultados aprobados.\n')
(P/'GUIA_REPRODUCIR.md').write_text('# Reproducción\n\nUsar el ZIP de auditoría y sus instrucciones REPRODUCIR.md, con las dependencias bloqueadas del programa. El informe distingue conversiones por CLI, por navegador y controles independientes. Embudo continúa aplazado por instrucción del usuario.\n')
files=[p for p in P.rglob('*') if p.is_file() and not any(x in p.parts for x in ['__pycache__','.pytest_cache','Registros_Conversion','.venv'])]
for p in files:
 target=M/p.relative_to(P);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();manifest={str(p.relative_to(M)):sha(p) for p in M.rglob('*') if p.is_file()}
(R/'FUENTES_R11_SHA256.json').write_text(json.dumps(manifest,indent=2));(R/'NUCLEO_EJECUTADO_R11_SHA256.json').write_text(json.dumps(manifest,indent=2))
report={'limites_modificados':False,'funciones_motor_v2':[],'controles_sin_cambios':[]}
a=ast.parse((OLD/'motor_v2.py').read_text());b=ast.parse((M/'motor_v2.py').read_text());defs={n.name:n for n in b.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
for node in a.body:
 if isinstance(node,(ast.FunctionDef,ast.ClassDef)):
  same=ast.dump(node,include_attributes=False)==ast.dump(defs[node.name],include_attributes=False);assert same,node.name;report['funciones_motor_v2'].append({'funcion':node.name,'identica':same})
for rel in ['perfiles_precision.py','perfiles_cad.py','calidad_topologica.py','saneamiento_cad.py','validacion_reconstruccion.py','validacion_densa.py','invariantes_material.py','prueba_cad.py','motor_superficies/contornos_compatibles.py','motor_superficies/pcurvas_compartidas.py','motor_superficies/encuentros_analiticos.py','motor_superficies/parches_triangulares.py','motor_superficies/fijacion_contornos.py','reconstruccion_curvas.py','reconstruccion_analitica.py']:
 assert sha(OLD/rel)==sha(M/rel),rel;report['controles_sin_cambios'].append({'archivo':rel,'sha256':sha(M/rel)})
report['extension_aislada']='La entrada principal conserva todas las funciones R10. Un envoltorio posterior llama al trabajador nuevo sólo sobre resultados aptos. El constructor opcional se usa únicamente en ese trabajador; None conserva el camino R10. Una forma nueva ya exacta conserva sus pcurvas verificadas.'
(R/'AUDITORIA_TOLERANCIAS.json').write_text(json.dumps(report,indent=2,ensure_ascii=False));print('CONGELADO',len(manifest),'archivos')
