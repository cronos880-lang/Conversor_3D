"""QA independiente: se ejecuta únicamente contra R10 congelada."""
from pathlib import Path
import sys,json,time,hashlib,traceback
R=Path(__file__).resolve().parent;OLD=Path('/workspace/work/mejora_superficies_post_R9_20261027/motor_R10_CONGELADO');sys.path[:0]=[str(OLD),str(OLD/'motor_superficies'),'/workspace/work/herramientas_r5']
from preprocesador_stl import cargar_exacto
from calidad_topologica import leer_solido_step_estricto
from reconstruccion_curvas import validar_cilindros_y_frontera,cilindros_respaldados
from meshfit_detect import detect
name=sys.argv[1];folder=R/'fuente'/name;step=folder/(sys.argv[2] if len(sys.argv)>2 else 'candidato.step');source=Path('/workspace/work/easymesh/material/stl_regresion_14')/(name+'.stl');start=time.monotonic();row={'ok':False,'step_sha256':hashlib.sha256(step.read_bytes()).hexdigest(),'evaluador':'R10 congelada, sin cambios'}
try:
 original=cargar_exacto(source);r,m=detect(str(source),angle_tol_deg=32.,rms_tol_rel=.01,flat_tol_deg=8.,scan_mode=False,mesh_input=original);required=cilindros_respaldados(r,m);print('STL',original.volume,len(original.faces),'cilindros',len(required),flush=True)
 shape,cyl,quality,topology,fine=validar_cilindros_y_frontera(source,step,original,required)
 row.update(ok=True,calidad=quality,cilindros=cyl,topologia=topology,mallados=fine)
except Exception as e:row['error']=repr(e);traceback.print_exc()
row['segundos']=time.monotonic()-start;step.with_name(step.stem+'_validacion_R10.json').write_text(json.dumps(row,indent=2));print(json.dumps(row),flush=True)
raise SystemExit(0 if row['ok'] else 2)
