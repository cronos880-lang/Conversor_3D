"""Construir estrategia nueva aislada conservando las rutas R10 y sus controles."""
from pathlib import Path
import json,shutil,ast
R=Path(__file__).resolve().parent;OLD=Path('/workspace/work/mejora_superficies_post_R9_20261027/motor_R10_CONGELADO');M=R/'motor_producto';S=M/'motor_superficies';research=R/'motor_experimental/motor_superficies'
manifest=json.loads((R/'BASE_R10_SHA256.json').read_text())
for rel in manifest:
 p=M/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(OLD/rel,p)
# Las nuevas superficies sólo las usa el trabajador nuevo. Nada se parchea globalmente.
for name in ['perfiles_medidos','barridos_medidos','extension_cilindros','generar_semilla','extension_planos']:
 text=(R/(name+'.py')).read_text().replace('from encuentros_analiticos import','from geometria_medida import').replace('from ajustar_primitivas import','from ajuste_cilindrico_medido import');(S/(name+'.py')).write_text(text)
for name in ['curvas_barridas','anclaje_barridos','planos_medidos','esquinas_medidas','tramos_barridos','proyeccion_barridos','refinamiento_contorno']:
 text=(research/(name+'.py')).read_text().replace('from encuentros_analiticos import','from geometria_medida import');(S/(name+'.py')).write_text(text)
text=(R/'ajustar_primitivas.py').read_text();text=text[:text.index('    for i,s in enumerate(surfaces):\n        if not isinstance(s,Geom_ToroidalSurface)')]+ '    return out,records\n';(S/'ajuste_cilindrico_medido.py').write_text(text)
text=(research/'encuentros_analiticos.py').read_text();start=text.index('def reconstruir(');end=text.index('def normalizar_circulos(');text=text[:start]+text[end:];text=text.replace('Rescate de B-Rep analíticos en un trabajador aislado.','Geometría de perfiles medidos en un trabajador aislado.');(S/'geometria_medida.py').write_text(text)
text=(research/'contornos_compatibles.py').read_text().replace('from encuentros_analiticos import','from geometria_medida import').replace('from pcurvas_compartidas import crear_pcurva','from geometria_medida import crear_pcurva')
# Redirigir sólo este constructor; las funciones R10 permanecen intactas.
text += '\nfrom geometria_medida import intersection_stable as _interseccion,refine_generic as refinar_interseccion\n';(S/'constructor_barridos.py').write_text(text)
p=S/'meshfit_brep.py';text=p.read_text().replace('contornos_compartidos=False):\n    """Devuelve','contornos_compartidos=False, constructor_medidos=None):\n    """Devuelve');text=text.replace('shell,faces=construir(mesh,labels,comp_surf,edge_tol,max_move=movement,','shell,faces=(constructor_medidos or construir)(mesh,labels,comp_surf,edge_tol,max_move=movement,');p.write_text(text)
# La salida exterior incluye todas las devoluciones históricas sin cambiar su selección.
p=M/'motor_v2.py';text=p.read_text();text=text.replace("    sys.exit(main())", "    from reconstruccion_medida import ejecutar_principal\n    sys.exit(ejecutar_principal(main,_SalidaCad,_calidad))");p.write_text(text)
for name in ['arrancar.py','entorno_local.py','Instalar_Entorno.bat','version_programa.py']:
 p=M/name;text=p.read_text().replace('R10','R11').replace('8776','8777').replace('2026.10.27-encuentros-analiticos','2026.10.28-perfiles-medidos');p.write_text(text)
p=M/'test_arranque_r8.py';p.write_text(p.read_text().replace('8776','8777'))
for p in M.rglob('*.html'):
 text=p.read_text().replace('R10','R11');p.write_text(text)
if (R/'reconstruccion_medida.py').exists():shutil.copyfile(R/'reconstruccion_medida.py',M/'reconstruccion_medida.py')
print('Preparado',M)

if (R/'test_perfiles_medidos.py').exists():shutil.copyfile(R/'test_perfiles_medidos.py',M/'test_perfiles_medidos.py')

for name in ['Instalar_Entorno.bat','Iniciar.bat']:
 p=M/name;p.write_bytes(p.read_text().replace('\r\n','\n').replace('\n','\r\n').encode('utf-8'))
p=M/'entorno_local.py';p.write_text(p.read_text().replace('R7, R8 o R9','R7, R8, R9 o R10'))
(M/'VERSION.txt').write_text('perfeccion_Visualizador_R11\n2026-10-28\n2026.10.28-perfiles-medidos\nEXPERIMENTAL. Reconstrucción de perfiles medidos con validación geométrica y CAD.\nPython 3.12 de 64 bits. Puerto 8777. Windows nativo pendiente de prueba.\n')

p=M/'servidor.py';text=p.read_text().replace("def _metodo_resultado(result):\n", "def _metodo_resultado(result):\n    if result.get('reconstruccion_medida',{}).get('aplicado'):return 'contornos_compatibles'\n");p.write_text(text)

# Sólo el constructor nuevo conserva una forma que ya pasa el control exacto.
p=S/'meshfit_brep.py';text=p.read_text();text=text.replace('fixed, nfw = _fix_wire_intersections(fixed, 1e-7 if contornos_compartidos else tol)',"if constructor_medidos is not None and BRepCheck_Analyzer(fixed,True,False,True).IsValid():nfw=0\n        else:fixed, nfw = _fix_wire_intersections(fixed, 1e-7 if contornos_compartidos else tol)");p.write_text(text)
# Retirar ensayos descartados de las fuentes de producto.
p=S/'constructor_barridos.py';text=p.read_text();start=text.index('        if isinstance(s,Geom_Plane) and len(ids)<=1:');end=text.index('        pts=np.vstack',start);text=text[:start]+'        if isinstance(s,Geom_Plane) and len(ids)<=1:continue\n'+text[end:];start=text.index('    preserve=set();');end=text.index('    targets=',start);text=text[:start]+text[end:];text=text.replace(' and l not in preserve','');p.write_text(text)
p=S/'planos_medidos.py';text=p.read_text();start=text.index('  if len(groups[r])<=1:');end=text.index('  key=id(s)',start);text=text[:start]+'  if len(groups[r])<=1:continue\n'+text[end:];p.write_text(text)
