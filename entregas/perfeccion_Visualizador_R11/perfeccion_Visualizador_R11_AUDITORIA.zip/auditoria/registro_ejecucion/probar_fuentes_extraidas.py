from pathlib import Path
import os,subprocess,sys,json,hashlib
R=Path(__file__).resolve().parent;M=R/'verificacion paquete R11/programa/Visor_experimental_fuentes'
manifest=json.loads((R/'FUENTES_R11_SHA256.json').read_text())
def check():
 for rel,h in manifest.items():assert hashlib.sha256((M/rel).read_bytes()).hexdigest()==h,rel
check()
cases=['test_arranque_r8.py','test_entorno_local.py','test_coherencia_exacta_r8.py','test_perfiles_medidos.py','test_proteccion_archivos_r5.py']
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1'}
with (R/'pruebas_paquete_extraido.stdout').open('w') as log:
 result=subprocess.run([sys.executable,'-m','pytest','-q',*cases,'--junitxml',str(R/'pruebas_paquete_extraido.xml')],cwd=M,env=env,stdout=log,stderr=subprocess.STDOUT)
check();raise SystemExit(result.returncode)
