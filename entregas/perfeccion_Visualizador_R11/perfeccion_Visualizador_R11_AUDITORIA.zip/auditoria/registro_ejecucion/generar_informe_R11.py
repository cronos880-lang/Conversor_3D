"""Cerrar sólo con pruebas de las fuentes finales y resultados completos."""
from pathlib import Path
import json,hashlib,csv,datetime,xml.etree.ElementTree as E
R=Path(__file__).resolve().parent;OLD=Path('/workspace/work/mejora_superficies_post_R9_20261027')
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def data(p):b=p.read_bytes();return b[b.index(b'DATA;'):]
def quality(r):return r['diagnostico']['calidad'] if r['ruta']=='interfaz_navegador' else r['informe_motor']['resultado']['calidad']
def main():
 cli=load(R/'regresion_cli.json')['resultados'];gui=load(R/'navegador_resultados.json')['resultados'];rows=cli+gui
 assert len(cli)==15 and len(gui)==9 and len({r['id'] for r in rows})==24 and all(r['ok'] for r in rows)
 assert all(r['original_sin_modificar'] and r['descarga_identica_backend'] and not r['errores_js'] for r in gui)
 tests=E.parse(R/'pruebas_R11.xml').find('.//testsuite')
 assert tests.get('tests')=='280' and all(tests.get(k)=='0' for k in ['errors','failures','skipped'])
 cold=load(R/'lectura_fria_R11.json');assert len(cold)==25 and all(r['ok'] for r in cold)
 assert load(R/'cancelacion_resultado.json')['ok']
 manifest=load(R/'FUENTES_R11_SHA256.json');assert manifest==load(R/'NUCLEO_EJECUTADO_R11_SHA256.json')
 assert all(sha(R/'motor_R11_CONGELADO'/p)==h for p,h in manifest.items())
 table=[]
 for r in rows:
  folder='navegador' if r['ruta']=='interfaz_navegador' else 'regresion_cli';p=R/folder/(r['id']+'.step');q=quality(r)
  assert sha(p)==r['sha256_step']
  table.append(dict(pieza=r['id'],ruta=r['ruta'],ok=True,caras=q['caras_step'],tipos=q['tipos_caras'],segundos=r['segundos'],max_denso_mm=q['desviacion_max_verificada_mm'],error_caja_mm=q['caja_error_mm'],error_volumen_pct=q['volumen_error_pct'],DATA_identico_R10=data(p)==data(OLD/folder/p.name),sha256_step=sha(p)))
 targets=load(R/'contrastes_finales_R10.json')
 assert all(targets[n]['ok'] for n in ['maneta','Bancada_Motor','Grapa'])
 mq=quality(next(r for r in rows if r['id']=='maneta'));bq=quality(next(r for r in rows if r['id']=='Bancada_Motor'))
 assert mq['caras_step']==36 and bq['caras_step']==239
 assert all(q['integridad_cad']['tolerancia_max_mm']<=1.000001e-7 for q in [mq,bq])
 assert targets['maneta']['grupos_cilindricos']==3 and targets['Bancada_Motor']['grupos_cilindricos']==15
 mr=next(r for r in rows if r['id']=='maneta')['informe_motor']['resultado'];assert mr['reconstruccion_medida']['aplicado']
 assert next(r for r in gui if r['id']=='Bancada_Motor')['diagnostico']['estrategia']=='perfiles_medidos_certificados'
 changed=[t['pieza'] for t in table if not t['DATA_identico_R10']];unchanged=24-len(changed)
 result=dict(version='R11 experimental',fecha_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),regresion=dict(principales=21,recientes=3,aprobados=24,DATA_identicos_R10=unchanged,modificados=changed),pruebas_automaticas={k:int(tests.get(k)) for k in ['tests','errors','failures','skipped']},lectura_fria=dict(archivos=25,aprobados=25),maneta=mq,Bancada_Motor=bq,contrastes_R10=targets,limites_aceptacion_modificados=False,fuentes_ejecutadas_y_entregadas_identicas=150,cancelacion_y_conversion_posterior=True,Embudo='Aplazado por el usuario; no se declara 14/14',Windows_nativo=False,Onshape=False,K1C=False)
 (R/'ACEPTACION_R11.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
 (R/'RESULTADOS_REGRESION.json').write_text(json.dumps(table,indent=2,ensure_ascii=False))
 with (R/'RESULTADOS_REGRESION.csv').open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=list(table[0]));w.writeheader();w.writerows(table)
 lines=['# Visor R11 experimental: resultados reales','',
 '**La maneta pasa de 9.351 caras planas a 36 caras (29 planos, cinco cilindros y dos superficies de revolución). La bancada pasa de 1.896 caras a 239 (150 planos, 25 cilindros, 14 superficies de extrusión y 50 B-splines).** Son resultados del programa completo, desde los STL originales, con perfil Precisión. La bancada se convierte además mediante carga, conversión y descarga reales en Chromium. Los dos STEP finales se contrastan con los validadores R10 congelados.','',
 '**La regresión aporta un tercer caso mejorado sin ajuste específico: Grapa pasa de 622 a 20 caras**, con diez planos, dos cilindros y ocho superficies de extrusión. Mantiene sus dos grupos cilíndricos y Euler 2; el error de volumen es 0,006990 %, el de caja 0,000034 mm y el máximo denso 0,001042 mm. También supera CAD exacto, BOP, tres fronteras finas CGAL sin cruces y el contraste independiente R10.','',
 '## Cambio del motor','',
 'La mejora genera una hipótesis compacta desde el STL y mide sus perfiles de revolución y extrusión sobre los vértices y triángulos originales. Extiende las regiones cilíndricas confirmadas, recupera regiones del STL que la hipótesis CAD había recortado y reúne continuaciones de un mismo perfil cuando la costura oblicua procede de la segmentación. Ajusta los encuentros entre planos, cilindros y barridos con una curva 3D común y curvas UV coherentes en ambas superficies. Conserva las curvas ya exactas, evitando que una reparación genérica posterior las altere. No identifica piezas por nombre, radio conocido ni huella; no necesita los STEP históricos para convertir.','',
 'Primero conserva el resultado aprobado de R10. La fase nueva se intenta sobre una única componente sana, cerrada, orientada y sin cruces, de hasta 20.000 triángulos y 30 MB, cuando el resultado anterior tiene al menos 500 caras. Debe reducirlas al menos un 25 % y superar todos los controles. Trabaja en otro proceso con un presupuesto adicional de 450 segundos. Ante fallo o agotamiento conserva el resultado anterior; la sustitución se hace de forma atómica después de validar. No se cambia la interfaz ni se pide otra decisión de precisión.','',
 f'Las 150 fuentes entregadas coinciden con las congeladas y ejecutadas. Las doce funciones/clases previas de motor_v2 conservan su AST; quince módulos de aceptación y rutas anteriores son idénticos byte a byte a R10. **{unchanged}/24 bloques DATA son idénticos a R10**. Resultados diferentes: '+', '.join(changed)+'.','',
 '## Precisión y validez','',
 'Se mantienen los límites de aceptación de Precisión: caja 0,02 mm, p95 denso 0,02 mm, máximo observado 0,06 mm y error de volumen 0,5 %. El control de cilindros sigue en 0,008 mm sobre las caras recortadas, no sobre un cilindro infinito. No se aumenta la tolerancia CAD; ambos objetivos mantienen 0,0000001 mm en sus aristas.','',
 'Hay una distinción interna: la nueva propuesta de planos usa un ajuste a los triángulos fuente de hasta 0,0001 mm, frente al ajuste primario de 0,00001 mm de la segmentación previa. Es un límite de construcción de la hipótesis; los evaluadores geométricos finales permanecen idénticos. Los perfiles se acotan a 0,003 mm contra la fuente, y la correspondencia 3D/UV a 0,00000005 mm. No se redondean radios a medidas nominales.','',
 '| Medida | Maneta R11 | Bancada R11 | Límite original |','|---|---:|---:|---:|',
 f'| Error de volumen | {mq["volumen_error_pct"]:.6f} % | {bq["volumen_error_pct"]:.6f} % | 0,5 % |',
 f'| Diferencia de caja | {mq["caja_error_mm"]:.6f} mm | {bq["caja_error_mm"]:.6f} mm | 0,02 mm |',
 f'| p95 denso máximo | {max(mq["inspeccion_densa"][k]["p95_mm"] for k in ["stl_a_cad","cad_a_stl"]):.8f} mm | {max(bq["inspeccion_densa"][k]["p95_mm"] for k in ["stl_a_cad","cad_a_stl"]):.8f} mm | 0,02 mm |',
 f'| Máximo en inspección densa | {mq["desviacion_max_verificada_mm"]:.6f} mm | {bq["desviacion_max_verificada_mm"]:.6f} mm | 0,06 mm |','',
 'Cada STEP final contiene un único sólido, supera CAD exacto y BOP sin interferencias. Se conservan los tres grupos cilíndricos confirmados en la maneta y los quince de la bancada. Euler se conserva en 0 y −14 respectivamente. Los contrastes independientes y sus huellas figuran en contrastes_finales_R10.json.','',
 '| Objetivo | Deflexión (mm) | Triángulos de frontera | Cerrado/orientado | Cruces CGAL | Máximo observado (mm) |','|---|---:|---:|---|---:|---:|']
 for name in ['maneta','Bancada_Motor']:
  proof=load(R/targets[name]['validacion'])
  for m in proof['mallados']['resoluciones']:
   assert m['cerrado'] and m['orientado'] and m['intersecciones_cgal']==0
   lines.append(f'| {name} | {m["deflexion_mm"]} | {m["caras"]} | Sí | 0 | {m["superficie"]["max_mm"]:.8f} |')
 lines+=['','Las distancias son observaciones de muestreo determinista, no una garantía Hausdorff global. El máximo de los mallados finos de la maneta puede superar el de la inspección densa y se informa por separado. La bancada conserva 50 caras B-spline: no se promete eliminar toda superficie libre ni recuperar el diseño paramétrico original.','',
 '## Pruebas de regresión','',
 '**280 pruebas automáticas aprobadas, sin fallos, errores ni omisiones. 24 conversiones aprobadas: 15 por CLI y nueve por navegador.** Se comprueban carga del STL, perfil por defecto, identidad de la instancia, descarga idéntica al backend, errores JavaScript y conservación del original. También pasan la cancelación sin descarga residual, una conversión posterior y la lectura fría de los 24 STEP más la caja de control.','',
 'Los registros conservan también los intentos intermedios rechazados. La aprobación de cada caso corresponde a su salida final validada, con código de éxito y STEP comprobado.','',
 'El cubo-carrito y sus tres giros están incluidos. El cubo se repara, se convierte y permite descargar el STL reparado con la huella certificada. Se cubren trece de las catorce piezas históricas; **Embudo sigue aplazado por indicación del usuario, por lo que no se declara 14/14**. Se añaden cinco regresiones previas y Lego 4×2, soporte móvil y Technic PEGS.','',
 '| Pieza | Caras STEP | Máximo denso (mm) | DATA igual a R10 |','|---|---:|---:|---|']
 for t in table:lines.append(f'| {t["pieza"]} | {t["caras"]} | {t["max_denso_mm"]:.6f} | {"Sí" if t["DATA_identico_R10"] else "No"} |')
 lines+=['','Los tiempos y SHA-256 están en RESULTADOS_REGRESION.csv/JSON. Se han ejecutado hasta dos conversiones concurrentes en Linux, con dos CPU y 8 GiB; los tiempos no son una comparación controlada de velocidad con tu ordenador. Esta entrega prioriza calidad y puede añadir tiempo de validación.','',
 '## Limitaciones y ensayos descartados','',
 'Se descartaron bancadas que parecían compactas pero fallaban BOP o CAD exacto. Sus registros se conservan como investigación NO APROBADA y sus STEP no se incluyen como resultados utilizables. La corrección final resuelve intersecciones entre barridos y conserva su correspondencia UV/3D. Las pruebas comprueban también que un hexágono no se convierta indebidamente en cilindro y que un rechazo mantenga el STEP anterior.','',
 '**No ejecutado en este entorno:** Windows nativo, importación e inspección visual en Onshape y prueba física con la Creality K1C. La validación OCC/CGAL no sustituye esas pruebas. La ausencia de líneas espurias en Onshape debe confirmarse allí. Tampoco se promete mejorar todos los STL defectuosos ni superficies arbitrarias.','',
 '## Entrega y uso','',
 'Extrae el ZIP completo en una carpeta nueva y abre Iniciar.bat. Incluye Visor_experimental_fuentes; reutiliza un entorno compatible de R7/R8/R9/R10 sin modificarlo, o usa Instalar_Entorno.bat con Python 3.12 x64. Debe indicar R11 experimental, puerto 8777. Mantén Automático (precisión). El perfil 0,08 permite otro margen, pero no obliga a reconocer más cilindros.','',
 'Se entregan fuentes completas, archivos modificados y parche desde R10, STEP antes/después, entradas y evaluadores para reproducción, registros reales y huellas. La verificación del ZIP extraído se documenta en VERIFICACION_PAQUETE.json y verificacion_extraida. Las versiones anteriores y la web de main se conservan.']
 (R/'INFORME_RESULTADOS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
 print('ACEPTADO',len(rows),'conversiones, 280 pruebas,',unchanged,'DATA idénticos',flush=True)
if __name__=='__main__':main()
