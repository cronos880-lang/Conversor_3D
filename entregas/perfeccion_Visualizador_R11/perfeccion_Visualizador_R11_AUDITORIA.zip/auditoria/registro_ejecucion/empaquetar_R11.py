from pathlib import Path
import json,hashlib,zipfile,shutil
R=Path(__file__).resolve().parent;OLD=Path('/workspace/work/mejora_superficies_post_R9_20261027')
S=R/'preparacion_entrega';OUT=R/'entrega_GitHub/perfeccion_Visualizador_R11';EX=R/'verificacion paquete R11'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def cp(a,b):b.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(a,b)
def archive(base,target,prefix=''):
 files=sorted(p for p in base.rglob('*') if p.is_file() and p.name!='MANIFIESTO_SHA256.json' and not any(x in p.parts for x in ['__pycache__','.pytest_cache','.venv']))
 manifest={str(p.relative_to(base)):sha(p) for p in files};(base/'MANIFIESTO_SHA256.json').write_text(json.dumps(manifest,indent=2));files.append(base/'MANIFIESTO_SHA256.json')
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in sorted(files):z.write(p,str(Path(prefix)/p.relative_to(base)))
 assert target.stat().st_size<95*1024**2,(target.name,target.stat().st_size)
 with zipfile.ZipFile(target) as z:assert z.testzip() is None
 return dict(archivo=target.name,bytes=target.stat().st_size,sha256=sha(target),ficheros=len(files))
def main():
 assert load(R/'ACEPTACION_R11.json')['regresion']['aprobados']==24
 app=S/'programa';qa=S/'auditoria';results=S/'resultados';comparison=S/'comparacion_bancada_maneta';changes=S/'archivos_modificados';OUT.mkdir(parents=True,exist_ok=True)
 summaries=['INFORME_RESULTADOS.md','ACEPTACION_R11.json','RESULTADOS_REGRESION.csv','RESULTADOS_REGRESION.json','AUDITORIA_TOLERANCIAS.json','ARCHIVOS_MODIFICADOS_R10.json','FUENTES_R11_SHA256.json','NUCLEO_EJECUTADO_R11_SHA256.json','ENTORNO_R11.json','contrastes_finales_R10.json']
 for name in summaries:
  for folder in [app,qa,OUT]:cp(R/name,folder/name)
 for name in ['pruebas_R11.xml','pruebas_R11.stdout','regresion_cli.json','navegador_resultados.json','cancelacion_resultado.json','lectura_fria_R11.json','regresion_cli.stdout','navegador_R11.stdout','bancada_final_R10.stdout','maneta_final_R10.stdout','grapa_final_R10.stdout']:
  cp(R/name,qa/name)
 for name in ['preparar_motor_R11.py','congelar_R11.py','preparar_entrega_R11.py','ejecutar_regresion_R11_paralela.py','probar_visor_R11.cjs','probar_cancelacion.cjs','probar_paquete_extraido.cjs','auditar_steps_R11.py','validar_candidata.py','generar_informe_R11.py','empaquetar_R11.py','cerrar_paquete_R11.py','probar_fuentes_extraidas.py','completar_verificacion_R11.py','registrar_entorno.py']:
  cp(R/name,qa/'registro_ejecucion'/name)
 for folder in ['regresion_cli','navegador']:
  for p in (R/folder).iterdir():
   if p.is_file():
    cp(p,results/folder/p.name)
    if p.suffix=='.json':cp(p,qa/'evidencias'/folder/p.name)
 gui=load(R/'navegador_resultados.json')['resultados'];cancel=load(R/'cancelacion_resultado.json');assert cancel['ok']
 jobs={r['job'] for r in gui}|{cancel['cancelacion']['id'],cancel['nuevo_trabajo']['id']}
 for job in jobs:
  for p in (R/'motor_R11_CONGELADO/Registros_Conversion').glob(job+'.*'):
   if job==cancel['cancelacion']['id'] and p.suffix=='.step':continue
   cp(p,results/'Registros_Conversion'/p.name)
 comparison.mkdir(parents=True,exist_ok=True)
 proof=load(R/'contrastes_finales_R10.json')
 for name,folder in [('maneta','regresion_cli'),('Bancada_Motor','navegador'),('Grapa','regresion_cli')]:
  cp(R/folder/(name+'.step'),comparison/(name+'_R11.step'))
  cp(OLD/folder/(name+'.step'),comparison/(name+'_R10.step'))
  cp(Path('/workspace/work/easymesh/material/stl_regresion_14')/(name+'.stl'),comparison/(name+'_original.stl'))
  cp(R/folder/(name+'.step'),OUT/'STEP_PARA_PROBAR'/(name+'_R11.step'))
  cp(R/proof[name]['validacion'],qa/'contrastes_independientes'/(name+'_validacion_R10.json'))
 (comparison/'LEEME.txt').write_text('Mismos STL originales y perfil Precisión. Maneta: R10 9.351 caras planas -> R11 36 caras (5 cilindros y 2 superficies de revolución). Bancada: R10 1.896 -> R11 239 caras (25 cilindros y 14 superficies de extrusión). Los STEP R11 proceden del programa completo; pasan los evaluadores R10 congelados. Incluye los STL y los STEP anteriores y nuevos de las dos piezas y de Grapa (622 -> 20 caras). Importación visual en Onshape pendiente de tu prueba.\n')
 manifest=load(R/'FUENTES_R11_SHA256.json')
 for rel,h in manifest.items():
  assert sha(app/'Visor_experimental_fuentes'/rel)==h
  cp(app/'Visor_experimental_fuentes'/rel,OUT/'Visor_experimental_fuentes'/rel)
 for p in changes.rglob('*'):
  if p.is_file():cp(p,OUT/'archivos_modificados'/p.relative_to(changes))
 cp(qa/'CAMBIOS_DESDE_R10.patch',changes/'CAMBIOS_DESDE_R10.patch');cp(R/'ARCHIVOS_MODIFICADOS_R10.json',changes/'ARCHIVOS_MODIFICADOS_R10.json')
 for name in ['Iniciar.bat','Instalar_Entorno.bat','LEEME_PRIMERO.txt']:cp(app/name,OUT/name)
 for name in ['CAMBIOS_DESDE_R10.patch','REPRODUCIR.md']:cp(qa/name,OUT/name)
 packages=[archive(app,OUT/'perfeccion_Visualizador_R11_EXPERIMENTAL_COMPLETA.zip'),archive(qa,OUT/'perfeccion_Visualizador_R11_AUDITORIA.zip','auditoria'),archive(results,OUT/'perfeccion_Visualizador_R11_RESULTADOS_STEP.zip','resultados'),archive(comparison,OUT/'R11_BANCADA_MANETA_Y_GRAPA_PARA_COMPARAR.zip','STEP_PARA_PROBAR'),archive(changes,OUT/'perfeccion_Visualizador_R11_ARCHIVOS_MODIFICADOS.zip','archivos_modificados')]
 (OUT/'PAQUETES_SHA256.json').write_text(json.dumps(packages,indent=2))
 assert not EX.exists(),'Extraer siempre en una carpeta nueva'
 EX.mkdir()
 for item in packages:
  with zipfile.ZipFile(OUT/item['archivo']) as z:z.extractall(EX/('programa' if 'COMPLETA' in item['archivo'] else '.'))
 for folder in ['programa','auditoria','resultados','STEP_PARA_PROBAR','archivos_modificados']:
  for rel,h in load(EX/folder/'MANIFIESTO_SHA256.json').items():assert sha(EX/folder/rel)==h,(folder,rel)
 (OUT/'VERIFICACION_PAQUETE.json').write_text(json.dumps(dict(CRC_cinco_zip=True,extraccion_real=True,ruta_con_espacios=True,fuentes_identicas=len(manifest),arranque_extraido='pendiente',Windows_nativo=False,Onshape=False,paquetes=packages),indent=2))
 (OUT/'README.md').write_text('''# Visor completo para Windows · R11 experimental

[**Descargar R11 completa**](./perfeccion_Visualizador_R11_EXPERIMENTAL_COMPLETA.zip?raw=true) · [**Comparar las tres mejoras R10/R11**](./R11_BANCADA_MANETA_Y_GRAPA_PARA_COMPARAR.zip?raw=true)

Extrae todo en una carpeta nueva y abre **Iniciar.bat**. Incluye `Visor_experimental_fuentes`. Si descargas el repositorio entero, entra en `entregas/perfeccion_Visualizador_R11` y abre allí Iniciar.bat. Puede reutilizar un entorno compatible de R7, R8, R9 o R10 sin modificarlo. Python 3.12 x64. Encabezado **R11 experimental**, puerto **8777**. Mantén **Automático (precisión)**.

La **maneta pasa de 9.351 a 36 caras**, con cinco cilindros y dos superficies de revolución. La **bancada pasa de 1.896 a 239**, con 25 cilindros y 14 superficies de extrusión. Se miden los perfiles sobre el STL original; sólo se reemplaza el resultado anterior después de superar los controles geométricos y CAD originales. La bancada conserva 50 caras B-spline. No se promete recuperar el diseño paramétrico ni mejorar todos los STL.

**280 pruebas automáticas y 24 conversiones aprobadas**, incluidas nueve conversiones reales por navegador. El cubo-carrito y sus giros están incluidos. Los dos objetivos y Grapa pasan también el evaluador R10 congelado. Grapa mejora de 622 a 20 caras, con dos cilindros y ocho extrusiones. Embudo continúa aplazado; no se declara 14/14. **Windows nativo, Onshape y K1C no se han ejecutado aquí.**

[Informe de resultados reales](./INFORME_RESULTADOS.md) · [Tabla CSV](./RESULTADOS_REGRESION.csv) · [Verificación del paquete](./VERIFICACION_PAQUETE.json)

- [STEP de bancada](./STEP_PARA_PROBAR/Bancada_Motor_R11.step?raw=true), [maneta](./STEP_PARA_PROBAR/maneta_R11.step?raw=true) y [Grapa](./STEP_PARA_PROBAR/Grapa_R11.step?raw=true).
- [Archivos modificados](./perfeccion_Visualizador_R11_ARCHIVOS_MODIFICADOS.zip?raw=true) y [parche desde R10](./CAMBIOS_DESDE_R10.patch).
- [Auditoría y reproducción](./perfeccion_Visualizador_R11_AUDITORIA.zip?raw=true).
- [Todos los STEP y registros](./perfeccion_Visualizador_R11_RESULTADOS_STEP.zip?raw=true).

R11 es una copia experimental independiente. Las versiones anteriores y la web de main se conservan.
''',encoding='utf-8')
 print(json.dumps(packages),flush=True)
if __name__=='__main__':main()
