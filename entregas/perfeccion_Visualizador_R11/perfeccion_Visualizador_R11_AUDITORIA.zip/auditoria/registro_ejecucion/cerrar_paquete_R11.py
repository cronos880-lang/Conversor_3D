from pathlib import Path
import json,hashlib,xml.etree.ElementTree as E
from empaquetar_R11 import archive,cp
R=Path(__file__).resolve().parent;OUT=R/'entrega_GitHub/perfeccion_Visualizador_R11';EX=R/'verificacion paquete R11';APP=EX/'programa/Visor_experimental_fuentes'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 report=load(R/'prueba_paquete_extraido.json');assert report['ok'],report
 tests=E.parse(R/'pruebas_paquete_extraido.xml').find('.//testsuite')
 assert int(tests.get('tests'))>=31 and all(tests.get(k)=='0' for k in ['failures','errors','skipped'])
 manifest=load(R/'FUENTES_R11_SHA256.json');assert all(sha(APP/p)==h for p,h in manifest.items())
 import sys;sys.path.insert(0,str(APP))
 from calidad_topologica import leer_solido_step_estricto
 from OCP.BRepCheck import BRepCheck_Analyzer
 shape=leer_solido_step_estricto(EX/'caja_paquete.step');exact=BRepCheck_Analyzer(shape.wrapped,True,False,True).IsValid()
 assert exact and len(shape.Solids())==1 and shape.Volume()>0
 cold=dict(solidos=1,caras=len(shape.Faces()),volumen_mm3=shape.Volume(),CAD_exacto=exact,sha256=sha(EX/'caja_paquete.step'))
 (R/'lectura_fria_paquete.json').write_text(json.dumps(cold,indent=2))
 for name in ['prueba_paquete_extraido.json','pruebas_paquete_extraido.xml','pruebas_paquete_extraido.stdout','lectura_fria_paquete.json']:
  for base in [OUT/'verificacion_extraida',R/'preparacion_entrega/auditoria/verificacion_paquete']:cp(R/name,base/name)
 for name in ['caja_paquete.step','caja_paquete.png']:
  for base in [OUT/'verificacion_extraida',R/'preparacion_entrega/auditoria/verificacion_paquete']:cp(EX/name,base/name)
 new=archive(R/'preparacion_entrega/auditoria',OUT/'perfeccion_Visualizador_R11_AUDITORIA.zip','auditoria')
 packages=[new if p['archivo']==new['archivo'] else p for p in load(OUT/'PAQUETES_SHA256.json')]
 (OUT/'PAQUETES_SHA256.json').write_text(json.dumps(packages,indent=2))
 record=load(OUT/'VERIFICACION_PAQUETE.json');record.update(arranque_extraido=True,perfil_defecto='precision',descarga_identica_backend=report['descarga_identica_backend'],errores_js=report['errores_js'],lectura_fria_caja=cold,pruebas_extraidas={k:int(tests.get(k)) for k in ['tests','failures','errors','skipped']},fuentes_recomprobadas_tras_pruebas=len(manifest),paquetes=packages)
 (OUT/'VERIFICACION_PAQUETE.json').write_text(json.dumps(record,indent=2,ensure_ascii=False))
 p=OUT/'README.md';p.write_text(p.read_text().replace('**280 pruebas automáticas y 24 conversiones aprobadas**',f'**280 pruebas automáticas y 24 conversiones aprobadas**; {tests.get("tests")} pruebas adicionales y conversión/descarga reales sobre el paquete extraído'))
 assert all(sha(OUT/p['archivo'])==p['sha256'] for p in packages)
 print('VERIFICADO:',len(manifest),'fuentes,',tests.get('tests'),'pruebas extraídas y flujo navegador. Windows nativo pendiente.',flush=True)
if __name__=='__main__':main()
