"""Preparar una copia portable de las fuentes congeladas; no publica resultados pendientes."""
from pathlib import Path
import hashlib,json,shutil,difflib
R=Path(__file__).resolve().parent
OLD=Path('/workspace/work/mejora_superficies_post_R9_20261027')
M=R/'motor_R11_CONGELADO';S=R/'preparacion_entrega';A=S/'programa';Q=S/'auditoria'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def cp(a,b):b.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(a,b)
def main():
 manifest=json.loads((R/'FUENTES_R11_SHA256.json').read_text())
 for rel,h in manifest.items():
  assert sha(M/rel)==h,rel
  cp(M/rel,A/'Visor_experimental_fuentes'/rel)
 for action in ['Iniciar','Instalar_Entorno']:
  text='@echo off\nsetlocal\ncd /d "%~dp0"\ncall "%~dp0Visor_experimental_fuentes\\'+action+'.bat"\nexit /b %errorlevel%\n'
  (A/(action+'.bat')).write_bytes(text.replace('\n','\r\n').encode())
 (A/'LEEME_PRIMERO.txt').write_text('''VISOR STL -> STEP R11 EXPERIMENTAL COMPLETA

Extrae TODO en una carpeta NUEVA y abre Iniciar.bat de esa carpeta.
Incluye Visor_experimental_fuentes. Conserva tus versiones anteriores.
Puede reutilizar el entorno compatible de R7, R8, R9 o R10 sin modificarlo.
Si hace falta instalar, usa Instalar_Entorno.bat (Python 3.12 de 64 bits).
Comprueba el encabezado R11 experimental y http://127.0.0.1:8777.

Mantén Automático (precisión). No hay nuevas opciones que configurar.
La reconstrucción nueva mide perfiles directamente en el STL; sólo sustituye
el resultado anterior tras superar los controles geométricos y CAD originales.
Consulta INFORME_RESULTADOS.md para los resultados y límites comprobados.
Windows nativo, Onshape y la impresora K1C no se ejecutan en este entorno Linux.
''',encoding='utf-8')
 cp(R/'FUENTES_R11_SHA256.json',A/'FUENTES_SHA256.json')
 previous=OLD/'preparacion_entrega/auditoria'
 for folder in ['material_pruebas','banco_negativo_R7','evaluador_R7_inmutable','entradas_recientes']:
  shutil.copytree(previous/folder,Q/folder,dirs_exist_ok=True)
 for name in ['EVALUADOR_R7_SHA256.json','compatibilidad_wheels_windows.json']:
  cp(previous/name,Q/name)
 for name in ['control_frontera_inmutable_M1.py','reproducir_pruebas.py']:
  cp(previous/'herramientas'/name,Q/'herramientas'/name)
 protocol=json.loads((previous/'PROTOCOLO_PORTABLE.json').read_text())
 for c in protocol['casos']:
  reference=next(OLD/f/(c['id']+'.step') for f in ['regresion_cli','navegador'] if (OLD/f/(c['id']+'.step')).exists())
  cp(reference,Q/'referencias_R10'/reference.name)
  c['referencia_step']='referencias_R10/'+reference.name;c['sha256_referencia_R10']=sha(reference)
  assert sha(Q/c['source'])==c['sha256'],c['id']
 for name in ['V_legoBrick4x2','Soporte_movil_2','Technic_PEGS_Cross_x6_A']:
  p=Q/'entradas_recientes'/(name+'.stl');assert p.exists(),p
  protocol['casos'].append(dict(id=name,grupo='recientes',source=str(p.relative_to(Q)),sha256=sha(p),limite_s=1800,ok_previo=True))
 protocol.update(version='R11',motor='../programa/Visor_experimental_fuentes',alcance='24 casos: 21 principales y tres recientes. Embudo aplazado por el usuario.')
 (Q/'PROTOCOLO_PORTABLE.json').write_text(json.dumps(protocol,indent=2,ensure_ascii=False))
 (Q/'herramientas/reproducir_regresion.py').write_text((previous/'herramientas/reproducir_regresion.py').read_text().replace('FUENTES_R10_SHA256','FUENTES_R11_SHA256').replace('21 casos','24 casos').replace('len(rows)==21','len(rows)==24'))
 (Q/'REPRODUCIR.md').write_text('''# Reproducción de R11

Extraer el programa completo como `programa` y la auditoría como `auditoria`, en la misma carpeta.
Usar Python 3.12 y las dependencias bloqueadas del programa. Añadir `requirements_pruebas.txt` para pytest.

```
python auditoria/herramientas/reproducir_pruebas.py --motor programa/Visor_experimental_fuentes --material-r7 auditoria/material_pruebas --banco-r7 auditoria/banco_negativo_R7 --xml pruebas.xml
python auditoria/herramientas/reproducir_regresion.py --motor programa/Visor_experimental_fuentes --auditoria auditoria --salida resultados
```

El primer comando ejecuta la batería completa, incluidos los nuevos perfiles medidos.
El segundo reproduce los 24 casos por CLI. Los registros de la entrega distinguen 15 conversiones
CLI y nueve conversiones reales por navegador. Las rutas absolutas de `registro_ejecucion` documentan
la ejecución original; no son dependencias del programa. El programa genera su hipótesis desde
el STL: no necesita los STEP de referencia. El evaluador R10 congelado se conserva para contrastar
los dos objetivos de forma independiente. Los evaluadores R7 se conservan para pruebas negativas.
La carpeta de investigación rechazada nunca se instala. Embudo continúa aplazado.
Windows nativo, Onshape y K1C siguen pendientes de verificación externa.
''',encoding='utf-8')
 before=json.loads((OLD/'FUENTES_R10_SHA256.json').read_text());changes=[];patch=[]
 for rel,h in manifest.items():
  if before.get(rel)==h:continue
  a=OLD/'motor_R10_CONGELADO'/rel;b=M/rel
  cp(b,S/'archivos_modificados'/rel)
  changes.append(dict(archivo=rel,sha256_R10=before.get(rel),sha256_R11=h))
  patch.extend(difflib.unified_diff(a.read_text().splitlines(keepends=True) if a.exists() else [],b.read_text().splitlines(keepends=True),fromfile='R10/'+rel if a.exists() else '/dev/null',tofile='R11/'+rel))
 (R/'ARCHIVOS_MODIFICADOS_R10.json').write_text(json.dumps(changes,indent=2))
 (Q/'CAMBIOS_DESDE_R10.patch').write_text(''.join(patch))
 for rel in before:cp(OLD/'motor_R10_CONGELADO'/rel,Q/'evaluador_R10_inmutable'/rel)
 cp(OLD/'FUENTES_R10_SHA256.json',Q/'EVALUADOR_R10_SHA256.json')
 (Q/'investigacion_NO_APROBADA').mkdir(exist_ok=True)
 for name in ['bancada271_validacion.stdout','bancada239_validacion.stdout']:
  cp(R/name,Q/'investigacion_NO_APROBADA'/name)
 (Q/'investigacion_NO_APROBADA/LEEME.md').write_text('Ensayos descartados. La primera bancada con 271 caras conservaba un fallo BOP; la siguiente con 239 fallaba CAD exacto. No son resultados aprobados ni se instalan. La versión final corrige las intersecciones UV/3D y se verifica de nuevo con R10 inmutable. Los STEP rechazados se excluyen del programa y de la comparación.\n')
 print('Preparadas',len(manifest),'fuentes y',len(changes),'archivos modificados')
if __name__=='__main__':main()
