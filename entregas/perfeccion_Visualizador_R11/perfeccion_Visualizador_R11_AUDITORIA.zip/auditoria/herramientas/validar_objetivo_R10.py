"""Contrastar cualquier STEP contra su STL usando únicamente el evaluador R10 congelado."""
from pathlib import Path
import argparse,hashlib,json,os,sys,time,traceback
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--auditoria',type=Path,required=True);p.add_argument('--stl',type=Path,required=True)
 p.add_argument('--step',type=Path,required=True);p.add_argument('--informe',type=Path,required=True);a=p.parse_args()
 root=a.auditoria.resolve();motor=root/'evaluador_R10_inmutable';manifest=json.loads((root/'EVALUADOR_R10_SHA256.json').read_text())
 def check():
  for rel,h in manifest.items():assert sha(motor/rel)==h,rel
 check();sys.path[:0]=[str(motor),str(motor/'motor_superficies')];os.environ['VISOR_PERFIL']='precision'
 from preprocesador_stl import cargar_exacto
 from meshfit_detect import detect
 from reconstruccion_curvas import cilindros_respaldados,validar_cilindros_y_frontera
 stl=a.stl.resolve();step=a.step.resolve();before=(sha(stl),sha(step));start=time.monotonic()
 row=dict(ok=False,evaluador='R10 congelada',perfil='precision',stl_sha256=before[0],step_sha256=before[1])
 try:
  original=cargar_exacto(stl)
  regions,mesh=detect(str(stl),angle_tol_deg=32.,rms_tol_rel=.01,flat_tol_deg=8.,scan_mode=False,mesh_input=original)
  required=cilindros_respaldados(regions,mesh)
  shape,cyl,quality,topology,fine=validar_cilindros_y_frontera(stl,step,original,required)
  assert before==(sha(stl),sha(step));check()
  row.update(ok=True,calidad=quality,cilindros=cyl,topologia=topology,mallados=fine)
 except Exception as exc:row['error']=str(exc);traceback.print_exc()
 row['segundos']=time.monotonic()-start;a.informe.parent.mkdir(parents=True,exist_ok=True);a.informe.write_text(json.dumps(row,indent=2,ensure_ascii=False))
 return 0 if row['ok'] else 2
if __name__=='__main__':raise SystemExit(main())
