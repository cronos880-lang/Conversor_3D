from pathlib import Path
import numpy as np,cadquery as cq,pytest
from OCP.Geom import Geom_Plane,Geom_RectangularTrimmedSurface
from OCP.GeomConvert import GeomConvert
from OCP.gp import gp_Pnt,gp_Dir,gp_Pln
from OCP.BRep import BRep_Tool
from OCP.BRepBuilderAPI import BRepBuilderAPI_NurbsConvert,BRepBuilderAPI_Sewing,BRepBuilderAPI_MakeSolid
from OCP.BRepLib import BRepLib
from planos_certificados import soporte_plano,convertir,exacto
M=Path(__file__).resolve().parent/'motor_M35/motor_superficies'

def patch():
 s=GeomConvert.SurfaceToBSplineSurface_s(Geom_RectangularTrimmedSurface(Geom_Plane(gp_Pln(gp_Pnt(0,0,0),gp_Dir(0,0,1))),0.,2.,0.,2.));s.IncreaseDegree(3,3);return s

def test_cota_sobre_todos_los_polos_detecta_bulto_interior():
 s=patch();assert soporte_plano(s) is not None
 p=s.Pole(2,2);s.SetPole(2,2,gp_Pnt(p.X(),p.Y(),.001))
 assert all(abs(s.Pole(i,j).Z())<1e-15 for i in (1,s.NbUPoles()) for j in (1,s.NbVPoles()))
 assert soporte_plano(s) is None

def test_conserva_agujero_y_cilindro_en_cara_de_dos_contornos():
 box=cq.Solid.makeBox(4,4,2).cut(cq.Solid.makeCylinder(.5,2,cq.Vector(2,2,0)))
 sewing=BRepBuilderAPI_Sewing(1e-7)
 for f in box.Faces():sewing.Add(BRepBuilderAPI_NurbsConvert(f.wrapped,True).Shape() if len(f.Wires())==2 and f.Center().z>1.99 else f.wrapped)
 sewing.Perform();shell=cq.Shape.cast(sewing.SewedShape()).Shells()[0];solid=BRepBuilderAPI_MakeSolid(shell.wrapped).Solid();BRepLib.OrientClosedSolid_s(solid);assert exacto(solid)
 before=cq.Solid(solid);after,proof=convertir(before,M)
 assert any(p['ok'] and p['contornos']==2 for p in proof)
 assert exacto(after.wrapped) and abs(after.Volume()-box.Volume())<1e-9
 assert abs(after.Area()-box.Area())<1e-9 and len(after.Solids())==1
 assert sum(f.geomType()=='CYLINDER' for f in after.Faces())==1

def test_no_sustituye_caja_analitica_sin_parches():
 shape=cq.Solid.makeBox(2,2,2)
 with pytest.raises(ValueError,match='No hay parches'):convertir(shape,M)
 assert len(shape.Faces())==6 and exacto(shape.wrapped)
