from pathlib import Path
import sys,numpy as np,trimesh
sys.path.insert(0,str(Path(__file__).parent/'motor_superficies'))
import cadquery as cq
from OCP.Geom import Geom_Plane,Geom_CylindricalSurface
from OCP.gp import gp_Pnt,gp_Dir,gp_Pln,gp_Ax3
from OCP.BRepCheck import BRepCheck_Analyzer
from realimentacion_bop import retirables,diagnosticar
import constructor_barridos as constructor
from solidificacion_exacta import solidificar


def test_nunca_propone_retirar_cilindro_confirmado():
 plane=Geom_Plane(gp_Pln(gp_Pnt(0,0,0),gp_Dir(0,0,1)));cylinder=Geom_CylindricalSurface(gp_Ax3(),1.)
 state=dict(primary={0,1},surfaces={0:plane,1:cylinder})
 assert retirables({0,1},state)==[0]


def test_reanuda_caja_y_conserva_su_geometria_y_fuente():
 mesh=trimesh.creation.box(extents=(2,2,2));beforeV=mesh.vertices.copy();beforeF=mesh.faces.copy()
 normals,labels=np.unique(mesh.face_normals,axis=0,return_inverse=True);surfaces={}
 for r,n in enumerate(normals):
  k=int(np.flatnonzero(labels==r)[0]);surfaces[r]=Geom_Plane(gp_Pln(gp_Pnt(*mesh.triangles_center[k]),gp_Dir(*n)))
 shell,_=constructor.construir(mesh,labels,surfaces,.001,.012,parches_regulares=True,triangulos_libres=True)
 state=constructor.ULTIMO_ESTADO;solid=cq.Shape.cast(solidificar(shell));assert diagnosticar(solid,state)['interferencias']==0
 region=min(state['primary']);ids=np.flatnonzero(state['labels']==region);vertex=int(state['mesh'].faces[ids[0],0]);tol,move,smooth,regular,triangles=state['args']
 shell,_=constructor.construir(state['mesh'],state['labels'],state['surfaces'],tol,move,smooth,regular,triangles,_estado=state,_retiros=[(region,vertex)])
 out=cq.Shape.cast(solidificar(shell));assert BRepCheck_Analyzer(out.wrapped,True,False,True).IsValid()
 assert abs(out.Volume()-8.)<1e-10 and out.isInside((0,0,0))
 assert np.array_equal(mesh.vertices,beforeV) and np.array_equal(mesh.faces,beforeF)
 assert diagnosticar(out,constructor.ULTIMO_ESTADO)['interferencias']==0


def test_localiza_hipotesis_fuente_en_cruces_entre_caras_distintas():
 from OCP.BRep import BRep_Tool
 first=cq.Workplane().box(1,1,1).val();second=first.translate((.25,.25,.25));candidate=cq.Compound.makeCompound([first,second])
 source=trimesh.util.concatenate([trimesh.creation.box(),trimesh.creation.box().apply_translation((.25,.25,.25))]);labels=np.full(len(source.faces),-1,int);surfaces={};faces={}
 for i,face in enumerate(candidate.Faces()):
  center=np.array(face.Center().toTuple());normal=np.array(face.normalAt().toTuple())
  ids=np.flatnonzero((np.abs((source.triangles_center-center)@normal)<1e-9)&(source.face_normals@normal>.9999))
  assert len(ids)==2;labels[ids]=i;faces[i]=face.wrapped;surfaces[i]=BRep_Tool.Surface_s(face.wrapped)
 assert np.all(labels>=0)
 state=dict(mesh=source,labels=labels,faces=faces,surfaces=surfaces,primary=set(faces))
 report=diagnosticar(candidate,state)
 assert report['interferencias']>0 and report['retiros']
 assert all(r in state['primary'] for r,v in report['retiros'])
 assert all(row['regiones'] for row in report['defectos'])
