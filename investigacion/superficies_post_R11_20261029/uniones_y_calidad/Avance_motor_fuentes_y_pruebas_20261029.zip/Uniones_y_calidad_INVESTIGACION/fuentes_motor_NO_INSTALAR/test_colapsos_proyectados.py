from pathlib import Path
import sys,numpy as np
sys.path.insert(0,str(Path(__file__).parent/'motor_superficies'))
from colapsos_proyectados import detectar


def test_detecta_colapso_de_vertices_sin_arista_compartida():
 source=np.array([[0.,0,0],[1.,0,0],[0,1.,0],[1.,1.,0]])
 positions={i:p.copy() for i,p in enumerate(source)};positions[3]=source[0]+np.array([1e-8,0,0])
 rows=detectar(source,positions)
 assert len(rows)==1 and rows[0]['vertices']==[0,3]
 assert np.array_equal(source,np.array([[0.,0,0],[1.,0,0],[0,1.,0],[1.,1.,0]]))


def test_no_confunde_geometria_original_proxima_con_colapso_nuevo():
 source=np.array([[0.,0,0],[1e-8,0,0],[1.,0,0]])
 assert detectar(source,{i:p.copy() for i,p in enumerate(source)})==[]
 assert detectar(source,{0:source[0],2:np.array([3e-7,0,0])})==[]
