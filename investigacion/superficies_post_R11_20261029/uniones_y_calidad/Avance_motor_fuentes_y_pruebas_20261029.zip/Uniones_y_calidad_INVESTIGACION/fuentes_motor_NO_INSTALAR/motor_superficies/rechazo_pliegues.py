"""Rechazar pliegues observados; la aceptación final CAD/BOP/CGAL sigue obligatoria."""
import numpy as np
from OCP.gp import gp_Pnt,gp_Vec


def exigir_regular(surface,reference):
    normal=np.asarray(reference,float);length=np.linalg.norm(normal)
    if length==0:raise ValueError('No se confirma la orientación del campo libre')
    normal/=length
    u0,u1,v0,v1=surface.Bounds()
    def values(first,last,axis):
        knots=[first,last]
        if hasattr(surface,'NbUKnots'):
            count=surface.NbUKnots() if axis==0 else surface.NbVKnots()
            knot=surface.UKnot if axis==0 else surface.VKnot
            knots.extend(knot(i) for i in range(1,count+1) if first<knot(i)<last)
        breaks=sorted(set(knots));out=[]
        for a,b in zip(breaks[:-1],breaks[1:]):out.extend(a+(b-a)*np.array([.01,.15,.5,.85,.99]))
        return np.unique(out)
    U,V=values(u0,u1,0),values(v0,v1,1)
    if len(U)*len(V)>16384:raise ValueError('El campo libre excede el presupuesto de comprobación de orientación')
    signs=set();count=0
    for u in U:
        for v in V:
            p=gp_Pnt();du=gp_Vec();dv=gp_Vec();surface.D1(float(u),float(v),p,du,dv)
            cross=np.cross(du.Coord(),dv.Coord());scale=np.linalg.norm(cross)
            if scale<=1e-24:raise ValueError('El campo libre presenta una parametrización colapsada')
            dot=float(cross@normal/scale);count+=1
            if abs(dot)>1e-8:signs.add(1 if dot>0 else -1)
            if len(signs)>1:raise ValueError('El campo libre cambia de orientación y se pliega; subdividir la región fuente')
    if not signs:raise ValueError('No se confirma una orientación regular del campo libre')
    return dict(muestras=count,signo=next(iter(signs)),nota='Rechazo de pliegues observados; no sustituye BOP ni CGAL')
