from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).parent/'motor_superficies'))
import cadquery as cq
import pytest
from OCP.BRep import BRep_Builder,BRep_Tool
from OCP.TopoDS import TopoDS_Shell
from OCP.BRepCheck import BRepCheck_Analyzer
from solidificacion_exacta import solidificar


@pytest.mark.parametrize('agujero',[False,True])
def test_orienta_shell_sin_sustituir_caras_ni_geometria(agujero):
    base=cq.Workplane().box(4,4,3)
    if agujero:base=base.faces('>Z').workplane().hole(1)
    original=base.val();faces=original.Faces();shell=TopoDS_Shell();builder=BRep_Builder();builder.MakeShell(shell)
    for i,face in enumerate(faces):builder.Add(shell,face.wrapped.Reversed() if i%2 else face.wrapped)
    # La reparación consiste exclusivamente en elegir sentidos coherentes.
    result=solidificar(shell);out=cq.Shape.cast(result)
    assert BRepCheck_Analyzer(result,True,False,True).IsValid()
    assert len(out.Faces())==len(faces) and abs(out.Volume()-original.Volume())<1e-9
    assert out.isInside((0,0,0)) is (not agujero)
    assert all(any(f.wrapped.IsSame(g.wrapped) for g in out.Faces()) for f in faces)
    assert all(BRep_Tool.Tolerance_s(e.wrapped)==1e-7 for e in out.Edges())


def test_no_convierte_un_shell_abierto_en_solido():
    shell=TopoDS_Shell();b=BRep_Builder();b.MakeShell(shell);b.Add(shell,cq.Face.makePlane(1,1).wrapped)
    with pytest.raises(ValueError):solidificar(shell)
