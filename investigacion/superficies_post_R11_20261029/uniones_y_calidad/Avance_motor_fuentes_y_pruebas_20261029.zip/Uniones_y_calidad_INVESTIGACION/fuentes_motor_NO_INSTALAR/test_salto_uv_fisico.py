from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).parent/'motor_superficies'))
from OCP.BRepTools import BRepTools
from OCP.BRep import BRep_Builder
from OCP.TopoDS import TopoDS_Shape
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.Geom import Geom_Plane,Geom_RectangularTrimmedSurface
from OCP.GeomConvert import GeomConvert
from OCP.gp import gp_Pnt,gp_Dir,gp_Pnt2d,gp_Pln
from fijacion_contornos import completar_vertices_singulares,salto_numerico_certificado


def test_cara_real_exacta_no_recibe_aristas_singulares_artificiales():
    shape=TopoDS_Shape();path=Path(__file__).parent/'fixtures_cad/Technic_cara_597_salto_numerico.brep'
    assert BRepTools.Read_s(shape,str(path),BRep_Builder())
    assert BRepCheck_Analyzer(shape,True,False,True).IsValid()
    result,proof=completar_vertices_singulares(shape)
    assert result.IsSame(shape) and proof['aristas_degeneradas_anadidas']==0
    assert BRepCheck_Analyzer(result,True,False,True).IsValid()


def plane():
    p=Geom_Plane(gp_Pln(gp_Pnt(0,0,0),gp_Dir(0,0,1)))
    return GeomConvert.SurfaceToBSplineSurface_s(Geom_RectangularTrimmedSurface(p,0.,1.,0.,1.))


def test_usa_distancia_fisica_sin_aumentar_cota():
    s=plane();a=gp_Pnt2d(.1,.2);point=s.Value(.1,.2)
    assert salto_numerico_certificado(s,a,gp_Pnt2d(.1+2e-9,.2),point)
    assert not salto_numerico_certificado(s,a,gp_Pnt2d(.100001,.2),point)
    assert not salto_numerico_certificado(s,a,gp_Pnt2d(.1,.2),gp_Pnt(0,0,.001))


def test_no_omite_un_salto_fuera_del_dominio():
    assert not salto_numerico_certificado(plane(),gp_Pnt2d(-1e-9,0.),gp_Pnt2d(0.,0.),gp_Pnt(0,0,0))
