from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).parent/'motor_superficies'))
from OCP.Geom import Geom_BezierSurface
from OCP.TColgp import TColgp_Array2OfPnt
from OCP.gp import gp_Pnt
from soportes_planos_exactos import reconocer


def surface():
 p=TColgp_Array2OfPnt(1,4,1,4)
 for i in range(1,5):
  for j in range(1,5):p.SetValue(i,j,gp_Pnt(127+i,-95+j,2.))
 return Geom_BezierSurface(p)


def test_reconoce_bezier_plano_con_todos_sus_polos():
 s=surface();plane,proof=reconocer(s)
 assert proof['polos']==16 and proof['cota_convexa_todos_polos_mm']<1e-12
 assert max(plane.Pln().Distance(s.Value(i/11,j/11)) for i in range(12) for j in range(12))<1e-10


def test_no_confunde_cuatro_esquinas_planas_con_un_plano():
 s=surface();p=s.Pole(2,2);s.SetPole(2,2,gp_Pnt(p.X(),p.Y(),p.Z()+1e-5))
 assert reconocer(s) is None
