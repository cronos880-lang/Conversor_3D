"""Dividir sólo la región libre conserva fuente, cilindros y conectividad."""
from pathlib import Path
import sys,numpy as np,trimesh
sys.path.insert(0,str(Path(__file__).parent/'motor_superficies'))
from OCP.Geom import Geom_Plane,Geom_CylindricalSurface
from OCP.gp import gp_Pln,gp_Pnt,gp_Dir,gp_Ax3
from constructor_barridos import subdividir_parches_complejos

def test_division_local_en_dos_niveles_no_modifica_la_malla_ni_primitivas():
 mesh=trimesh.creation.cylinder(radius=1.,height=2.,sections=32);V=mesh.vertices.copy();F=mesh.faces.copy()
 labels=np.where(mesh.face_normals[:,2]>.5,0,np.where(mesh.face_normals[:,2]<-.5,1,2));side=np.flatnonzero(labels==2);bottom=np.flatnonzero(labels==1)
 top=Geom_Plane(gp_Pln(gp_Pnt(0,0,1),gp_Dir(0,0,1)));cylinder=Geom_CylindricalSurface(gp_Ax3(gp_Pnt(0,0,0),gp_Dir(0,0,1)),1.)
 surfaces={0:top,1:Geom_Plane(gp_Pln(gp_Pnt(0,0,-1),gp_Dir(0,0,1))),2:cylinder};mesh.hipotesis_no_primarias={id(top)};mesh.hipotesis_parches_completos={id(top)};mesh.parches_altura_medidos={0:{'fuente':True}}
 for level,maximum in [(1,2),(2,1)]:
  mesh.regiones_libres_refinadas={id(top):level};subdividir_parches_complejos(mesh,labels,surfaces,{1,2})
  for region in set(map(int,labels))-{1,2}:
   assert np.count_nonzero(labels==region)<=maximum
   assert surfaces[region] is top
  assert np.array_equal(mesh.vertices,V) and np.array_equal(mesh.faces,F)
  assert np.all(labels[side]==2) and np.all(labels[bottom]==1) and surfaces[2] is cylinder
  assert mesh.is_watertight and mesh.is_winding_consistent and mesh.euler_number==2
