import cadquery as cq
import pytest
from cilindros_contiguos import proponer,certificar_recortes,cilindros
from OCP.BRepCheck import BRepCheck_Analyzer


def pieza(divisiones=2,hueco=False):
    parts=[]
    for i in range(divisiones):
        p=cq.Solid.makeCylinder(3,4,angleDegrees=360/divisiones).rotate((0,0,0),(0,0,1),i*360/divisiones)
        if hueco:p=p.cut(cq.Solid.makeCylinder(1,4))
        parts.append(p)
    result=parts[0]
    for p in parts[1:]:result=result.fuse(p)
    return result


@pytest.mark.parametrize('divisiones',[2,4])
@pytest.mark.parametrize('hueco',[False,True])
def test_reune_cilindros_conservando_dominio_y_agujero(divisiones,hueco):
    old=pieza(divisiones,hueco);before=old.Volume();original_faces=len(old.Faces())
    new,proof=proponer(old)
    assert len(new.Faces())<original_faces
    assert len(cilindros(new))<len(cilindros(old))
    assert BRepCheck_Analyzer(new.wrapped,True,False,True).IsValid()
    assert old.Volume()==before and len(old.Faces())==original_faces
    assert abs(new.Volume()-before)<1e-8
    assert new.isInside((0,0,2)) is (not hueco)
    assert proof['requiere_qa_final_independiente']


def test_no_acepta_recorte_desplazado_con_misma_area_y_radio():
    old=cq.Solid.makeCylinder(3,4);other=old.translate((0,0,1))
    with pytest.raises(ValueError,match='dominio'):certificar_recortes(old,other)


def test_no_acepta_cambio_de_radio():
    with pytest.raises(ValueError,match='dominio'):
        certificar_recortes(cq.Solid.makeCylinder(3,4),cq.Solid.makeCylinder(3.001,4))


def test_rechazo_conserva_archivos_y_no_entrega_step_incompleto(tmp_path):
    import trimesh,hashlib,json
    from cilindros_contiguos import ejecutar
    source=tmp_path/'caja.stl';base=tmp_path/'base.step';candidate=tmp_path/'candidato.step';report=tmp_path/'informe.json'
    trimesh.creation.box().export(source);cq.exporters.export(cq.Workplane().box(1,1,1),str(base))
    digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before=(digest(source),digest(base))
    assert ejecutar(source,base,candidate,report)==2
    assert not candidate.exists() and not json.loads(report.read_text())['ok']
    assert (digest(source),digest(base))==before


def test_no_sobrescribe_candidato_existente(tmp_path):
    from cilindros_contiguos import ejecutar
    source=tmp_path/'fuente.stl';base=tmp_path/'base.step';candidate=tmp_path/'candidato.step';report=tmp_path/'informe.json'
    source.write_bytes(b'fuente');base.write_bytes(b'base');candidate.write_bytes(b'conservar')
    with pytest.raises(ValueError,match='salidas nuevas'):ejecutar(source,base,candidate,report)
    assert candidate.read_bytes()==b'conservar' and not report.exists()


def test_no_sobrescribe_entrada_a_traves_de_enlace(tmp_path):
    from cilindros_contiguos import ejecutar
    source=tmp_path/'fuente.stl';base=tmp_path/'base.step';candidate=tmp_path/'candidato.step';report=tmp_path/'informe.json'
    source.write_bytes(b'fuente');base.hardlink_to(source)
    with pytest.raises(ValueError,match='mismo archivo'):ejecutar(source,base,candidate,report)
    assert source.read_bytes()==b'fuente' and not report.exists()
