"""El contacto debe coincidir con la curva, incluso con planos casi paralelos."""
from pathlib import Path
import sys,numpy as np,pytest
from scipy.optimize import least_squares
sys.path.insert(0,str(Path(__file__).parent/'motor_superficies'))
from OCP.Geom import Geom_Plane
from OCP.gp import gp_Pnt,gp_Dir,gp_Pln
from afin_planos import espacio,resolver
from geometria_medida import intersection_stable

def plane(point,normal):return Geom_Plane(gp_Pln(gp_Pnt(*point),gp_Dir(*normal)))

@pytest.mark.parametrize('angle',[1e-4,1e-6,1e-7,1e-9,1e-10])
@pytest.mark.parametrize('origin',[(0.,0.,0.),(127.,-95.,1.6)])
def test_planos_casi_paralelos_comparten_extremos_exactos(angle,origin):
    origin=np.array(origin);surfaces=[plane(origin,(0,0,1)),plane(origin,(0,angle,1))];point=origin+np.array([0.,8e-5,0.])
    A=np.array([s.Axis().Direction().Coord() for s in surfaces])
    residual=lambda q:A@(q-origin)
    result=resolver(surfaces,point,point,residual).x
    # La distancia a la línea de encuentro, no sólo a cada plano, es microscópica.
    assert np.linalg.norm((result-origin)[1:])<1e-10
    assert np.linalg.norm(result-point)<.003
    p=np.array([result+np.array([-1.,0,0]),result+np.array([1.,0,0])])
    curve,first,last=intersection_stable(*surfaces,p,.003,False)
    assert curve.Value(first).Distance(gp_Pnt(*p[0]))<1e-10
    assert curve.Value(last).Distance(gp_Pnt(*p[1]))<1e-10
    # Reproduce la falsa seguridad del ajuste de coordenadas con penalización.
    if angle<1e-5:
        old=least_squares(lambda q:np.r_[residual(q),(q-point)*1e-6],point,xtol=1e-13,ftol=1e-13,gtol=1e-13)
        assert np.max(abs(residual(old.x)))<2e-7
        assert np.linalg.norm((old.x-origin)[1:])>2e-6

def test_planos_paralelos_incompatibles_no_se_promedian():
    with pytest.raises(ValueError,match='no comparten'):espacio([plane((0,0,0),(0,0,1)),plane((0,0,.001),(0,0,1))],np.zeros(3))

def test_tres_planos_fijan_un_unico_vertice():
    target=np.array([1.,2.,3.]);surfaces=[plane(target,n) for n in np.eye(3)]
    residual=lambda q:q-target
    result=resolver(surfaces,target+.001,target-.001,residual).x
    assert np.linalg.norm(result-target)<1e-12

def test_se_conserva_el_grado_libre_para_otros_contactos():
    # Dos planos dejan libre X; un tercer contacto fija X sin abandonar los planos.
    surfaces=[plane((0,0,0),(0,1,0)),plane((0,0,0),(0,0,1))]
    result=resolver(surfaces,np.array([.2,.001,.001]),np.array([.2,0.,0.]),lambda q:np.array([q[0]-.21])).x
    assert abs(result[0]-.21)<1e-10 and np.linalg.norm(result[1:])<1e-12


def test_semilla_conciliada_conserva_contacto_cilindrico_casi_tangente():
    delta=3e-7;surfaces=[plane((0,0,0),(0,0,1)),plane((1-delta,0,0),(1,0,0))]
    source=np.array([1.,0.,0.]);canonical=np.array([1-delta,np.sqrt(1-(1-delta)**2),0.])
    residual=lambda q:np.array([np.linalg.norm(q[:2])-1.])
    result=resolver(surfaces,source,canonical,residual).x
    assert abs(residual(result)[0])<1e-12
    assert np.linalg.norm(result-source)<.003
    assert abs(result[0]-(1-delta))<1e-12 and abs(result[2])<1e-12


def test_soportes_coincidentes_conservan_cadena_no_recta():
    from OCP.GeomAPI import GeomAPI_ProjectPointOnCurve
    sa=plane((0,0,0),(0,0,1));sb=plane((0,0,0),(0,0,-1));points=np.array([[0.,0.,0.],[1.,0.,0.],[1.,1.,0.]])
    curve,first,last=intersection_stable(sa,sb,points,.003,False)
    for p in points:assert GeomAPI_ProjectPointOnCurve(gp_Pnt(*p),curve,first,last).LowerDistance()<1e-12


def test_no_aplasta_un_retroceso_aunque_quepa_en_tolerancia_de_movimiento():
    from afin_planos import ContornoPlanoIncompatible
    sa=plane((0,0,0),(0,1,0));sb=plane((0,0,0),(0,0,1));points=np.array([[0.,0.,0.],[.01,0,0],[.009,0,0],[.02,0,0]])
    with pytest.raises(ContornoPlanoIncompatible):intersection_stable(sa,sb,points,.012,False)


def test_contacto_solo_de_planos_minimiza_desplazamiento_sin_heredar_semilla():
 surfaces=[plane((0,0,0),(0,0,1))];source=np.array([.2,.3,.00005]);seed=np.array([.2004,.3003,0.])
 result=resolver(surfaces,source,seed,lambda q:np.array([q[2]])).x
 assert np.linalg.norm(result-np.array([.2,.3,0.]))<1e-12


def test_minimo_de_planos_no_ignora_otro_contacto_microscopico():
 delta=3e-9;surfaces=[plane((0,0,0),(0,0,1)),plane((1-delta,0,0),(1,0,0))]
 source=np.array([1.,0.,0.]);seed=np.array([1-delta,np.sqrt(1-(1-delta)**2),0.])
 result=resolver(surfaces,source,seed,lambda q:np.array([np.linalg.norm(q[:2])-1.])).x
 assert abs(np.linalg.norm(result[:2])-1.)<1e-12 and result[1]>0.
