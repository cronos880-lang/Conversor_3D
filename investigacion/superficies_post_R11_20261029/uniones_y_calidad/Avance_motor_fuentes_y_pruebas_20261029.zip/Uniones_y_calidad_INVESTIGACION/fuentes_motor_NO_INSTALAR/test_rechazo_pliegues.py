from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).parent/'motor_superficies'))
import pytest
from OCP.Geom import Geom_BezierSurface
from OCP.TColgp import TColgp_Array2OfPnt
from OCP.gp import gp_Pnt
from rechazo_pliegues import exigir_regular


def surface(fold):
 p=TColgp_Array2OfPnt(1,3,1,2)
 # x=(u-.5)^2 tiene dos hojas superpuestas, pese a su límite plano.
 for i,x in enumerate([.25,-.25,.25] if fold else [0.,.5,1.],1):
  for j,y in enumerate([0.,1.],1):p.SetValue(i,j,gp_Pnt(x,y,.002 if i==2 else 0.))
 return Geom_BezierSurface(p)


def test_rechaza_parche_plegado_aunque_este_cerca_de_la_fuente():
 with pytest.raises(ValueError,match='pliega|colapsada'):exigir_regular(surface(True),(0,0,1))


def test_permite_altura_curvada_regular_y_sentido_invertido():
 s=surface(False)
 assert exigir_regular(s,(0,0,1))['signo']==1
 assert exigir_regular(s,(0,0,-1))['signo']==-1


def test_integracion_campo_curvo_regular_no_falla_antes_del_control():
 from constructor_barridos import _superficie_libre
 from OCP.Geom import Geom_Plane,Geom_BezierCurve
 from OCP.gp import gp_Pln,gp_Dir
 from OCP.TColgp import TColgp_Array1OfPnt
 import numpy as np
 def curve(points):
  a=TColgp_Array1OfPnt(1,len(points))
  for i,p in enumerate(points,1):a.SetValue(i,gp_Pnt(*p))
  return Geom_BezierCurve(a)
 curves=[curve([(0,0,0),(.5,0,.004),(1,0,0)]),curve([(1,0,0),(1,1,0)]),curve([(1,1,0),(0,1,0)]),curve([(0,1,0),(0,0,0)])]
 original=Geom_Plane(gp_Pln(gp_Pnt(0,0,0),gp_Dir(0,0,1)))
 candidate=_superficie_libre(original,[(c,0.,1.) for c in curves],np.array([[.25,.25,0.],[.75,.25,0.],[.25,.75,0.],[.75,.75,0.]]))
 assert exigir_regular(candidate,(0,0,1))['muestras']>0
