from pathlib import Path
import sys,numpy as np,pytest
sys.path.insert(0,str(Path(__file__).parent/'motor_superficies'))
from OCP.Geom import Geom_CylindricalSurface,Geom_Line
from OCP.Geom2d import Geom2d_Line
from OCP.gp import gp_Ax3,gp_Ax1,gp_Pnt,gp_Dir,gp_Ax2d,gp_Pnt2d,gp_Dir2d
from geometria_medida import UV_KNOWN,registrar_uv,limpiar_registro_uv,crear_pcurva
from pcurvas_compartidas import _error

def data(offset=0.):
 s=Geom_CylindricalSurface(gp_Ax3(gp_Pnt(0,0,0),gp_Dir(0,0,1)),1.);c=Geom_Line(gp_Ax1(gp_Pnt(1+offset,0,0),gp_Dir(0,0,1)))
 bad=Geom2d_Line(gp_Ax2d(gp_Pnt2d(3,0),gp_Dir2d(0,1)))
 return s,c,bad

@pytest.mark.parametrize('registered',[False,True])
def test_dato_uv_obsoleto_no_sustituye_curva_3d_actual(registered):
 limpiar_registro_uv();s,c,bad=data()
 if registered:registrar_uv(c,s,bad)
 else:UV_KNOWN[id(c),id(s)]=bad
 assert _error(c,bad,s,0,1)>1.
 uv,proof=crear_pcurva(c,0,1,s)
 assert _error(c,uv,s,0,1)<5e-8
 limpiar_registro_uv()

def test_recalcular_uv_no_acepta_curva_fuera_del_cilindro():
 limpiar_registro_uv();s,c,bad=data(.001);registrar_uv(c,s,bad)
 with pytest.raises(ValueError):crear_pcurva(c,0,1,s)
 limpiar_registro_uv()
