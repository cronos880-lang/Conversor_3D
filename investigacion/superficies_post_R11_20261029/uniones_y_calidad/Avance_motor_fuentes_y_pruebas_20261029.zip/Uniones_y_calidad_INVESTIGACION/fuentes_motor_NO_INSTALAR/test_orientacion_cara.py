from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).parent/'motor_superficies'))
import cadquery as cq
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.BRep import BRep_Tool
from OCP.TopoDS import TopoDS
from orientacion_cara import corregir


def test_orienta_contorno_sin_cambiar_geometria_ni_aristas():
    original=cq.Face.makePlane(2,1)
    # Invertir sólo el wire reproduce BadOrientationOfSubshape.
    from OCP.BRep import BRep_Builder
    from OCP.TopoDS import TopoDS_Face
    builder=BRep_Builder();bad=TopoDS_Face();support=BRep_Tool.Surface_s(original.wrapped)
    builder.MakeFace(bad,support,1e-7)
    for wire in original.Wires():builder.Add(bad,wire.wrapped.Reversed())
    assert not BRepCheck_Analyzer(bad,True,False,True).IsValid()
    result=corregir(bad)
    assert BRepCheck_Analyzer(result,True,False,True).IsValid()
    assert BRep_Tool.Surface_s(result)==support
    assert all(any(a.wrapped.IsSame(b.wrapped) for b in cq.Face(result).Edges()) for a in original.Edges())
    assert abs(cq.Face(result).Area()-original.Area())<1e-12


def test_cara_valida_se_conserva():
    original=cq.Face.makePlane(2,1).wrapped
    assert corregir(original).IsSame(original)
