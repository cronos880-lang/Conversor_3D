from pathlib import Path
import sys,numpy as np,pytest
sys.path.insert(0,str(Path(__file__).parent/'motor_superficies'))
from OCP.Geom import Geom_BSplineCurve,Geom_BezierCurve
from OCP.TColgp import TColgp_Array1OfPnt
from OCP.TColStd import TColStd_Array1OfReal,TColStd_Array1OfInteger
from OCP.gp import gp_Pnt
from parches_triangulares import superficie_triangular
from pcurvas_compartidas import _lineal_uv,_error

def compound():
 P=TColgp_Array1OfPnt(1,7)
 for i,p in enumerate([(0,0,0),(1/6,0,0),(1/3,0,.001),(.5,0,.001),(2/3,0,.001),(5/6,0,0),(1,0,0)],1):P.SetValue(i,gp_Pnt(*p))
 K=TColStd_Array1OfReal(1,3);M=TColStd_Array1OfInteger(1,3)
 for i,(k,m) in enumerate([(0.,4),(.5,3),(1.,4)],1):K.SetValue(i,k);M.SetValue(i,m)
 return Geom_BSplineCurve(P,K,M,3,False)

def line(a,b):
 P=TColgp_Array1OfPnt(1,2);P.SetValue(1,gp_Pnt(*a));P.SetValue(2,gp_Pnt(*b));return Geom_BezierCurve(P)

@pytest.mark.parametrize('curved_side',[0,1,2])
def test_tres_contornos_compuestos_con_parametro_triangular_regular(curved_side):
 # Rotar el perfil curvo entre las tres fronteras conserva su expresión exacta.
 c=compound()
 if curved_side==1:
  from OCP.gp import gp_Trsf,gp_Ax1,gp_Dir
  # Construcción directa de la frontera B→C: x=1-t,y=t.
  for i in range(1,c.NbPoles()+1):
   p=c.Pole(i);c.SetPole(i,gp_Pnt(1-p.X(),p.X(),p.Z()))
 elif curved_side==2:
  for i in range(1,c.NbPoles()+1):
   p=c.Pole(i);c.SetPole(i,gp_Pnt(0,1-p.X(),p.Z()))
 curves=[line((0,0,0),(1,0,0)),line((1,0,0),(0,1,0)),line((0,1,0),(0,0,0))];curves[curved_side]=c
 edges=[(c,c.FirstParameter(),c.LastParameter()) for c in curves];anchor=np.array([1/3,1/3,.0003]);surface=superficie_triangular(edges,anchor)
 for i,(c,a,b) in enumerate(edges):
  start,end=[((0,0),(1,0)),((1,0),(0,1)),((0,1),(0,0))][i]
  assert _error(c,_lineal_uv(a,b,start,end),surface,a,b)<5e-8
 assert surface.Value(1/3,1/3).Distance(gp_Pnt(*anchor))<1e-8
 # X=u,Y=v en toda la superficie: no hay pliegue ni ápice paramétrico colapsado.
 for u in np.linspace(0,1,19):
  for v in np.linspace(0,1-u,17):
   p=surface.Value(float(u),float(v));assert abs(p.X()-u)<1e-9 and abs(p.Y()-v)<1e-9


def test_contorno_compuesto_plano_no_se_abulta_por_el_anclaje_uv():
 c=compound()
 for i in range(1,c.NbPoles()+1):
  p=c.Pole(i);c.SetPole(i,gp_Pnt(p.X(),p.Y(),0.))
 curves=[c,line((1,0,0),(0,1,0)),line((0,1,0),(0,0,0))]
 surface=superficie_triangular([(c,c.FirstParameter(),c.LastParameter()) for c in curves],np.array([1/3,1/3,.0001]),anclaje_geometrico=True)
 assert max(abs(surface.Pole(i,j).Z()) for i in range(1,surface.NbUPoles()+1) for j in range(1,surface.NbVPoles()+1))<1e-12
