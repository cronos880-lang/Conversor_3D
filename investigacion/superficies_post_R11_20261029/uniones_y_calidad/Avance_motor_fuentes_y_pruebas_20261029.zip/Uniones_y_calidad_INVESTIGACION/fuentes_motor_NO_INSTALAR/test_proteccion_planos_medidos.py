from pathlib import Path
import sys,numpy as np,trimesh
sys.path.insert(0,str(Path(__file__).parent/'motor_superficies'))
from OCP.Geom import Geom_Plane
from OCP.gp import gp_Pln,gp_Pnt,gp_Dir
from campos_fuente import proponer

def source(curve_both=False):
 xs=np.linspace(-1,1,17);ys=np.linspace(0,1,9);V=np.array([(x,y,.002*x*x if curve_both or x>0 else 0.) for x in xs for y in ys]);F=[]
 for i in range(16):
  for j in range(8):
   a=i*9+j;b=(i+1)*9+j;F.extend([[a,b,b+1],[a,b+1,a+1]])
 mesh=trimesh.Trimesh(V,np.array(F),process=False);labels=(mesh.triangles_center[:,0]>0).astype(int)
 plane=Geom_Plane(gp_Pln(gp_Pnt(0,0,0),gp_Dir(0,0,1)));return mesh,labels,{0:plane,1:plane.Copy()}

def test_plano_respaldado_no_se_absorbe_en_un_campo_curvo_vecino():
 mesh,labels,surfaces=source();left=np.flatnonzero(labels==0);right=np.flatnonzero(labels==1);plane=surfaces[0]
 result,out=proponer(mesh,labels,surfaces)
 assert np.all(result[left]==0) and out[0] is plane
 assert all(not isinstance(out[int(r)],Geom_Plane) for r in np.unique(result[right]))

def test_una_etiqueta_plana_sin_respaldo_geometrico_sigue_pudiendo_corregirse():
 mesh,labels,surfaces=source(True);result,out=proponer(mesh,labels,surfaces)
 assert all(not isinstance(out[int(r)],Geom_Plane) for r in np.unique(result))
