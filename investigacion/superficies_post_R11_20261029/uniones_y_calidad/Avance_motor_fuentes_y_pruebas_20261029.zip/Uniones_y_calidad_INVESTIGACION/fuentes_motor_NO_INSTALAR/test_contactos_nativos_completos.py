from pathlib import Path
import sys,numpy as np,pytest,trimesh
sys.path.insert(0,str(Path(__file__).parent/'motor_superficies'))
from OCP.Geom import Geom_Plane,Geom_CylindricalSurface
from OCP.gp import gp_Pnt,gp_Dir,gp_Pln,gp_Ax3
from planos_medidos import conciliar
from hipotesis_local import soporte_libre_exacto

def test_cilindro_y_tapas_se_concilian_sin_exigir_extrusion():
 mesh=trimesh.creation.cylinder(radius=1.,height=2.,sections=48)
 labels=np.where(mesh.face_normals[:,2]>.5,0,np.where(mesh.face_normals[:,2]<-.5,1,2))
 cylinder=Geom_CylindricalSurface(gp_Ax3(gp_Pnt(0,0,0),gp_Dir(0,0,1)),1.)
 surfaces={0:Geom_Plane(gp_Pln(gp_Pnt(0,0,1.0000003),gp_Dir(0,0,1))),1:Geom_Plane(gp_Pln(gp_Pnt(0,0,-.9999997),gp_Dir(0,0,1))),2:cylinder}
 out=conciliar(mesh,labels,surfaces)
 canonical=mesh.esquinas_canonicas_medidas
 assert len(canonical)==96
 for v,p in canonical.items():
  assert abs(np.linalg.norm(p[:2])-1.)<1e-9
  cap=0 if mesh.vertices[v,2]>0 else 1
  n=np.array(out[cap].Axis().Direction().Coord());origin=np.array(out[cap].Location().Coord())
  assert abs((p-origin)@n)<1e-9 and np.linalg.norm(p-mesh.vertices[v])<=.003
 assert out[2] is cylinder and cylinder.Radius()==1.

def test_retirar_plano_cambia_representacion_conservando_soporte():
 plane=Geom_Plane(gp_Pln(gp_Pnt(12,-4,7),gp_Dir(.3,.4,.5)))
 uv=np.array([(u,v) for u in (-2.,0,3.) for v in (-1.,1.,4.)]);points=np.array([plane.Value(*q).Coord() for q in uv]);free=soporte_libre_exacto(plane,points)
 for q in uv:assert free.Value(*q).Distance(plane.Value(*q))<1e-10

def test_cilindro_confirmado_no_se_retira_como_parche_libre():
 cylinder=Geom_CylindricalSurface(gp_Ax3(gp_Pnt(0,0,0),gp_Dir(0,0,1)),1.)
 with pytest.raises(ValueError,match='nunca cilindros'):soporte_libre_exacto(cylinder,np.array([[1,0,0],[0,1,0],[0,1,1]]))
