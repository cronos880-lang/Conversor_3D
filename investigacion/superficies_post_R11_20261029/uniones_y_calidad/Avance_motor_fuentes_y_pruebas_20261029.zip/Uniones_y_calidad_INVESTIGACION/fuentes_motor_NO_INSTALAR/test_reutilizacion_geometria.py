from pathlib import Path
import sys,numpy as np,trimesh
sys.path.insert(0,str(Path(__file__).parent/'motor_superficies'))
from OCP.Geom import Geom_Plane
from OCP.gp import gp_Pnt,gp_Dir,gp_Pln
from geometria_preparada import certificar,valida

def data():
 mesh=trimesh.creation.box();labels=np.r_[np.zeros(6,int),np.ones(6,int)];native=Geom_Plane(gp_Pln(gp_Pnt(0,0,0),gp_Dir(0,0,1)));free=native.Copy();surfaces={0:free,1:native};return mesh,labels,surfaces

def test_subdividir_region_libre_preserva_certificado_de_primitivas():
 mesh,labels,surfaces=data();certificate=certificar(mesh,labels,surfaces,{1});assert valida(mesh,labels,surfaces,certificate)
 labels[:3]=2;surfaces[2]=surfaces[0];assert valida(mesh,labels,surfaces,certificate)

def test_cambiar_vertices_o_triangular_malla_invalida_geometria_reutilizada():
 mesh,labels,surfaces=data();certificate=certificar(mesh,labels,surfaces,{1});mesh.vertices[0,0]+=.00001;assert not valida(mesh,labels,surfaces,certificate)
 mesh,labels,surfaces=data();certificate=certificar(mesh,labels,surfaces,{1});mesh.faces[0]=mesh.faces[0][::-1];assert not valida(mesh,labels,surfaces,certificate)

def test_cambiar_soporte_o_pertenencia_nativa_invalida_certificado():
 mesh,labels,surfaces=data();certificate=certificar(mesh,labels,surfaces,{1});surfaces[1]=surfaces[1].Copy();assert not valida(mesh,labels,surfaces,certificate)
 mesh,labels,surfaces=data();certificate=certificar(mesh,labels,surfaces,{1});labels[6]=0;assert not valida(mesh,labels,surfaces,certificate)
