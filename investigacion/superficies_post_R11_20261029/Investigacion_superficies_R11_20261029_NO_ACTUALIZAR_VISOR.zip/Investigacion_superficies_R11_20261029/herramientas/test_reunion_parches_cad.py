from pathlib import Path
import cadquery as cq,pytest
from OCP.BRepBuilderAPI import BRepBuilderAPI_Sewing,BRepBuilderAPI_MakeSolid,BRepBuilderAPI_NurbsConvert
from OCP.BRepLib import BRepLib
from OCP.BRepCheck import BRepCheck_Analyzer
from reunir_parches_cad import proponer
MODULE=Path(__file__).resolve().parents[1]/'fuentes_investigacion_M34/motor_superficies'

def tiled_box():
    box=cq.Solid.makeBox(2,2,2);sewing=BRepBuilderAPI_Sewing(1e-7)
    for f in box.Faces():
        if f.Center().z<1.999:sewing.Add(f.wrapped)
    for left,right in [(0,1),(1,2)]:
        wire=cq.Wire.makePolygon([cq.Vector(left,0,2),cq.Vector(right,0,2),cq.Vector(right,2,2),cq.Vector(left,2,2)],close=True)
        face=cq.Face.makeFromWires(wire)
        sewing.Add(BRepBuilderAPI_NurbsConvert(face.wrapped,True).Shape())
    sewing.Perform();shell=cq.Shape.cast(sewing.SewedShape()).Shells()[0];solid=BRepBuilderAPI_MakeSolid(shell.wrapped).Solid();BRepLib.OrientClosedSolid_s(solid)
    checker=BRepCheck_Analyzer(solid,True);checker.SetExactMethod(True);assert checker.IsValid()
    return cq.Solid(solid)

def test_reunion_preserva_cierre_volumen_y_aristas_exteriores():
    before=tiled_box();assert len(before.Faces())==7
    after,proof=proponer(before,MODULE)
    assert len(after.Faces())==6 and len(after.Solids())==1
    assert abs(after.Volume()-before.Volume())<1e-10
    assert abs(after.Area()-before.Area())<1e-10
    assert after.isValid() and sum(p['ok'] for p in proof)==1
    assert max(p['max_pcurva_mm'] for p in proof if p['ok'])<5e-8

def test_no_redondea_esquinas_de_caja_ni_cambia_primitivas_compactas():
    box=cq.Solid.makeBox(2,2,2)
    with pytest.raises(ValueError,match='Ninguna'):proponer(box,MODULE)
    assert len(box.Faces())==6 and box.isValid() and abs(box.Volume()-8)<1e-10


def test_cota_bidireccional_detecta_extension_fuera_del_soporte_finito():
    from reunir_parches_cad import comparar_soportes
    def rectangle(lo,hi):
        return cq.Face.makeFromWires(cq.Wire.makePolygon([cq.Vector(lo,lo,0),cq.Vector(hi,lo,0),cq.Vector(hi,hi,0),cq.Vector(lo,hi,0)],close=True))
    original=rectangle(0,1);extendida=rectangle(-1,2)
    # Ambas superficies infinitas son el mismo plano; el recorte real sí cambia.
    with pytest.raises(ValueError,match='soporte previo acotado'):comparar_soportes([original],extendida,MODULE)
