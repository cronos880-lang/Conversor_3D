from pathlib import Path
import subprocess,sys,os,json,time,hashlib,argparse,psutil
root=Path(__file__).resolve().parents[1];parser=argparse.ArgumentParser();parser.add_argument('--salida',type=Path,required=True);args=parser.parse_args();out=args.salida.resolve()
if out.exists():raise SystemExit('La salida debe ser una carpeta nueva')
out.mkdir(parents=True);source=root/'casos/bancada/original.stl';base=root/'casos/bancada/Bancada_R11_239caras.step';step=out/'candidato_NO_APROBADO.step'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before=[sha(source),sha(base)]
env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'}
commands=[['reunir_parches_cad.py',str(base),str(step),str(out/'propuesta.json'),str(root/'fuentes_investigacion_M34/motor_superficies'),'1'],['validar_reunion_cad.py',str(source),str(base),str(step),str(out/'validacion.json')]]
for index,command in enumerate(commands):
 start=time.monotonic();reason=None
 with (out/('etapa_'+str(index)+'.log')).open('w') as stream:
  process=subprocess.Popen([sys.executable,str(root/'herramientas'/command[0]),*command[1:]],env=env,stdout=stream,stderr=subprocess.STDOUT)
  while process.poll() is None:
   try:
    tree=[psutil.Process(process.pid),*psutil.Process(process.pid).children(recursive=True)];ram=0
    for p in tree:
     try:ram+=p.memory_info().rss
     except psutil.NoSuchProcess:pass
    if time.monotonic()-start>600 or ram>3000*1024**2:
     reason='Límite de tiempo o memoria'
     for p in reversed(tree):
      try:p.kill()
      except psutil.NoSuchProcess:pass
     break
   except psutil.NoSuchProcess:pass
   time.sleep(.2)
  process.wait()
 assert before==[sha(source),sha(base)],'Se modificó una entrada'
 report=out/('propuesta.json' if index==0 else 'validacion.json')
 if reason or process.returncode or not report.exists() or not json.loads(report.read_text()).get('ok'):
  raise SystemExit(reason or 'Propuesta rechazada; revisar los informes. No sustituir resultados anteriores.')
step.rename(out/'Bancada_ESTUDIO_VALIDADO.step');print('Estudio validado; no es una versión del Visor:',out)
