from pathlib import Path
import sys,os,json,hashlib,time,traceback
import numpy as np
R=Path(__file__).resolve().parents[1];M=R/'fuentes_investigacion_M34';sys.path[:0]=[str(M),str(M/'motor_superficies')]
source,base,candidate,report=map(Path,sys.argv[1:]);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before=[sha(p) for p in (source,base,candidate)];record=dict(ok=False);start=time.monotonic()
try:
 from preprocesador_stl import cargar_exacto
 from meshfit_detect import detect
 from reconstruccion_curvas import cilindros_respaldados,validar_cilindros_y_frontera,inventario
 from OCP.BRepAdaptor import BRepAdaptor_Surface
 from OCP.GeomAbs import GeomAbs_Cylinder
 import cadquery as cq
 original=cargar_exacto(source)
 result,working=detect(str(source),angle_tol_deg=32.,rms_tol_rel=.01,flat_tol_deg=8.,scan_mode=False,mesh_input=original.copy())
 required=cilindros_respaldados(result,working)
 shape,cylinders,quality,topology,boundary=validar_cilindros_y_frontera(source,candidate,original,required)
 def cylinder_inventory(shape):
  rows=[]
  for f in shape.Faces():
   a=BRepAdaptor_Surface(f.wrapped)
   if a.GetType()!=GeomAbs_Cylinder:continue
   c=a.Cylinder();axis=np.array(c.Axis().Direction().Coord());p=np.array(c.Location().Coord());center=p-axis*(p@axis)
   if tuple(axis)<tuple(-axis):axis=-axis
   rows.append([c.Radius(),*center,*axis,f.Area()])
  return sorted(rows)
 old=cq.importers.importStep(str(base)).val();a,b=np.asarray(cylinder_inventory(old)),np.asarray(cylinder_inventory(shape))
 if a.shape!=b.shape or not np.allclose(a,b,rtol=0,atol=1e-8):raise ValueError('Cambió el inventario completo de cilindros')
 if before!=[sha(p) for p in (source,base,candidate)]:raise ValueError('Cambió un archivo durante la validación')
 record.update(ok=True,original_sha256=before[0],base_sha256=before[1],step_sha256=before[2],antes=inventario(old),despues=inventario(shape),cilindros_completos_inalterados=len(a),cilindros_respaldados=cylinders,calidad=quality,topologia_material=topology,mallado_fino=boundary)
except Exception as exc:record['error']=str(exc);traceback.print_exc()
record['segundos']=time.monotonic()-start;report.write_text(json.dumps(record,indent=2,ensure_ascii=False));print(record,flush=True)
