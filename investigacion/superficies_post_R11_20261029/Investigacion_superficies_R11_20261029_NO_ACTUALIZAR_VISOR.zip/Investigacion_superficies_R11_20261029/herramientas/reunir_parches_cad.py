"""Experimento: reunir parches CAD suaves preservando todas las curvas frontera.
No integrado en el programa. Cualquier propuesta requiere la validación externa.
"""
from pathlib import Path
import collections,json,sys,time
import numpy as np,cadquery as cq
from OCP.BRep import BRep_Tool,BRep_Builder
from OCP.Geom import Geom_BSplineSurface,Geom_Plane,Geom_TrimmedCurve
from OCP.GeomConvert import GeomConvert
from OCP.BRepTools import BRepTools_WireExplorer
from OCP.GeomFill import GeomFill_BSplineCurves,GeomFill_StretchStyle
from OCP.TopoDS import TopoDS_Face,TopoDS_Shell
from OCP.TopAbs import TopAbs_REVERSED
from OCP.BRepBuilderAPI import BRepBuilderAPI_Sewing,BRepBuilderAPI_MakeSolid
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.BRepLib import BRepLib
from OCP.ShapeFix import ShapeFix_Face


def comparar_soportes(anteriores,nueva,module_dir):
 sys.path[:0]=[str(module_dir.parent),str(module_dir)]
 from reparador_exacto_aislado import medidas_superficie
 import trimesh
 def mesh_of(items):
  vv=[];ff=[]
  for item in items:
   v,f=item.tessellate(.00025,.04);offset=len(vv);vv.extend(x.toTuple() for x in v);ff.extend(tuple(int(i)+offset for i in t) for t in f)
  return trimesh.Trimesh(np.asarray(vv),np.asarray(ff),process=False)
 comparison=medidas_superficie(mesh_of(anteriores),mesh_of([nueva]))
 if comparison['max_mm']>.003:raise ValueError('La superficie nueva abandona el soporte previo acotado: '+str(comparison['max_mm']))
 return comparison


def proponer(shape,module_dir,angle_degrees=1.):
 sys.path[:0]=[str(module_dir.parent),str(module_dir)];from frontera_compuesta import cuatro_lados
 from pcurvas_compartidas import crear_pcurva,_error,_iso_comun
 faces=shape.Faces();edge_faces=collections.defaultdict(list);edges={}
 for i,f in enumerate(faces):
  for e in f.Edges():edge_faces[e.hashCode()].append(i);edges[e.hashCode()]=e
 free={i for i,f in enumerate(faces) if isinstance(BRep_Tool.Surface_s(f.wrapped),(Geom_BSplineSurface,Geom_Plane))};adj=collections.defaultdict(set)
 for key,pair in edge_faces.items():
  if len(pair)!=2 or not all(i in free for i in pair):continue
  a,b=pair;e=edges[key];both_planes=all(isinstance(BRep_Tool.Surface_s(faces[i].wrapped),Geom_Plane) for i in pair)
  try:
   worst=max(1-abs(faces[a].normalAt(e.positionAt(t)).dot(faces[b].normalAt(e.positionAt(t)))) for t in (.2,.5,.8))
   if worst<(1e-12 if both_planes else 1-np.cos(np.radians(angle_degrees))):adj[a].add(b);adj[b].add(a)
  except Exception:pass
 groups=[]
 while free:
  stack=[free.pop()];part=[]
  while stack:
   i=stack.pop();part.append(i)
   for j in adj[i]&free:free.remove(j);stack.append(j)
  if len(part)>1 and any(isinstance(BRep_Tool.Surface_s(faces[i].wrapped),Geom_BSplineSurface) for i in part):groups.append(part)
 removed=set();added=[];records=[]
 for part in groups:
  info=dict(caras=part,ok=False)
  try:
   border=[e for i in part for e in faces[i].Edges() if sum(j in part for j in edge_faces[e.hashCode()])==1]
   if not 3<=len(border)<=64:raise ValueError('Presupuesto de frontera')
   wires=cq.Wire.combine(border)
   if len(wires)!=1:raise ValueError('Se conservan los dominios con varios contornos')
   wire=wires[0];explorer=BRepTools_WireExplorer(wire.wrapped);ordered=[];physical=[]
   while explorer.More():
    e=explorer.Current();c=BRep_Tool.Curve_s(e,0.,0.);lo,hi=BRep_Tool.Range_s(e);trim=Geom_TrimmedCurve(c,lo,hi)
    if e.Orientation()==TopAbs_REVERSED:trim.Reverse()
    ordered.append((trim,trim.FirstParameter(),trim.LastParameter()));physical.append((e,c,lo,hi));explorer.Next()
   curves=([GeomConvert.CurveToBSplineCurve_s(Geom_TrimmedCurve(c,a,b)) for c,a,b in ordered] if len(ordered) in (3,4) else cuatro_lados(ordered))
   if curves is None:raise ValueError('No hay cuatro lados compuestos')
   surface=GeomFill_BSplineCurves(*curves,GeomFill_StretchStyle).Surface()
   if not all(_iso_comun(c,a,b,surface) is not None for e,c,a,b in physical):raise ValueError('La superficie no conserva su frontera')
   from OCP.GeomAPI import GeomAPI_ProjectPointOnSurf
   from OCP.gp import gp_Pnt
   points=[]
   for i in part:
    vertices,triangles=faces[i].tessellate(.0005,.05)
    vertices=np.asarray([v.toTuple() for v in vertices]);points.extend(vertices);points.extend(vertices[np.asarray(triangles)].mean(axis=1))
   # Sólo propuesta: después se compara contra el STL original y todos los mallados.
   maximum=max(GeomAPI_ProjectPointOnSurf(gp_Pnt(*p),surface).LowerDistance() for p in points)
   if maximum>.003:raise ValueError('El interior abandona el soporte previo: '+str(maximum))
   face=TopoDS_Face();builder=BRep_Builder();builder.MakeFace(face,surface,1e-7);builder.Add(face,wire.wrapped)
   errors=[]
   for e,c,lo,hi in physical:
    uv,uv_info=crear_pcurva(c,lo,hi,surface);err=_error(c,uv,surface,lo,hi);errors.append(err)
    if err>5e-8:raise ValueError('Desacuerdo de pcurva: '+str(err))
    builder.UpdateEdge(e,uv,face,BRep_Tool.Tolerance_s(e))
   fix=ShapeFix_Face(face);fix.SetPrecision(1e-7);fix.SetMaxTolerance(1e-7);fix.FixOrientation();face=fix.Face()
   built=cq.Face(face)
   if built.normalAt(faces[part[0]].Center()).dot(faces[part[0]].normalAt(faces[part[0]].Center()))<0:face.Reverse();built=cq.Face(face)
   checker=BRepCheck_Analyzer(face,True);checker.SetExactMethod(True)
   if not checker.IsValid():raise ValueError('Cara exacta inválida')
   comparison=comparar_soportes([faces[i] for i in part],built,module_dir)
   removed.update(part);added.append(built);info.update(ok=True,max_soporte_previo_mm=maximum,max_soporte_bidireccional_mm=comparison['max_mm'],max_pcurva_mm=max(errors),frontera=len(border))
  except Exception as exc:info['error']=str(exc)
  records.append(info);print(info,flush=True)
 if not removed:raise ValueError('Ninguna reunión válida')
 sewing=BRepBuilderAPI_Sewing(1e-7,True,True,True,False)
 for i,f in enumerate(faces):
  if i not in removed:sewing.Add(f.wrapped)
 for f in added:sewing.Add(f.wrapped)
 sewing.Perform();sewed=cq.Shape.cast(sewing.SewedShape());shells=sewed.Shells()
 if len(shells)!=1:raise ValueError('La propuesta no forma un solo shell')
 solid=BRepBuilderAPI_MakeSolid(shells[0].wrapped).Solid();BRepLib.OrientClosedSolid_s(solid)
 check=BRepCheck_Analyzer(solid,True);check.SetExactMethod(True)
 if not check.IsValid():raise ValueError('El sólido reunido no pasa CAD exacto')
 return cq.Solid(solid),records

if __name__=='__main__':
 source,destination,report,module_dir=map(Path,sys.argv[1:5]);angle=float(sys.argv[5]) if len(sys.argv)>5 else 1.;start=time.monotonic();record=dict(ok=False)
 try:
  result,records=proponer(cq.importers.importStep(str(source)).val(),module_dir,angle);cq.exporters.export(result,str(destination));record.update(ok=True,caras=len(result.Faces()),grupos=records)
 except Exception as exc:
  import traceback;traceback.print_exc();record['error']=str(exc);destination.unlink(missing_ok=True)
 record['segundos']=time.monotonic()-start;report.write_text(json.dumps(record,indent=2));print(record,flush=True)
