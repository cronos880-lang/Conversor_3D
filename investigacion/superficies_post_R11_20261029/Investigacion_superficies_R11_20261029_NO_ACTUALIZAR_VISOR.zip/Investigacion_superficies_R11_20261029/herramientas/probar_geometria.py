from pathlib import Path
import subprocess,sys,os
root=Path(__file__).resolve().parents[1];motor=root/'fuentes_investigacion_M34'
env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'}
for cwd,tests in [(motor,['test_perfiles_medidos.py','test_pcurvas_compartidas.py','test_encuentros_analiticos.py','test_retirada_hipotesis.py','test_proyeccion_esquina_real.py']),(root/'herramientas',['test_reunion_parches_cad.py'])]:
 result=subprocess.run([sys.executable,'-m','pytest','-q',*tests],cwd=cwd,env=env)
 if result.returncode:raise SystemExit(result.returncode)
