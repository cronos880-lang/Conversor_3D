# Investigación sobre superficies posterior a R11 — entrega parcial

**No es R12 ni una actualización del Visor. Mantén tu programa R11.**

Incluye fuentes de investigación, pruebas y un STEP de bancada para comparar. Las hipótesis generales del motor M34 aún fallan en piezas reales y **no deben instalarse sobre el programa**. Los lanzadores heredados dentro de las fuentes no convierten este paquete en una entrega aprobada de Windows.

Consulta `INFORME_RESULTADOS.md` para distinguir resultados aprobados, rechazos y pruebas pendientes. Abre `STEP_VALIDADO/Bancada_ESTUDIO_206caras.step` en tu CAD para comparar con `casos/bancada/Bancada_R11_239caras.step`. Persisten parches; no se declara resuelto todo el interior.

## Reproducción para desarrollo

Probado en Linux con Python 3.12 y las dependencias de `fuentes_investigacion_M34/requirements_pruebas.txt`. No se ha probado este experimento en Windows ni Onshape. Conserva el reparador y sus licencias incluidos; las dependencias CGAL/gpytoolbox/libigl se instalan según los requisitos fijados de R11. No se incluyen binarios Linux para Windows.

```bash
python -m pip install -r fuentes_investigacion_M34/requirements_pruebas.txt
python herramientas/probar_geometria.py
python herramientas/reproducir_bancada.py --salida nueva_prueba_bancada
```

El primer comando de pruebas cubre 54 casos del motor y 3 de reunión CAD. La batería completa de 284 necesita además los materiales originales de la auditoría R11 y las variables de rutas descritas en el informe; esos materiales completos no se duplican aquí. El reproducer sólo acepta una carpeta nueva, limita cada etapa a 600 s y 3000 MiB, verifica las entradas y sólo marca el STEP como validado tras superar todo el control.

El control ondulado es una pieza sintética; sus 132 caras iniciales son una referencia facetada artificial, no la salida de R11. Su mejora no demuestra por sí sola resultados en piezas reales.
