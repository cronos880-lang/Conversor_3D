"""La retirada de una hipótesis conserva el soporte y no lo vuelve a reconocer."""
from pathlib import Path
import sys,numpy as np,trimesh
sys.path.insert(0,str(Path(__file__).parent/'motor_superficies'))
from OCP.Geom import Geom_SurfaceOfLinearExtrusion,Geom_BSplineSurface
from OCP.gp import gp_Dir
from test_perfiles_medidos import profile
from hipotesis_local import soporte_libre_exacto

def test_representacion_libre_conserva_soporte_en_dominio_completo():
    surface=Geom_SurfaceOfLinearExtrusion(profile(),gp_Dir(0,1,0))
    points=np.array([surface.Value(float(u),float(v)).Coord() for u in np.linspace(.1,1.9,11) for v in [-1.,2.]])
    patch=soporte_libre_exacto(surface,points)
    assert isinstance(patch,Geom_BSplineSurface)
    for u in np.linspace(.1,1.9,101):
        for v in np.linspace(-1,2,7):assert patch.Value(float(u),float(v)).Distance(surface.Value(float(u),float(v)))<1e-10

def test_no_volver_a_promover_soporte_retirado(monkeypatch):
    import campos_fuente
    surface=Geom_SurfaceOfLinearExtrusion(profile(),gp_Dir(0,1,0))
    points=np.array([surface.Value(float(u),float(v)).Coord() for u in np.linspace(.1,1.9,11) for v in [-1.,2.]])
    patch=soporte_libre_exacto(surface,points)
    mesh=trimesh.creation.box();labels=np.zeros(len(mesh.faces),dtype=int)
    mesh.hipotesis_no_primarias={id(patch)}
    def fail(*args,**kwargs):raise AssertionError('Un soporte retirado no admite otra hipótesis')
    monkeypatch.setattr(campos_fuente,'altura_medida',fail)
    result,surfaces=campos_fuente.proponer(mesh,labels,{0:patch})
    assert np.array_equal(result,labels) and surfaces[0] is patch
