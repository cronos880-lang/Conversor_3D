"""Regresión del mínimo perdido en un perfil real de la bancada."""
from pathlib import Path
import sys,json,numpy as np,pytest
sys.path.insert(0,str(Path(__file__).parent/'motor_superficies'))
from OCP.Geom import Geom_BSplineCurve,Geom_SurfaceOfLinearExtrusion
from OCP.TColgp import TColgp_Array1OfPnt
from OCP.TColStd import TColStd_Array1OfReal,TColStd_Array1OfInteger
from OCP.gp import gp_Pnt,gp_Dir
from proyeccion_barridos import uv_exacta
from scipy.optimize import minimize_scalar

@pytest.mark.parametrize('region',[75,156])
def test_minimo_global_en_esquina_real(region):
    spec=json.loads((Path(__file__).parent/'fixtures_investigacion/esquina_bancada_proyeccion.json').read_text())
    point=np.array(spec['punto']);s=next(s for s in spec['superficies'] if s['region']==region)
    P=TColgp_Array1OfPnt(1,len(s['polos']));K=TColStd_Array1OfReal(1,len(s['nudos']));D=TColStd_Array1OfInteger(1,len(s['nudos']))
    for j,p in enumerate(s['polos'],1):P.SetValue(j,gp_Pnt(*p))
    for j,(k,m) in enumerate(zip(s['nudos'],s['multiplicidades']),1):K.SetValue(j,k);D.SetValue(j,m)
    c=Geom_BSplineCurve(P,K,D,s['grado'],s['periodica']);axis=np.array(s['eje']);surface=Geom_SurfaceOfLinearExtrusion(c,gp_Dir(*axis))
    origin=np.array(c.Value(c.FirstParameter()).Coord());target=point-axis*((point-origin)@axis);q=gp_Pnt(*target)
    uv=uv_exacta(surface,point[None,:])[0];measured=surface.Value(*map(float,uv)).Distance(gp_Pnt(*point))
    # Referencia independiente: rejilla densa seguida de refinamiento escalar.
    grid=np.unique(np.r_[np.linspace(c.FirstParameter(),c.LastParameter(),20001),s['nudos']])
    d=np.array([c.Value(float(t)).SquareDistance(q) for t in grid]);j=int(d.argmin())
    ref=minimize_scalar(lambda t:c.Value(float(t)).SquareDistance(q),bounds=(grid[max(0,j-1)],grid[min(len(grid)-1,j+1)]),method='bounded',options={'xatol':1e-14})
    assert abs(measured-np.sqrt(ref.fun))<1e-10
    assert measured<(2e-5 if region==75 else 3e-6)
