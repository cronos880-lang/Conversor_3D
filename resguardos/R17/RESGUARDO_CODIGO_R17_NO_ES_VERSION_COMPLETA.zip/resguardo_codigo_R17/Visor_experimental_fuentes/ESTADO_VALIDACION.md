# R17 experimental · reconstrucción desde perfiles y detalles del STL

En validación: nueva ruta de revolución con rebajes medidos. La guía ranurada conserva R16; sus propuestas nuevas han sido rechazadas. Véase el informe completo de la entrega para resultados y límites.
